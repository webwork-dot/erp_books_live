<?php

echo json_encode(array('status' => 404, 'message' => 'Page Not Found'));
?>