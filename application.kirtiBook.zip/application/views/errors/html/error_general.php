<?php

echo json_encode(array('status' => 503, 'message' => 'Service Unavailable'));
?>