<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product_master extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
        $this->load->model('product_master_model');
    }
    
    
    // Books -> School Text Book Starts
    public function add_product_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']        = $params['user_id'];
                $data['ip_address']     = $this->input->ip_address();
                $data['publisher_id']   = $params['publisher'];
                $data['board_id']       = implode(',', $params['board']);
                $data['grade_id']       = (!empty($params['grades']) ? implode(',', $params['grades']) : '');
                $data['subject_id']     = $params['subject'];
                $data['title']          = $params['title'];
                $data['isbn']           = trim($params['isbn']);
                $data['product_origin'] = $params['product_origin'];
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                
                $data['age_grade'] = $params['age_grade'];
                $data['from_age']  = ($params['from_age'] == '' ? '0' : $params['from_age']);
                $data['to_age']    = ($params['to_age'] == '' ? '0' : $params['to_age']);
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['category'];
                
                $pdata['user_id']        = $params['user_id'];
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                $pdata['created_at']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
               
                if($params['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['user_id'];
                }
                $pdata['last_modified']    =  date('Y-m-d H:i:s');
                
                if ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['publisher_id'] == '' && $data['board_id'] == '' && $data['grade_id'] == '' && $data['subject_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->add_product_post($data,$pdata,$category,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    
    public function update_product_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params               = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']      = $params['user_id'];
                $data['publisher_id'] = $params['publisher'];
                $data['board_id']     = implode(',', $params['board']);
                $data['grade_id']     = (!empty($params['grades']) ? implode(',', $params['grades']) : '');
                $data['subject_id']   = $params['subject'];
                $data['title']        = $params['title'];
                $data['isbn']         = trim($params['isbn']);
                $data['product_origin'] = $params['product_origin'];
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                
                $data['age_grade'] = $params['age_grade'];
                $data['from_age']  = ($params['from_age'] == '' ? '0' : $params['from_age']);
                $data['to_age']    = ($params['to_age'] == '' ? '0' : $params['to_age']);
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                
                $data['last_modified'] = date('Y-m-d H:i:s');
                $data["slug"]          = str_slug($params["title"]);
                $category              = $params['category'];
                $id                    = $params['id'];
                
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                
                
                if (array_key_exists("staff_id",$params)){
                    $pdata['staff_id'] = $params['staff_id'];
                }
                else{
                    $pdata['staff_id'] = '0';
                }
                
                if($params['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['staff_id'];
                }
                
                $pdata['last_modified']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                
                if ($this->product_master_model->check_update_product_isbn($data['isbn'], $data['user_id'], $id, 'on_update')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['publisher_id'] == '' && $data['board_id'] == '' && $data['grade_id'] == '' && $data['subject_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->update_product_post($data,$pdata,$category,$id,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    // Books -> School Text Book Ends    
    
    
    
    public function get_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $category = $params['category'];
                $per_page = $params['per_page'];
                $offset   = $params['offset'];
                
                if ($user_id != '' && $category != '') {
                    $response = $this->product_model->get_product_list($user_id, $category, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    
    
    
    public function get_product_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_master_model->get_product_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    
    
    public function set_product_as_sold()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->set_product_as_sold($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    
    
    
    // Books -> Others Book Starts
    public function add_product_other_book_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params               = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']      = $params['user_id'];
                $data['publisher_id'] = $params['publisher'];
                $data['board_id']     = implode(',', $params['board']);
                $data['grade_id']     = (!empty($params['grades']) ? implode(',', $params['grades']) : '');
                $data['subject_id']   = $params['subject'];
                $data['title']        = $params['title'];
                $data['isbn']         = trim($params['isbn']);
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                
                $data['age_grade']      = $params['age_grade'];
                $data['from_age']       = ($params['from_age'] == '' ? '0' : $params['from_age']);
                $data['to_age']         = ($params['to_age'] == '' ? '0' : $params['to_age']);
                $data['product_origin'] = $params['product_origin'];
                $data['highlights']     = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['category'];
                
                
                if (array_key_exists("staff_id",$params)){
                    $pdata['staff_id'] = $params['staff_id'];
                }
                else{
                    $pdata['staff_id'] = '0';
                }
                
                $pdata['user_id']       = $params['user_id'];
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                
                if($pdata['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['user_id'];
                }
                $pdata['last_modified']    =  date('Y-m-d H:i:s');	
                $pdata['created_at']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                if ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['publisher_id'] == '' && $data['board_id'] == '' && $data['grade_id'] == '' && $data['subject_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->add_product_other_book_post($data,$pdata,$category,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    
    public function update_product_other_book_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params               = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']      = $params['user_id'];
                $data['publisher_id'] = $params['publisher'];
                $data['board_id']     = implode(',', $params['board']);
                $data['grade_id']     = (!empty($params['grades']) ? implode(',', $params['grades']) : '');
                $data['subject_id']   = $params['subject'];
                $data['title']        = $params['title'];
                $data['isbn']         = trim($params['isbn']);
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['age_grade']      = $params['age_grade'];
                $data['from_age']       = ($params['from_age'] == '' ? '0' : $params['from_age']);
                $data['to_age']         = ($params['to_age'] == '' ? '0' : $params['to_age']);
                $data['product_origin'] = $params['product_origin'];
                $data['highlights']     = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                
                $data['last_modified'] = date('Y-m-d H:i:s');
                $data["slug"]          = str_slug($params["title"]);
                $category              = $params['category'];
                $id                    = $params['id'];
                
                $pdata['user_id']        = $params['user_id'];
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                
                if (array_key_exists("staff_id",$params)){
                    $pdata['staff_id'] = $params['staff_id'];
                }
                else{
                    $pdata['staff_id'] = '0';
                }
                if($pdata['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['user_id'];
                }
                $pdata['last_modified']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                if ($this->product_master_model->check_update_product_isbn($data['isbn'], $data['user_id'], $id, 'on_update')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['publisher_id'] == '' && $data['board_id'] == '' && $data['grade_id'] == '' && $data['subject_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->update_product_other_book_post($data,$pdata,$category,$id,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    // Books -> Others Book Ends    
    
    
    
    // Books ->  Note Starts
    public function add_product_note_book_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']        = $params['user_id'];
                $data['title']          = $params['title'];
                $data['brand_id']       = $params['brand'];
                $data['size']           = $params['size'];
                $data['binding_type']   = $params['binding_type'];
                $data['product_origin'] = $params['product_origin'];
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                $data['isbn']             = $params['isbn'];
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['category'];
                
                $pdata['user_id']        = $params['user_id'];
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                $pdata['created_at']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                if($params['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['user_id'];
                }
                $pdata['last_modified']    =  date('Y-m-d H:i:s');
                
                
                if ($data['title'] == '' && $data['product_description'] == '' && $data['gst'] == '' && $data['isbn'] == '' && $data['brand'] == '' && $data['size'] == '' && $data['binding_type'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } elseif ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } else {
                    $response = $this->product_master_model->add_product_note_book_post($data,$pdata,$category,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    
    public function update_product_note_book_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']        = $params['user_id'];
                $data['title']          = $params['title'];
                $data['brand_id']       = $params['brand'];
                $data['size']           = $params['size'];
                $data['binding_type']   = $params['binding_type'];
                $data['product_origin'] = $params['product_origin'];
                
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                $data['isbn']             = $params['isbn'];
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                
                $data['last_modified'] = date('Y-m-d H:i:s');
                $data["slug"]          = str_slug($params["title"]);
                $category              = $params['category'];
                $id                    = $params['id'];
                
                $pdata['user_id']        = $params['user_id'];
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                
                if (array_key_exists("staff_id",$params)){
                    $pdata['staff_id'] = $params['staff_id'];
                }
                else{
                    $pdata['staff_id'] = '0';
                }
                if($pdata['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['user_id'];
                }
                $pdata['last_modified']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                
                if ($data['title'] == '' && $data['product_description'] == '' && $data['isbn'] == '' && $data['gst'] == '' && $data['brand'] == '' && $data['size'] == '' && $data['binding_type'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } elseif ($this->product_master_model->check_update_product_isbn($data['isbn'], $data['user_id'], $id, 'on_update')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } else {
                    $response = $this->product_master_model->update_product_note_book_post($data,$pdata,$category,$id,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    // Books -> Note Book Ends    
    
    
    
    // Uniform Starts
    public function add_product_uniform_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                      = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']             = $params['user_id'];
                $data['title']               = $params['title'];
                $data['model_number']        = $params['sku'];
                $data['min_quantity']        = $params['min_quantity'];
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                $data['base_price']          = $params['base_price'];
                $data['discount_price']      = $params['price'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                
                
                $data['is_bookset']      = ($params['is_bookset'] != '' ? $params['is_bookset'] : '0');
                $data['is_individually'] = ($params['is_individually'] != '' ? $params['is_individually'] : '0');
                $data['is_exchange']     = ($params['is_exchange'] != '' ? $params['is_exchange'] : '0');
                $data['day_exchange']    = $params['day_exchange'];
                $data['highlights']      = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                ;
                
                $data['size']   = implode(',', $params['size']);
                $data['school'] = $params['school'];
                
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['category'];
                $warehouse          = $params['warehouse'];
                $quantity           = $params['quantity'];
                
                if ($this->product_model->check_product_sku($data['model_number'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product code already exist!'
                    ));
                } elseif ($params['size'] == '' && !isset($params['school']) && $data['school'] == '' && $data['title'] == '' && $data['model_number'] == '' && $data['min_quantity'] == '' && $data['product_description'] == '' && $data['base_price'] == '' && $data['discount_price'] == '' && $data['gst'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_model->add_product_uniform_post($data, $category, $warehouse, $quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    
    public function update_product_uniform_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                      = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']             = $params['user_id'];
                $data['title']               = $params['title'];
                $data['model_number']        = $params['sku'];
                $data['min_quantity']        = $params['min_quantity'];
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                $data['base_price']          = $params['base_price'];
                $data['discount_price']      = $params['price'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                
                $data['is_bookset']      = ($params['is_bookset'] != '' ? $params['is_bookset'] : '0');
                $data['is_individually'] = ($params['is_individually'] != '' ? $params['is_individually'] : '0');
                $data['is_exchange']     = ($params['is_exchange'] != '' ? $params['is_exchange'] : '0');
                $data['day_exchange']    = $params['day_exchange'];
                $data['highlights']      = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                ;
                
                $data['size']   = implode(',', $params['size']);
                $data['school'] = $params['school'];
                
                $data['last_modified'] = date('Y-m-d H:i:s');
                $data["slug"]          = str_slug($params["title"]);
                $category              = $params['category'];
                $warehouse             = $params['warehouse'];
                $quantity              = $params['quantity'];
                $id                    = $params['id'];
                
                if ($this->product_model->check_product_sku($data['model_number'], $data['user_id'], $id, 'on_update')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product code already exist!'
                    ));
                } elseif ($data['size'] == '' && $data['school'] == '' && $data['title'] == '' && $data['model_number'] == '' && $data['min_quantity'] == '' && $data['product_description'] == '' && $data['base_price'] == '' && $data['discount_price'] == '' && $data['gst'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_model->update_product_uniform_post($data, $category, $warehouse, $quantity, $id);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    // Uniform Ends    
    
    
    
    
    // Books -> Stationery Starts
    
    public function get_stationery_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $category = '6';
                $per_page = $params['per_page'];
                $offset   = $params['offset'];
                
                if ($user_id != '' && $category != '') {
                    $response = $this->product_model->get_stationery_product_list($user_id, $category, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_product_stationery_post_()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params           = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']  = $params['user_id'];
                $data['brand_id'] = $params['brand'];
                $data['title']    = $params['title'];
                $data['color']    = $params['color'];
                $data['subcate']  = $params['subcate'];
                $data['isbn']     = trim($params['isbn']);
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['category'];
                
                if ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['brand_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '' && $data['color'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->add_product_stationery_post($data, $category);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    public function add_product_stationery_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params           = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']  = $params['user_id'];
                $data['brand_id'] = $params['brand'];
                $data['title']    = $params['title'];
                $data['color']    = $params['color'];
                $data['subcate']  = $params['subcate'];
                $data['isbn']     = trim($params['isbn']);
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']    = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['subcate'];
                
                if ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['brand_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '' && $data['color'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->add_product_stationery_post($data,$pdata,$category,$warehouse,$quantity);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    
    public function update_product_stationery_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params           = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']  = $params['user_id'];
                $data['brand_id'] = $params['brand'];
                $data['title']    = $params['title'];
                $data['isbn']     = trim($params['isbn']);
                $data['color']   = $params['color'];
				if(count($params['subcate'])>0){
					$subcate = $params['subcate'];
					$subcate = implode(',',$subcate);
					$data['subcate'] = $subcate;
				}
				else{
					$data['subcate'] = '';
				}
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                $data['no_of_pages']         = $params['pages'];
                $data['gst']              = $params['gst'];
                $data['hsn']              = $params['hsn'];
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                $data['last_modified'] = date('Y-m-d H:i:s');
                $data["slug"]          = str_slug($params["title"]);
                $category              = $params['category'];
                $id                    = $params['id'];
                
                $pdata['model_number']    = $params['sku'];
                $pdata['min_quantity']    = $params['min_quantity'];
                $pdata['base_price']      = $params['base_price'];
                $pdata['discount_price']    = $params['price'];
                
                $pdata['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
                $pdata['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
                $pdata['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
                $pdata['day_exchange']    = $params['day_exchange'];
                
                if (array_key_exists("staff_id",$params)){
                    $pdata['staff_id'] = $params['user_id'];
                }
                else{
                    $pdata['staff_id'] = '0';
                }
                
                if($pdata['staff_id'] == 0 ){
                    $pdata['last_user_id']    =  $params['user_id'];
                }else{
                    $pdata['last_user_id']    =  $params['user_id'];
                }
                $pdata['last_modified']    =  date('Y-m-d H:i:s');
                $warehouse  = $params['warehouse'];
                $quantity  = $params['quantity'];
                
                if ($this->product_master_model->check_update_product_isbn($data['isbn'], $data['user_id'], $id, 'on_update')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['brand_id'] == '' && $data['stationery_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '' && $data['color'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->update_product_stationery_post($data,$pdata,$category,$id,$warehouse,$quantity,$params['subcate']);
                    simple_json_output($response);
                }
            }
        }
    }
    
    // Books -> Stationery Ends
    
    
    //product images Starts    
    
    
    public function upload_images()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            
            $pid = $this->input->post('pid');
            if ($this->input->post('type')) {
                $type = $this->input->post('type');
            } else {
                $type = '';
            }
            
            
            if ($pid == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'error! while uploadding images!'
                ));
            } else {
                $response = $this->product_master_model->upload_images($pid, $type);
                simple_json_output($response);
            }
            
        }
    }
    
    public function upload_services_images()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            
            $pid = $this->input->post('pid');
            if ($this->input->post('type')) {
                $type = $this->input->post('type');
            } else {
                $type = '';
            }
            
            if ($pid == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'error! while uploadding images!'
                ));
            } else {
                $response = $this->product_master_model->upload_services_images($pid, $type);
                simple_json_output($response);
            }
            
        }
    }
    
    
    
    
    public function product_image_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_master_model->product_image_delete($id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    
    
    // product images Ends    
    
    
    
    // Books -> shoes Starts
    
    public function get_shoes_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $category = '38';
                $per_page = $params['per_page'];
                $offset   = $params['offset'];
                
                if ($user_id != '' && $category != '') {
                    $response = $this->product_model->get_shoes_product_list($user_id, $category, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    
    
    public function add_product_shoes_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params           = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']  = $params['user_id'];
                $data['brand_id'] = $params['brand'];
                $data['title']    = $params['title'];
                $data['color']    = $params['color'];
                $data['gender']   = $params['gender'];
                $data['age_type'] = $params['age_type'];
                $data['isbn']     = trim($params['isbn']);
                ;
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                ;
                
                $data['created_at'] = date('Y-m-d H:i:s');
                $data["slug"]       = str_slug($params["title"]);
                $category           = $params['category'];
                
                if ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], '', 'on_create')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['brand_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '' && $data['color'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->add_product_shoes_post($data, $category);
                    simple_json_output($response);
                }
            }
        }
    }
    
    
    
    public function update_product_shoes_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params           = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']  = $params['user_id'];
                $data['brand_id'] = $params['brand'];
                $data['title']    = $params['title'];
                $data['color']    = $params['color'];
                $data['gender']   = $params['gender'];
                $data['age_type'] = $params['age_type'];
                $data['isbn']     = trim($params['isbn']);
                ;
                
                $data['product_description'] = $params['product_description'];
                $data['lenght']              = $params['lenght'];
                $data['width']               = $params['width'];
                $data['height']              = $params['height'];
                $data['weight']              = $params['weight'];
                if ($params['pages'] == '') {
                    $data['no_of_pages'] = 0;
                } else {
                    $data['no_of_pages'] = $params['pages'];
                }
                
                
                $data['gst'] = $params['gst'];
                if ($params['hsn'] == '') {
                    $data['hsn'] = 0;
                } else {
                    $data['hsn'] = $params['hsn'];
                }
                $data['meta_title']       = $params['meta_title'];
                $data['meta_keyword']     = $params['meta_keyword'];
                $data['meta_description'] = $params['meta_description'];
                $data['product_origin']   = $params['product_origin'];
                
                $data['highlights'] = (!empty($params['highlights']) ? trim_and_return_json($params['highlights']) : '[]');
                ;
                
                $data['last_modified'] = date('Y-m-d H:i:s');
                $data["slug"]          = str_slug($params["title"]);
                $category              = $params['category'];
                $id                    = $params['id'];
                
                if ($this->product_master_model->check_product_isbn($data['isbn'], $data['user_id'], $id, 'on_update')) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Product ISBN already exist!'
                    ));
                } elseif ($data['brand_id'] == '' && $data['stationery_id'] == '' && $data['title'] == '' && $data['isbn'] == '' && $data['product_description'] == '' && $data['gst'] == '' && $data['color'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->product_master_model->update_product_shoes_post($data, $category, $id);
                    simple_json_output($response);
                }
            }
        }
    }
    
    // Books -> Stationery Ends
    
    
}