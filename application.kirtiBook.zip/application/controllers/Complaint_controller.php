<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Complaint_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('complaint_model');
    }


    public function complaint_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];

                if (array_key_exists("school",$params)){
                    $filter['school']  = $params['school'];
                }
                else{  $filter['school']  = array();  }

                if (array_key_exists("complaint_category",$params)){
                    $filter['complaint_category']  = $params['complaint_category'];
                }
                else{  $filter['complaint_category']  = array();  }

                if (array_key_exists("complaint_status",$params)){
                    $filter['ticket_status']  = $params['complaint_status'];
                }
                else{ $filter['ticket_status']  = ''; }

                if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{ $filter['keyword']  = '';  }

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                $filter['academic_year']=array();

                if ($user_id != '') {
                    $response = $this->complaint_model->complaint_list($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function complaint_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id = $params['id'];

                if ($user_id != '') {
                    $response = $this->complaint_model->complaint_details($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function complaint_reply()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id = $params['id'];
                $reply = $params['reply'];
                $action_status = $params['action_status'];

                if ($user_id != '') {
                    $response = $this->complaint_model->complaint_reply($user_id,$id,$reply,$action_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
   
    public function complaint_closed()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id = $params['id'];

                if ($user_id != '') {
                    $response = $this->complaint_model->complaint_closed($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

}
