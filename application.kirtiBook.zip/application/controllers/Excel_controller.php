<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'third_party/phpspreadsheet/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Excel_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Calcutta');
        $this->load->model('excel_model');
    }

    public function index(){
        $data = array();
    }

    public function generate_consolidate_report_by_slot()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $process_slot   = $params['process_slot'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->consolidated_report_list($user_id,$process_slot);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'There is some error while fetching data..'
                    ));
				}


            }
        }
    }

    public function export_consolidate_report_by_slot()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $process_slot   = $params['process_slot'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_list($user_id,$process_slot);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');
                $sheet->setCellValue('V1', 'Amount');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
                    $sheet->setCellValue('V'.$count, $item['amount']);
    				$count++;
				}

				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');

        $upload_path = './uploads/excel/';

				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);


            }
        }
    }







    public function check_gst_report()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];
				$data = array();

				if($start_end_date!=''){


        	    $from =  date('Y-m-d',strtotime($start_end_date['0']));
                $to =  date('Y-m-d',strtotime($start_end_date['1']));

                $date1 = new DateTime($from);
                $date2 = new DateTime($to);
                $diff = $date1->diff($date2);

			    if($diff->days<=30){

			     	$result = $this->excel_model->get_gst_report($start_end_date,$user_id);
		    	    /*	echo $this->db->last_query();
		             exit();*/
    				if(!empty($result)){
    				     json_output(200, array(
                            'status' => 200,
                            'message' => ''
                        ));
    				}
    				else{
    				     json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, No data available on selected dates!'
                        ));
    				}

				 }
				 else{
				    json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, Only 30 days data can be exported!'
                    ));

				 }


				}
				else{
				    json_output(200, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
				}


            }
        }
    }

    public function export_gst_report()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
				$user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];

				$fileName='gst_report';
				$this->load->helper('download');
				$data = array();
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Sr no');
				$sheet->setCellValue('B1', 'Customer Name');
				$sheet->setCellValue('C1', 'Order No');
				$sheet->setCellValue('D1', 'Invoice No');
				$sheet->setCellValue('E1', 'Date');
				$sheet->setCellValue('F1', 'Total Invoice Amount');
				$sheet->setCellValue('G1', 'Invoice Amount of 0% GST Products');
				$sheet->setCellValue('H1', 'GST  0%');
				$sheet->setCellValue('I1', 'CGST');
				$sheet->setCellValue('J1', 'SGST');
				$sheet->setCellValue('K1', 'Invoice Amount of 5% GST Products');
				$sheet->setCellValue('L1', 'GST  5%');
				$sheet->setCellValue('M1', 'CGST');
				$sheet->setCellValue('N1', 'SGST');
				$sheet->setCellValue('O1', 'Invoice Amount of 12% GST Products');
				$sheet->setCellValue('P1', 'GST  12%');
				$sheet->setCellValue('Q1', 'CGST');
				$sheet->setCellValue('R1', 'SGST');
				$sheet->setCellValue('S1', 'Invoice Amount of 18% GST Products');
				$sheet->setCellValue('T1', 'GST  18%');
				$sheet->setCellValue('U1', 'CGST');
				$sheet->setCellValue('V1', 'SGST');
				$sheet->setCellValue('W1', 'Invoice Amount of 28% GST Products');
				$sheet->setCellValue('X1', 'GST 28%');
				$sheet->setCellValue('Y1', 'CGST');
				$sheet->setCellValue('Z1', 'SGST');

				$count = 2;
				$orders = $this->excel_model->get_gst_report($start_end_date,$user_id);
				foreach($orders as $order){
				$sheet->setCellValue('A'.$count, $count-1);
				$sheet->setCellValue('B'.$count, $order['customer']);
				$sheet->setCellValue('C'.$count, $order['order_number']);
				$sheet->setCellValue('D'.$count, $order['invoice_no']);
				$sheet->setCellValue('E'.$count, $order['created_at']);
				$sheet->setCellValue('F'.$count, $order['invoice_amt']);
				$sheet->setCellValue('G'.$count, price_format_decimal($order['gst_0_excl']));
				$sheet->setCellValue('H'.$count, price_format_decimal($order['gst_0_amt']));
				$sheet->setCellValue('I'.$count, price_format_decimal($order['gst_0_amt']/2));
				$sheet->setCellValue('J'.$count, price_format_decimal($order['gst_0_amt']/2));

				$sheet->setCellValue('K'.$count, price_format_decimal($order['gst_5_excl']));
				$sheet->setCellValue('L'.$count, price_format_decimal($order['gst_5_amt']));
				$sheet->setCellValue('M'.$count, price_format_decimal($order['gst_5_amt']/2));
				$sheet->setCellValue('N'.$count, price_format_decimal($order['gst_5_amt']/2));

				$sheet->setCellValue('O'.$count, price_format_decimal($order['gst_12_excl']));
				$sheet->setCellValue('P'.$count, price_format_decimal($order['gst_12_amt']));
				$sheet->setCellValue('Q'.$count, price_format_decimal($order['gst_12_amt']/2));
				$sheet->setCellValue('R'.$count, price_format_decimal($order['gst_12_amt']/2));

				$sheet->setCellValue('S'.$count, price_format_decimal($order['gst_18_excl']));
				$sheet->setCellValue('T'.$count, price_format_decimal($order['gst_18_amt']));
				$sheet->setCellValue('U'.$count, price_format_decimal($order['gst_18_amt']/2));
				$sheet->setCellValue('V'.$count, price_format_decimal($order['gst_18_amt']/2));

				$sheet->setCellValue('W'.$count, price_format_decimal($order['gst_28_excl']));
				$sheet->setCellValue('X'.$count, price_format_decimal($order['gst_28_amt']));
				$sheet->setCellValue('Y'.$count, price_format_decimal($order['gst_28_amt']/2));
				$sheet->setCellValue('Z'.$count, price_format_decimal($order['gst_28_amt']/2));

				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';

				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}

    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);

            }
        }
        }




  public function generate_consolidate_by_status()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $status   = $params['status'];
                $warehouse_id   = $params['warehouse_id'];
                $courier_id   = $params['courier_id'];

               	if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->consolidated_report_by_status($warehouse_id,$courier_id,$user_id,$status,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}


            }
        }
    }

    public function export_consolidate_report_by_status()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $status   = $params['status'];
                $warehouse_id   = $params['warehouse_id'];
                $courier_id   = $params['courier_id'];

               	if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_by_status($warehouse_id,$courier_id,$user_id,$status,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

                $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';

				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }

     public function test_export_consolidate_report_by_slot()
    {

                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = '592';
                $process_slot = '5281_66011850';

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_list($user_id,$process_slot);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
    				$count++;
				}

				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);


    }



    public function export_consolidate_report_by_vendor() {

                $this->load->model('excel_advanced');
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = '23420';

				$fileName='consolidated_report_7 Radcliffe_';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_advanced->consolidated_report_by_vendor_list($user_id);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');
                $sheet->setCellValue('V1', 'Order Status');
                $sheet->setCellValue('W1', 'TDS Gst');
                $sheet->setCellValue('X1', 'TDS');
                $sheet->setCellValue('Y1', 'TCS Gst');
                $sheet->setCellValue('Z1', 'TCS');
                $sheet->setCellValue('AA1', 'Invoice Amount');
                $sheet->setCellValue('AB1', 'Shipping Charges');
                $sheet->setCellValue('AC1', 'Order Amount');
                $sheet->setCellValue('AD1', 'Package Name');
                $sheet->setCellValue('AE1', 'Total Products');
                $sheet->setCellValue('AF1', 'Total Quantity');
                $sheet->setCellValue('AG1', 'Total Price');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
                    $sheet->setCellValue('V'.$count, $item['order_status']);
                    $sheet->setCellValue('W'.$count, $item['tds_gst']);
                    $sheet->setCellValue('X'.$count, $item['tds']);
                    $sheet->setCellValue('Y'.$count, $item['tcs_gst']);
                    $sheet->setCellValue('Z'.$count, $item['tcs']);
                    $sheet->setCellValue('AA'.$count, $item['invoice_amount']);
                    $sheet->setCellValue('AB'.$count, $item['price_shipping']);
                    $sheet->setCellValue('AC'.$count, $item['price_total']);
                    $sheet->setCellValue('AD'.$count, $item['package_name']);
                    $sheet->setCellValue('AE'.$count, $item['total_products']);
                    $sheet->setCellValue('AF'.$count, $item['product_quantity']);
                    $sheet->setCellValue('AG'.$count, $item['total_price']);
    				$count++;
				}

				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);


    }



  public function generate_complaints_reports(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];

               if (array_key_exists("school",$params)){
                    $filter['school']  = $params['school'];
                }

                if (array_key_exists("complaint_category",$params)){
                    $filter['complaint_category']  = $params['complaint_category'];
                }
                else{  $filter['complaint_category']  = array();  }

                if (array_key_exists("complaint_status",$params)){
                    $filter['ticket_status']  = $params['complaint_status'];
                }
                else{ $filter['ticket_status']  = array(); }

                if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{ $filter['keyword']  = array();  }

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->export_complaint_list($user_id,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}


            }
        }
    }


    public function export_complaints_reports()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];

                if (array_key_exists("school",$params)){
                    $filter['school']  = $params['school'];
                }

                if (array_key_exists("complaint_category",$params)){
                    $filter['complaint_category']  = $params['complaint_category'];
                }
                else{  $filter['complaint_category']  = array();  }

                if (array_key_exists("complaint_status",$params)){
                    $filter['ticket_status']  = $params['complaint_status'];
                }
                else{ $filter['ticket_status']  = array(); }

                if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{ $filter['keyword']  = array();  }

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->export_complaint_list($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();


				$sheet->setCellValue('A1', 'Sr no');
				$sheet->setCellValue('B1', 'Order Number');
                $sheet->setCellValue('C1', 'Product Name/School Name');
                $sheet->setCellValue('D1', 'Ticket Status');
                $sheet->setCellValue('E1', 'Order Type');
                $sheet->setCellValue('F1', 'Ticket Code');
                $sheet->setCellValue('G1', 'Username');
                $sheet->setCellValue('H1', 'Order Id');
                $sheet->setCellValue('I1', 'Cat Name');
                $sheet->setCellValue('J1', 'Ticket Desc');
                $sheet->setCellValue('K1', 'Added Date');

                $sheet->setCellValue('L1', 'Shpping No');
                $sheet->setCellValue('M1', 'Location');
                $sheet->setCellValue('N1', 'Shipping Address');
                $sheet->setCellValue('O1', 'State');
                $sheet->setCellValue('P1', 'City');
                $sheet->setCellValue('Q1', 'Land Mark');
                $sheet->setCellValue('R1', 'Pincode');
                $sheet->setCellValue('S1', 'Phone Number');
                $sheet->setCellValue('T1', 'Grade Name');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_number']);
                    $sheet->setCellValue('C'.$count, $item['product_name']);
                    $sheet->setCellValue('D'.$count, $item['ticket_status']);
                    $sheet->setCellValue('E'.$count, $item['order_type']);
                    $sheet->setCellValue('F'.$count, $item['ticket_code']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['order_id']);
                    $sheet->setCellValue('I'.$count, $item['cat_name']);
                    $sheet->setCellValue('J'.$count, $item['ticket_desc']);
                    $sheet->setCellValue('K'.$count, $item['added_date']);

                    $sheet->setCellValue('L'.$count, $item['shpping_no']);
                    $sheet->setCellValue('M'.$count, $item['location']);
                    $sheet->setCellValue('N'.$count, $item['address']);
                    $sheet->setCellValue('O'.$count, $item['state']);
                    $sheet->setCellValue('P'.$count, $item['city']);
                    $sheet->setCellValue('Q'.$count, $item['landmark']);
                    $sheet->setCellValue('R'.$count, $item['pincode']);
                    $sheet->setCellValue('S'.$count, $item['phone_number']);
                    $sheet->setCellValue('T'.$count, $item['grade_name']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }

    public function generate_consolidate_report_by_all_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){

                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }

                }
                else{ $filter['academic_year']  = array();  }


                $filter['order_array'] = $params['order_array'];

				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->consolidated_report_by_all_orders($user_id,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}


            }
        }
    }

    public function generate_consolidate_report_by_students_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){

                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }

                }
                else{ $filter['academic_year']  = array();  }


                $filter['order_array'] = $params['order_array'];

				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->consolidated_report_by_students_orders($user_id,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}


            }
        }
    }

    public function generate_consolidate_report_by_school_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){
                        $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                        $filter['academic_year']  = $params['academic_year'];
                    }
                }
                else{ $filter['academic_year']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->consolidated_report_by_school_orders($user_id,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}
            }
        }
    }

    public function generate_consolidate_report_by_individual_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){
                        $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                        $filter['academic_year']  = $params['academic_year'];
                    }
                }
                else{ $filter['academic_year']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->consolidated_report_by_individual_orders($user_id,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}
            }
        }
    }

    public function download_customer_report()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{
                    $filter['keyword']='';
                }

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->download_customer_report($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

                $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Customer Name');
                $sheet->setCellValue('C1', 'Customer Phone');
                $sheet->setCellValue('D1', 'Customer Email');
                $sheet->setCellValue('E1', 'Registered On');
				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['username']);
                    $sheet->setCellValue('C'.$count, $item['phone_number']);
                    $sheet->setCellValue('D'.$count, $item['email']);
                    $sheet->setCellValue('E'.$count, $item['created_at']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }

    public function download_consolidate_report_by_school_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }


                 if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){

                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }

                }
                else{ $filter['academic_year']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_by_school_orders($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

                $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');
                $sheet->setCellValue('V1', 'Order Amount');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
                    $sheet->setCellValue('V'.$count, $item['price_total']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }

    public function download_consolidate_report_by_individual_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }


                 if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){

                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }

                }
                else{ $filter['academic_year']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_by_individual_orders($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

                $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');
                $sheet->setCellValue('V1', 'Order Amount');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
                    $sheet->setCellValue('V'.$count, $item['price_total']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }

    public function download_consolidate_report_all_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }


                 if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){

                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }

                }
                else{ $filter['academic_year']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_by_all_orders($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

                $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order Type');
                $sheet->setCellValue('C1', 'Shipping No');
                $sheet->setCellValue('D1', 'Order No');
                $sheet->setCellValue('E1', 'Invoice No');
                $sheet->setCellValue('F1', 'Date of Order');
                $sheet->setCellValue('G1', 'Customer Name');
                $sheet->setCellValue('H1', 'School-Board-City');
                $sheet->setCellValue('I1', 'Grade');
                $sheet->setCellValue('J1', 'Order Placed');
                $sheet->setCellValue('K1', 'Contact Number');
                $sheet->setCellValue('L1', 'Shipping Address');
                $sheet->setCellValue('M1', 'Landmark');
                $sheet->setCellValue('N1', 'Pincode');
                $sheet->setCellValue('O1', 'Weight');
                $sheet->setCellValue('P1', 'Warehouse');
                $sheet->setCellValue('Q1', 'House No');
                $sheet->setCellValue('R1', 'Building Name');
                $sheet->setCellValue('S1', 'Street Name');
                $sheet->setCellValue('T1', 'Locality');
                $sheet->setCellValue('U1', 'Alternate Mobile');
                $sheet->setCellValue('V1', 'Order Amount');
                $sheet->setCellValue('W1', 'Student');

				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_type']);
                    $sheet->setCellValue('C'.$count, $item['order_slot']);
                    $sheet->setCellValue('D'.$count, $item['order_number']);
                    $sheet->setCellValue('E'.$count, $item['invoice_no']);
                    $sheet->setCellValue('F'.$count, $item['created_at']);
                    $sheet->setCellValue('G'.$count, $item['username']);
                    $sheet->setCellValue('H'.$count, $item['school_name'].'-'.$item['board_name'].'-'.$item['school_city']);
                    $sheet->setCellValue('I'.$count, $item['grade_name']);
                    $sheet->setCellValue('J'.$count, $item['details']);
                    $sheet->setCellValue('K'.$count, $item['phone_number']);
                    $sheet->setCellValue('L'.$count, $item['address']);
                    $sheet->setCellValue('M'.$count, $item['landmark']);
                    $sheet->setCellValue('N'.$count, $item['pincode']);
                    $sheet->setCellValue('O'.$count, $item['total_weight']);
                    $sheet->setCellValue('P'.$count, $item['warehouse']);
                    $sheet->setCellValue('Q'.$count, $item['flat_house_no']);
                    $sheet->setCellValue('R'.$count, $item['building_name']);
                    $sheet->setCellValue('S'.$count, $item['address']);
                    $sheet->setCellValue('T'.$count, $item['location']);
                    $sheet->setCellValue('U'.$count, $item['alternate_phone']);
                    $sheet->setCellValue('V'.$count, $item['price_total']);
                    $sheet->setCellValue('W'.$count, $item['student_name']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
				$upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }  
        }
    }

    public function download_consolidate_report_students_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }


                 if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year'));
                    if($curr_date==$params['academic_year']){

                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }

                }
                else{ $filter['academic_year']  = array();  }

                $filter['order_array'] = $params['order_array'];

				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->consolidated_report_by_students_orders($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

                $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Student Name');
                $sheet->setCellValue('C1', 'Date of Birth');
                $sheet->setCellValue('D1', 'Parent Phone');
                $sheet->setCellValue('E1', 'School');
                $sheet->setCellValue('F1', 'Board');
                $sheet->setCellValue('G1', 'Grade');
				$count = 2;
				foreach ($contact_list as $item) {
                    $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['name']);
                    $sheet->setCellValue('C'.$count, $item['dob']);
                    $sheet->setCellValue('D'.$count, $item['phone_number']);
                    $sheet->setCellValue('E'.$count, $item['school_name']);
                    $sheet->setCellValue('F'.$count, $item['board_name']);
                    $sheet->setCellValue('G'.$count, $item['grade_name']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}


    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }



  public function generate_credit_note_reports()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['keyword']  = '';  }

				$this->load->helper('download');
				$data = array();
				$result = $this->excel_model->get_export_order_vendor_customer_cn($user_id,$filter);
				if(!empty($result)){
				     json_output(200, array(
                        'status' => 200,
                        'message' => ''
                    ));
				}
				else{
				     json_output(200, array(
                        'status' => 400,
                        'message' => 'Sorry, No data available for export!'
                    ));
				}


            }
        }
    }

    public function download_credit_note_reports()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
				if (array_key_exists("keyword",$params)){
                    $filter['keyword']  = $params['keyword'];
                }
                else{  $filter['keyword']  = '';  }



				$fileName='consolidated_report';
				$this->load->helper('download');
				$data = array();
				$contact_list = $this->excel_model->get_export_order_vendor_customer_cn($user_id,$filter);
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Sr no');
				$sheet->setCellValue('B1', 'Txn Id');
				$sheet->setCellValue('C1', 'CN Invoice No');
				$sheet->setCellValue('D1', 'OG Invoice No');
				$sheet->setCellValue('E1', 'Order No');
				$sheet->setCellValue('F1', 'Order Date');
				$sheet->setCellValue('G1', 'Delivered Date');
				$sheet->setCellValue('H1', 'Customer Name');
				$sheet->setCellValue('I1', 'Customer Mobile');
				$sheet->setCellValue('J1', 'Carrier');
				$sheet->setCellValue('K1', 'Order Amount');

				$count = 2;
				foreach ($contact_list as $order) {
				   $sheet->setCellValue('A'.$count, $count-1);
					$sheet->setCellValue('B'.$count, $order['txn_id']);
					$sheet->setCellValue('C'.$count, $order['invoice_cn']);
					$sheet->setCellValue('D'.$count, $order['invoice_no']);
					$sheet->setCellValue('E'.$count, $order['order_number']);
					$sheet->setCellValue('F'.$count, $order['created_at']);
					$sheet->setCellValue('G'.$count, $order['delivered_date']);
					$sheet->setCellValue('H'.$count, $order['username']);
					$sheet->setCellValue('I'.$count, $order['phone_number']);
					$sheet->setCellValue('J'.$count, get_phrase($order['courier']));
					$sheet->setCellValue('K'.$count, $order['price_total']);
    				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}
    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);
            }
        }
    }





    public function check_received_payments_report(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];
				$data = array();

				if($start_end_date!=''){

        	    $from =  date('Y-m-d',strtotime($start_end_date['0']));
                $to =  date('Y-m-d',strtotime($start_end_date['1']));

                $date1 = new DateTime($from);
                $date2 = new DateTime($to);
                $diff = $date1->diff($date2);

			    if($diff->days<=90){

			     	$result = $this->excel_model->get_received_payments_report($start_end_date,$user_id);
		    	    /*	echo $this->db->last_query();
		             exit();*/
    				if(!empty($result)){
    				     json_output(200, array(
                            'status' => 200,
                            'message' => ''
                        ));
    				}
    				else{
    				     json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, No data available on selected dates!'
                        ));
    				}

				 }
				 else{
				    json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, Only 90 days data can be exported!'
                    ));

				 }


				}
				else{
				    json_output(200, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
				}


            }
        }
    }

    public function export_received_payments_report() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
				$user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];

				$fileName='received_payments_report';
				$this->load->helper('download');
				$data = array();
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

				$sheet->setCellValue('A1', 'Sr no');
				$sheet->setCellValue('B1', 'Date of payment');
				$sheet->setCellValue('C1', 'Amount of Payment');
				$sheet->setCellValue('D1', 'UTR No');

				$count = 2;
				$orders = $this->excel_model->get_received_payments_report($start_end_date,$user_id);
				foreach($orders as $order){
				$sheet->setCellValue('A'.$count, $count-1);
				$sheet->setCellValue('B'.$count, $order['payment_date']);
				$sheet->setCellValue('C'.$count, price_format_decimal($order['payment_made']));
				$sheet->setCellValue('D'.$count, $order['utr_no']);
				$sheet->setCellValue('E'.$count, $order['created_at']);
				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}

    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);

            }
        }
        }







    public function check_pending_payments_report(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];
				$data = array();

				if($start_end_date!=''){

        	    $from =  date('Y-m-d',strtotime($start_end_date['0']));
                $to =  date('Y-m-d',strtotime($start_end_date['1']));

                $date1 = new DateTime($from);
                $date2 = new DateTime($to);
                $diff = $date1->diff($date2);

			    if($diff->days<=180){

			     	$result = $this->excel_model->get_pending_payments_report($start_end_date,$user_id);
		    	    /*	echo $this->db->last_query();
		             exit();*/
    				if(!empty($result)){
    				     json_output(200, array(
                            'status' => 200,
                            'message' => ''
                        ));
    				}
    				else{
    				     json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, No data available on selected dates!'
                        ));
    				}

				 }
				 else{
				    json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, Only 30 days data can be exported!'
                    ));

				 }


				}
				else{
				    json_output(200, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
				}


            }
        }
    }

    public function export_pending_payments_report() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
				$user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];

				$fileName='pending_payments_report';
				$this->load->helper('download');
				$data = array();
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

		         $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order No');
                $sheet->setCellValue('C1', 'Invoice No');
                $sheet->setCellValue('D1', 'Invoice Amt (Inc. GST)');
                $sheet->setCellValue('E1', 'TDS');
                $sheet->setCellValue('F1', 'TCS');
                $sheet->setCellValue('G1', 'Commission on Invoice');
                $sheet->setCellValue('H1', 'Net amount payable');
                $sheet->setCellValue('I1', 'Order Date');
                $sheet->setCellValue('J1', 'Days From Order');
                $sheet->setCellValue('K1', 'Dispatch Date');
                $sheet->setCellValue('L1', 'Days From Dispatch');
                $sheet->setCellValue('M1', 'Delivery Date');
                $sheet->setCellValue('N1', 'Days From Delivery');
                $sheet->setCellValue('O1', 'Amount of Payment Made');
                $sheet->setCellValue('P1', 'UTR No');
                $sheet->setCellValue('Q1', 'Date of Payment');
                $sheet->setCellValue('R1', '% of Payment');
                $sheet->setCellValue('S1', 'Balance Amount');

				$count = 2;
				$orders = $this->excel_model->get_pending_payments_report($start_end_date,$user_id);
				foreach($orders as $item){
		           $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_number']);
                    $sheet->setCellValue('C'.$count, $item['invoice_no']);
                    $sheet->setCellValue('D'.$count, $item['invoice_amt']);
                    $sheet->setCellValue('E'.$count, $item['tds']);
                    $sheet->setCellValue('F'.$count, $item['tcs']);
                    $sheet->setCellValue('G'.$count, $item['commision_amount']);
                    $sheet->setCellValue('H'.$count, $item['net_amount']);
                    $sheet->setCellValue('I'.$count, $item['order_date']);
                    $sheet->setCellValue('J'.$count, $item['order_date_ago']);
                    $sheet->setCellValue('K'.$count, $item['dispatched_date']);
                    $sheet->setCellValue('L'.$count, $item['dispatched_date_ago']);
                    $sheet->setCellValue('M'.$count, $item['delivered_date']);
                    $sheet->setCellValue('N'.$count, $item['delivered_date_ago']);
                    $sheet->setCellValue('O'.$count, $item['payment_made']);
                    $sheet->setCellValue('P'.$count, $item['utr_no']);
                    $sheet->setCellValue('Q'.$count, $item['payment_date']);
                    $sheet->setCellValue('R'.$count, $item['payment_per']);
                    $sheet->setCellValue('S'.$count, $item['balance_amt']);
				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');
        $upload_path = './uploads/excel/';
				try {
            		$writer->save($upload_path.$fileName);
            		$content =file_get_contents($upload_path.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}

    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($upload_path.$fileName);
            	force_download($fileName, $content);
            	exit($content);

            }
        }
        }








    public function check_completed_payments_report(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];
				$data = array();

				if($start_end_date!=''){

        	    $from =  date('Y-m-d',strtotime($start_end_date['0']));
                $to =  date('Y-m-d',strtotime($start_end_date['1']));

                $date1 = new DateTime($from);
                $date2 = new DateTime($to);
                $diff = $date1->diff($date2);

			    if($diff->days<=180){

			     	$result = $this->excel_model->get_completed_payments_report($start_end_date,$user_id);
		    	    /*	echo $this->db->last_query();
		             exit();*/
    				if(!empty($result)){
    				     json_output(200, array(
                            'status' => 200,
                            'message' => ''
                        ));
    				}
    				else{
    				     json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, No data available on selected dates!'
                        ));
    				}

				 }
				 else{
				    json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, Only 30 days data can be exported!'
                    ));

				 }


				}
				else{
				    json_output(200, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
				}


            }
        }
    }

    public function export_completed_payments_report() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);
				$user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];

				$fileName='completed_payments_report';
				$this->load->helper('download');
				$data = array();
				$spreadsheet = new Spreadsheet();
				$sheet = $spreadsheet->getActiveSheet();

		         $sheet->setCellValue('A1', 'Sr no');
                $sheet->setCellValue('B1', 'Order No');
                $sheet->setCellValue('C1', 'Invoice No');
                $sheet->setCellValue('D1', 'Invoice Amt (Inc. GST)');
                $sheet->setCellValue('E1', 'TDS');
                $sheet->setCellValue('F1', 'TCS');
                $sheet->setCellValue('G1', 'Commission on Invoice');
                $sheet->setCellValue('H1', 'Net amount payable');
                $sheet->setCellValue('I1', 'Order Date');
                $sheet->setCellValue('J1', 'Days From Order');
                $sheet->setCellValue('K1', 'Dispatch Date');
                $sheet->setCellValue('L1', 'Days From Dispatch');
                $sheet->setCellValue('M1', 'Delivery Date');
                $sheet->setCellValue('N1', 'Days From Delivery');
                $sheet->setCellValue('O1', 'Amount of Payment Made');
                $sheet->setCellValue('P1', 'UTR No');
                $sheet->setCellValue('Q1', 'Date of Payment');
                $sheet->setCellValue('R1', '% of Payment');
                $sheet->setCellValue('S1', 'Balance Amount');

				$count = 2;
				$orders = $this->excel_model->get_completed_payments_report($start_end_date,$user_id);
				foreach($orders as $item){
		           $sheet->setCellValue('A'.$count, $count-1);
                    $sheet->setCellValue('B'.$count, $item['order_number']);
                    $sheet->setCellValue('C'.$count, $item['invoice_no']);
                    $sheet->setCellValue('D'.$count, $item['invoice_amt']);
                    $sheet->setCellValue('E'.$count, $item['tds']);
                    $sheet->setCellValue('F'.$count, $item['tcs']);
                    $sheet->setCellValue('G'.$count, $item['commision_amount']);
                    $sheet->setCellValue('H'.$count, $item['net_amount']);
                    $sheet->setCellValue('I'.$count, $item['order_date']);
                    $sheet->setCellValue('J'.$count, $item['order_date_ago']);
                    $sheet->setCellValue('K'.$count, $item['dispatched_date']);
                    $sheet->setCellValue('L'.$count, $item['dispatched_date_ago']);
                    $sheet->setCellValue('M'.$count, $item['delivered_date']);
                    $sheet->setCellValue('N'.$count, $item['delivered_date_ago']);
                    $sheet->setCellValue('O'.$count, $item['payment_made']);
                    $sheet->setCellValue('P'.$count, $item['utr_no']);
                    $sheet->setCellValue('Q'.$count, $item['payment_date']);
                    $sheet->setCellValue('R'.$count, $item['payment_per']);
                    $sheet->setCellValue('S'.$count, $item['balance_amt']);
				$count++;
				}
				$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
				$fileName = $fileName.'.xlsx';
				$this->output->set_header('Content-Type: application/vnd.ms-excel');
				$this->output->set_header("Content-type: application/csv");
				$this->output->set_header('Cache-Control: max-age=0');

				try {
            		$writer->save(FCPATH.$fileName);
            		$content =file_get_contents(FCPATH.$fileName);
            	} catch(Exception $e) {
            		exit($e->getMessage());
            	}

    			header("Content-Disposition: attachment; filename=".$fileName);
            	unlink($fileName);
            	force_download($fileName, $content);
            	exit($content);

            }
        }
        }

}

?>
