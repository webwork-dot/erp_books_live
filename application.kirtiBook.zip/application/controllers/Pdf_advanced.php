<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf_advanced extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('pdf_model');
    }
    
   
 
    public function generate_shipping_invoice_(){
        $db3 = $this->load->database('crondb3', TRUE);        	
        $query = $db3->query("SELECT id,buyer_id,user_invoice_url,order_status FROM orders WHERE payment_status='payment_received' AND (order_status='delivered' OR cancel_status='delivered') AND user_invoice IS NULL ORDER BY delivered_date asc limit 5000");
        if ($query->num_rows() > 0) {
        $result_data = $query->result_array();
        foreach ($result_data as $info) {
		   $inv_no= $this->pdf_model->update_user_invoice_number($info['id']); 
        }
      
      }
    }
    
    
     public function generate_shipping_invoice_CI(){
        $db3 = $this->load->database('crondb3', TRUE);        	
        $query = $db3->query("SELECT id,order_status,refunded_id,user_invoice_ci_url,refund_amount,price_total FROM orders WHERE payment_status='payment_received' AND order_status='cancelled' AND (user_invoice_ci IS NULL AND user_invoice_ci_url IS NULL) AND  (refunded_id IS NOT NULL) AND (price_total>=refund_amount) ORDER BY refunded_date asc limit 600");
        
        if ($query->num_rows() > 0) {
        $result_data = $query->result();
        foreach ($result_data as $order) {
            if($order->order_status=='cancelled' && $order->refunded_id!=NULL && $order->user_invoice_ci_url==NULL && ($order->price_total>=$order->refund_amount)){
		      $inv_no= $this->pdf_model->update_user_invoice_ci_number($order->id); 
            }
        }
      
      }
    } 
    
    
    
      
   public function generate_shipping_invoice_credit_note__(){
        $db3 = $this->load->database('crondb3', TRUE);        	
        $query = $db3->query("SELECT id,buyer_id,refunded_id FROM orders WHERE payment_status='payment_received' AND hcheck=1 order by refunded_date asc");
     
        
        if ($query->num_rows() > 0) {
        $result_data = $query->result();
        foreach ($result_data as $order) {
            if($order->refunded_id!=NULL && $order->user_invoice_cn==NULL){
		      $inv_no= $this->pdf_model->update_user_invoice_cn_number($order->id); 
            }
        }
      
      }
    }    
    
 
}