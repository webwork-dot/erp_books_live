<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Package extends CI_Controller
{
     function __construct()
    {
        parent::__construct();
        $this->load->model('package_model');
    }
    
    public function get_board()
    {
        $school_id = $this->input->post('school_id', true);
        
        $board_list = $this->common_model->get_board_by_school($school_id);
        
        foreach ($board_list['data'] as $board) {
            echo '<option value="' . $board['id'] . '">' . $board['name'] . '</option>';
        }
    }

	public function get_product(){
        $divid       = $this->input->post('id', true);
        $category_id = $this->input->post('category_id', true);
        $user_id = $this->input->post('user_id', true);
        $grade_id = $this->input->post('grade_id', true);
        $board_id = $this->input->post('board_id', true);
        $data_row = $this->input->post('data_row', true);
    
        if ($category_id != '' ) { 
            $products = $this->package_model->get_product_by_bookset_category($category_id,$user_id,$grade_id,$board_id);
            echo '<select class="form-control form-input m-r-10 product_ selectpicker" data-live-search="true" id="mproduct_' . $data_row . '"  data-row="' . $data_row . '" data-index="' . $divid . '" name="product' . $divid . '[]">'; 
            echo '<option value="">Select Product</option>';
            foreach ($products['data'] as $item) {
               echo '<option value="' . $item['id'] . '">' . $item['title'] . '-' . $item['model_number']. '</option>';
            }
           echo "</select>";
        } else {
            echo '<select class="form-control form-input m-r-10 product_ selectpicker" data-live-search="true" id="mproduct_' . $data_row . '"   data-row="' . $data_row . '" data-index="' . $divid . '" name="product' . $divid . '[]" >';
            
            echo '<option value="">Select Product</option>';
            echo "</select>";
        }        
    }  
    
    public function get_package_name()
    {
        $category_id = $this->input->post('category_id', true);
        $grade_id = $this->input->post('grade_id', true);
  
        $products = $this->package_model->get_package_name($category_id,$grade_id);
        echo json_encode($products);
    }
    
    public function get_product_dprice()
    {
        $product_id = $this->input->post('product_id', true);
        $user_id = $this->input->post('user_id', true);
        $category_id = $this->input->post('category_id', true);
  
        $products = $this->package_model->get_product_dprice($product_id,$user_id,$category_id);
        //echo $products['discount_price'];
        echo json_encode($products);
         //base_price
    }
    
    
    public function get_service_categories()
    {
        $products = $this->package_model->get_service_categories();
        echo json_encode($products);
    }
    
      public function get_categories()
    {
  
        $products = $this->package_model->get_categories();
        //echo $products['discount_price'];
        echo json_encode($products);
         //base_price
    }
                     
}