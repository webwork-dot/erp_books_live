<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Account_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('account_model');
    }
    
    
    public function get_credit_note()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->account_model->get_credit_note($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function check_download_product_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } 
        else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $order_id = $params['order_id'];
                 
                $flag=0;
                foreach($order_id as $order_ids){
                    
                    $check_order = $this->account_model->check_order_by_id($order_ids,$user_id);
                    
                    if($check_order->num_rows()>0){
            	       $order=$check_order->row();
            	      
            	       if($order->invoice_cn_url==NULL){
                	         $flag=0;
                	         break;
            	       }
            	       else{
            	            $flag=1;   
            	       }                      
            	    }
            	    else{
            	        $flag=2;
            	        break;
            	    }
                }
                
                // echo $flag;
                // exit();
                
                if($flag==0){
                    json_output(200, array(
                        'status' => 400,
                        'message' => 'Some selected orders invoices not generated yet!'
                    ));
                }  
                elseif($flag==2){
                    json_output(200, array(
                        'status' => 400,
                        'message' => 'Invalid requests!'
                    ));
                }
                else{
                    json_output(200, array(
                        'status' => 200,
                        'message' => 'Orders invoices Generated Successfully'
                    ));
                }
            }
        }
    }
    
   
    public function download_product_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if($check_auth_client == true) {
             $params       = json_decode(file_get_contents('php://input'), TRUE);
             $user_id      = $params['user_id'];
             $order_id = $params['order_id'];
             $this->load->library('zip');  
              foreach($order_id as $order_ids){
        	      $order = $this->account_model->get_order_by_id($order_ids)->row();
        	      if($order->invoice_cn_url!='' && $order->invoice_cn_url!=NULL){
                        $filepath1 = FCPATH.'/'.$order->invoice_cn_url;
                        $this->zip->read_file($filepath1);
        	       }
               }
            // Download
            $filename = 'vendor_customer_CN_'.date('Ymdhis').'.zip';
            $this->zip->download($filename);
         }
        }
    }
    
    public function received_payments()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword']; 
                
                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date'] = $params['start_end_date'];
                }
                else{
                    $filter['start_end_date'] = '';
                }
                
                if ($user_id != '') {
                    $response = $this->account_model->received_payments($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function received_payments_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['utr']  = $params['id'];
                
                if ($user_id != '') {
                    $response = $this->account_model->received_payments_details($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function pending_payments()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date'] = $params['start_end_date'];
                }
                else{
                    $filter['start_end_date'] = '';
                }
                
                if ($user_id != '') {
                    $response = $this->account_model->pending_payments($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function completed_payments()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];  
                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date'] = $params['start_end_date'];
                }
                else{
                    $filter['start_end_date'] = '';
                }
                
                if ($user_id != '') {
                    $response = $this->account_model->completed_payments($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function kirtibook_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->account_model->kirtibook_invoice($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function kirtibook_invoice_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['invoice_no']  = $params['id'];
                
                if ($user_id != '') {
                    $response = $this->account_model->kirtibook_invoice_details($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    
    
    
    
    
 
public function check_invoice_report()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } 
        else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
				$user_id  		= $params['user_id'];
                $start_end_date   = $params['start_end_date'];	
               if($start_end_date!=''){ 
			  
			    $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
                $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
                 
                $date1 = new DateTime($from);
                $date2 = new DateTime($to);
                $diff = $date1->diff($date2);   
			  
            	  if($diff->days<=30){
            	      
            	    if (array_key_exists("keyword",$params)){
                        $keyword  = $params['keyword'];
                    }
                    else{  $keyword  = '';  }  
				
			     	$result = $this->account_model->get_invoice_report($start_end_date,$keyword,$user_id); 
		    	    /*	echo $this->db->last_query();
		             exit();*/
    				if(!empty($result)){
    				     json_output(200, array(
                            'status' => 200,
                            'message' => ''
                        ));
    				}
    				else{
    				     json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, No data available on selected dates!'
                        ));
    				}
			
					 }
				 else{
				    json_output(200, array(
                            'status' => 400,
                            'message' => 'Sorry, Only 30 days data can be downloadable!'
                    ));   
				     
				 }	
				
				}
				else{
				    json_output(200, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
				}	
				
				
            }
        }
    }
    
   
    public function download_invoice_report()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if($check_auth_client == true) {
             $params       = json_decode(file_get_contents('php://input'), TRUE);			 
			 $user_id  		   = $params['user_id'];
             $start_end_date   = $params['start_end_date'];	
             
            if (array_key_exists("keyword",$params)){
                $keyword  = $params['keyword'];
            }
            else{  $keyword  = '';  }  
             
             $this->load->library('zip'); 

			 $orders=$this->account_model->get_invoice_report($start_end_date,$keyword,$user_id); 			 
             foreach($orders as $order){
        	   if($order->invoice_url!='' && $order->invoice_url!=NULL){
                   $filepath1 = vendor_download_url().'/'.$order->invoice_url;
                   $this->zip->read_file($filepath1);
        	    }
             }
            // Download
			$filename = 'invoice_'.date('Ymdhis').'.zip';
            $this->zip->download($filename);
         }
        }
    }  
    
    
    
    
   public function accounts_statistics()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id   = $params['user_id'];  
                if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year')); 
                    if($curr_date==$params['academic_year']){
                        
                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }
                    
                }
                else{ $filter['academic_year']  = array();  }
                
                if ($user_id != '') {
                    $response = $this->account_model->accounts_statistics($user_id,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    
    
    public function school_by_vendor()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];   
                
                if (array_key_exists("academic_year",$params)){
                   $curr_date=date('Y').'-'.date('Y', strtotime('+1 year')); 
                    if($curr_date==$params['academic_year']){
                        
                     $filter['academic_year']  = $this->auth_model->get_academic_year($params['academic_year']);
                    }
                    else{
                     $filter['academic_year']  = $params['academic_year'];
                    }
                    
                }
                else{ $filter['academic_year']  = array();  }
                
                if ($user_id != '') {
                    $response = $this->account_model->get_accounts_school_by_vendor($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
}