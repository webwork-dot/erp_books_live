<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Stock_controller extends CI_Controller
{
     function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
        $this->load->model('Stock_model');
    }
    
    public function stationery_stock_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->Stock_model->stationery_stock_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function product_stock_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->Stock_model->product_stock_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function uniform_stock_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->Stock_model->uniform_stock_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function update_product_status()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $master_id  = $params['master_id'];
                $status   = $params['status'];
                
                if ($user_id != '' && $master_id != '') {
                    $response = $this->Stock_model->update_product_status($user_id,$master_id,$status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function update_product_stock()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $quantity   = $params['quantity'];
                $kirtibook_price   = $params['kirtibook_price'];
                $price   = $params['price'];
                $master_id = $params['master_id'];
                $product_id = $params['product_id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->Stock_model->update_product_stock($user_id,$product_id,$master_id,$id,$quantity,$kirtibook_price,$price);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function shoes_stock_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->Stock_model->shoes_stock_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    
}