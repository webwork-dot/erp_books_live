<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('pdf_model');
    }

    public function print_qr()
    {

    }

    public function test_qr()
    {
        $shipping_no='KBA0091';
        $type='self';
        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
        $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no,$type);

      //  echo $html_content;exit();
		$this->load->library('pdf');
		$this->pdf->set_paper("A4", "portrait");
		$this->pdf->set_option('isHtml5ParserEnabled', TRUE);
		$this->pdf->load_html($html_content);
		$this->pdf->render();
		$pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
		 $this->pdf->stream($pdfname, array("Attachment"=>0));
		$output    = $this->pdf->output();

        echo $html_content;
    }


    public function generate_shipping_label2()
    {
        $slot_no='KISAS10025';
        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
        $html_content .= $this->pdf_model->fetch_shipping_label($slot_no);

        echo $html_content;
        exit();

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $slot_no = $params['slot_no'];
                if (!empty($slot_no)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');

                    foreach ($slot_no as $shipping_no):
                        $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
                        if ($shipping_label->num_rows() > 0) {
                            $row = $shipping_label->row();
                            if ($row->barcode_url == NULL) {
                                $this->pdf_model->get_barcode($row->slot_no, $row->id);
                            }
                        } else {
                            $label_id = $this->pdf_model->add_shipping_label($shipping_no);
                            $this->pdf_model->get_barcode($shipping_no, $label_id);
                        }


                        $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

                        if ($row->label_url == NULL) {
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
                            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no);

                            $this->load->library('pdf');
                            $this->pdf->set_paper("A4", "portrait");
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
                            //$this->pdf->stream($pdfname, array("Attachment"=>0));
                            $output    = $this->pdf->output();
                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_label_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_label_generated($shipping_no, $file_url);
                            }
                            unset($this->pdf);
                            $check_label = '1';
                        }
                    endforeach;


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping bill already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function generate_shipping_label()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $slot_no = $params['slot_no'];
                if (!empty($slot_no)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');

                    foreach ($slot_no as $shipping_no):
                        $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
                        if ($shipping_label->num_rows() > 0) {
                            $row = $shipping_label->row();
                            if ($row->barcode_url == NULL) {
                                $this->pdf_model->get_picqer_barcode($row->slot_no , $row->id,'barcode_url');
                            }
                        } else {
                            $label_id = $this->pdf_model->add_shipping_label($shipping_no);
                            $this->pdf_model->get_picqer_barcode($shipping_no , $label_id,'barcode_url');
                        }


                        $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

                        if ($row->label_url == NULL) {
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
                            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no,'self');

                            $this->load->library('pdf');
                            $this->pdf->set_paper("A4", "portrait");
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
                            //$this->pdf->stream($pdfname, array("Attachment"=>0));
                            $output    = $this->pdf->output();
                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_label_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_label_generated($shipping_no, $file_url);
                            }
                            unset($this->pdf);
                            $check_label = '1';
                        }
                    endforeach;


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping bill already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function check_download_shipping_label_dtdc()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];

                $flag = 0;

                $labels = array();
                foreach ($process_slot as $shipping_no) {
                    $order = $this->order_model->check_shipping_label_dtdc($shipping_no);
                    if ($order > 0) {
                        //
                    } else {
                        $flag     = 1;
                        $labels[] = $shipping_no;
                        //break;
                    }
                }

                if ($flag > 0) {
                    $all_labels = implode(",", $labels);

                    json_output(200, array(
                        'status' => 400,
                        'message' => 'Following DTDC Shipping Invoice Not Generated Yet-' . $all_labels
                    ));
                } else {
                    json_output(200, array(
                        'status' => 200,
                        'message' => 'DTDC Shipping Invoice Generated Successfully'
                    ));
                }
            }
        }
    }

    public function check_download_shipping_label()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];
				$check_provider = $this->pdf_model->check_shipping_label_provider($process_slot,'self');
				 if($check_provider==false){
					   json_output(400, array(
							'status' => 400,
							'message' => 'All orders shipment provider must be in Self'
						));
				 }
				 else{
					$flag = 0;

					$labels = array();
					foreach ($process_slot as $shipping_no) {
						$order = $this->order_model->check_shipping_label($shipping_no);
						if ($order > 0) {
							//
						} else {
							$flag     = 1;
							$labels[] = $shipping_no;
							//break;
						}
					}

					if ($flag > 0) {
						$all_labels = implode(",", $labels);

						json_output(200, array(
							'status' => 400,
							'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
						));
					} else {
						json_output(200, array(
							'status' => 200,
							'message' => 'Shipping Invoice Generated Successfully'
						));
					}
              }
            }
        }
    }

    public function download_shipping_label_app()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];
                $files=array();
                foreach ($process_slot as $shipping_no):
                    $order = $this->pdf_model->get_shipping_label($shipping_no)->row();
                    if ($order->label_url != '' && $order->label_url != NULL) {
                        $filepath1 = 'https://liveapi.kirtibook.in/vendor/v1/'.$order->label_url;
                        $files[]=array(
                            'url' => $filepath1,
                            'shipping_no'=>$shipping_no
                        );
                    }
                endforeach;
                json_output(200, array(
                    'status' => 200,
                    'message' => 'success',
                    'data' => $files
                ));
                // Download
                //$filename = 'Label_' . date('Ymdhis') . '.zip';
                //$this->zip->download($filename);
            }
        }
    }

    public function download_shipping_label_dtdc()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];
                $this->load->library('zip');

                foreach ($process_slot as $shipping_no):
                    $order = $this->pdf_model->get_shipping_label($shipping_no)->row();
                    if ($order->dtdc_label_url != '' && $order->dtdc_label_url != NULL) {
                        $filepath1 = vendor_download_url() . '/' . $order->dtdc_label_url;
                        $this->zip->read_file($filepath1);
                    }
                endforeach;
                // Download
                $filename = 'Label_' . date('Ymdhis') . '.zip';
                $this->zip->download($filename);
            }
        }
    }

    public function download_shipping_label()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];
                $this->load->library('zip');

                foreach ($process_slot as $shipping_no):
                    $order = $this->pdf_model->get_shipping_label($shipping_no)->row();
                    if ($order->label_url != '' && $order->label_url != NULL) {
                        $filepath1 = vendor_download_url() . '/' . $order->label_url;
                        $this->zip->read_file($filepath1);
                    }
                endforeach;
                // Download
                $filename = 'Label_' . date('Ymdhis') . '.zip';
                $this->zip->download($filename);
            }
        }
    }

    public function download_shipping_label_test()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];
                $this->load->library('zip');
                $filepath1 = array();


                $process_slot = $this->db->query("SELECT * FROM `vendor_shipping_label` WHERE DATE(created_at)='2021-04-29'")->result();
                foreach ($process_slot as $order):
                    $shipping_no = $order->slot_no;
                // $order = $this->pdf_model->get_shipping_label($shipping_no)->row();
                    if ($order->barcode_url != '' && $order->barcode_url != NULL) {
                        if (!file_exists(FCPATH . $order->barcode_url)) {
                            $filepath1[] = $order->slot_no;
                        }

                        //$this->zip->read_file($filepath1);
                    }
                endforeach;
                echo json_encode($filepath1);
                // Download
                //$filename = 'Label_'.date('Ymdhis').'.zip';
                //$this->zip->download($filename);
            }
        }
    }
    
	public function test_shipping_bills()    {
        $this->load->library('pdf');
        $this->load->library('zip');

        $slot_no = array(
            'SHBHS3824'
        );

        foreach ($slot_no as $shipping_no):
            $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
            if ($shipping_label->num_rows() > 0) {
                $row = $shipping_label->row();
                if ($row->barcode_url == NULL) {
                    $this->pdf_model->get_barcode($row->slot_no, $row->id);
                }
            } else {
                //$label_id = $this->pdf_model->add_shipping_label($shipping_no);
                $this->pdf_model->get_barcode($shipping_no, $label_id);
            }

            $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

            //if($row->label_url==NULL){
            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no);

            $this->load->library('pdf');
            $this->pdf->set_paper("A4", "portrait");
            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
            $this->pdf->load_html($html_content);
            $this->pdf->render();
            $pdfname = 'Shipping-Label-' . $shipping_no . '.pdf';
            $this->pdf->stream($pdfname, array(
                "Attachment" => 0
            ));
            $output = $this->pdf->output(); /*$year = date("Y");
        $month = date("m");
        $day = date("d");
        //The folder path for our file should be YYYY/MM/DD
        $directory = "uploads/vendor_label_report/"."$year/$month/$day/";

        //If the directory doesn't already exists.
        if(!is_dir($directory)){ mkdir($directory, 0755, true);}

        $file_url=$directory.$pdfname;
        if(file_put_contents($file_url, $output)){
        $this->pdf_model->update_label_generated($shipping_no,$file_url);
        }
        unset($this->pdf);
        $check_label='1';*/
        // }
        endforeach;


        /*
        foreach($shipping_nos as $shipping_no):
        $order = $this->pdf_model->get_shipping_label($shipping_no)->row();
        if($order->label_url!='' && $order->label_url!=NULL){
        $filepath1 = FCPATH.'/'.$order->label_url;
        $this->zip->read_file($filepath1);
        }
        endforeach;

        // Download
        $filename = 'Label_'.date('Ymdhis').'.zip';
        $this->zip->download($filename);*/
    }



    public function test()
    {
        $result = $this->order_model->order_details_by_order_slot('SKRAS0010');
        echo json_encode($result);
    }

	public function generate_dtdc_label()
    {
		$query = $this->pdf_model->get_dtdc_label_limit();
		if ($query->num_rows() > 0) {
			$result_data = $query->result_array();
            foreach ($result_data as $info) {
                $awb_number = $info['awb_number'];
                $slot_no = $info['slot_no'];
                $curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => 'https://dtdcapi.shipsy.io/api/customer/integration/consignment/label/multipiece',
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS => "{\"reference_number\":\"$awb_number\"}",
					CURLOPT_HTTPHEADER => array(
					  'content-type: application/json',
					  'api-key: 9820bacb9c50f0ae71b1a6ce43e5d0'
					),
				));
				$response = curl_exec($curl);
				curl_close($curl);
				$dtdc_arr = json_decode($response);

				if($dtdc_arr->status=='OK'){
					if($dtdc_arr->data){
					  if ($dtdc_arr->data[0]->label) {
							$source_url = $dtdc_arr->data[0]->label;
							date_default_timezone_set('Asia/Kolkata');
							$year        = date("Y");
							$month       = date("m");
							$day         = date("d");
							$upload_path = "./uploads/vendor_label_report/" . "$year/$month/$day/";
							if (!is_dir($upload_path)) {
							  mkdir($upload_path, 0755, true);
							}
							$destination_path = $upload_path.$awb_number.".pdf";
							$output = base64_decode($source_url);
							if (file_put_contents($destination_path, $output)) {
								$data_order = array(
								  'dtdc_label_url' => $destination_path,
								  'updated_at' => date('Y-m-d H:i:s')
								);
								$this->db->where('slot_no', $slot_no);
								$this->db->update('vendor_shipping_label', $data_order);
								$check_label = '1';
							}
						}
					}
				}
            }
		}
		$resultdata = array(
			'status' => 200,
			'message' => 'Success'
		);
		simple_json_output($resultdata);
	}

    public function generate_shipping_label_sq_dtdc()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $slot_nos = $params['slot_no'];

                if (!empty($slot_nos)) {
                    $check_label = '0';
                    foreach ($slot_nos as $slot_no) {
                        $shipping_sql = $this->pdf_model->get_shipping_label_dtdc_limit_1($slot_no);
                        $pass         = 0;
                        $courier='';
                        $awb_number='';
                        if ($shipping_sql->num_rows() > 0) {
                            $shipping_label = $shipping_sql->row();
                            $awb_number=$shipping_label->awb_number;
                            if ($shipping_label->dtdc_label_url == '' && $shipping_label->dtdc_label_url == NULL) {
                                $pass = 1;
                            } else {
                                $pass = 0;
                            }
                        } else {
                            $pass = 1;
                        }

                        if ($pass == 1) {
							$curl = curl_init();
						    curl_setopt_array($curl, array(
								CURLOPT_URL => 'https://dtdcapi.shipsy.io/api/customer/integration/consignment/label/multipiece',
								CURLOPT_RETURNTRANSFER => true,
								CURLOPT_MAXREDIRS => 10,
								CURLOPT_FOLLOWLOCATION => true,
								CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								CURLOPT_CUSTOMREQUEST => 'POST',
								CURLOPT_POSTFIELDS => "{\"reference_number\":\"$awb_number\"}",
								CURLOPT_HTTPHEADER => array(
								  'content-type: application/json',
								  'api-key: 9820bacb9c50f0ae71b1a6ce43e5d0'
								),
						    ));
							$response = curl_exec($curl);
							curl_close($curl);
							$dtdc_arr = json_decode($response);

                            if($dtdc_arr->status=='OK'){
                                if($dtdc_arr->data){
                                  if ($dtdc_arr->data[0]->label) {
										$source_url = $dtdc_arr->data[0]->label;
										date_default_timezone_set('Asia/Kolkata');
										$year        = date("Y");
										$month       = date("m");
										$day         = date("d");
										$upload_path = "./uploads/vendor_label_report/" . "$year/$month/$day/";
										if (!is_dir($upload_path)) {
										  mkdir($upload_path, 0755, true);
										}
										$destination_path = $upload_path.$awb_number.".pdf";
										//copy($source_url, $destination_path);
										$output = base64_decode($source_url);
										if (file_put_contents($destination_path, $output)) {
											$data_order = array(
											  'dtdc_label_url' => $destination_path,
											  'updated_at' => date('Y-m-d H:i:s')
											);
											$this->db->where('slot_no', $slot_no);
											$this->db->update('vendor_shipping_label', $data_order);
											$check_label = '1';
										}
									}
									$check_label = '1';
                                }
                            }
                            else{
                                $check_label = '0';
                            }
                        }
                    }

                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping bill already generated!'
                        );
                    }
                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function generate_shipping_label_sq()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $slot_nos = $params['slot_no'];
			    $check_provider = $this->pdf_model->check_shipping_label_provider($slot_nos,'self');
				 if($check_provider==false){
					   json_output(400, array(
							'status' => 400,
							'message' => 'All orders shipment provider must be in Self'
						));
				 }
				 else{
					if (!empty($slot_nos)) {
						$check_label = '0';
						foreach ($slot_nos as $slot_no) {
							$shipping_sql = $this->pdf_model->get_shipping_label($slot_no);
							$pass         = 0;
										$courier='';
										$awb_number='';
							if ($shipping_sql->num_rows() > 0) {
								$shipping_label = $shipping_sql->row();

											$courier=$shipping_label->courier;
											$awb_number=$shipping_label->awb_number;

								if ($shipping_label->label_url == '' && $shipping_label->label_url == NULL) {
									$pass = 1;
								} else {
									if (!file_exists(FCPATH . $shipping_label->label_url)) {
										$this->pdf_model->get_blank_vendor_shipping($slot_no, $shipping_label->label_url);
										$pass = 1;
									} else {
										$pass = 0;
									}
								}
							} else {
								$pass = 1;
							}

							if ($pass == 1) {

								$data    = array();
								$curl    = curl_init();
								$url     = vendor_url() . "pdf_controller/generate_shipping_label";
								$user_id = $user_id;
								$slot_no = $slot_no;
								curl_setopt_array($curl, array(
									CURLOPT_URL => $url,
									CURLOPT_RETURNTRANSFER => true,
									CURLOPT_ENCODING => "",
									CURLOPT_MAXREDIRS => 10,
									CURLOPT_TIMEOUT => 50,
									CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
									CURLOPT_CUSTOMREQUEST => "POST",
									CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"slot_no\":[\"$slot_no\"]}",
									CURLOPT_HTTPHEADER => array(
										"auth-key: kirtibookapi",
										"cache-control: no-cache",
										"client-service: frontend-client",
										"content-type: application/json"
									)
								));

								$response = curl_exec($curl);
								curl_close($curl);
								$result = json_decode($response, TRUE);
								if ($result['status'] == 200) {
									$check_label = '1';
								} else {
									$check_label = '0';
								}
							}
						}

						if ($check_label == 1) {
							$resultdata = array(
								'status' => 200,
								'message' => 'Success'
							);
						} else {
							$resultdata = array(
								'status' => 400,
								'message' => 'Shipping bill already generated!'
							);
						}
						simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
             }
            }
        }
    }


    public function generate_product_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if (!empty($order_id)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);
                    if ($order->is_invoice == 0) {

                        $this->load->library('pdf');
                        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                        $html_content .= $this->pdf_model->fetch_invoice_report($order->id);
                        $paper_size = array(
                            0,
                            0,
                            750,
                            1050
                        );
                        $this->pdf->set_paper($paper_size);
                        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                        $this->pdf->load_html($html_content);
                        $this->pdf->render();
                        $pdfname = 'invoice_' . $order->order_number . '.pdf';

                        $this->pdf->stream($pdfname, array(
                            "Attachment" => 0
                        ));
                        $output = $this->pdf->output();

                        $year      = date("Y");
                        $month     = date("m");
                        $day       = date("d");
                        //The folder path for our file should be YYYY/MM/DD
                        $directory = "uploads/vendor_invoice_report/" . "$year/$month/$day/";

                        //If the directory doesn't already exists.
                        if (!is_dir($directory)) {
                            mkdir($directory, 0755, true);
                        }

                        $file_url = $directory . $pdfname;
                        if (file_put_contents($file_url, $output)) {
                            $this->pdf_model->update_invoice_generated($order->id, $file_url);
                        }
                        $check_label = 1;
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Invoice already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function generate_shipping_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if (!empty($order_id)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_url == NULL) {
                        if ($order->order_status == 'delivered') {
                            $inv_no = $this->pdf_model->update_user_invoice_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_user_invoice($order_id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'shipping_invoice_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/sk_vendor_user_invoice_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_user_invoice_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function generate_shipping_invoice_credit_note()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if ($order_id != '') {

                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_cn_url == NULL && $order->user_invoice != NULL) {
                        if ($order->order_status == 'cancelled') {
                            $inv_no = $this->pdf_model->update_user_invoice_cn_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_user_invoice_cn($order->id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'shipping_invoice_credit_note_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_user_invoice_cn_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_user_invoice_cn_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Credit Note Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Credit Note already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function generate_product_invoice_credit_note()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if ($order_id != '') {

                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->invoice_cn_url == NULL) {
                        if ($order->order_status == 'cancelled' || $order->order_status == 'applied_for_exchange') {
                            $inv_no = $this->pdf_model->update_invoice_cn_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_invoice_cn_report($order->id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'product_invoice_credit_note_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year  = date("Y");
                            $month = date("m");
                            $day   = date("d");

                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_invoice_cn_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_invoice_cn_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Product Invoice Credit Note Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Product Invoice Credit Note already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function test_download_shipping_invoice_by_order_id($order_id = '13')
    {
        $this->load->library('pdf');
        $this->load->library('zip');
        $this->load->model('pdf_model');
        // echo '1';
        // exit();

        $order = $this->order_model->get_order($order_id);

        $delivered_date = date('Y-m-d H:i:s', strtotime($order->delivered_date . ' + 0 day'));
        $inv_no         = $this->pdf_model->update_user_invoice_number($order_id);
        $this->load->library('pdf');
        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
        echo $html_content .= $this->pdf_model->fetch_invoice_cn_report($order->id);
        $paper_size = array(
            0,
            0,
            750,
            1050
        );
        $this->pdf->set_paper($paper_size);
        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
        $this->pdf->load_html($html_content);
        $this->pdf->render();
        $pdfname = 'shipping_invoice_' . $order->order_number . '.pdf';

        $this->pdf->stream($pdfname, array(
            "Attachment" => 0
        ));
        $output = $this->pdf->output();

        $year      = date("Y");
        $month     = date("m");
        $day       = date("d");
        //The folder path for our file should be YYYY/MM/DD
        $directory = "uploads/vendor_user_invoice_report/" . "$year/$month/$day/";

        //If the directory doesn't already exists.
        /*    if(!is_dir($directory)){ mkdir($directory, 0755, true);}

        $file_url=$directory.$pdfname;
        if(file_put_contents($file_url, $output)){
        $this->pdf_model->update_invoice_generated($order->id,$file_url);
        }
        unset($this->pdf);*/
    }



    public function generate_shipping_invoice_CI()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if ($order_id != '') {

                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_ci_url == NULL && ($order->price_total >= $order->refund_amount)) {
                        if ($order->order_status == 'cancelled' && $order->refunded_id != NULL) {
                            $inv_no = $this->pdf_model->update_user_invoice_ci_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_user_invoice_ci($order->id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'shipping_invoice_CI_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_user_invoice_ci_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_user_invoice_ci_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice CI Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice CI already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function manual_shipping_invoice_credit_note()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if ($order_id != '') {

                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_cn_url == NULL && $order->user_invoice != NULL) {
                        if ($order->order_status == 'delivered' && $order->refunded_id != NULL) {
                            $inv_no = $this->pdf_model->update_user_invoice_cn_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_user_invoice_cn($order->id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'manual_shipping_invoice_credit_note_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_user_invoice_cn_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_user_invoice_cn_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Credit Note Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Credit Note already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function manual_shipping_invoice_CI_()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if ($order_id != '') {

                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_ci_url == NULL && ($order->price_shipping >= $order->refund_amount)) {
                        if ($order->order_status == 'delivered' && $order->refunded_id != NULL) {
                            $inv_no = $this->pdf_model->update_user_invoice_ci_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_user_invoice_ci($order->id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'manual_shipping_invoice_CI_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_user_invoice_ci_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_user_invoice_ci_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice CI Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice CI already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }





    public function check_download_kirtibook_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params         = json_decode(file_get_contents('php://input'), TRUE);
                $user_id        = $params['user_id'];
                $vendor_invoice = $params['vendor_invoice'];

                $flag        = 0;
                $check_order = $this->pdf_model->check_kirtibook_invoice($vendor_invoice, $user_id);
                if ($check_order->num_rows() > 0) {
                    $order = $check_order->row();
                    if ($order->vendor_invoice == NULL) {
                        //generate cron
                        $flag = 0;
                    } else {
                        $flag = 1;
                    }
                } else {
                    $flag = 2;
                }


                if ($flag == 0) {
                    json_output(200, array(
                        'status' => 400,
                        'message' => 'Invoice Not Generated Yet'
                    ));
                } elseif ($flag == 2) {
                    json_output(200, array(
                        'status' => 400,
                        'message' => 'Invalid requests!'
                    ));
                } else {
                    json_output(200, array(
                        'status' => 200,
                        'message' => 'Invoice Generated Successfully'
                    ));
                }
            }
        }
    }


    public function download_kirtibook_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $inv     = $params['vendor_invoice'];
                $this->load->library('zip');


                $vendor_invoice_ = $this->pdf_model->get_order_vendor_invoice($inv, $user_id);
                if ($vendor_invoice_->num_rows() > 0) {
                    $vendor_invoice = $vendor_invoice_->row();
                    $filepath1      = vendor_download_url() . '/' . $vendor_invoice->invoice_url;
                    $this->zip->read_file($filepath1);

                    // Download
                    $filename = 'vendor_invoice_' . date('Ymdhis') . '.zip';
                    $this->zip->download($filename);
                }
            }
        }
    }



    public function manual_shipping_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if (!empty($order_id)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_url2 == NULL) {
                        if ($order->order_status == 'delivered') {
                            $inv_no = $this->pdf_model->update_user_invoice_number2($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->manual_fetch_user_invoice($order_id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'manual_shipping_invoice_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_user_invoice_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_user_invoice_generated2($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Manual Shipping Invoice Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Manual Shipping Invoice already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function generate_product_invoice_refresh()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if (!empty($order_id)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);
                    if ($order->is_invoice == 1 && $order->is_refresh == 0) {

                        $this->load->library('pdf');
                        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                        $html_content .= $this->pdf_model->fetch_invoice_report($order->id);
                        $paper_size = array(
                            0,
                            0,
                            750,
                            1050
                        );
                        $this->pdf->set_paper($paper_size);
                        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                        $this->pdf->load_html($html_content);
                        $this->pdf->render();
                        $pdfname = 'invoice_ref_' . $order->order_number . '.pdf';

                        $this->pdf->stream($pdfname, array(
                            "Attachment" => 0
                        ));
                        $output = $this->pdf->output();

                        $year      = date("Y");
                        $month     = date("m");
                        $day       = date("d");
                        //The folder path for our file should be YYYY/MM/DD
                        $directory = "uploads/vendor_invoice_report/" . "$year/$month/$day/";

                        //If the directory doesn't already exists.
                        if (!is_dir($directory)) {
                            mkdir($directory, 0755, true);
                        }

                        $file_url = $directory . $pdfname;
                        if (file_put_contents($file_url, $output)) {
                            $this->pdf_model->update_invoice_generated_refresh($order->id, $file_url);
                        }
                        $check_label = 1;
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Invoice already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function test_generate_product_invoice()
    {
        $user_id  = $params['user_id'];
        $order_id = '19';

        $check_label = '0';
        $this->load->library('pdf');
        $this->load->library('zip');

        $this->load->library('pdf');
        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
        $html_content .= $this->pdf_model->fetch_invoice_report($order_id);
        $paper_size = array(
            0,
            0,
            750,
            1050
        );
        $this->pdf->set_paper($paper_size);
        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
        $this->pdf->load_html($html_content);
        $this->pdf->render();
        $pdfname = 'invoice_' . $order->order_number . '.pdf';

        $this->pdf->stream($pdfname, array(
            "Attachment" => 0
        ));
        $output = $this->pdf->output();

    }









    public function generate_shipping_invoice_refresh()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if (!empty($order_id)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->user_invoice_url != NULL && $order->is_refresh == 0) {
                        if ($order->order_status == 'delivered') {
                            $inv_no = $this->pdf_model->update_user_invoice_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_user_invoice($order_id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'shipping_invoice_' . $order->order_number . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year  = date("Y");
                            $month = date("m");
                            $day   = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            //$directory = "uploads/vendor_user_invoice_report/"."$year/$month/$day/";

                            //If the directory doesn't already exists.
                            //if(!is_dir($directory)){ mkdir($directory, 0755, true);}

                            $file_url = $order->user_invoice_url;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_shipping_invoice_refresh($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function test_manual_shipping_invoice()
    {
        $user_id  = $params['user_id'];
        $order_id = '5670';
        $order    = $this->order_model->get_order($order_id);

        $check_label = '0';
        $this->load->library('pdf');
        $this->load->library('zip');

        $this->load->library('pdf');
        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
        $html_content .= $this->pdf_model->manual_fetch_user_invoice($order_id);
        $paper_size = array(
            0,
            0,
            750,
            1050
        );
        $this->pdf->set_paper($paper_size);
        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
        $this->pdf->load_html($html_content);
        $this->pdf->render();
        $pdfname = 'manual_shipping_invoice_' . $order->order_number . '.pdf';

        $this->pdf->stream($pdfname, array(
            "Attachment" => 0
        ));
        $output = $this->pdf->output();
    }



    public function test_generate_shipping_invoice_CI()
    {
        $user_id  = $params['user_id'];
        $order_id = '98761';
        $order    = $this->order_model->get_order($order_id);

        $check_label = '0';
        $this->load->library('pdf');
        $this->load->library('zip');

        $this->load->library('pdf');
        $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
       // $html_content .= $this->pdf_model->fetch_user_invoice_ci($order_id);
        $html_content .= $this->pdf_model->fetch_user_invoice_ci($order_id);
        $paper_size = array(
            0,
            0,
            750,
            1050
        );
        $this->pdf->set_paper($paper_size);
        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
        $this->pdf->load_html($html_content);
        $this->pdf->render();
        $pdfname = 'shipping_invoice_CI_' . $order->order_number . '.pdf';

        $this->pdf->stream($pdfname, array(
            "Attachment" => 0
        ));
        $output = $this->pdf->output();
    }


    public function manual_handling_credit_note()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];
                if ($order_id != '') {

                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');
                    $order = $this->order_model->get_order($order_id);

                    if ($order->vendor_cn_url == NULL && $order->vendor_invoice != NULL) {
                        if ($order->vendor_refund != NULL) {
                            $inv_no = $this->pdf_model->update_vendor_cn_number($order_id);

                            $this->load->library('pdf');
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/custom.css">';
                            $html_content .= $this->pdf_model->fetch_vendor_invoice_cn($order->id);
                            $paper_size = array(
                                0,
                                0,
                                750,
                                1050
                            );
                            $this->pdf->set_paper($paper_size);
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname = 'manual_vendor_invoice_credit_note_' . $inv_no . '.pdf';

                            $this->pdf->stream($pdfname, array(
                                "Attachment" => 0
                            ));
                            $output = $this->pdf->output();

                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/sk_vendor_invoice_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_vendor_invoice_cn_generated($order->id, $file_url);
                            }
                            $check_label = 1;
                        } else {
                            $check_label = 2;
                        }
                    } else {
                        $check_label = 1;
                    }


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else if ($check_label == 2) {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Credit Note Can only be generated after delivered!'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping Invoice Credit Note already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }




public function check_download_product_invoice(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $order_ids = $params['slot_no'];

                $flag = 0;

            
                $labels = array();
                foreach ($order_ids as $order_id) {
                    $order = $this->pdf_model->check_vorder_by_id($order_id);
                    if ($order->num_rows() > 0) {
                        //
                    } else {
                        $flag     = 1;
                        $labels[] = $order->row()->order_number;
                        //break;
                    }
                }

                if ($flag > 0) {
                    $all_labels = implode(",", $labels);

                    json_output(200, array(
                        'status' => 400,
                        'message' => 'Following Invoice Not Generated Yet-' . $all_labels
                    ));
                } else {
                    json_output(200, array(
                        'status' => 200,
                        'message' => 'Invoice Generated Successfully'
                    ));
                }
            }
        }
    }
	



	 public function download_product_invoice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $order_ids = $params['slot_no'];
                $this->load->library('zip');

                foreach ($order_ids as $order_id):
					$order = $this->pdf_model->get_order_by_id($order_id)->row();
					if($order->invoice_url!='' && $order->invoice_url!=NULL){
						$filepath1 = vendor_download_url().'/'.$order->invoice_url;
						$this->zip->read_file($filepath1);
					}
                endforeach;
                // Download
                $filename = 'invoice_' . date('Ymdhis') . '.zip';
                $this->zip->download($filename);
            }
        }
    }


  /*Bigship Starts*/
   public function generate_shipping_label_sq_bigship()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $slot_nos = $params['slot_no'];
				
				 $check_provider = $this->pdf_model->check_shipping_label_provider($slot_nos,'bigship');
				 if($check_provider==false){
					   json_output(400, array(
							'status' => 400,
							'message' => 'All orders shipment provider must be in Bigship'
						));
				 }
				 else{
					if (!empty($slot_nos)) {
						$check_label = '0';
						foreach ($slot_nos as $slot_no) {
							$shipping_sql = $this->pdf_model->get_shipping_label($slot_no);
							$pass = 0;
							$err_msg='Shipping bill already generated!';
							$courier='';
							$awb_number='';
							if ($shipping_sql->num_rows() > 0) {
								$shipping_label = $shipping_sql->row();

								$courier=$shipping_label->courier;
								$awb_number=$shipping_label->awb_number;
								if ($shipping_label->awb_number == '' && $shipping_label->awb_number == NULL) {
								   $pass = 0;
								   $err_msg='AWB Number is blank, Can not proceed!';
								}
								elseif ($shipping_label->bigship_label_url == '' && $shipping_label->bigship_label_url == NULL) {
									$pass = 1;
								} else {
									if (!file_exists(FCPATH . $shipping_label->label_url)) {
										$this->pdf_model->get_blank_vendor_shipping($slot_no, $shipping_label->label_url);
										$pass = 1;
									} else {
										$pass = 0;
									}
								}
							} else {
								$pass = 0;
								$err_msg='Order not assigned to Bigship';
							}

							if ($pass == 1) {

								$data    = array();
								$curl    = curl_init();
								$url     = vendor_url() . "pdf_controller/generate_shipping_label_bigship";
								$user_id = $user_id;
								$slot_no = $slot_no;
								curl_setopt_array($curl, array(
									CURLOPT_URL => $url,
									CURLOPT_RETURNTRANSFER => true,
									CURLOPT_ENCODING => "",
									CURLOPT_MAXREDIRS => 10,
									CURLOPT_TIMEOUT => 50,
									CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
									CURLOPT_CUSTOMREQUEST => "POST",
									CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"slot_no\":[\"$slot_no\"]}",
									CURLOPT_HTTPHEADER => array(
										"auth-key: kirtibookapi",
										"cache-control: no-cache",
										"client-service: frontend-client",
										"content-type: application/json"
									)
								));

								$response = curl_exec($curl);
								curl_close($curl);
								$result = json_decode($response, TRUE);
								if ($result['status'] == 200) {
									$check_label = '1';
								} else {
									$check_label = '0';
								}
							}
						}

						if ($check_label == 1) {
							$resultdata = array(
								'status' => 200,
								'message' => 'Success'
							);
						} else {
							$resultdata = array(
								'status' => 400,
								'message' =>  $err_msg
							);
						}
						simple_json_output($resultdata);
					} else {
						json_output(400, array(
							'status' => 400,
							'message' => 'Enter required fields'
						));
					}
				}
            }
        }
    }
	
	
	 public function generate_shipping_label_bigship() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $slot_no = $params['slot_no'];
                if (!empty($slot_no)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');

                    foreach ($slot_no as $shipping_no):
                        $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
                        if ($shipping_label->num_rows() > 0) {
                            $row = $shipping_label->row();
                            if ($row->barcode_awb_url == NULL) {
                                $this->pdf_model->get_picqer_barcode($row->awb_number , $row->id,'barcode_awb_url');
                            }
                        }


                        $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

                        if ($row->label_url == NULL) {
                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
                            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no,'bigship');

                            $this->load->library('pdf');
                            $this->pdf->set_paper("A4", "portrait");
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
                            //$this->pdf->stream($pdfname, array("Attachment"=>0));
                            $output    = $this->pdf->output();
                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            //The folder path for our file should be YYYY/MM/DD
                            $directory = "uploads/vendor_label_report/" . "$year/$month/$day/";

                            //If the directory doesn't already exists.
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;
                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_label_bighsip_generated($shipping_no, $file_url);
                            }
                            unset($this->pdf);
                            $check_label = '1';
                        }
                    endforeach;


                    if ($check_label == 1) {
                        $resultdata = array(
                            'status' => 200,
                            'message' => 'Success'
                        );
                    } else {
                        $resultdata = array(
                            'status' => 400,
                            'message' => 'Shipping bill already generated!'
                        );
                    }

                    simple_json_output($resultdata);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
	
	 public function check_download_shipping_label_bigship()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];	
				$check_provider = $this->pdf_model->check_shipping_label_provider($process_slot,'bigship');
				if($check_provider==false){
					   json_output(400, array(
							'status' => 400,
							'message' => 'All orders shipment provider must be in Bigship'
						));
				 }
				 else{
					$flag = 0;

					$labels = array();
					foreach ($process_slot as $shipping_no) {
						$order = $this->order_model->check_shipping_label_bigship($shipping_no);
						if ($order > 0) {
							//
						} else {
							$flag     = 1;
							$labels[] = $shipping_no;
							//break;
						}
					}

					if ($flag > 0) {
						$all_labels = implode(",", $labels);

						json_output(200, array(
							'status' => 400,
							'message' => 'Following Bigship Shipping Invoice Not Generated Yet-' . $all_labels
						));
					} else {
						json_output(200, array(
							'status' => 200,
							'message' => 'Bigship Shipping Invoice Generated Successfully'
						));
					}
				}
            }
        }
    }
	
  public function download_shipping_label_bigship() {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params       = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $process_slot = $params['slot_no'];
                $this->load->library('zip');

                foreach ($process_slot as $shipping_no):
                    $order = $this->pdf_model->get_shipping_label($shipping_no)->row();
                    if ($order->bigship_label_url != '' && $order->bigship_label_url != NULL) {
                        $filepath1 = vendor_download_url() . '/' . $order->bigship_label_url;
                        $this->zip->read_file($filepath1);
                    }
                endforeach;
                // Download
                $filename = 'Label_' . date('Ymdhis') . '.zip';
                $this->zip->download($filename);
            }
        }
    }

	
	public function test_picqer_qr()  {
        $code='3401032288';
        $id='209';
        $field='barcode_awb_url';
        $html_content= $this->pdf_model->get_picqer_barcode($code, $id, $field);

        echo $html_content;
    }

	
  /*Bigship Ends*/

}
