<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Packaging_material_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('packaging_material_model');
    }
    
   

    public function packaging_materials()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['keyword']      = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->packaging_material_model->get_paginated_stock_allocate($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function packaging_materials_history()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['id']           = $params['id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['keyword']      = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->packaging_material_model->packaging_materials_history($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
}