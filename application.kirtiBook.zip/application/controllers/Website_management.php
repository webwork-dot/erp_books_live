<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Website_management extends CI_Controller
{
     function __construct()
    {
        parent::__construct();
        $this->load->model('website_management_model');
    }
    
    public function get_publisher_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_publisher_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_publisher_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_publisher_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_publisher()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('publisher','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Publisher Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_publisher($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_publisher()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('publisher','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Publisher Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_publisher($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function publisher_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->publisher_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_board_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_board_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_board_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_board_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_board()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                $data['slug'] = str_slug($params["name"]);
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('board','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Board Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_board($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_board()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                $data['slug'] = str_slug($params["name"]);
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('board','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Board Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_board($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function board_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->board_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_subject_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_subject_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_subject_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_subject_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_subject()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('subject','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Subject Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_subject($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_subject()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('subject','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Subject Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_subject($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function subject_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->subject_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_grade_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_grade_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_grade_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_grade_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_grade()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                $data['sort']       = $params['sort'];
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('grade_list','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Grade Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_grade($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_grade()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                $data['sort']       = $params['sort'];
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('grade_list','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Grade Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_grade($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function grade_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->grade_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_brand_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_brand_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_brand_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_brand_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_brand()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('brand','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Brand Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_brand($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_brand()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('brand','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Brand Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_brand($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function brand_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->brand_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_binding_type_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_binding_type_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_binding_type_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_binding_type_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_binding_type()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('binding_type','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Binding Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_binding_type($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_binding_type()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('binding_type','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Binding Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_binding_type($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function binding_type_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->binding_type_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_categories_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_categories_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_categories_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_categories_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_categories()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                $data['parent_id']       = $params['parent_id'];
                $data['title_meta_tag']       = $params['name'];
                $data['description']       = $params['name'];
                $data['keywords']       = $params['name'];
				$data['slug'] = str_slug($params["name"]);
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('categories','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Category Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_categories($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_categories()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
                $data['parent_id']       = $params['parent_id'];
				$data['title_meta_tag']       = $params['name'];
                $data['description']       = $params['name'];
                $data['keywords']       = $params['name'];
				$data['slug'] = str_slug($params["name"]);
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('categories','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Category Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_categories($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function categories_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->categories_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_subcategories_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_subcategories_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_subcategories_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_subcategories_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_category_by_parent(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_category_by_parent($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }   
    
    public function get_size_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '') {
                    $response = $this->website_management_model->get_size_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_size_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->get_size_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_size()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $user_id  = $params['user_id'];
                $data['name']        = $params['name'];
                $data['category_id'] = '10';
                
                if($data['name']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('size','name',$data['name'],'','on_create')){
                   json_output(400, array( 'status' => 400, 'message' => 'Size Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->add_size($data,$user_id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function edit_size()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                $id  = $params['id'];
                $user_id  = $params['user_id'];
                $data['name']       = $params['name'];
				$data['category_id'] = '10';
                
                if($data['name']=='' && $id==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Please Enter Name'));
                } else if($this->website_management_model->check_duplicate_entry('size','name',$data['name'],$id,'on_update')){
                   json_output(400, array( 'status' => 400, 'message' => 'Size Name already exist!'));
                }  
                else {
                   $response = $this->website_management_model->edit_size($data,$user_id,$id);
                   simple_json_output($response);
                }
           }
        }
    }
    
    public function size_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->website_management_model->size_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
}    