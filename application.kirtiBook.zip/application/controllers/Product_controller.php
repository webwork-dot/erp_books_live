<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product_controller extends CI_Controller
{
     function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
        $this->load->model('product_master_model');
    }
    
    
    // Books -> School Text Book Starts
    public function add_product_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']       = $params['user_id'];
            $data['master_id']       = $params['master_id'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['base_price']      = $params['base_price'];
            $data['discount_price']    = $params['price'];
            
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            
            
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');
            
            $data['created_at']    =  date('Y-m-d H:i:s');
            
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['model_number']=='' &&  $data['min_quantity']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['base_price']=='' ){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_post($data,$warehouse, $quantity);
           simple_json_output($response);
        }
       }
     }
    }
    
    public function add_product_other_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']       = $params['user_id'];
            $data['master_id']       = $params['master_id'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['base_price']      = $params['base_price'];
            $data['discount_price']    = $params['price'];
            
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');	
            
            
            $data['created_at']    =  date('Y-m-d H:i:s');
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['model_number']=='' &&  $data['min_quantity']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['base_price']=='' ){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_other_post($data,$warehouse, $quantity);
           simple_json_output($response);
        }
       }
     }
    }
    
    public function edit_product_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            
            $data['user_id']       = $params['user_id'];
            $product_id       = $params['product_id'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['base_price']      = $params['base_price'];
            $data['discount_price']    = $params['price'];
            
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            
            
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            
            
            
            $data['last_modified']    =  date('Y-m-d H:i:s');
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'], $product_id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['model_number']=='' &&  $data['min_quantity']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['base_price']=='' ){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->edit_product_post($data,$warehouse, $quantity,$product_id);
           simple_json_output($response);
        }
       }
     }
    }
    
   
          
    public function update_product_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['publisher_id']    = $params['publisher'];
            $data['board_id']    = implode(',', $params['board']); 
            $data['grade_id']    = (!empty($params['grades'])?  implode(',', $params['grades']):'');
            $data['subject_id']    = $params['subject'];
            $data['title']    = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
            
            $data['age_grade']     = $params['age_grade'];
            $data['from_age']      = $params['from_age'];
            $data['to_age']        = $params['to_age'];
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
            $id  = $params['id'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['publisher_id']=='' && $data['board_id']=='' && $data['grade_id']=='' &&  $data['subject_id']=='' && $data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_post($data,$category,$warehouse, $quantity,$id);
           simple_json_output($response);
        }
       }
     }
    }
      
 
    // Books -> School Text Book Ends    
    
    
    
 public function get_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_uniform_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_uniform_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_educational_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                $filter['is_delete']  = $params['is_delete'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_educational_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_educational_service_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['is_delete']  = $params['is_delete'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_educational_service_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_delete_uniform_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_delete_uniform_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }  
    
    public function get_all_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['status']  = $params['status'];
                
                if ($user_id != '') {
                    $response = $this->product_model->get_all_product_list($user_id,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_product_list_()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_product_list_($user_id,$category,$per_page,$offset,$filter);
                    // echo $this->db->last_query();
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_shoes_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_shoes_product_list($user_id,$category,$per_page,$offset,$filter);
                    // echo $this->db->last_query();
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_shoes_deleted_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_shoes_deleted_product_list($user_id,$category,$per_page,$offset,$filter);
                    // echo $this->db->last_query();
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_product_list_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = $params['category'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_product_list_delete($user_id,$category,$per_page,$offset,$filter);
                    // echo $this->db->last_query();
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    
   
   public function get_product_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_model->get_product_details($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_product_details_()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $parent_id   = $params['parent_id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_model->get_product_details_($user_id,$id,$parent_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function get_educational_product_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_model->get_educational_product_details($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function set_product_as_sold()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->set_product_as_sold($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function set_product_as_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->set_product_as_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function set_product_as_restore()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->set_product_as_restore($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function set_service_product_as_restore()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->set_service_product_as_restore($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function assign_school()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $school   = implode(',',$params['school']);
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->assign_school($user_id,$id,$school);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
     // Books -> Others Book Starts
    public function add_product_other_book_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['publisher_id']    = $params['publisher'];
            $data['board_id']    = implode(',', $params['board']); 
            $data['grade_id']    = (!empty($params['grades'])?  implode(',', $params['grades']):'');
            $data['subject_id']    = $params['subject'];
            $data['title']    = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
            
            $data['age_grade']     = $params['age_grade'];
            $data['from_age']      = $params['from_age'];
            $data['to_age']        = $params['to_age'];
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            if($data['staff_id'] == 0){
                $data['last_user_id']    =  $data['user_id'] ;
            }else{
                $data['last_user_id']    =  $data['staff_id'] ;
            }
            
            $data['last_modified']    =  date('Y-m-d H:i:s');
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['publisher_id']=='' && $data['board_id']=='' && $data['grade_id']=='' &&  $data['subject_id']=='' && $data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_other_book_post($data,$category,$warehouse, $quantity);
           simple_json_output($response);
        }
       }
     }
    }
    
   
          
    public function update_product_other_book_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['publisher_id']    = $params['publisher'];
            $data['board_id']    = implode(',', $params['board']); 
            $data['grade_id']    = (!empty($params['grades'])?  implode(',', $params['grades']):'');
            $data['subject_id']    = $params['subject'];
            $data['title']    = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
            
            $data['age_grade']     = $params['age_grade'];
            $data['from_age']      = $params['from_age'];
            $data['to_age']        = $params['to_age'];
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
            $id  = $params['id'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['publisher_id']=='' && $data['board_id']=='' && $data['grade_id']=='' &&  $data['subject_id']=='' && $data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_other_book_post($data,$category,$warehouse, $quantity,$id);
           simple_json_output($response);
        }
       }
     }
    }
      
 
    // Books -> Others Book Ends    
    
    
    
    
    
    
    
    
    
    
     // Books -> Others Note Starts
    public function add_product_note_book_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
           
            $data['user_id']    = $params['user_id'];
            $data['master_id']    = $params['master_id'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
   
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
           
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');	
            
            $data['created_at']    =  date('Y-m-d H:i:s');
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['min_quantity']=='' && $data['base_price']=='' && $data['discount_price']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_note_book_post($data,$warehouse, $quantity);
           simple_json_output($response);
        }
       }
     }
    }
    
   
          
    public function update_product_note_book_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['title']    = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
       
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
            $id  = $params['id'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_note_book_post($data,$category,$warehouse, $quantity,$id);
           simple_json_output($response);
        }
       }
     }
    }
      
 
    // Books -> Note Book Ends    
    
     
    
     // Uniform Starts
    public function add_product_uniform_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']         = $params['user_id'];
            $data['title']           = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']          = $params['lenght'];
            $data['width']           = $params['width'];
            $data['height']          = $params['height'];
            $data['weight']          = $params['weight'];
            
            $data['gst']             = $params['gst'];
            $data['uniform_cat']     = $params['uniform_cat'];
            $data['category_id']     = $params['category'];
            $data['hsn']             = $params['hsn'];
            $data['meta_title']      = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']= $params['meta_description'];
            
            $data['is_bookset']    ='0';
            $data['is_individually'] = '1';
            $data['is_exchange']     = '1';
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            $data['size']            =  implode(',', $params['size']); 
            $data['school']          = $params['school'];
            $data['product_origin']  = $params['product_origin'];
            $data['gender']          = $params['gender'];
            $data['color_id']        = $params['color'];
            $data['board_id']        = $params['board_id'];
            
            date_default_timezone_set('Asia/Kolkata');
            
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');	
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
            $category  = $params['uniform_cat'];
            $stock_data  = $params['stock_data'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($params['size']=='' && !isset($params['school'])  && $data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_uniform_post($data,$category,$stock_data);
           simple_json_output($response);
        }
       }
     }
    }
    
    
    
   
          
    public function update_product_uniform_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
             if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']    = $params['user_id'];
            $data['title']    = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
          
            
            $data['gst']    = $params['gst'];
            //$data['uniform_cat']    = $params['uniform_cat'];
            //$data['category_id']    = $params['category'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
            
   
           
   
            $data['is_bookset']    ='0';
            $data['is_individually'] = '1';
            $data['is_exchange']     = '1';
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            //$data['size']    =  implode(',', $params['size']); 
            $data['school']  = $params['school'];
            $data['product_origin']  = $params['product_origin'];
            $data['gender']  = $params['gender'];
            $data['color_id']  = $params['color'];
            $data['board_id']  = $params['board_id'];
            
            date_default_timezone_set('Asia/Kolkata');
             if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            
            
            $data['last_modified']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
            $category  = $params['uniform_cat'];
            $stock_data  = $params['stock_data'];
            $product_id  = $params['id'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$product_id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($params['size']=='' && !isset($params['school'])  && $data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_uniform_post($data,$category,$stock_data,$product_id);
           simple_json_output($response);
        }
       }
     }
    }
      
 
    // Uniform Ends    
    
    // Educational Products Start    
    
    public function add_educational_services_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        }else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                if (array_key_exists("staff_id",$params)){
                    $data['staff_id'] = $params['staff_id'];
                }
                else{
                    $data['staff_id'] = '0';
                }
                
                $data['user_id']    = $params['user_id'];
                $data['title']    = $params['title'];
                $data['product_description']    = $params['product_description'];
                $data['base_price']    = $params['base_price'];
                $data['discount_price']    = $params['price'];
                $data['gst']    = $params['gst'];
                $data['category_id']    = $params['category'];
                $data['meta_title']    = $params['meta_title'];
                $data['meta_keyword']    = $params['meta_keyword'];
                $data['meta_description']    = $params['meta_description'];
                $data['is_bookset']    ='0';
                $data['is_individually'] = '0';
                $data['is_exchange']     = '0';
                $data['is_service']     = '1';
                $data['base_price']     = '0';
                $data['gst']     = '0';
                $type_list    = $params['type_list'];
                $user_id    = $params['user_id'];
                
                date_default_timezone_set('Asia/Kolkata');
                
                if($data['staff_id'] == 0 ){
                     $data['last_user_id']    =  $data['user_id'];
                }else{
                    $data['last_user_id']    =  $data['staff_id'];
                }
                $data['last_modified']    =  date('Y-m-d H:i:s');
                $data['created_at']    =  date('Y-m-d H:i:s');
    	    	$data["slug"] = str_slug($params["title"]);
    	    	
                $category  = '261';

                    
                if($data['title']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
                }
                else {   
                    $response = $this->product_model->add_educational_services_post($data,$category,$type_list,$user_id);
                    simple_json_output($response);
                }
            }
        }
    }
    
    public function add_educational_product_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        }else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                
                if (array_key_exists("staff_id",$params)){
                    $data['staff_id'] = $params['staff_id'];
                }
                else{
                    $data['staff_id'] = '0';
                }
                
                $data['user_id']    = $params['user_id'];
                $data['title']    = $params['title'];
                $data['model_number']    = $params['sku'];
                $data['min_quantity']    = $params['min_quantity'];
                $data['product_description']    = $params['product_description'];
                $data['lenght']    = $params['lenght'];
                $data['width']    = $params['width'];
                $data['height']    = $params['height'];
                $data['weight']    = $params['weight'];
                $data['base_price']    = $params['base_price'];
                $data['discount_price']    = $params['price'];
                
                $data['age_grade']    = $params['age_group'];
              
                
                $data['gst']    = $params['gst'];
                $data['category_id']    = $params['category'];
                $data['hsn']    = $params['hsn'];
                $data['meta_title']    = $params['meta_title'];
                $data['meta_keyword']    = $params['meta_keyword'];
                $data['meta_description']    = $params['meta_description'];
                
       
               
       
                $data['is_bookset']    ='0';
                $data['is_individually'] = '1';
                $data['is_exchange']     = '1';
                $data['day_exchange']    = $params['day_exchange'];
                $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
                
               
                $data['product_origin']  = $params['product_origin'];
               
                date_default_timezone_set('Asia/Kolkata');
                
                if($data['staff_id'] == 0 ){
                     $data['last_user_id']    =  $data['user_id'];
                }else{
                    $data['last_user_id']    =  $data['staff_id'];
                }
                $data['last_modified']    =  date('Y-m-d H:i:s');	
                
                $data['created_at']    =  date('Y-m-d H:i:s');
    	    	$data["slug"] = str_slug($params["title"]);
                $category  = '262';
                $stock_data  = $params['stock_data'];
                    
                if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
                    json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
                }    
                elseif($data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['gst']==''){
                    json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
                }
                else {   
                    $response = $this->product_model->add_educational_product_post($data,$category,$stock_data);
                    simple_json_output($response);
                }
            }
        }
    }
    
    public function update_educational_product_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
             if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']    = $params['user_id'];
            $data['title']    = $params['title'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
                
            $data['age_grade']    = $params['age_group'];
          
            
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
            
   
           
   
           
            $data['is_individually'] = '1';
            $data['is_exchange']     = '1';
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
           
            $data['product_origin']  = $params['product_origin'];
          
            
            date_default_timezone_set('Asia/Kolkata');
             if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            
            
            $data['last_modified']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["title"]);
	    	$category  = '262';
            $stock_data  = $params['stock_data'];
            $product_id  = $params['id'];
                
            if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$product_id,'on_update')){
                json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
            }    
            elseif($data['title']==''  && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['gst']=='' && $data['base_price']=='' && $data['discount_price']==''){
                json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
            }
            else {
                $response = $this->product_model->update_educational_product_post($data,$category,$stock_data,$product_id);
                simple_json_output($response);
            }
        }
     }
    }
    
    
    
     // Books -> Stationery Starts
     
     
 public function get_stationery_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = '6';
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_stationery_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_stationery_product_delete_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = '6';
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                $filter['warehouse_id']  = $params['warehouse_id'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_stationery_product_delete_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    
     
     
    public function add_product_stationery_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['staff_id']    = $params['staff_id'];
            $data['user_id']    = $params['user_id'];
            $data['master_id']    = $params['master_id'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            
            if($params['staff_id'] == 0 ){
                 $data['last_user_id']    =  $params['user_id'];
            }else{
                $data['last_user_id']    =  $params['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');	
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['model_number']=='' && $data['base_price']=='' &&  $data['min_quantity']==''  && $data['discount_price']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_stationery_post($data,$warehouse, $quantity);
           simple_json_output($response);
        }
       }
     }
    }
    
    
    public function add_product_shoes_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']    = $params['user_id'];
            $data['master_id']    = $params['master_id'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            
           
            
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['size']    =  implode(',', $params['size']); 
            
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');	
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    
            
            $stock_data  = $params['stock_data'];
            
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['model_number']=='' && $data['base_price']=='' &&  $data['min_quantity']==''  && $data['discount_price']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_shoes_post($data,$stock_data);
           simple_json_output($response);
        }
       }
     }
    }
    
    public function update_product_shoes_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            if (array_key_exists("staff_id",$params)){
                $data['staff_id'] = $params['staff_id'];
            }
            else{
                $data['staff_id'] = '0';
            }
            
            $data['user_id']    = $params['user_id'];
           
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['day_exchange']    = $params['day_exchange'];
            
            
            if($data['staff_id'] == 0 ){
                 $data['last_user_id']    =  $data['user_id'];
            }else{
                $data['last_user_id']    =  $data['staff_id'];
            }
            $data['last_modified']    =  date('Y-m-d H:i:s');	
            
	         $product_id    = $params['product_id'];
            
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['model_number']=='' && $data['base_price']=='' &&  $data['min_quantity']==''  && $data['discount_price']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_shoes_post($data,$product_id);
           simple_json_output($response);
        }
       }
     }
    }
    
   
          
    public function update_product_stationery_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['brand_id']    = $params['brand'];
            $data['stationery_id']    = $params['stationary_type'];
        
            $data['description']    = $params['description'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
      
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["description"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
            $id  = $params['id'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['brand_id']=='' && $data['stationery_id']=='' && $data['description']=='' && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_stationery_post($data,$category,$warehouse, $quantity,$id);
           simple_json_output($response);
        }
       }
     }
    }
      
 
    // Books -> Stationery Ends
    
    
    //product images Starts    
        
    
    public function upload_images()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
           
                $pid   = $this->input->post('pid');
                
                if ($pid== '') {
                  	  json_output(400, array( 'status' => 400, 'message' => 'error! while uploadding images!'));
                  }
                 else{ 
                    $response = $this->product_model->upload_images($pid);
                    simple_json_output($response);
                } 
            
        }
    } 
    
    
     
    
     public function product_image_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                
                if ($user_id != '' && $id != '') {
                    $response = $this->product_model->product_image_delete($id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
     
    
    // product images Ends    
    
    
       
    
    public function filter_school_text_book()  {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $filter['user_id'] = $params['user_id'];
                $filter['publisher'] = $params['publisher'];
                $filter['board']     = $params['board'];
                $filter['grades']    = $params['grades'];
                $filter['subject']   = $params['subject'];
                $filter['keywords']  = $params['keywords'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                
                if ($filter['keywords']=='' && $filter['publisher'] && $filter['board']  && $filter['grades']  && $filter['subject']) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please select atelast one search criteria!'
                    ));
                } else { 
                    $response = $this->product_master_model->get_filter_school_text_book($filter,$per_page,$offset);
                    simple_json_output($response);
                
                }
            }
        }
    } 
    
    
  public function get_product_master_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $parent_id   = $params['parent_id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_master_model->get_product_master_details($user_id,$id,$parent_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    
    
    
    
  public function get_product_stationary_master_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $parent_id   = $params['parent_id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_master_model->get_product_stationary_master_details($user_id,$id,$parent_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
   public function get_product_shoes_master_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $parent_id   = $params['parent_id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_master_model->get_product_shoes_master_details($user_id,$id,$parent_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }  
    
    
   
   
    
    
  public function get_product_toys_master_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $id   = $params['id'];
                $parent_id   = $params['parent_id'];
                
                if ($user_id != '' && $id!='') {
                    $response = $this->product_master_model->get_product_toys_master_details($user_id,$id,$parent_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    public function filter_note_book()  {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $filter['user_id']  = $params['user_id'];
                $filter['keywords']  = $params['keywords'];
                $filter['brand']  = $params['brand'];
                $per_page  = $params['per_page']; 
                $offset  = $params['offset'];
       
                 if ($filter['keywords']=='') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please enter one search criteria!'
                    ));
                } else { 
                    $response = $this->product_master_model->get_filter_note_book($filter,$per_page,$offset);
                    simple_json_output($response);
                }
            }
        }
    } 
     
    
    
    public function filter_other_book()  {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $filter['user_id'] = $params['user_id'];
                $filter['publisher'] = $params['publisher'];
                $filter['board']     = $params['board'];
                $filter['grades']    = $params['grades'];
                $filter['subject']   = $params['subject'];
                $filter['keywords']  = $params['keywords'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                
                if ($filter['keywords']=='' && $filter['publisher'] && $filter['board']  && $filter['grades']  && $filter['subject']) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please select atelast one search criteria!'
                    ));
                } else { 
                    $response = $this->product_master_model->get_filter_other_book($filter,$per_page,$offset);
                    simple_json_output($response);
                
                }
            }
        }
    } 
    
    
   
    
    public function filter_stationary()  {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $filter['user_id'] = $params['user_id'];
                $filter['brand_id'] = $params['brand'];
                $filter['stationary_id']     = $params['stationary_type'];
                $filter['keywords']  = $params['keywords'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                
                if ($filter['keywords']=='' && $filter['brand_id'] && $filter['stationary_id']) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please select atelast one search criteria!'
                    ));
                } else { 
                    $response = $this->product_master_model->get_filter_stationary($filter,$per_page,$offset);
                    simple_json_output($response);
                
                }
            }
        }
    }  
    
    public function filter_shoes()  {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $filter['user_id'] = $params['user_id'];
                $filter['category']     = $params['category'];
                $filter['brand_id']    = $params['brand'];
                $filter['color']   = $params['color'];
                $filter['keywords']  = $params['keywords'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                
                if ($filter['keywords']=='' && $filter['category']  && $filter['brand_id']  && $filter['color']) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please select atelast one search criteria!'
                    ));
                } else { 
                    $response = $this->product_master_model->get_filter_shoes($filter,$per_page,$offset);
                    simple_json_output($response);
                
                }
            }
        }
    } 
    
    
    
    
    
    public function filter_toys()  {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $filter['brand_id'] = $params['brand'];
                $filter['stationary_id']     = $params['stationary_type'];
                $filter['keywords']  = $params['keywords'];
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                
                if ($filter['keywords']=='' && $filter['brand_id'] && $filter['stationary_id']) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please select atelast one search criteria!'
                    ));
                } else { 
                    $response = $this->product_master_model->get_filter_toys($filter,$per_page,$offset);
                    simple_json_output($response);
                
                }
            }
        }
    }    
    
     // Books -> Toys Starts
     
     
 public function get_toys_product_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $category  = '155';
                $per_page  = $params['per_page'];
                $offset  = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                
                if ($user_id != '' && $category!='') {
                    $response = $this->product_model->get_toys_product_list($user_id,$category,$per_page,$offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    } 
    
    
     
     
    public function add_product_toys_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['brand_id']    = $params['brand'];
            $data['stationery_id']    = $params['stationary_type'];
        
            $data['description']    = $params['description'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
          
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["description"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],'','on_create')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['brand_id']=='' && $data['stationery_id']=='' && $data['description']=='' && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->add_product_toys_post($data,$category,$warehouse, $quantity);
           simple_json_output($response);
        }
       }
     }
    }
    
   
          
    public function update_product_toys_post()
    { 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
        $check_auth_client = $this->LoginModel->check_auth_client();
        if ($check_auth_client == true) {
            $params   = json_decode(file_get_contents('php://input'), TRUE);
            $data['user_id']    = $params['user_id'];
            $data['brand_id']    = $params['brand'];
            $data['stationery_id']    = $params['stationary_type'];
        
            $data['description']    = $params['description'];
            $data['model_number']    = $params['sku'];
            $data['min_quantity']    = $params['min_quantity'];
            $data['product_description']    = $params['product_description'];
            $data['lenght']    = $params['lenght'];
            $data['width']    = $params['width'];
            $data['height']    = $params['height'];
            $data['weight']    = $params['weight'];
            $data['no_of_pages']    = $params['pages'];
            $data['base_price']    = $params['base_price'];
            $data['discount_price']    = $params['price'];
            $data['gst']    = $params['gst'];
            $data['hsn']    = $params['hsn'];
            $data['meta_title']    = $params['meta_title'];
            $data['meta_keyword']    = $params['meta_keyword'];
            $data['meta_description']    = $params['meta_description'];
      
            $data['is_bookset']    =($params['is_bookset']!=''? $params['is_bookset']:'0');
            $data['is_individually'] = ($params['is_individually']!=''? $params['is_individually']:'0');
            $data['is_exchange']     = ($params['is_exchange']!=''? $params['is_exchange']:'0');
            $data['day_exchange']    = $params['day_exchange'];
            $data['highlights']      = (!empty($params['highlights'])? trim_and_return_json($params['highlights']):'[]'); ;
            
            $data['created_at']    =  date('Y-m-d H:i:s');
	    	$data["slug"] = str_slug($params["description"]);
            $category  = $params['category'];
            $warehouse  = $params['warehouse'];
            $quantity  = $params['quantity'];
            $id  = $params['id'];
                
          if($this->product_model->check_product_sku($data['model_number'],$data['user_id'],$id,'on_update')){
          json_output(400, array( 'status' => 400, 'message' => 'Product code already exist!'));
          }    
         elseif($data['brand_id']=='' && $data['stationery_id']=='' && $data['description']=='' && $data['model_number']=='' &&  $data['min_quantity']=='' && $data['product_description']=='' && $data['base_price']=='' && $data['discount_price']=='' && $data['gst']==''){
          json_output(400, array( 'status' => 400, 'message' => 'Enter all fields!.'));
        }
       else {
           $response = $this->product_model->update_product_toys_post($data,$category,$warehouse, $quantity,$id);
           simple_json_output($response);
        }
       }
     }
    }
      
 
    // Books -> Stationery Ends
    
   
    
    
    
    
    
    
    
    
}