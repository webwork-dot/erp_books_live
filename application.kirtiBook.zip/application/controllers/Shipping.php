<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Shipping extends CI_Controller{

    public function __construct(){
        parent::__construct(); 
        /*cache control*/
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');   
        $this->load->model('shipping_model');
    }

   
    public function bigship_token() {
        $this->shipping_model->bigship_token();
    }   
    
	public function bigship_assign_courier() {
      $this->shipping_model->bigship_assign_courier();
    }
	
	public function bigship_update_failed_awb_courier() {
      $this->shipping_model->bigship_update_failed_awb_courier();
    }  
    
	public function demo_bigship_get_courier_rates($id) {
      $this->shipping_model->demo_bigship_get_courier_rates($id);
    }

	public function bigship_tracking() {
      $this->shipping_model->bigship_tracking();
    }
	
	
	
	   
	
}
