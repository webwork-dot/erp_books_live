<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Order_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('order_model');
        $this->load->model('pdf_model');
    }

    public function orderform_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $order_id = $params['order_id'];

                if ($user_id != '' && $order_id!='') {
                    $response = $this->order_model->orderform_details($user_id,$order_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function all_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params   = json_decode(file_get_contents('php://input'), TRUE);
                $user_id  = $params['user_id'];
                $per_page = $params['per_page'];
                $offset   = $params['offset'];
                $filter['keyword'] = $params['keyword'];

                if ($user_id != '') {
                    $response = $this->order_model->all_order($user_id, $per_page, $offset,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function mark_delivered()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $slot_no = $params['slot_no'];
                if ($user_id != '') {
                    $response = $this->order_model->mark_delivered($user_id,$slot_no);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function process_order_scan_dtdc()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    $response = $this->order_model->process_order_scan_dtdc($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function process_order_scan()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    $response = $this->order_model->process_order_scan($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function process_ready_for_shipment()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Disabled'
                    ));
                    //$response = $this->order_model->process_ready_for_shipment($user_id,$order_array,$order_status);
                    //simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function process_ready_for_shipment_dtdc_app()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    //$response = $this->order_model->process_ready_for_shipment_dtdc($user_id,$order_array,$order_status);
                    $response = $this->order_model->process_ready_for_shipment($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function picked_dtdc_app()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    $response = $this->order_model->picked_dtdc_app($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function process_ready_for_shipment_dtdc()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Disabled'
                    ));
                    //$response = $this->order_model->process_ready_for_shipment_dtdc($user_id,$order_array,$order_status);
                    //simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function process_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    $response = $this->order_model->process_order_($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function pending_to_process_order()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if(empty($order_array)){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please, select atleast one order!'
                    ));

                }
                elseif ($user_id != '') {
                    $response = $this->order_model->pending_to_process_order($user_id,$order_array,$order_status);		
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }  

	public function pending_to_process_order_bighsip()    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if(empty($order_array)){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please, select atleast one order!'
                    ));

                }
                elseif ($user_id != '') {
                    $response = $this->order_model->pending_to_process_order_bigship($user_id,$order_array,$order_status); 				
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function pending_to_process_order_dtdc()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if(empty($order_array)){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please, select atleast one order!'
                    ));
                }
                elseif ($user_id != '') {

                    $response = $this->order_model->pending_to_process_order_dtdc($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function confirm_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_id = $params['order_id'];

                if ($user_id != '') {
                    $response = $this->order_model->confirm_order($user_id,$order_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function cancel_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_id = $params['order_id'];
                $cancel_reason = $params['cancel_reason'];
                $otp = $params['otp'];

                if ($user_id != '') {
                    $response = $this->order_model->cancel_order($user_id,$order_id,$cancel_reason,$otp);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function pending_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword'] = $params['keyword'];
                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($user_id != '') {
                    $response = $this->order_model->pending_order($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function proccess_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $id               = $params['id'];
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword'] = $params['keyword'];


                if ($user_id != '') {
                    $response = $this->order_model->proccess_order($id,$user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
	
	

    public function slot_proccess_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword'] = $params['keyword'];
				
				if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }


                if ($user_id != '') {
                    $response = $this->order_model->slot_proccess_order($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function cancel_order_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword'] = $params['keyword'];
				
				if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }


                if ($user_id != '') {
                    $response = $this->order_model->cancel_order_list($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function pending_slot_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword']      = $params['keyword'];


                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{
                    $filter['start_end_date']  = array();
                }

                if (array_key_exists("source",$params)){
                    $source = $params['source'];
                }
                else{
                    $source = 'web';
                }
				
				if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($user_id != '') {
                    $response = $this->order_model->pending_slot_order($user_id,$per_page,$offset,$filter,$source);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function failed_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword']      = $params['keyword'];


                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{
                    $filter['start_end_date']  = array();
                }

                if (array_key_exists("source",$params)){
                    $source = $params['source'];
                }
                else{
                    $source = 'web';
                }
				
				if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  } 

                if ($user_id != '') {
                    $response = $this->order_model->failed_order($user_id,$per_page,$offset,$filter,$source);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function order_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $response = $this->order_model->order_details($user_id, $id);
                    json_outputs($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function failed_order_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $response = $this->order_model->failed_order_details($user_id, $id);
                    json_outputs($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function print_order_details_by_slot()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $order_type_ = $this->auth_model->get_shipping_label_order_type($id);
                    if ($order_type_ == 'Complaints') {
                        $response = $this->order_model->complaints_order_details_by_order_slot($id);
                    } else {
                        $response = $this->order_model->order_details_by_order_slot($id);
                    }

                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function order_shipping_details()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $response = $this->order_model->order_details($user_id, $id);
                    json_outputs($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function cancel_order_details()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $response = $this->order_model->cancel_order_details($user_id, $id);
                    json_outputs($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }


    public function download_shipping_bills_single()
    {
        $this->load->library('pdf');
        //$order_id = $this->input->post('order_id', true);
        //$order    = $this->order_model->get_order('25356');
        $html_content = '<link rel="stylesheet" href="https://vendor.kirtibook.in/assets/pdf/bootstrap.min.css">';
        $html_content .= '<link rel="stylesheet" href="https://vendor.kirtibook.in/assets/pdf/custom.css">';
        $html_content .= $this->pdf_model->fetch_shipping_bill_report_test('28');
        //$this->pdf->set_paper("A4", "portrait");
        $paper_size = array(
            0,
            0,
            750,
            1050
        );
        $this->pdf->set_paper($paper_size);
        $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
        $this->pdf->load_html($html_content);
        $this->pdf->render();
        $pdfname = 'test.pdf';

        $this->pdf->stream($pdfname, array(
            "Attachment" => 0
        ));
        $output = $this->pdf->output();
    }

    public function assign_order_slot($address_id,$warehouse_id,$order_id)
	{
	     $check_slot_no = $this->order_model->check_order_slot($address_id,$warehouse_id);
	        if($check_slot_no > 0){
	            $row=$this->order_model->get_order_type($order_id);
	            $vendor_id = $row['vendor_id'];
                if($row['order_type'] == 'bookset'){

                    $check_bookset_slot_no = $this->order_model->check_bookset_order_slot($address_id,$warehouse_id);
                    if($check_bookset_slot_no == 0){
                            $get_slot_no_ = $this->order_model->get_order_slot($address_id,$warehouse_id);
                            $order_slot_ = $get_slot_no_['order_slot'];

                            if($this->order_model->update_order_slot($order_id,$order_slot_)){
                                $resultpost = array(
                                    'status' => 200,
                                    'message' => 'success',
                                );
                                // return $resultpost;
                            }else{
                                $resultpost = array(
                                    'status' => 400,
                                    'message' => 'Error! Order must be in Proceesing status!',
                                );
                                // return $resultpost;
                            }

                    }else{
                            $single_ = $this->order_model->get_single_order_slot($order_id);
                            $slot_ = $single_['order_slot'];
                            if($slot_ =='' || $slot_ =='null'){
                                // $order_slot_1 = $order_id.'_'.token_6_digit();
                                $order_slot_1 = $this->create_order_slot($vendor_id);
                                if($this->order_model->update_order_slot($order_id,$order_slot_1)){
                                    $resultpost = array(
                                        'status' => 200,
                                        'message' => 'success',
                                    );
                                }
                                else{
                                    $resultpost = array(
                                        'status' => 400,
                                          'message' => 'Error! Order must be in Proceesing status!!',
                                    );
                                    // return $resultpost;
                                 }

                            }else{
                                $resultpost = array(
                                    'status' => 400,
                                     'message' => 'Error! Order must be in Proceesing status!!!',
                                );
                                // return $resultpost;
                            }
                    }
                }else{
                        $get_slot_no = $this->order_model->get_order_slot($address_id,$warehouse_id);
                        $order_slot_ = $get_slot_no['order_slot'];
                        if($this->order_model->update_order_slot($order_id,$order_slot_)){
                            $sql=$this->db->last_query();

                                $resultpost = array(
                                        'status' => 200,
                                        'message' => 'success',
                                    );
                                // return $resultpost;
                        }else{
                                $resultpost = array(
                                    'status' => 400,
                                    'message' => 'Error! Order must be in Proceesing status!',
                                );
                                // return $resultpost;
                            }
                }
            }else{
                // $order_slot = $order_id.'_'.token_6_digit();
                $row=$this->order_model->get_order_type($order_id);
	            $vendor_id = $row['vendor_id'];
                $order_slot = $this->create_order_slot($vendor_id);

                if($this->order_model->update_order_slot($order_id,$order_slot)){
                    $resultpost = array(
                                    'status' => 200,
                                    'message' => 'success',
                                  );

                    // return $resultpost;
                }else{
                        $resultpost = array(
                            'status' => 400,
                             'message' => 'Error! Order must be in Proceesing status!',
                        );

                }
            }

             return simple_json_output($resultpost);
	}

	public function create_order_slot($vendor_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date_created = date('Y-m-d H:i');

        $slot_series = $this->db->query("SELECT slot_series FROM `users` WHERE id='$vendor_id' LIMIT 1")->row()->slot_series;

        $check_inv_sql = $this->db->query("SELECT slot_no FROM `vendor_order_slot` WHERE vendor_id='$vendor_id' LIMIT 1");
        if ($check_inv_sql->num_rows() > 0) {
            $row          = $check_inv_sql->row();
            $last_slot_id = $row->slot_no;
        } else {
            $ini_number      = sprintf('%04d', '0');
            $last_slot_id = $slot_series . $ini_number;
        }

        $length=strlen(trim($slot_series));

        $invoice_id     = (int) substr($last_slot_id, $length); //this will remove KON
        $vendor_type    = $slot_series; // this will retuen KON
        $new_order_slot = $vendor_type . sprintf('%04d', $invoice_id + 1);

		$count = $this->db->get_where('vendor_order_slot', array(
                'vendor_id' => $vendor_id
        ))->num_rows();

        if ($count > 0) {
            $data['vendor_id']    = $vendor_id;
			$data['modified_date'] = $date_created;
			$data['slot_no']   = $new_order_slot;
			$this->db->where('vendor_id', $vendor_id);
			$this->db->update('vendor_order_slot', $data);
        } else {
            // if not found new_order_slot in table
            // insert new entry with new_order_slot
            $data['vendor_id']    = $vendor_id;
			$data['slot_date'] = $date_created;
			$data['slot_no']   = $new_order_slot;
			$this->db->insert('vendor_order_slot', $data);
        }

        return $new_order_slot;
    }

	public function otp_send_by_order_id()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $order_id     = $params['order_id'];
                if ($user_id != '' && $order_id !='') {
                    $response = $this->order_model->otp_send_by_order_id($user_id, $order_id);
                    simple_json_output($response);
                } else {
                    simple_json_output(array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }



    public function all_order_details()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $response = $this->order_model->all_order_details($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function get_orders_details_by_shupping_no()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $order_slot      = $params['order_slot'];
                if ($user_id != '') {
                    $response = $this->order_model->get_orders_details_by_shupping_no($user_id, $order_slot);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

    public function all_orders_by_school()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = 50;
                $offset                 = $params['offset'];
                $filter['keyword'] = $params['keyword'];

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if (array_key_exists("order_status",$params)){
                    $filter['order_status']  = $params['order_status'];
                }
                else{ $filter['order_status']  = array();  }

                if ($user_id != '') {
                    $response = $this->order_model->all_orders_by_school($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function all_orders_by_individual()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = 50;
                $offset                 = $params['offset'];
                $filter['keyword'] = $params['keyword'];

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if (array_key_exists("order_status",$params)){
                    $filter['order_status']  = $params['order_status'];
                }
                else{ $filter['order_status']  = array();  }

                if ($user_id != '') {
                    $response = $this->order_model->all_orders_by_individual($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function all_orders_mobile()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = 50;
                $offset                 = $params['offset'];
                $filter['keyword'] = $params['keyword'];

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if (array_key_exists("order_status",$params)){
                    $filter['order_status']  = $params['order_status'];
                }
                else{ $filter['order_status']  = array();  }




                if ($user_id != '') {
                    $response = $this->order_model->all_orders_mobile($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function all_orders()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = 50;
                $offset                 = $params['offset'];
                $filter['keyword'] = $params['keyword'];

                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if (array_key_exists("order_status",$params)){
                    $filter['order_status']  = $params['order_status'];
                }
                else{ $filter['order_status']  = array();  }


                if ($user_id != '') {
                    $response = $this->order_model->all_orders($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function all_proccess_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);

                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword'] = $params['keyword'];


                if ($user_id != '') {
                    $response = $this->order_model->all_proccess_order($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function exchange_pending_slot_order(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword']      = $params['keyword'];


                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }
				
				if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }



                if ($user_id != '') {
                    $response = $this->order_model->exchange_pending_slot_order($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

      public function back_to_pending_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    $response = $this->order_model->back_to_pending_order($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }




    public function all_complaints_pending_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = 'delivered';
                $filter['keyword']      = $params['keyword'];


                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("start_end_date",$params)){
                    $filter['start_end_date']  = $params['start_end_date'];
                }
                else{ $filter['start_end_date']  = array();  }
				
				if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }



                if ($user_id != '') {
                    $response = $this->order_model->all_complaints_pending_order($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function complaints_pending_to_process_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if(empty($order_array)){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Please, select atleast one order!'
                    ));

                }
                elseif ($user_id != '') {

                    $response = $this->order_model->complaints_pending_to_process_order($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

     public function back_to_process_order()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $order_array = $params['order_array'];
                $order_status     = $params['order_status'];
                if ($user_id != '') {
                    $response = $this->order_model->back_to_process_order($user_id,$order_array,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


     public function all_shipping_bills_details(){

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];
                if ($user_id != '') {
                    $response = $this->order_model->all_shipping_bills_details($user_id, $id);
                    json_outputs($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
	
	
     public function all_shipped_shipping_bills_details(){

        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id 	  = $params['user_id'];
                $warehouse_id = $params['warehouse_id'];
                $courier_id   = $params['courier_id'];
                if ($user_id != '') {
                    $response = $this->order_model->all_shipped_shipping_bills_details($user_id, $warehouse_id, $courier_id);
                    json_outputs($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }


     public function return_order_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['order_status'] = $params['order_status'];
                $filter['keyword'] = $params['keyword'];


                if ($user_id != '') {
                    $response = $this->order_model->return_order_list($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
	
	
	public function customer_invoice_order(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                $filter['courier_id']   = $params['courier_id'];
                $filter['warehouse_id'] = $params['warehouse_id'];
                $filter['order_status'] = 'delivered';
                $filter['keyword'] = $params['keyword'];
                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($user_id != '') {
                    $response = $this->order_model->customer_invoice_order($user_id, $per_page, $offset, $filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

}
