<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Request_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('request_model');
    }
    
    public function category_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $parent_id = $params['parent_id'];  
                
                if ($user_id != '') {
                    $response = $this->request_model->category_list($user_id,$parent_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function school_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                
                if ($user_id != '') {
                    $response = $this->request_model->school_list($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function order_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $order_status = $params['order_status'];  
                
                if ($user_id != '' && $order_status != '') {
                    $response = $this->request_model->order_list($user_id,$order_status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function add_product_request()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $type = 'product';  
                $category = $params['category'];  
                $sub_category = $params['sub_category'];  
                $message = $params['message'];  
                $title = $params['title'];  
                
                if ($user_id != '' && $type != '' && $category != '' && $title != '') {
                    $response = $this->request_model->add_product_request($user_id,$type,$category,$sub_category,$message,$title);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function upload_product_doc()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            
            $user_id = $this->input->post('user_id');
            $id = $this->input->post('id');
            
            if ($user_id == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'All fields are required!'
                ));
            } else {
                $response = $this->request_model->upload_product_doc($user_id,$id);
                simple_json_output($response);
            }
            
        }
    }
    
    public function add_school_request()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $type = 'school';    
                $school_type = $params['school_type'];  
                $school_name = $params['school_name'];  
                $school_for = $params['school_for'];  
                $board = $params['board'];  
                $school_id = $params['school_id'];  
                $school_status = $params['school_status'];  
                $message = $params['message']; 
                $title = $params['title']; 
                
                $error = 0;
                if(($school_type == 'New School' || $school_type == 'Edit School')){
                    if($school_name != '' && $school_for != ''  && $board != ''){
                        $error = 0; 
                    }else{
                        $error = 1; 
                    }
                }else if($school_type == 'School Status'){
                    if($school_id != '' && $school_status != ''){
                        $error = 0; 
                    }else{
                        $error = 2; 
                    }
                }
                
                if ($user_id != '' && $school_type != '' && $error == 0 && $title != '') {
                    $response = $this->request_model->add_school_request($user_id,$type,$school_type,$school_name,$school_for,$board,$school_id,$school_status,$message,$title);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'error' => $error,
                        'status' => 400,
                        'message' => 'Please Enter All Fields !!'
                    ));
                }
            }
        }
    }
    
    public function upload_school_doc()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            
            $user_id = $this->input->post('user_id');
            $id = $this->input->post('id');
            
            if ($user_id == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'All fields are required!'
                ));
            } else {
                $response = $this->request_model->upload_school_doc($user_id,$id);
                simple_json_output($response);
            }
            
        }
    }
    
    public function add_order_request()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $type = 'order';  
                $order_status = $params['order_status'];  
                $order_no = $params['order_no'];  
                $message = $params['message'];  
                $title = $params['title']; 
                
                if ($user_id != '' && $type != '' && $order_status != '' && $order_no != '' && $title != '') {
                    $response = $this->request_model->add_order_request($user_id,$type,$order_status,$order_no,$message,$title);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function add_account_request()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $type = 'accounts';  
                $accounts = $params['accounts'];  
                $message = $params['message'];  
                $title = $params['title']; 
                
                if ($user_id != '' && $type != '' && $accounts != '' && $title != '') {
                    $response = $this->request_model->add_account_request($user_id,$type,$accounts,$message,$title);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function add_profile_request()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $type = 'profile';  
                $profile = $params['profile'];  
                $message = $params['message']; 
                $title = $params['title'];
                
                if ($user_id != '' && $type != '' && $profile != '' && $title != '') {
                    $response = $this->request_model->add_profile_request($user_id,$type,$profile,$message,$title);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function request_log()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $per_page               = $params['per_page'];
                $offset                 = $params['offset'];
                
                if ($user_id != '') {
                    $response = $this->request_model->request_log($user_id,$per_page,$offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function request_log_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];  
                $id              = $params['id'];
                
                if ($user_id != '') {
                    $response = $this->request_model->request_log_details($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }
    
    public function request_log_reply()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id = $params['id'];
                $reply = $params['reply'];
                
                if ($user_id != '') {
                    $response = $this->request_model->request_log_reply($user_id,$id,$reply);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter Username or Password'
                    ));
                }
            }
        }
    }

}    