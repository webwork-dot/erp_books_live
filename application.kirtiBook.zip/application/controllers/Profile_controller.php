<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('profile_model');
    }
	
	public function get_national_courier()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
				$courier_type = $params['courier_type'];
				$product_type = $params['product_type'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_national_courier($user_id,$courier_type,$product_type);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
	
	public function update_courier_charges()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
				$id = $params['id'];
				$quantity = $params['quantity'];

                if ($user_id != '') {
                    $response = $this->profile_model->update_courier_charges($user_id,$id,$quantity);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function get_communication_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_communication_details_by_id($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function update_communication_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $data['company_name']   = $params['company_name'];
                $data['person_name']    = $params['person_name'];
                $data['address']        = $params['address'];
                $data['state_id']       = $params['state_id'];
                $data['city_id']        = $params['city_id'];
                $data['pincode']        = $params['pincode'];
                $data['contact_number'] = $params['contact_number'];
                $data['location']       = $params['location'];
                $data['lattitude']      = $params['lattitude'];
                $data['longitude']      = $params['longitude'];

                if ($user_id != '' && $data['company_name'] != '' && $data['person_name'] != '' && $data['address'] != '' && $data['state_id'] != '' && $data['city_id'] != '' && $data['pincode'] != '' && $data['contact_number'] != '') {
                    $response = $this->profile_model->update_communication_details($user_id, $data);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function get_billing_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_billing_details_by_id($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function update_billing_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $data['address']        = $params['address'];
                $data['state_id']       = $params['state_id'];
                $data['city_id']        = $params['city_id'];
                $data['state_name']     = $this->auth_model->get_state_name($params['state_id']);
                $data['city_name']      = $this->auth_model->get_city_name($params['city_id']);
                $data['pincode']        = $params['pincode'];
                $data['contact_number'] = $params['contact_number'];
                $data2['pan']           = strtoupper($params['pan']);
                $data2['gst']           = strtoupper($params['gst']);
                $data['location']       = $params['location'];
                $data['lattitude']      = $params['lattitude'];
                $data['longitude']      = $params['longitude'];

                if ($user_id != '' && $data2['pan'] != '' && $data2['gst'] != '' && $data['address'] != '' && $data['state_id'] != '' && $data['city_id'] != '' && $data['pincode'] != '' && $data['contact_number'] != '') {
                    $response = $this->profile_model->update_billing_details($user_id, $data, $data2);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }





    public function get_bank_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_bank_details_by_id($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function update_bank_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params             = json_decode(file_get_contents('php://input'), TRUE);
                $user_id            = $params['user_id'];
                $data['bank_id']    = $params['bank_id'];
                $data['branch']     = $params['branch'];
                $data['ifsc_code']  = $params['ifsc_code'];
                $data['account_no'] = $params['account_no'];

                if ($user_id != '' && $data['bank_id'] != '' && $data['branch'] != '' && $data['ifsc_code'] != '' && $data['account_no'] != '') {
                    $response = $this->profile_model->update_bank_details($user_id, $data);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function get_shipping_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_shipping_list($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function get_shipping_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];

                if ($user_id != '' && $id != '') {
                    $response = $this->profile_model->get_shipping_details_by_id($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function add_shipping_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $data['address']        = $params['address'];
                $data['landmark']       = $params['landmark'];
                $data['state_id']       = $params['state_id'];
                $data['city_id']        = $params['city_id'];
                $data['pincode']        = $params['pincode'];
                $data['contact_number'] = $params['contact_number'];
                $data['location']       = $params['location'];
                $data['lattitude']      = $params['lattitude'];
                $data['longitude']      = $params['longitude'];
                $data['name']      = $params['name'];

                if ($user_id != '' && $data['landmark'] != '' && $data['address'] != '' && $data['state_id'] != '' && $data['city_id'] != '' && $data['pincode'] != '' && $data['contact_number'] != '') {
                    $response = $this->profile_model->add_shipping_details($user_id, $data);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function update_shipping_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id                = $params['user_id'];
                $id                     = $params['id'];
                $data['address']        = $params['address'];
                $data['landmark']       = $params['landmark'];
                $data['state_id']       = $params['state_id'];
                $data['city_id']        = $params['city_id'];
                $data['pincode']        = $params['pincode'];
                $data['contact_number'] = $params['contact_number'];
                $data['location']       = $params['location'];
                $data['lattitude']      = $params['lattitude'];
                $data['longitude']      = $params['longitude'];
                $data['name']      = $params['name'];

                if ($user_id != '' && $id != '' && $data['landmark'] != '' && $data['address'] != '' && $data['state_id'] != '' && $data['city_id'] != '' && $data['pincode'] != '' && $data['contact_number'] != '') {
                    $response = $this->profile_model->update_shipping_details($user_id, $data, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function shipping_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];

                if ($user_id != '' && $id != '') {
                    $response = $this->profile_model->shipping_delete($user_id, $id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function get_vendor_documents()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_vendor_documents_by_id($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function get_vendor_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];


                if ($user_id != '') {
                    $response = $this->profile_model->get_vendors_by_id($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_vendor_details_()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $staff_id = (isset($params['staff_id'])? $params['staff_id']:'0');

                if ($user_id != '') {
                    $response = $this->profile_model->get_vendor_details($user_id,$staff_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function update_profile()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params            = json_decode(file_get_contents('php://input'), TRUE);

                $data['username']  = $params['username'];
                $data['email']     = $params['email'];
                $data['firm_name'] = $params['firm_name'];


                $staff_id = (isset($params['staff_id'])? $params['staff_id']:'0');
                if($staff_id == 0){
                    $user_id = $params['user_id'];
                }else{
                    $user_id = $staff_id;
                }

                if ($user_id == '' && $data['username'] == '' && $data['email'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
                }
                //is email unique
                elseif (!$this->LoginModel->is_unique_email($data['email'], $user_id)) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Email Duplication.'
                    ));
                } else {
                    $response = $this->profile_model->update_profile($user_id, $data);
                    simple_json_output($response);
                }
            }
        }
    }

    public function profile_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                $response = $this->profile_model->profile_details($user_id);
                simple_json_output($response);

            } else {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'Error! Email Duplication.'
                ));
            }
        }
    }


    public function change_password()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                   = json_decode(file_get_contents('php://input'), TRUE);

                $data['old_password']     = $params['old_password'];
                $data['password']         = $params['password'];
                $data['password_confirm'] = $params['password_confirm'];


                $staff_id = (isset($params['staff_id'])? $params['staff_id']:'0');
                if($staff_id == 0){
                    $user_id = $params['user_id'];
                }else{
                    $user_id = $staff_id;
                }


                if ($user_id == '' && $data['old_password'] == '' && $data['password'] == '' && $data['password_confirm'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
                } elseif ($data['password'] != $data['password_confirm']) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Password Mismatch!'
                    ));
                } else {
                    $response = $this->profile_model->change_password($user_id, $data);
                    simple_json_output($response);
                }
            }
        }
    }



    public function get_vendor_progress_for_dashboard()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_vendor_progress_for_dashboard($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_vendor_progress()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_vendor_progress($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }




    public function get_category_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_category_details_by_id($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_school_category()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_school_category($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }




    public function get_vendor_commission_category()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_vendor_commission_category($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function update_category_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params     = json_decode(file_get_contents('php://input'), TRUE);
                $user_id    = $params['user_id'];
                $categories = $params['categories'];


                if ($user_id == '' && empty($categories)) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'All fields are required!'
                    ));
                }

                elseif ($this->profile_model->check_vendor_commission($user_id)) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Category already defined!'
                    ));
                }

                else {
                    $response = $this->profile_model->update_category_details($user_id, $categories);
                    simple_json_output($response);
                }
            }
        }
    }




    public function upload_document_post()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {

            $user_id = $this->input->post('user_id');

            if ($user_id == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'All fields are required!'
                ));
            } else {
                $response = $this->profile_model->upload_document_details($user_id);
                simple_json_output($response);
            }

        }
    }




    public function add_school()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['vendor_id']      = $params['user_id'];
                $data['name']           = $params['name'];
                $data['board']          = implode(',', $params['board']);
                $data['category']       = 7;
                $data['strength']       = $params['strength'];
                $data['description']    = $params['description'];
                $data['affiliation_no'] = $params['affiliation_no'];
                $data['state_id']       = $params['state_id'];
                $data['city_id']        = $params['city_id'];
                $data['school_person']  = $params['school_person'];
                $data['school_email']   = $params['school_email'];
                $data['school_phone']   = $params['school_phone'];
                $data['address']        = $params['address'];
                $data['pincode']        = $params['pincode'];
                $data['location']       = $params['location'];
                $data['lattitude']      = $params['lattitude'];
                $data['longitude']      = $params['longitude'];
                $data['principal_name']      = $params['principal_name'];
                $data['principal_email']      = $params['principal_email'];
                $data['principal_phone']      = $params['principal_phone'];
                $data['status']         = 1;
                $data['pending']        = 1;
                $data['created_at']     = date('Y-m-d H:i:s');
	        	$data["slug"] = str_slug($params["name"]);

	        	if($params['school_password']!=''){
	        	    $data['password'] = md5($params['school_password']);
	        	}


                if ($data['name'] == '' && $data['board'] == '' && $data['description'] == '' && $data['affiliation_no'] == '' && $data['state_id'] == '' && $data['city_id'] == '' && $data['address'] == '' && $data['pincode'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->profile_model->add_school($data);
                    simple_json_output($response);
                }
            }
        }
    }





    public function update_school()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $id                     = $params['id'];
                $data['vendor_id']      = $params['user_id'];
                $data['name']           = $params['name'];
                $data['board']          = implode(',', $params['board']);
                $data['category']       = implode(',', $params['category']);
                $data['strength']       = $params['strength'];
                $data['description']    = $params['description'];
                $data['affiliation_no'] = $params['affiliation_no'];
                $data['state_id']       = $params['state_id'];
                $data['city_id']        = $params['city_id'];
                $data['school_person']  = $params['school_person'];
                $data['school_email']   = $params['school_email'];
                $data['school_phone']   = $params['school_phone'];
                $data['address']        = $params['address'];
                $data['pincode']        = $params['pincode'];
                $data['location']       = $params['location'];
                $data['lattitude']      = $params['lattitude'];
                $data['longitude']      = $params['longitude'];
                $data['principal_name']      = $params['principal_name'];
                $data['principal_email']      = $params['principal_email'];
                $data['principal_phone']      = $params['principal_phone'];
                $data['status']         = $params['school_status'];
                $data['pending']        = 1;
                $data['created_at']     = date('Y-m-d H:i:s');
	        	$data["slug"] = str_slug($params["name"]);

	        	if($params['school_password']!=''){
	        	    $data['password'] = md5($params['school_password']);
	        	} 
	        	else{
	        	    $data['password'] = md5(123456);
	        	}

                if ($id != '' && $data['name'] == '' && $data['board'] == '' && $data['description'] == '' && $data['affiliation_no'] == '' && $data['state_id'] == '' && $data['city_id'] == '' && $data['address'] == '' && $data['pincode'] == '' && $data['location'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->profile_model->update_school($data, $id);
                    simple_json_output($response);
                }
            }
        }
    }



    public function upload_school_images()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {

            $user_id = $this->input->post('user_id');
            $pid     = $this->input->post('pid');

            if ($user_id == '' && $pid == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'All fields are required!'
                ));
            } else {
                $response = $this->profile_model->upload_school_images($user_id, $pid);
                simple_json_output($response);
            }

        }
    }


    public function get_customer_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $filter['user_id'] = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];
                $filter['keyword']  = $params['keyword'];

                if ($filter['user_id'] != '') {
                    $response = $this->profile_model->get_customer_list($filter, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_school_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $filter['user_id'] = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];
                $filter['keyword']  = $params['keyword'];

                if (array_key_exists("status",$params)){
                    $filter['status']= $params['status'];
                }
                else{
                    $filter['status']='';
                }

                if ($filter['user_id'] != '') {
                    $response = $this->profile_model->get_school_list($filter, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function update_school_block()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $master_id  = $params['id'];
                $status   = $params['status'];

                if ($user_id != '' && $master_id != '') {
                    $response = $this->profile_model->update_school_block($user_id,$master_id,$status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function update_national_block()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $master_id  = $params['id'];
                $status   = $params['status'];

                if ($user_id != '' && $master_id != '') {
                    $response = $this->profile_model->update_national_block($user_id,$master_id,$status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function update_school_status()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params    = json_decode(file_get_contents('php://input'), TRUE);
                $user_id   = $params['user_id'];
                $master_id  = $params['id'];
                $status   = $params['status'];

                if ($user_id != '' && $master_id != '') {
                    $response = $this->profile_model->update_school_status($user_id,$master_id,$status);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_student_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $filter['user_id'] = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];
                $filter['keyword']  = $params['keyword'];
                if (array_key_exists("school",$params)){
                    $filter['school_id']  = $params['school'];
                }
                else{  $filter['school_id']  = array();  }

                if (array_key_exists("grade",$params)){
                    $filter['grade_id']  = $params['grade'];
                }
                else{ $filter['grade_id']  = array(); }

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($filter['user_id'] != '') {
                    $response = $this->profile_model->get_student_list($filter, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_school_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id      = $params['id'];

                if ($user_id != '' && $id) {
                    $response = $this->profile_model->get_school_details($id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function upload_vendor_logo()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {

            $pid = $this->input->post('pid');

            if ($pid == '') {
                json_output(400, array(
                    'status' => 400,
                    'message' => 'error! while uploadding images!'
                ));
            } else {
                $response = $this->profile_model->upload_vendor_logo($pid);
                //simple_json_output($response);
            }

        }
    }

    public function vendor_logo_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->vendor_logo_delete($user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



    public function get_product_by_category()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params      = json_decode(file_get_contents('php://input'), TRUE);
                $user_id     = $params['user_id'];
                $category_id = $params['category_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_product_by_category($user_id, $category_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function get_product_dprice()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params     = json_decode(file_get_contents('php://input'), TRUE);
                $user_id    = $params['user_id'];
                $product_id = $params['product_id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_product_dprice($product_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function add_new_package_simple()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']        = $params['user_id'];
                $data['board_id']       = $params['board_id'];
                $data['school_id']      = $params['school_id'];
                $data['grade_id']       = $params['grade_id'];
                $data['shipping_id']    = $params['shipping_id'];
                $data['category']       = $params['category'];
                $data['package_name']   = $params['package_name'];
                $data['package_price']  = $params['package_price'];
                $data['package_offer_price']  = $params['package_offer_price'];
                $data['package_gst']    = $params['package_gst'];
                $data['package_hsn']    = $params['package_hsn'];
                $data['is_it']          = $params['is_it'];
                $data['weight']         = $params['weight'];
                $data['note']           = $params['note'];
                $data['product']        = $params['product'];
                $data['minimum_package']        = $params['minimum_package'];
                //$data['package_status']   = $params['package_status'];
                $data['package_status']   = 1;
                $check = $this->auth_model->check_package_duplications($data['school_id'], $data['board_id'], $data['grade_id']);
                if ($check->num_rows() > 0) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Package duplication!!'
                    ));
                }
                elseif ($data['user_id'] == '' && $data['board_id'] == '' && $data['school_id'] == '' && $data['grade_id'] == '' && $data['shipping_id'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->profile_model->add_new_package_simple($data);
                    simple_json_output($response);
                }
            }
        }
    }

    public function add_new_package()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['user_id']        = $params['user_id'];
                $data['board_id']       = $params['board_id'];
                $data['school_id']      = $params['school_id'];
                $data['grade_id']       = $params['grade_id'];
                $data['shipping_id']    = $params['shipping_id'];
                $data['category']       = $params['category'];
                $data['package_name']   = $params['package_name'];
                $data['is_it']          = $params['is_it'];
                $data['weight']         = $params['weight'];
                $data['note']           = $params['note'];
                $data['product']        = $params['product'];
                $data['minimum_package']        = $params['minimum_package'];
                
                $check = $this->auth_model->check_package_duplications($data['school_id'], $data['board_id'], $data['grade_id']);
                
                if ($check->num_rows() > 0) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Package duplication!!'
                    ));
                }
                
                elseif ($data['user_id'] == '' && $data['board_id'] == '' && $data['school_id'] == '' && $data['grade_id'] == '' && $data['shipping_id'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->profile_model->add_new_package($data);
                    simple_json_output($response);
                }
            }
        }
    }
    
    public function update_package_simple()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['package_id']     = $params['package_id'];
                $data['user_id']        = $params['user_id'];
                $data['board_id']       = $params['board_id'];
                $data['school_id']      = $params['school_id'];
                $data['grade_id']       = $params['grade_id'];
                $data['shipping_id']    = $params['shipping_id'];
                $data['category']       = $params['category'];
                $data['package_category_id'] = $params['package_category_id'];
                $data['package_name']   = $params['package_name'];
                $data['package_price']  = $params['package_price'];
                $data['package_offer_price']  = $params['package_offer_price'];
                $data['package_gst']    = $params['package_gst'];
                $data['package_hsn']    = $params['package_hsn'];
                $data['is_it']          = $params['is_it'];
                $data['weight']         = $params['weight'];
                $data['note']           = $params['note'];
                $data['product']        = $params['product'];
                $data['minimum_package'] = $params['minimum_package'];
                $data['package_status'] = $params['package_status'];

                $check = $this->auth_model->check_package_duplications_on_update($data['school_id'], $data['board_id'], $data['grade_id'],$data['package_id']);

                if ($check->num_rows() > 0) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Package duplication!!'
                    ));
                }

                elseif ($data['package_id'] == '' && $data['user_id'] == '' && $data['board_id'] == '' && $data['school_id'] == '' && $data['grade_id'] == '' && $data['shipping_id'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->profile_model->update_package_simple($data);
                    simple_json_output($response);
                }
            }
        }
    }

    public function update_package()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $data['package_id']     = $params['package_id'];
                $data['user_id']        = $params['user_id'];
                $data['board_id']       = $params['board_id'];
                $data['school_id']      = $params['school_id'];
                $data['grade_id']       = $params['grade_id'];
                $data['shipping_id']    = $params['shipping_id'];
                $data['category']       = $params['category'];
                $data['package_category_id'] = $params['package_category_id'];
                $data['package_name']   = $params['package_name'];
                $data['package_price']  = $params['package_price'];
                $data['package_offer_price']  = $params['package_offer_price'];
                $data['package_gst']    = $params['package_gst'];
                $data['package_hsn']    = $params['package_hsn'];
                $data['is_it']          = $params['is_it'];
                $data['weight']         = $params['weight'];
                $data['note']           = $params['note'];
                $data['product']        = $params['product'];
                $data['minimum_package'] = $params['minimum_package'];
                $data['package_status'] = $params['package_status'];

                $check = $this->auth_model->check_package_duplications_on_update($data['school_id'], $data['board_id'], $data['grade_id'],$data['package_id']);

                if ($check->num_rows() > 0) {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error! Package duplication!!'
                    ));
                }

                elseif ($data['package_id'] == '' && $data['user_id'] == '' && $data['board_id'] == '' && $data['school_id'] == '' && $data['grade_id'] == '' && $data['shipping_id'] == '') {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter all fields!.'
                    ));
                } else {
                    $response = $this->profile_model->update_package($data);
                    simple_json_output($response);
                }
            }
        }
    }


    public function package_category_delete()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params     = json_decode(file_get_contents('php://input'), TRUE);
                $user_id    = $params['user_id'];
                $package_id = $params['package_id'];
                $package_category_id = $params['package_category_id'];

                if ($user_id != '' && $package_id!='' && $package_category_id!='') {
                    $response = $this->profile_model->package_category_delete_ajax($user_id,$package_id,$package_category_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_package_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $filter['user_id'] = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];
                $filter['keyword']  = $params['keyword'];

                if (array_key_exists("status",$params)){
                    $filter['status']= $params['status'];
                }
                else{
                    $filter['status']='';
                }

                if ($filter['user_id'] != '') {
                    $response = $this->profile_model->get_package_list($filter, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }
    
    public function get_package_list_simple()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $filter['user_id'] = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];
                $filter['keyword']  = $params['keyword'];

                if (array_key_exists("status",$params)){
                    $filter['status']= $params['status'];
                }
                else{
                    $filter['status']='';
                }

                if ($filter['user_id'] != '') {
                    $response = $this->profile_model->get_package_list_simple($filter, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_staff_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_staff_list($user_id,$per_page,$offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_staff_details()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id = $params['id'];

                if ($user_id != '') {
                    $response = $this->profile_model->get_staff_details($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function delete_staff()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $id = $params['id'];

                if ($user_id != '') {
                    $response = $this->profile_model->delete_staff($user_id,$id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function add_staff()
    {
        $this->load->library('bcrypt');
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $data['role']        = 'staff';
                $data['username']       = $params['username'];
                $data['email']       = $params['email'];
                $data['phone_number']        = $params['phone_number'];
                $data['password']        = $this->bcrypt->hash_password($params['password']);
                $data['vendor_aproval']        = '1';
                $data['banned']        = $params['banned'];
                $data['approve']        = '1';
                $data['access_manager']        = implode(',',$params['access_manager']);

                $check_staff_email = $this->auth_model->check_staff_email($user_id,$data['email'],'','on_create');
                $check_staff_mobile = $this->auth_model->check_staff_mobile($user_id,$data['phone_number'],'','on_create');
                if($check_staff_email == true){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error !! Email Id Already Exist'
                    ));
                }else if($check_staff_mobile == true){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error !! Contact Number Already Exist'
                    ));
                }
                else if ($user_id != '' && $data['username'] != '' && $data['email'] != '' && $data['phone_number'] != '' && $data['password'] != '' && $data['access_manager'] != '') {
                    $response = $this->profile_model->add_staff($user_id,$data);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error !!  Enter required fields'
                    ));
                }
            }
        }
    }

   public function update_staff()
    {
        $this->load->library('bcrypt');
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params                 = json_decode(file_get_contents('php://input'), TRUE);
                $user_id      = $params['user_id'];
                $staff_id = (isset($params['id'])? $params['id']:'0');
                $data['username']       = $params['username'];
                $data['email']       = $params['email'];
                $data['phone_number']        = $params['phone_number'];
                $data['banned']        = $params['banned'];
                $data['access_manager']        = implode(',',$params['access_manager']);

                $check_staff_email = $this->auth_model->check_staff_email($user_id,$data['email'],$staff_id,'on_update');
                $check_staff_mobile = $this->auth_model->check_staff_mobile($user_id,$data['phone_number'],$staff_id,'on_update');
                if($check_staff_email == true){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error !! Email Id Already Exist'
                    ));
                }else if($check_staff_mobile == true){
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error !! Contact Number Already Exist'
                    ));
                }
                else if ($user_id != '' && $data['username'] != '' && $data['email'] != '' && $data['phone_number'] != '' && $data['access_manager'] != '') {
                    $response = $this->profile_model->update_staff($staff_id,$data);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Error !!  Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_active_package_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $filter['user_id'] = $params['user_id'];
                $per_page          = $params['per_page'];
                $offset            = $params['offset'];
                $filter['keyword']  = $params['keyword'];

                if ($filter['user_id'] != '') {
                    $response = $this->profile_model->get_active_package_list($filter, $per_page, $offset);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_discount_list()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);

                $orderform_id = $params['orderform_id'];
                $user_id = $params['user_id'];

                if ($orderform_id != '' && $user_id != '') {
                    $response = $this->profile_model->get_discount_list($orderform_id,$user_id);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function update_discount_orderform()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params = json_decode(file_get_contents('php://input'), TRUE);


                $user_id = $params['user_id'];
                $discount_amt = $params['discount_amt'];
                $discount = $params['discount'];
                $discount_type = $params['discount_type'];
                $discount_cat = $params['discount_cat'];
                $orderform_id = $params['orderform_id'];
                $packages_ids = $params['packages_ids'];



                if ($orderform_id != '' && $user_id != '') {
                    $response = $this->profile_model->update_discount_orderform($user_id,$discount_amt,$discount,$discount_type,$discount_cat,$orderform_id,$packages_ids);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }


    public function get_shipping_count_list(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $filter['order_status'] = $params['order_status'];

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($user_id != '' && $filter['order_status']!='') {
                    $response = $this->profile_model->get_shipping_count_list($user_id,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_handed_dtdc_count_list(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $filter['order_status'] = $params['order_status'];

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($user_id != '' && $filter['order_status']!='') {
                    $response = $this->profile_model->get_handed_dtdc_count_list($user_id,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }

    public function get_dtdc_count_list(){
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array(
                'status' => 400,
                'message' => 'Bad request.'
            ));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $params  = json_decode(file_get_contents('php://input'), TRUE);
                $user_id = $params['user_id'];
                $filter['order_status'] = $params['order_status'];

                if (array_key_exists("academic_year",$params)){
                    $filter['academic_year']  = $params['academic_year'];
                }
                else{ $filter['academic_year']  = array();  }

                if ($user_id != '' && $filter['order_status']!='') {
                    $response = $this->profile_model->get_dtdc_count_list($user_id,$filter);
                    simple_json_output($response);
                } else {
                    json_output(400, array(
                        'status' => 400,
                        'message' => 'Enter required fields'
                    ));
                }
            }
        }
    }



}
