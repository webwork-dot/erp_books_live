<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {
  public function __construct()
  {
    parent::__construct();

    /*cache control*/
    $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    $this->output->set_header('Pragma: no-cache');
    date_default_timezone_set('Asia/Calcutta');
    $this->load->model('cron_model');
    $this->load->model('pdf_model');
  }

  public function check_out_for_delivery() {
      $this->cron_model->check_out_for_delivery();
  }

	public function check_delivered() {
		$this->cron_model->check_delivered();
	}

    public function generate_dtdc_label() {
        $this->cron_model->generate_dtdc_label();
    }

    public function generate_shipping_bill_new() {
        $this->cron_model->generate_shipping_bill_new();
    }
    
    public function generate_shipping_bill_new_2() {
        $this->cron_model->generate_shipping_bill_new_2();
    }
    
    public function generate_shipping_bill_new_3() {
        $this->cron_model->generate_shipping_bill_new_3();
    }

	public function generate_shipping_bill() {
        $this->cron_model->generate_shipping_bill();
    }

	public function generate_product_invoice() {
        $this->cron_model->generate_product_invoice();
    }

	public function generate_shipping_invoice() {
        $this->cron_model->generate_shipping_invoice();
    }

	public function generate_shipping_invoice_credit_note() {
        $this->cron_model->generate_shipping_invoice_credit_note();
    }

	public function generate_product_invoice_credit_note() {
        $this->cron_model->generate_product_invoice_credit_note();
    }

	public function generate_shipping_invoice_CI() {
        $this->cron_model->generate_shipping_invoice_CI();
    }

    public function generate_gst_report() {
     $this->cron_model->generate_gst_report();
    }

	public function generate_product_invoice_refresh() {
        $this->cron_model->generate_product_invoice_refresh();
    }

	public function generate_shipping_invoice_refresh() {
        $this->cron_model->generate_shipping_invoice_refresh();
    }
    
    public function update_cron_gst_report() {
        $this->cron_model->update_cron_gst_report();
    }

}
