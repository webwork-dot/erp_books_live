<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'third_party/phpspreadsheet/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Phpspreadsheet extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Calcutta');
        // $this->load->model('HighschoolModel');
        $this->load->model('request_model');
    }
    
    public function index()
    {
        $data = array();
    }
    
   
  public function export_all_highschool_enquiries()
  {   
        $filename = "highschool_enquiries".date('Ymd') . ".xlsx";	
        $spreadsheet = new Spreadsheet(); 

        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet(); 
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Name'); 
        // Sets the value of cell B1 

        $count=2;	
    
        $orders = $this->HighschoolModel->all_highschool_enquiries();    
        foreach($orders as $order){  
            $sheet->setCellValue('A'.$count, $order['name']); 
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
         
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
  }
  
    
    
    
    
    public function marketing_save_export_file() {     
		
		$this->load->helper('download');  
		$data = array();  
	      
        $filename = "highschool_enquiries".date('Ymd');	
        $contact_list =  $this->HighschoolModel->all_highschool_enquiries();   
		

		// get employee list
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();
     
		$sheet->setCellValue('A1', 'Name');
 
        $rowCount = 2;
        foreach ($contact_list as $element) {
            $sheet->setCellValue('A' . $rowCount, $element['name']);
            $rowCount++;
        }
 
  
      $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
      $fileName = $filename.'.xlsx';
    
	//delete temporary history data	

    $this->output->set_header('Content-Type: application/vnd.ms-excel');
    $this->output->set_header("Content-type: application/csv");
    $this->output->set_header('Cache-Control: max-age=0');
  	
	try {
		$writer->save(FCPATH.$fileName); 
		$content =file_get_contents(FCPATH.$fileName);
	} catch(Exception $e) {
		exit($e->getMessage());
	}

	header("Content-Disposition: attachment; filename=".$fileName);  	
	unlink($fileName);
	force_download($fileName, $content);
	exit($content);	
	
    }
    
    
    public function upload()
    {
        //check auth
        /*	if (!auth_check()) {
        redirect(lang_base_url());
        }
        if (!is_user_vendor()) {
        redirect(lang_base_url());
        }
        */
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        $data = array();
        
        // If file uploaded
        if (!empty($_FILES['fileURL']['name'])) {
            // get file extension
            $extension = pathinfo($_FILES['fileURL']['name'], PATHINFO_EXTENSION);
            
            if ($extension == 'xlsx') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            }
            // file path
            $spreadsheet    = $reader->load($_FILES['fileURL']['tmp_name']);
            $allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
            
            // array Count
            $arrayCount   = count($allDataInSheet);
            $flag         = 0;
            $createArray  = array(
                'Publisher',
                'Board',
                'Grade',
                'Subject',
                'Product_Name/Display_Name',
                'ISBN/SKU/Product_code',
                'Quantity',
                'Length_(in_cm)',
                'Width_(in_cm)',
                'Height_(in_cm)',
                'Weight_(in_gm)',
                'No_Of_Pages',
                'MRP',
                'Discounted_MRP',
                'Gst_(%)',
                'HSN',
                'Meta_Titles',
                'Meta_Keywords',
                'Meta_Description'
            );
            $makeArray    = array(
                'Publisher' => 'Publisher',
                'Board' => 'Board',
                'Grade' => 'Grade',
                'Subject' => 'Subject',
                'Product_Name/Display_Name' => 'Product_Name/Display_Name',
                'ISBN/SKU/Product_code' => 'ISBN/SKU/Product_code',
                'Quantity' => 'Quantity',
                'Length_(in_cm)' => 'Length_(in_cm)',
                'Width_(in_cm)' => 'Width_(in_cm)',
                'Height_(in_cm)' => 'Height_(in_cm)',
                'Weight_(in_gm)' => 'Weight_(in_gm)',
                'No_Of_Pages' => 'No_Of_Pages',
                'MRP' => 'MRP',
                'Discounted_MRP' => 'Discounted_MRP',
                'Gst_(%)' => 'Gst_(%)',
                'HSN' => 'HSN',
                'Meta_Titles' => 'Meta_Titles',
                'Meta_Keywords' => 'Meta_Keywords',
                'Meta_Description' => 'Meta_Description'
            );
            $SheetDataKey = array();
            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value                      = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    }
                }
            }
            $dataDiff = array_diff_key($makeArray, $SheetDataKey);
            if (empty($dataDiff)) {
                $flag = 1;
            }
            // match excel sheet column
            if ($flag == 1) {
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $addresses      = array();
                    $publisher_name = trim($SheetDataKey['Publisher']);
                    $publisher      = $this->product_model->get_publisher_by_name($publisher_name);
                    $publisher_id   = $publisher['id'];
                    
                    $board_name = trim($SheetDataKey['Board']);
                    $board      = $this->product_model->get_board_by_name($board_name);
                    $board_id   = $board['id'];
                    
                    $grade_name = trim($SheetDataKey['Grade']);
                    $grade      = $this->product_model->get_grades_by_name($grade_name);
                    $grade_id   = $grade['id'];
                    
                    $subject_name = trim($SheetDataKey['Subject']);
                    $subject      = $this->product_model->get_subject_by_name($subject_name);
                    $subject_id   = $subject['id'];
                    
                    $title          = $SheetDataKey['Product_Name/Display_Name'];
                    $model_number   = $SheetDataKey['ISBN/SKU/Product_code'];
                    $quantity       = $SheetDataKey['Quantity'];
                    $lenght         = $SheetDataKey['Length_(in_cm)'];
                    $width          = $SheetDataKey['Width_(in_cm)'];
                    $height         = $SheetDataKey['Height_(in_cm)'];
                    $weight         = $SheetDataKey['Weight_(in_gm)'];
                    $no_of_pages    = $SheetDataKey['No_Of_Pages'];
                    $base_price     = $SheetDataKey['MRP'];
                    $discount_price = $SheetDataKey['Discounted_MRP'];
                    $Gst            = $SheetDataKey['Gst_(%)'];
                    $gst            = $SheetDataKey['HSN'];
                    $model_number   = $SheetDataKey['Meta_Titles'];
                    $model_number   = $SheetDataKey['Meta_Keywords'];
                    $model_number   = $SheetDataKey['Meta_Description'];
                    
                    
                    $fetchData[]       = array(
                        'publisher_id' => $publisher_id,
                        'board_id' => $board_id,
                        'grade_id' => $grade_id,
                        'subject_id' => $subject_id,
                        'title' => $title,
                        'model_number' => $model_number,
                        'quantity' => $quantity,
                        'lenght' => $lenght,
                        'width' => $width,
                        'height' => $height,
                        'weight' => $weight,
                        'no_of_pages' => $no_of_pages,
                        'base_price' => $base_price,
                        'discount_price' => $discount_price,
                        'gst' => $gst,
                        'hsn' => $hsn,
                        'meta_title' => $meta_title,
                        'meta_description' => $meta_description,
                        'meta_keyword' => $meta_keyword,
                        'category_id' => '',
                        'brand_id' => '',
                        'stationery_id' => '',
                        'description' => '',
                        'currency' => "",
                        'user_id' => user()->id,
                        'status' => 0,
                        'is_promoted' => 0,
                        'visibility' => 1,
                        'rating' => 0,
                        'hit' => 0,
                        'demo_url' => "",
                        'external_link' => "",
                        'files_included' => "",
                        'is_sold' => 0,
                        'is_deleted' => 0,
                        'is_draft' => 0,
                        'is_free_product' => 0,
                        'created_at' => date('Y-m-d H:i:s')
                    );
                    $fetchData["slug"] = str_slug($fetchData["title"]);
                    
                }
                
                
                //add product
                if ($this->product_model->product_excel_insert($fetchData)) {
                    $user = user();
                    redirect(lang_base_url() . "profile/" . $user->slug . "/4");
                } else {
                    $this->session->set_flashdata('error', trans("msg_error"));
                }
                
                
                
            } else {
                echo "Please import correct file, did not match excel sheet column";
            }
            $this->load->view('product/test', $data);
        }
        
    }
    
    // checkFileValidation
    
    public function export_all_publishers()
    {
        $fileName = 'sales_data';
        $this->load->helper('download');
        $data         = array();
        $contact_list = $this->product_model->publisher_list();
        
        // get employee list
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        
        $header = array(
            "Name"
        );
        
        $sheet->setCellValue('A1', 'Name');
        
        
        $rowCount = 2;
        foreach ($contact_list as $element) {
            $sheet->setCellValue('A' . $rowCount, $element['name']);
            
            $rowCount++;
        }
        
        $writer   = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $fileName = $fileName . '.xlsx';
        
        $this->output->set_header('Content-Type: application/vnd.ms-excel');
        $this->output->set_header("Content-type: application/csv");
        $this->output->set_header('Cache-Control: max-age=0');
        $writer->save(ROOT_UPLOAD_PATH . $fileName);
        //redirect(HTTP_UPLOAD_PATH.$fileName); 
        $filepath = file_get_contents(ROOT_UPLOAD_PATH . $fileName);
        force_download($fileName, $filepath);
    }
    
    
    
    public function download()
    {
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Hello World !');
        
        $writer = new Xlsx($spreadsheet);
        
        $filename = 'name-of-the-generated-file';
        
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '.xlsx"');
        header('Cache-Control: max-age=0');
        
        $writer->save('php://output'); // download file 
        
    }
    
    
    
    
    public function export_consolidate_report($order_status)
    {
        
        
        $user_id     = $this->input->post('user_id', true);
        $filename    = $order_status . "_consolidate_report_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Transaction Id');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'Request Date');
        $sheet->setCellValue('C1', 'Shipment Date');
        $sheet->setCellValue('D1', 'Kirti Book Order No');
        $sheet->setCellValue('E1', 'Kirti Invoice no');
        $sheet->setCellValue('F1', 'Customer Name');
        $sheet->setCellValue('G1', 'Student Name');
        $sheet->setCellValue('H1', 'Student Mobile');
        $sheet->setCellValue('I1', 'School');
        $sheet->setCellValue('J1', 'Grade');
        $sheet->setCellValue('K1', 'Sub Total');
        $sheet->setCellValue('L1', 'Shipping Charges');
        $sheet->setCellValue('M1', 'Discount');
        $sheet->setCellValue('N1', 'Amount');
        $sheet->setCellValue('O1', 'Contact');
        $sheet->setCellValue('P1', 'Mail id');
        $sheet->setCellValue('Q1', 'Remark');
        $sheet->setCellValue('R1', 'Shipping Address');
        $sheet->setCellValue('S1', 'Landmark');
        $sheet->setCellValue('T1', 'State');
        $sheet->setCellValue('U1', 'City');
        $sheet->setCellValue('V1', 'Pincode');
        $sheet->setCellValue('W1', 'Order Status');
        $sheet->setCellValue('X1', 'House No');
        $sheet->setCellValue('Y1', 'Building Name');
        $sheet->setCellValue('Z1', 'Street Name');
        $sheet->setCellValue('AA1', 'Locality');
        $sheet->setCellValue('AB1', 'Alternate Mobile');
        
        $count = 2;
        
        $filter_data['date_range']   = $this->input->get('date_range');
        $filter_data['vendor']       = $this->input->get('vendor');
        $filter_data['school']       = $this->input->get('school');
        $filter_data['grade_id']     = $this->input->get('grade_id');
        $filter_data['order_status'] = $order_status;
        $filter_data['keywords']     = $this->input->get('keywords');
        $orders                      = $this->order_model->get_consolidated_report($filter_data);
        foreach ($orders as $order) {
            $shipping      = $this->order_model->get_order_shipping($order['id']);
            $shipping_addr = $shipping->shipping_address_1 . ', ' . $shipping->shipping_city . '-' . $shipping->shipping_zip_code . ', ' . $shipping->shipping_state . ', ' . $shipping->shipping_country;
            
            $sheet->setCellValue('A' . $count, $order['payment_id']);
            $sheet->setCellValue('B' . $count, $order['created_at']);
            $sheet->setCellValue('C' . $count, $order['shipping_date']);
            $sheet->setCellValue('D' . $count, $order['order_number']);
            $sheet->setCellValue('E' . $count, $order['invoice_no']);
            $sheet->setCellValue('F' . $count, $order['customer']);
            $sheet->setCellValue('G' . $count, $order['student']);
            $sheet->setCellValue('H' . $count, $order['phone_number']);
            $sheet->setCellValue('I' . $count, $order['school_name']);
            $sheet->setCellValue('J' . $count, $order['grade_name']);
            $sheet->setCellValue('K' . $count, $order['price_subtotal']);
            $sheet->setCellValue('L' . $count, $order['price_shipping']);
            $sheet->setCellValue('M' . $count, $order['price_discount']);
            $sheet->setCellValue('N' . $count, $order['price_total']);
            $sheet->setCellValue('O' . $count, $order['phone_number']);
            $sheet->setCellValue('P' . $count, $order['email']);
            $sheet->setCellValue('Q' . $count, '');
            $sheet->setCellValue('R' . $count, $shipping_addr);
            $sheet->setCellValue('S' . $count, $shipping->shipping_landmark);
            $sheet->setCellValue('T' . $count, $shipping->shipping_state);
            $sheet->setCellValue('U' . $count, $shipping->shipping_city);
            $sheet->setCellValue('V' . $count, $shipping->shipping_zip_code);
            $sheet->setCellValue('W' . $count, $order['order_status']);
            
            $sheet->setCellValue('X' . $count, $shipping->house_no);
            $sheet->setCellValue('Y' . $count, $shipping->bldg_name);
            $sheet->setCellValue('Z' . $count, $shipping->street_name);
            $sheet->setCellValue('AA' . $count, $shipping->locality);
            $sheet->setCellValue('AB' . $count, $shipping->alternate_mobile);
            
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    
    
    
    public function export_all_consolidate_report()
    {
        $user_id     = $this->input->post('user_id', true);
        $filename    = "all_consolidate_report_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Transaction Id');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'Request Date');
        $sheet->setCellValue('C1', 'Shipment Date');
        $sheet->setCellValue('D1', 'Kirti Book Order No');
        $sheet->setCellValue('E1', 'Kirti Invoice no');
        $sheet->setCellValue('F1', 'Customer Name');
        $sheet->setCellValue('G1', 'Student Name');
        $sheet->setCellValue('H1', 'Student Mobile');
        $sheet->setCellValue('I1', 'School');
        $sheet->setCellValue('J1', 'Grade');
        $sheet->setCellValue('K1', 'Sub Total');
        $sheet->setCellValue('L1', 'Shipping Charges');
        $sheet->setCellValue('M1', 'Discount');
        $sheet->setCellValue('N1', 'Amount');
        $sheet->setCellValue('O1', 'Contact');
        $sheet->setCellValue('P1', 'Mail id');
        $sheet->setCellValue('Q1', 'Remark');
        $sheet->setCellValue('R1', 'Shipping Address');
        $sheet->setCellValue('S1', 'Landmark');
        $sheet->setCellValue('T1', 'State');
        $sheet->setCellValue('U1', 'City');
        $sheet->setCellValue('V1', 'Pincode');
        $sheet->setCellValue('W1', 'Order Status');
        $sheet->setCellValue('X1', 'House No');
        $sheet->setCellValue('Y1', 'Building Name');
        $sheet->setCellValue('Z1', 'Street Name');
        $sheet->setCellValue('AA1', 'Locality');
        $sheet->setCellValue('AB1', 'Alternate Mobile');
        
        $count = 2;
        
        $filter_data['date_range']   = $this->input->get('date_range');
        $filter_data['vendor']       = $this->input->get('vendor');
        $filter_data['school']       = $this->input->get('school');
        $filter_data['grade_id']     = $this->input->get('grade_id');
        $filter_data['order_status'] = $this->input->get('order_status');
        ;
        $filter_data['keywords']  = $this->input->get('keywords');
        $filter_data['warehouse'] = $this->input->get('warehouse');
        $filter_data['courier']   = $this->input->get('courier');
        $orders                   = $this->order_model->get_all_consolidated_report($filter_data);
        foreach ($orders as $order) {
            $shipping      = $this->order_model->get_order_shipping($order['id']);
            $shipping_addr = $shipping->shipping_address_1 . ', ' . $shipping->shipping_city . '-' . $shipping->shipping_zip_code . ', ' . $shipping->shipping_state . ', ' . $shipping->shipping_country;
            
            $sheet->setCellValue('A' . $count, $order['payment_id']);
            $sheet->setCellValue('B' . $count, $order['created_at']);
            $sheet->setCellValue('C' . $count, $order['shipping_date']);
            $sheet->setCellValue('D' . $count, $order['order_number']);
            $sheet->setCellValue('E' . $count, $order['invoice_no']);
            $sheet->setCellValue('F' . $count, $order['customer']);
            $sheet->setCellValue('G' . $count, $order['student']);
            $sheet->setCellValue('H' . $count, $order['phone_number']);
            $sheet->setCellValue('I' . $count, $order['school_name']);
            $sheet->setCellValue('J' . $count, $order['grade_name']);
            $sheet->setCellValue('K' . $count, $order['price_subtotal']);
            $sheet->setCellValue('L' . $count, $order['price_shipping']);
            $sheet->setCellValue('M' . $count, $order['price_discount']);
            $sheet->setCellValue('N' . $count, $order['price_total']);
            $sheet->setCellValue('O' . $count, $order['phone_number']);
            $sheet->setCellValue('P' . $count, $order['email']);
            $sheet->setCellValue('Q' . $count, '');
            $sheet->setCellValue('R' . $count, $shipping_addr);
            $sheet->setCellValue('S' . $count, $shipping->shipping_landmark);
            $sheet->setCellValue('T' . $count, $shipping->shipping_state);
            $sheet->setCellValue('U' . $count, $shipping->shipping_city);
            $sheet->setCellValue('V' . $count, $shipping->shipping_zip_code);
            $sheet->setCellValue('W' . $count, $order['order_status']);
            
            $sheet->setCellValue('X' . $count, $shipping->house_no);
            $sheet->setCellValue('Y' . $count, $shipping->bldg_name);
            $sheet->setCellValue('Z' . $count, $shipping->street_name);
            $sheet->setCellValue('AA' . $count, $shipping->locality);
            $sheet->setCellValue('AB' . $count, $shipping->alternate_mobile);
            
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    
    
    public function all_ageing_report()
    {
        $user_id     = $this->input->post('user_id', true);
        $filename    = "all_ageing_report_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Order number');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'Order date');
        $sheet->setCellValue('C1', 'Status');
        $sheet->setCellValue('D1', 'Ageing');
        $sheet->setCellValue('E1', 'School ');
        $sheet->setCellValue('F1', 'Courier');
        
        $count = 2;
        
        $filter_data['date_range']   = $this->input->get('date_range');
        $filter_data['vendor']       = $this->input->get('vendor');
        $filter_data['school']       = $this->input->get('school');
        $filter_data['grade_id']     = $this->input->get('grade_id');
        $filter_data['order_status'] = $this->input->get('order_status');
        ;
        $filter_data['keywords']  = $this->input->get('keywords');
        $filter_data['warehouse'] = $this->input->get('warehouse');
        $filter_data['courier']   = $this->input->get('courier');
        $orders                   = $this->order_model->get_all_ageing_report($filter_data);
        foreach ($orders as $order) {
            $sheet->setCellValue('A' . $count, $order['order_number']);
            $sheet->setCellValue('B' . $count, $order['created_at']);
            $sheet->setCellValue('C' . $count, $order['order_status']);
            $sheet->setCellValue('D' . $count, days_left($order['created_at']));
            $sheet->setCellValue('E' . $count, $order['school_name']);
            $sheet->setCellValue('F' . $count, $order['courier']);
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    
    
    public function export_school_consolidate_report()
    {
        
        
        $user_id     = $this->input->post('user_id', true);
        $filename    = "all_consolidate_report_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Transaction Id');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'Request Date');
        $sheet->setCellValue('C1', 'Shipment Date');
        $sheet->setCellValue('D1', 'Kirti Book Order No');
        $sheet->setCellValue('E1', 'Kirti Invoice no');
        $sheet->setCellValue('F1', 'Customer Name');
        $sheet->setCellValue('G1', 'Student Name');
        $sheet->setCellValue('H1', 'Student Mobile');
        $sheet->setCellValue('I1', 'School');
        $sheet->setCellValue('J1', 'Grade');
        $sheet->setCellValue('K1', 'Sub Total');
        $sheet->setCellValue('L1', 'Shipping Charges');
        $sheet->setCellValue('M1', 'Discount');
        $sheet->setCellValue('N1', 'Amount');
        $sheet->setCellValue('O1', 'Contact');
        $sheet->setCellValue('P1', 'Mail id');
        $sheet->setCellValue('Q1', 'Remark');
        $sheet->setCellValue('R1', 'Shipping Address');
        $sheet->setCellValue('S1', 'Landmark');
        $sheet->setCellValue('T1', 'State');
        $sheet->setCellValue('U1', 'City');
        $sheet->setCellValue('V1', 'Pincode');
        $sheet->setCellValue('W1', 'Order Status');
        $sheet->setCellValue('X1', 'House No');
        $sheet->setCellValue('Y1', 'Building Name');
        $sheet->setCellValue('Z1', 'Street Name');
        $sheet->setCellValue('AA1', 'Locality');
        $sheet->setCellValue('AB1', 'Alternate Mobile');
        
        $count = 2;
        
        $filter_data['date_range']   = $this->input->get('date_range');
        $filter_data['vendor']       = $this->input->get('vendor');
        $filter_data['school']       = $this->input->get('school');
        $filter_data['grade_id']     = $this->input->get('grade_id');
        $filter_data['order_status'] = $this->input->get('order_status');
        ;
        $filter_data['keywords'] = $this->input->get('keywords');
        
        $this->load->model("school_login_model");
        $orders = $this->school_login_model->get_all_consolidated_report($filter_data);
        foreach ($orders as $order) {
            $shipping      = $this->order_model->get_order_shipping($order['id']);
            $shipping_addr = $shipping->shipping_address_1 . ', ' . $shipping->shipping_city . '-' . $shipping->shipping_zip_code . ', ' . $shipping->shipping_state . ', ' . $shipping->shipping_country;
            
            $sheet->setCellValue('A' . $count, $order['payment_id']);
            $sheet->setCellValue('B' . $count, $order['created_at']);
            $sheet->setCellValue('C' . $count, $order['shipping_date']);
            $sheet->setCellValue('D' . $count, $order['order_number']);
            $sheet->setCellValue('E' . $count, $order['invoice_no']);
            $sheet->setCellValue('F' . $count, $order['customer']);
            $sheet->setCellValue('G' . $count, $order['student']);
            $sheet->setCellValue('H' . $count, $order['phone_number']);
            $sheet->setCellValue('I' . $count, $order['school_name']);
            $sheet->setCellValue('J' . $count, $order['grade_name']);
            $sheet->setCellValue('K' . $count, $order['price_subtotal']);
            $sheet->setCellValue('L' . $count, $order['price_shipping']);
            $sheet->setCellValue('M' . $count, $order['price_discount']);
            $sheet->setCellValue('N' . $count, $order['price_total']);
            $sheet->setCellValue('O' . $count, $order['phone_number']);
            $sheet->setCellValue('P' . $count, $order['email']);
            $sheet->setCellValue('Q' . $count, '');
            $sheet->setCellValue('R' . $count, $shipping_addr);
            $sheet->setCellValue('S' . $count, $shipping->shipping_landmark);
            $sheet->setCellValue('T' . $count, $shipping->shipping_state);
            $sheet->setCellValue('U' . $count, $shipping->shipping_city);
            $sheet->setCellValue('V' . $count, $shipping->shipping_zip_code);
            $sheet->setCellValue('W' . $count, $order['order_status']);
            
            $sheet->setCellValue('X' . $count, $shipping->house_no);
            $sheet->setCellValue('Y' . $count, $shipping->bldg_name);
            $sheet->setCellValue('Z' . $count, $shipping->street_name);
            $sheet->setCellValue('AA' . $count, $shipping->locality);
            $sheet->setCellValue('AB' . $count, $shipping->alternate_mobile);
            
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    public function export_coupons_history()
    {
        if (!auth_check()) {
            redirect(lang_base_url());
        }
        
        $filename    = "coupons_history_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Sr no');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'User');
        $sheet->setCellValue('C1', 'User Mobile');
        $sheet->setCellValue('D1', 'Coupon Title');
        $sheet->setCellValue('E1', 'Reedem Points');
        $sheet->setCellValue('F1', 'Date');
        
        
        $count = 2;
        
        $filter_data['date_range'] = $this->input->post('date_range');
        $filter_data['keywords']   = $this->input->post('keywords');
        $point                     = $this->point_admin_model->get_all_points_history($filter_data);
        
        foreach ($point as $item) {
            $sheet->setCellValue('A' . $count, $count - 1);
            $sheet->setCellValue('B' . $count, $item->username);
            $sheet->setCellValue('C' . $count, $item->phone_number);
            $sheet->setCellValue('D' . $count, $item->coupon_code);
            $sheet->setCellValue('E' . $count, $item->credit);
            $sheet->setCellValue('F' . $count, $item->date);
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    
    
    
    
    public function export_pending_orders()
    {
        
        
        $user_id     = $this->input->post('user_id', true);
        $filename    = "pending_orders_report_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Sr no');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'Request Date');
        $sheet->setCellValue('C1', 'Shipment Date');
        $sheet->setCellValue('D1', 'Kirti Book Order No');
        $sheet->setCellValue('E1', 'Kirti Invoice no');
        $sheet->setCellValue('F1', 'Customer Name');
        $sheet->setCellValue('G1', 'Student Name');
        $sheet->setCellValue('H1', 'OPTIONAL');
        $sheet->setCellValue('I1', 'School');
        $sheet->setCellValue('J1', 'Grade');
        $sheet->setCellValue('K1', 'Sub Total');
        $sheet->setCellValue('L1', 'Shipping Charges');
        $sheet->setCellValue('M1', 'Discount');
        $sheet->setCellValue('N1', 'Amount');
        $sheet->setCellValue('O1', 'Contact');
        $sheet->setCellValue('P1', 'Mail id');
        $sheet->setCellValue('Q1', 'Remark');
        $sheet->setCellValue('R1', 'Shipping Address');
        $sheet->setCellValue('S1', 'Landmark');
        $sheet->setCellValue('T1', 'State');
        $sheet->setCellValue('U1', 'City');
        $sheet->setCellValue('V1', 'Pincode');
        
        
        $count = 2;
        
        $filter_data['date_range']   = $this->input->get('date_range');
        $filter_data['vendor']       = $this->input->get('vendor');
        $filter_data['school']       = $this->input->get('school');
        $filter_data['grade_id']     = $this->input->get('grade_id');
        $filter_data['order_status'] = $this->input->get('order_status');
        $filter_data['keywords']     = $this->input->get('keywords');
        $orders                      = $this->order_model->get_export_orders_pending($filter_data);
        
        
        foreach ($orders as $order) {
            
            $orderform_id = $this->product_model->get_orderform_id($order['id']);
            // echo $this->db->last_query();
            $ord_f_id_arr = array();
            foreach ($orderform_id as $orderform) {
                $ord_f_id_arr[] = $orderform->package_id;
            }
            $ord_f_id = implode(", ", $ord_f_id_arr);
            $pak_id   = explode(",", $ord_f_id);
            $opt      = array();
            foreach ($pak_id as $pak) {
                $package_cat_name = $this->product_model->get_package_name_by_id($pak);
                if ($package_cat_name['is_it'] != '1') {
                    $opt[] = $package_cat_name['package_name'];
                }
            }
            $comma_opt = implode(", ", $opt);
            
            
            $shipping = $this->order_model->get_order_shipping($order['id']);
            $sheet->setCellValue('A' . $count, $count - 1);
            $sheet->setCellValue('B' . $count, $order['created_at']);
            $sheet->setCellValue('C' . $count, $order['shipping_date']);
            $sheet->setCellValue('D' . $count, $order['order_number']);
            $sheet->setCellValue('E' . $count, $order['invoice_no']);
            $sheet->setCellValue('F' . $count, $order['customer']);
            $sheet->setCellValue('G' . $count, $order['student']);
            $sheet->setCellValue('H' . $count, $comma_opt);
            $sheet->setCellValue('I' . $count, $order['school_name']);
            $sheet->setCellValue('J' . $count, $order['grade_name']);
            $sheet->setCellValue('K' . $count, $order['price_subtotal']);
            $sheet->setCellValue('L' . $count, $order['price_shipping']);
            $sheet->setCellValue('M' . $count, $order['price_discount']);
            $sheet->setCellValue('N' . $count, $order['price_total']);
            $sheet->setCellValue('O' . $count, $order['phone_number']);
            $sheet->setCellValue('P' . $count, $order['email']);
            $sheet->setCellValue('Q' . $count, '');
            $sheet->setCellValue('R' . $count, $shipping->shipping_address_1);
            $sheet->setCellValue('S' . $count, $shipping->shipping_landmark);
            $sheet->setCellValue('T' . $count, $shipping->shipping_state);
            $sheet->setCellValue('U' . $count, $shipping->shipping_city);
            $sheet->setCellValue('V' . $count, $shipping->shipping_zip_code);
            
            $count++;
        }
        
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    public function upload_delivery_orders()
    {
        
        $data       = array();
        $returnData = array();
        $fetchData  = array();
        
        $invoice_date = date('Y-m-d', strtotime(trim($this->input->post('invoice_date', true)) . ' + 0 day'));
        
        // If file uploaded
        if (!empty($_FILES['fileURL']['name'])) {
            // get file extension
            $extension = pathinfo($_FILES['fileURL']['name'], PATHINFO_EXTENSION);
            
            if ($extension == 'xlsx') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            }
            // file path
            $spreadsheet    = $reader->load($_FILES['fileURL']['tmp_name']);
            $allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
            
            // array Count
            $arrayCount   = count($allDataInSheet);
            /*                print_r($allDataInSheet);
            echo $arrayCount;
            exit();*/
            $flag         = 0;
            $createArray  = array(
                'order_number',
                'delivered_date'
            );
            $makeArray    = array(
                'order_number' => 'order_number',
                'delivered_date' => 'delivered_date'
            );
            $SheetDataKey = array();
            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value                      = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    }
                }
            }
            
            $dataDiff = array_diff_key($makeArray, $SheetDataKey);
            if (empty($dataDiff)) {
                $flag = 1;
            }
            // match excel sheet column
            $is_return = 0;
            if ($flag == 1) {
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $order_number    = trim($SheetDataKey['order_number']);
                    $delivered_date  = trim($SheetDataKey['delivered_date']);
                    $added_date      = date('Y-m-d H:i:s', strtotime('+ 0 day'));
                    $order_number    = filter_var(trim($allDataInSheet[$i][$order_number]), FILTER_SANITIZE_STRING);
                    $delivered_date_ = trim($allDataInSheet[$i][$delivered_date]);
                    $delivered_date  = date('Y-m-d H:i:s', strtotime(trim($delivered_date_) . ' + 0 day'));
                    
                    if ($order_number != '') {
                        $validity      = $this->order_admin_model->check_order_in_dispatched($order_number);
                        $validity_date = $this->order_admin_model->check_order_in_invoice_date($order_number, $invoice_date);
                        if ($validity == false || $validity_date == false) {
                            $returnData[] = $order_number;
                            $is_return    = 1;
                        } else {
                            $fetchData[] = array(
                                'order_number' => $order_number,
                                'delivered_date' => $delivered_date,
                                'added_date' => $added_date,
                                'user_invoice_date' => $invoice_date,
                                'is_delivered' => 0,
                                'is_active' => 0
                            );
                            
                        }
                    }
                }
                
                $output = '';
                //add product
                $this->order_admin_model->setBatchImport($fetchData);
                if ($count_ = $this->order_admin_model->delivery_order_excel_insert($fetchData)) {
                    if (count($returnData) > 0) {
                        $output = '<span class="text-red">These orders are not in out for delivery status or Invoice date issue-' . implode(', ', $returnData) . '</span>';
                    }
                    
                    
                    
                    $this->session->set_flashdata('success', "Order uploaded Successfully! " . $output);
                    redirect($this->agent->referrer());
                } else {
                    if (count($returnData) > 0) {
                        $output = '<span class="text-red">These orders are not in out for delivery status or Invoice date issue-' . implode(', ', $returnData) . '</span>';
                    }
                    
                    $this->session->set_flashdata('error', "orders not added!" . $output);
                    redirect($this->agent->referrer());
                }
                
            } else {
                $this->session->set_flashdata('error', "Please import correct file, did not match excel sheet column");
                redirect($this->agent->referrer());
            }
        }
    }
    
    
    
    public function export_kirtibook_customer_invoice()
    {
        
        
        $filename    = "kirtibook_customer_invoice_" . date('Ymd') . ".xlsx";
        $spreadsheet = new Spreadsheet();
        
        // Retrieve the current active worksheet 
        $sheet = $spreadsheet->getActiveSheet();
        
        // Set the value of cell A1 
        $sheet->setCellValue('A1', 'Sr no');
        // Sets the value of cell B1 
        $sheet->setCellValue('B1', 'Txn Id');
        $sheet->setCellValue('C1', 'Invoice No');
        $sheet->setCellValue('D1', 'Order No');
        $sheet->setCellValue('E1', 'Order Date');
        $sheet->setCellValue('F1', 'Delivered Date');
        $sheet->setCellValue('G1', 'Customer Name');
        $sheet->setCellValue('H1', 'Customer Mobile');
        $sheet->setCellValue('I1', 'Carrier');
        $sheet->setCellValue('J1', 'Order Amount');
        $sheet->setCellValue('K1', 'Product Handling Charge');
        $count = 2;
        
        $filter_data['date_range']   = $this->input->get('date_range');
        $filter_data['vendor']       = $this->input->get('vendor');
        $filter_data['school_id']    = $this->input->get('school');
        $filter_data['grade_id']     = $this->input->get('grade_id');
        $filter_data['order_status'] = $this->input->get('order_status');
        $filter_data['keywords']     = $this->input->get('keywords');
        $filter_data['courier']      = $this->input->get('courier');
        
        $this->load->model('download_admin_model');
        $orders = $this->download_admin_model->get_export_order_delivered($filter_data);
        
        if ($orders) {
            foreach ($orders as $order) {
                $shipping = $this->order_model->get_order_shipping($order['id']);
                $sheet->setCellValue('A' . $count, $count - 1);
                $sheet->setCellValue('B' . $count, $order['payment_id']);
                $sheet->setCellValue('C' . $count, $order['user_invoice']);
                $sheet->setCellValue('D' . $count, $order['order_number']);
                $sheet->setCellValue('E' . $count, date('d-m-Y, h:i A', strtotime($order['created_at'])));
                $sheet->setCellValue('F' . $count, date('d-m-Y, h:i A', strtotime($order['delivered_date'])));
                $sheet->setCellValue('G' . $count, $order['username']);
                $sheet->setCellValue('H' . $count, $order['phone_number']);
                $sheet->setCellValue('I' . $count, $order['courier']);
                $sheet->setCellValue('J' . $count, $order['price_total']);
                $sheet->setCellValue('K' . $count, $order['price_shipping']);
                
                $count++;
            }
        }
        $spreadsheet->setActiveSheetIndex(0);
        
        // Redirect output to a client's web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=$filename");
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');
        
        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0
        
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    
    public function upload_dispatch_orders()
    {
        $data       = array();
        $returnData = array();
        $fetchData  = array();
        
        // If file uploaded
        if (!empty($_FILES['fileURL']['name'])) {
            // get file extension
            $extension = pathinfo($_FILES['fileURL']['name'], PATHINFO_EXTENSION);
            
            if ($extension == 'xlsx') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            } else {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            }
            // file path
            $spreadsheet    = $reader->load($_FILES['fileURL']['tmp_name']);
            $allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
            
            // array Count
            $arrayCount   = count($allDataInSheet);
            /*                print_r($allDataInSheet);
            echo $arrayCount;
            exit();*/
            $flag         = 0;
            $createArray  = array(
                'order_number',
                'dispatched_date'
            );
            $makeArray    = array(
                'order_number' => 'order_number',
                'dispatched_date' => 'dispatched_date'
            );
            $SheetDataKey = array();
            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value                      = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    }
                }
            }
            
            $dataDiff = array_diff_key($makeArray, $SheetDataKey);
            if (empty($dataDiff)) {
                $flag = 1;
            }
            // match excel sheet column
            $is_return = 0;
            if ($flag == 1) {
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $order_number     = trim($SheetDataKey['order_number']);
                    $dispatched_date  = trim($SheetDataKey['dispatched_date']);
                    $added_date       = date('Y-m-d H:i:s', strtotime('+ 0 day'));
                    $order_number     = filter_var(trim($allDataInSheet[$i][$order_number]), FILTER_SANITIZE_STRING);
                    $dispatched_date_ = trim($allDataInSheet[$i][$dispatched_date]);
                    $dispatched_date  = date('Y-m-d H:i:s', strtotime(trim($dispatched_date_) . ' + 0 day'));
                    
                    if ($order_number != '') {
                        $validity = $this->order_admin_model->check_order_in_shipped($order_number);
                        if ($validity == false) {
                            $returnData[] = $order_number;
                            $is_return    = 1;
                        } else {
                            $fetchData[] = array(
                                'order_number' => $order_number,
                                'dispatched_date' => $dispatched_date,
                                'added_date' => $added_date,
                                'is_delivered' => 0,
                                'is_active' => 0
                            );
                        }
                        
                    }
                }
                
                $output = '';
                //add product
                $this->order_admin_model->setBatchImport($fetchData);
                if ($count_ = $this->order_admin_model->dispatch_order_excel_insert($fetchData)) {
                    
                    if (count($returnData) > 0) {
                        $output = '<span class="text-red">These orders are not in ready for shipment status-' . implode(', ', $returnData) . '</span>';
                    }
                    
                    $this->session->set_flashdata('success', "Order uploaded Successfully! " . $output);
                    redirect($this->agent->referrer());
                } else {
                    $output = '';
                    if (count($returnData) > 0) {
                        $output = '<span class="text-red">These orders are not in ready for shipment status-' . implode(', ', $returnData) . '</span>';
                    }
                    $this->session->set_flashdata('error', "Order upload fail! " . $output);
                    //$this->session->set_flashdata('error', trans("msg_error"));	 
                    redirect($this->agent->referrer());
                }
                
            } else {
                $this->session->set_flashdata('error', "Please import correct file, did not match excel sheet column");
                redirect($this->agent->referrer());
            }
        }
    }
    
    
    public function sample_school_text_book_excel() {   
        //load spreadsheet
       
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/kirtibook_master_school_text_book.xlsx");
        
       
        $sheet = $spreadsheet->getSheet('1');
        $sheet->removeColumnByIndex('1'); 
        $count=1;
        $category  = $this->request_model->get_categories_by_parent('8')->result();   
        foreach($category as $item){
           $name=$item->id.' | '.$item->name;
           $sheet->setCellValue('A'.$count, $name); 
           $count++;
        }
       
        //xx_publisher_table   
        $sheet2 = $spreadsheet->getSheet('2');
        $sheet2->removeColumnByIndex('1'); 
        $count2=1;
        $publisher_list  = $this->request_model->get_publisher_list();   
        foreach($publisher_list->result() as $item2){
           $name2=$item2->id.' | '.$item2->name;
           $sheet2->setCellValue('A'.$count2, $name2); 
           $count2++;
        }
        
        //xx_board_table   
        $sheet3 = $spreadsheet->getSheet('3');
        $sheet3->removeColumnByIndex('1'); 
        $count3=1;
        $board_list  = $this->request_model->get_board_list();   
        foreach($board_list->result() as $item3){
           $sheet3->setCellValue('A'.$count3, $item3->name); 
           $count3++;
        }
          
        //xx_grade_table   
        $sheet4 = $spreadsheet->getSheet('4');
        $sheet4->removeColumnByIndex('1'); 
        $count4=1;
        $grade_list  = $this->request_model->get_grade_list();   
        foreach($grade_list->result() as $item4){
           $name4=$item4->id.' | '.$item4->name;
           $sheet4->setCellValue('A'.$count4, $name4); 
           $count4++;
        }
       
        //xx_subject_table   
        $sheet5 = $spreadsheet->getSheet('5');
        $sheet5->removeColumnByIndex('1'); 
        $count5=1;
        $subject_list  = $this->request_model->get_subject_list();   
        foreach($subject_list->result() as $item5){
           $name5=$item5->id.' | '.$item5->name;
           $sheet5->setCellValue('A'.$count5, $name5); 
           $count5++;
        }
        
        //xx_product_origin_table   
        $sheet6 = $spreadsheet->getSheet('6');
        $sheet6->removeColumnByIndex('1'); 
        $count6=1;
        $country_list  = $this->request_model->get_country_list();   
        foreach($country_list->result() as $item6){
           $sheet6->setCellValue('A'.$count6, $item6->name); 
           $count6++;
        }
        
        //write it again to Filesystem with the same name (=replace)
        $spreadsheet->setActiveSheetIndex(0);
        $writer = new Xlsx($spreadsheet);
        $writer->save('assets/kirtibook_master_school_text_book.xlsx');
        $this->load->helper('download');
          
        $file = FCPATH.'assets/kirtibook_master_school_text_book.xlsx';
        $filename = 'kirtibook_master_school_text_book.xlsx';
        // check file exists    
        if (file_exists($file)) {
         // get file content
        $data = file_get_contents ($file);
         //force download
        force_download($filename, $data); 
        }
        else{
            json_output(400, array(
                'status' => 400,
                'message' => 'There is some error while downloding sample file!'
            ));
        }
  
    }
    
    public function sample_note_book_excel() {   
        //load spreadsheet
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/kirtibook_master_note_book.xlsx");
        
        //xx_category_table
        /*print_r($spreadsheet->getSheetNames());
         exit();*/
        $sheet = $spreadsheet->getSheet('1');
        $sheet->removeColumnByIndex('1'); 
        $count=1;
        $category  = $this->request_model->get_categories_by_parent('10')->result();   
        foreach($category as $item){
           $name=$item->id.' | '.$item->name;
           $sheet->setCellValue('A'.$count, $name); 
           $count++;
        }
       
        //xx_brand_table   
        $sheet2 = $spreadsheet->getSheet('2');
        $sheet2->removeColumnByIndex('1'); 
        $count2=1;
        $brand_list  = $this->request_model->get_brand_by_category('10');   
        foreach($brand_list->result() as $item2){
           $name2=$item2->id.' | '.$item2->name;
           $sheet2->setCellValue('A'.$count2, $name2); 
           $count2++;
        }
        
        //xx_size_table   
        $sheet3 = $spreadsheet->getSheet('3');
        $sheet3->removeColumnByIndex('1'); 
        $count3=1;
        $size_list  = $this->request_model->get_size_by_category('10');   
        foreach($size_list->result() as $item3){
           $name3=$item3->id.' | '.$item3->name;
           $sheet3->setCellValue('A'.$count3, $name3); 
           $count3++;
        }
          
       //xx_binding_type_table   
        $sheet4 = $spreadsheet->getSheet('4');
        $sheet4->removeColumnByIndex('1'); 
        $count4=1;
        $binding_type_list  = $this->request_model->get_binding_type_list();   
        foreach($binding_type_list->result() as $item4){
           $name4=$item4->id.' | '.$item4->name;
           $sheet4->setCellValue('A'.$count4, $name4); 
           $count4++;
        }
       
        
        //xx_product_origin_table   
        $sheet6 = $spreadsheet->getSheet('5');
        $sheet6->removeColumnByIndex('1'); 
        $count6=1;
        $country_list  = $this->request_model->get_country_list();   
        foreach($country_list->result() as $item6){
           $sheet6->setCellValue('A'.$count6, $item6->name); 
           $count6++;
        }
        
        //write it again to Filesystem with the same name (=replace)
        $spreadsheet->setActiveSheetIndex(0);
        $writer = new Xlsx($spreadsheet);
        $writer->save('assets/kirtibook_master_note_book.xlsx');
        $this->load->helper('download');
          
        $file = FCPATH.'assets/kirtibook_master_note_book.xlsx';
        $filename = 'kirtibook_master_note_book.xlsx';
        // check file exists    
        if (file_exists($file)) {
         // get file content
         $data = file_get_contents ($file);
         //force download
         force_download ($filename, $data); 
        }
        else{
        $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
    	redirect($this->agent->referrer());
        }
  
    }
    
    public function sample_other_book_excel() {   
        //load spreadsheet
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/kirtibook_master_other_book.xlsx");
        
        //xx_category_table
        /*print_r($spreadsheet->getSheetNames());
         exit();*/
        $sheet = $spreadsheet->getSheet('1');
        $sheet->removeColumnByIndex('1'); 
        $count=1;
        $category  = $this->request_model->get_categories_by_parent('45')->result();   
        foreach($category as $item){
           $name=$item->id.' | '.$item->name;
           $sheet->setCellValue('A'.$count, $name); 
           $count++;
        }
       
        //xx_publisher_table   
        $sheet2 = $spreadsheet->getSheet('2');
        $sheet2->removeColumnByIndex('1'); 
        $count2=1;
        $publisher_list  = $this->request_model->get_publisher_list();   
        foreach($publisher_list->result() as $item2){
           $name2=$item2->id.' | '.$item2->name;
           $sheet2->setCellValue('A'.$count2, $name2); 
           $count2++;
        }
        
        //xx_board_table   
        $sheet3 = $spreadsheet->getSheet('3');
        $sheet3->removeColumnByIndex('1'); 
        $count3=1;
        $board_list  = $this->request_model->get_board_list();   
        foreach($board_list->result() as $item3){
           $sheet3->setCellValue('A'.$count3, $item3->name); 
           $count3++;
        }
          
       //xx_grade_table   
        $sheet4 = $spreadsheet->getSheet('4');
        $sheet4->removeColumnByIndex('1'); 
        $count4=1;
        $grade_list  = $this->request_model->get_grade_list();   
        foreach($grade_list->result() as $item4){
           $name4=$item4->id.' | '.$item4->name;
           $sheet4->setCellValue('A'.$count4, $name4); 
           $count4++;
        }
       
        //xx_subject_table   
        $sheet5 = $spreadsheet->getSheet('5');
        $sheet5->removeColumnByIndex('1'); 
        $count5=1;
        $subject_list  = $this->request_model->get_subject_list();   
        foreach($subject_list->result() as $item5){
           $name5=$item5->id.' | '.$item5->name;
           $sheet5->setCellValue('A'.$count5, $name5); 
           $count5++;
        }
        
         //xx_product_origin_table   
        $sheet6 = $spreadsheet->getSheet('6');
        $sheet6->removeColumnByIndex('1'); 
        $count6=1;
        $country_list  = $this->request_model->get_country_list();   
        foreach($country_list->result() as $item6){
           $sheet6->setCellValue('A'.$count6, $item6->name); 
           $count6++;
        }
        
        //write it again to Filesystem with the same name (=replace)
        $spreadsheet->setActiveSheetIndex(0);
        $writer = new Xlsx($spreadsheet);
        $writer->save('assets/kirtibook_master_other_book.xlsx');
        $this->load->helper('download');
          
        $file = FCPATH.'assets/kirtibook_master_other_book.xlsx';
        $filename = 'kirtibook_master_other_book.xlsx';
        // check file exists    
        if (file_exists($file)) {
         // get file content
         $data = file_get_contents ($file);
         //force download
         force_download ($filename, $data); 
        }
        else{
        $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
    	redirect($this->agent->referrer());
        }
  
    }
    
    public function sample_stationery_excel() {  
       
        //load spreadsheet
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/kirtibook_master_stationary.xlsx");
        
        //xx_category_table
        /*print_r($spreadsheet->getSheetNames());
         exit();*/
        $sheet = $spreadsheet->getSheet('1');
        $sheet->removeColumnByIndex('1'); 
        $count=1;
        $stationery_category  = $this->request_model->get_stationery_category_details();   
        foreach($stationery_category as $item){
           $sheet->setCellValue('A'.$count, $item['name']); 
           $count++;
        }
       
        //xx_stationery_brand_table   
        $sheet2 = $spreadsheet->getSheet('2');
        $sheet2->removeColumnByIndex('1'); 
        $count2=1;
        $brand_list  = $this->request_model->get_brand_by_category('6');   
        foreach($brand_list->result() as $item2){
           $name2= $item2->id.' | '.$item2->name;
           $sheet2->setCellValue('A'.$count2, $name2); 
           $count2++;
        }
        
        //xx_color_table   
        $sheet3 = $spreadsheet->getSheet('3');
        $sheet3->removeColumnByIndex('1'); 
        $count3=1;
        $color_list  = $this->request_model->get_color_by_category('6');   
        foreach($color_list->result() as $item3){
           $name3= $item3->id.' | '.$item3->name;
           $sheet3->setCellValue('A'.$count3, $name3); 
           $count3++;
        }
          
       //xx_product_origin_table   
        $sheet4 = $spreadsheet->getSheet('4');
        $sheet4->removeColumnByIndex('1'); 
        $count4=1;
        $country_list  = $this->request_model->get_country_list();   
        foreach($country_list->result() as $item4){
           $sheet4->setCellValue('A'.$count4, $item4->name); 
           $count4++;
        }
        
        
        //write it again to Filesystem with the same name (=replace)
        $spreadsheet->setActiveSheetIndex(0);
        $writer = new Xlsx($spreadsheet);
        $writer->save('assets/kirtibook_master_stationary.xlsx');
          $this->load->helper('download');
          
         $file = FCPATH.'assets/kirtibook_master_stationary.xlsx';
        $filename = 'kirtibook_master_stationary.xlsx';
        // check file exists    
        if (file_exists($file)) {
         // get file content
         $data = file_get_contents ($file);
         //force download
         force_download ($filename, $data); 
        }
        else{
        $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
    	redirect($this->agent->referrer());
        }
      
    }
    
    public function sample_uniform_excel($id) {  
       
        //load spreadsheet
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/kirtibook_master_uniform.xlsx");
        
        //xx_category_table
        /*print_r($spreadsheet->getSheetNames());
         exit();*/
        $sheet = $spreadsheet->getSheet('1');
        $sheet->removeColumnByIndex('1'); 
        $count=1;
        $category  = $this->request_model->get_categories_by_parent('22')->result();   
        foreach($category as $item){
           $name=$item->id.' | '.$item->name;
           $sheet->setCellValue('A'.$count, $name); 
           $count++;
        }
       
        //xx_type_table   
        $sheet2 = $spreadsheet->getSheet('2');
        $sheet2->removeColumnByIndex('1'); 
        $count2=1;
        $brand_list  = $this->request_model->get_uniform_category_details();   
        foreach($brand_list as $item2){
           $name2= $item2['name'];
           $sheet2->setCellValue('A'.$count2, $name2); 
           $count2++;
        }
        
        //xx_size_table   
        $sheet3 = $spreadsheet->getSheet('3');
        $sheet3->removeColumnByIndex('1'); 
        $count3=1;
        $color_list  = $this->request_model->get_uniform_size_details();   
        foreach($color_list as $item3){
           $name3= $item3['name'];
           $sheet3->setCellValue('A'.$count3, $name3); 
           $count3++;
        }
       
       //xx_school_table   
        $sheet4 = $spreadsheet->getSheet('4');
        $sheet4->removeColumnByIndex('1'); 
        $count4=1;
        $country_list  = $this->request_model->get_school_by_vendor($id);   
        foreach($country_list->result() as $item4){
           $sheet4->setCellValue('A'.$count4, $item4->name); 
           $count4++;
        }
       
        
       //xx_board_table   
        $sheet5 = $spreadsheet->getSheet('5');
        $sheet5->removeColumnByIndex('1'); 
        $count5=1;
        $board_list  = $this->request_model->get_board_list($id);   
        foreach($board_list->result() as $item5){
           $sheet5->setCellValue('A'.$count5, $item5->name); 
           $count5++;
        }
        
       //xx_board_table   
        $sheet7 = $spreadsheet->getSheet('7');
        $sheet7->removeColumnByIndex('1'); 
        $count7=1;
        $color_list  = $this->request_model->get_uniform_color();   
        foreach($color_list->result() as $item7){
           $sheet7->setCellValue('A'.$count7, $item7->name); 
           $count7++;
        }
        
        
        //write it again to Filesystem with the same name (=replace)
        $spreadsheet->setActiveSheetIndex(0);
        $writer = new Xlsx($spreadsheet);
        $writer->save('assets/kirtibook_master_uniform.xlsx');
          $this->load->helper('download');
          
         $file = FCPATH.'assets/kirtibook_master_uniform.xlsx';
        $filename = 'kirtibook_master_uniform.xlsx';
        // check file exists    
        if (file_exists($file)) {
         // get file content
         $data = file_get_contents ($file);
         //force download
         force_download ($filename, $data); 
        }
        else{
        $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
    	redirect($this->agent->referrer());
        }
      
    }
    
    public function sample_bookset_excel() {  
       
        //load spreadsheet
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/kirtibook_master_bookset.xlsx");
        
        //xx_board_table
        $sheet = $spreadsheet->getSheet('1');
        $sheet->removeColumnByIndex('1'); 
        $count=1;
        $board_list  = $this->request_model->get_board_list();   
        foreach($board_list->result() as $item1){
           $sheet->setCellValue('A'.$count, $item1->name); 
           $count++;
        }
       
        //xx_grade_table   
        $sheet2 = $spreadsheet->getSheet('2');
        $sheet2->removeColumnByIndex('1'); 
        $count2=1;
        $grade_list  = $this->request_model->get_grade_list();   
       
        foreach($grade_list->result() as $item2){
           $name2=$item2->id.' | '.$item2->name;
           $sheet2->setCellValue('A'.$count2, $name2); 
           $count2++;
        }
         
        
        //write it again to Filesystem with the same name (=replace)
        $spreadsheet->setActiveSheetIndex(0);
        $writer = new Xlsx($spreadsheet);
        $writer->save('assets/kirtibook_master_bookset.xlsx');
          $this->load->helper('download');
          
         $file = FCPATH.'assets/kirtibook_master_bookset.xlsx';
        $filename = 'kirtibook_master_bookset.xlsx';
        // check file exists    
        if (file_exists($file)) {
         // get file content
         $data = file_get_contents ($file);
         //force download
         force_download ($filename, $data); 
        }
        else{
        $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
    	redirect($this->agent->referrer());
        }
      
    }
    
    public function download_school_text_book() {   
    //load spreadsheet
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/school_text_book.xlsx");
    
    
    $sheet = $spreadsheet->getSheet('1');
    $sheet->removeColumnByIndex('1'); 
    $count=1;
    $category  = $this->common_model->category_by_parent('8');  
    $category = $category['data'];
    foreach($category as $item){
       $name=$item['id'].' | '.$item['name'];
       $sheet->setCellValue('A'.$count, $name); 
       $count++;
    }
    
    $sheet2 = $spreadsheet->getSheet('2');
    $sheet2->removeColumnByIndex('1'); 
    $count2=1;
    $publisher_list  = $this->common_model->publisher_list();  
    $publisher_list = $publisher_list['data'];
    foreach($publisher_list as $publisher){
       $publisher_name = $publisher['id'].' | '.$publisher['name'];
       $sheet2->setCellValue('A'.$count2, $publisher_name); 
       $count2++;
    }
    
    $sheet3 = $spreadsheet->getSheet('3');
    $sheet3->removeColumnByIndex('1'); 
    $count3=1;
    $board_list  = $this->common_model->board_list();  
    $board_list = $board_list['data'];
    foreach($board_list as $board){
       $board_name = $board['id'].' | '.$board['name'];
       $sheet3->setCellValue('A'.$count3, $board_name); 
       $count3++;
    }
    
    $sheet4 = $spreadsheet->getSheet('4');
    $sheet4->removeColumnByIndex('1'); 
    $count4=1;
    $subject_list  = $this->common_model->subject_list();  
    $subject_list = $subject_list['data'];
    foreach($subject_list as $subject){
       $subject_name = $subject['id'].' | '.$subject['name'];
       $sheet4->setCellValue('A'.$count4, $subject_name); 
       $count4++;
    }
    
    $sheet5 = $spreadsheet->getSheet('5');
    $sheet5->removeColumnByIndex('1'); 
    $count5=1;
    $grades_list  = $this->common_model->grades_list();  
    $grades_list = $grades_list['data'];
    foreach($grades_list as $grades){
       $grades_name = $grades['id'].' | '.$grades['name'];
       $sheet5->setCellValue('A'.$count5, $grades_name); 
       $count5++;
    }
    
    //write it again to Filesystem with the same name (=replace)
    $spreadsheet->setActiveSheetIndex(0);
    $writer = new Xlsx($spreadsheet);
    $writer->save('assets/school_text_book.xlsx');
    $this->load->helper('download');
      
    $file = FCPATH.'assets/school_text_book.xlsx';
    $filename = 'sample_school_text_book.xlsx';
    // check file exists    
    if (file_exists($file)) {
     // get file content
     $data = file_get_contents ($file);
     //force download
     force_download ($filename, $data); 
    }
    else{
    $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
	redirect($this->agent->referrer());
    }
  
   }
   
   public function download_note_book() {   
    //load spreadsheet
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load("assets/note_book.xlsx");
    
    
    $sheet = $spreadsheet->getSheet('1');
    $sheet->removeColumnByIndex('1'); 
    $count=1;
    $category  = $this->common_model->category_by_parent('10');  
    $category = $category['data'];
    foreach($category as $item){
       $name=$item['id'].' | '.$item['name'];
       $sheet->setCellValue('A'.$count, $name); 
       $count++;
    }
    
    $sheet2 = $spreadsheet->getSheet('2');
    $sheet2->removeColumnByIndex('1'); 
    $count2=1;
    $publisher_list  = $this->common_model->brand_list('10');  
    $publisher_list = $publisher_list['data'];
    foreach($publisher_list as $publisher){
       $publisher_name = $publisher['id'].' | '.$publisher['name'];
       $sheet2->setCellValue('A'.$count2, $publisher_name); 
       $count2++;
    }
    
    $sheet3 = $spreadsheet->getSheet('3');
    $sheet3->removeColumnByIndex('1'); 
    $count3=1;
    $board_list  = $this->common_model->size_list('10');  
    $board_list = $board_list['data'];
    foreach($board_list as $board){
       $board_name = $board['id'].' | '.$board['name'];
       $sheet3->setCellValue('A'.$count3, $board_name); 
       $count3++;
    }
    
    $sheet4 = $spreadsheet->getSheet('4');
    $sheet4->removeColumnByIndex('1'); 
    $count4=1;
    $subject_list  = $this->common_model->binding_type_list('10');  
    $subject_list = $subject_list['data'];
    foreach($subject_list as $subject){
       $subject_name = $subject['id'].' | '.$subject['name'];
       $sheet4->setCellValue('A'.$count4, $subject_name); 
       $count4++;
    }
    
    //write it again to Filesystem with the same name (=replace)
    $spreadsheet->setActiveSheetIndex(0);
    $writer = new Xlsx($spreadsheet);
    $writer->save('assets/note_book.xlsx');
    $this->load->helper('download');
      
    $file = FCPATH.'assets/note_book.xlsx';
    $filename = 'sample_note_book.xlsx';
    // check file exists    
    if (file_exists($file)) {
     // get file content
     $data = file_get_contents ($file);
     //force download
     force_download ($filename, $data); 
    }
    else{
    $this->session->set_flashdata('errors', 'There is some error while downloding sample file!');
	redirect($this->agent->referrer());
    }
  
   }
    
    
    
}

?>