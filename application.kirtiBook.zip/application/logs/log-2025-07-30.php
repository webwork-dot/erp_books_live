<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-07-30 15:24:41 --> Severity: Warning --> implode(): Invalid arguments passed /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/models/Excel_model.php 826
ERROR - 2025-07-30 15:24:41 --> Severity: Warning --> implode(): Invalid arguments passed /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/models/Excel_model.php 826
