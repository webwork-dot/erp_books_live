<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-07-18 19:21:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/libraries/dompdf/src/Adapter/CPDF.php:1131) /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/helpers/json_output_helper.php 13
