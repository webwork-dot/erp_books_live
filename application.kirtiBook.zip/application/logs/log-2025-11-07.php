<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-07 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:06:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:12:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:17:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:22:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:41:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:48:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:53:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 00:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 00:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 00:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:07:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:24:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:33:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:37:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:41:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:46:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 01:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 01:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 01:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:03:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:06:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:12:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:17:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:34:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:39:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:44:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 02:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:58:02 --> Unable to connect to the database
ERROR - 2025-11-07 02:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 02:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 03:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 03:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:02:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:09:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:11:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:14:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:16:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:34:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:41:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:48:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:53:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:56:02 --> Unable to connect to the database
ERROR - 2025-11-07 03:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 03:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 03:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:07:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:17:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:22:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:29:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:32:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:39:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:43:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:46:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:57:02 --> Unable to connect to the database
ERROR - 2025-11-07 04:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 04:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 04:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 05:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:03:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:09:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:11:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:22:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:32:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:37:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:51:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:54:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:54:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:57:02 --> Unable to connect to the database
ERROR - 2025-11-07 05:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 05:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 05:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 06:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 06:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:01:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:08:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:26:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:03 --> Unable to connect to the database
ERROR - 2025-11-07 06:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:30:03 --> Unable to connect to the database
ERROR - 2025-11-07 06:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:34:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:39:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:47:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:53:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 06:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 06:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 06:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:02:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:08:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:11:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:29:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:41:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:47:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:53:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:56:02 --> Unable to connect to the database
ERROR - 2025-11-07 07:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 07:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 07:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:07:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:24:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:27:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:32:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:39:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:44:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:53:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 08:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 08:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 08:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:01:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:07:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:12:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:22:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:39:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 09:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 09:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 09:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:07:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:11:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:29:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:44:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:48:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:54:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:54:02 --> Unable to connect to the database
ERROR - 2025-11-07 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 10:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 10:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 11:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:06:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:17:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:33:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:37:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:43:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:48:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:57:02 --> Unable to connect to the database
ERROR - 2025-11-07 11:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 11:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 11:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 12:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:02:02 --> Unable to connect to the database
ERROR - 2025-11-07 12:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 12:06:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:06:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:07:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:07:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:08:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:08:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:09:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:09:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:10:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:10:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:11:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:11:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:12:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:12:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:13:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:13:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:14:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:14:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:16:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:16:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:17:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:17:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:18:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:18:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:18:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:18:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:19:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:19:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:21:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:21:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:21:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:21:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:22:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:22:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:23:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:23:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:24:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:24:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:26:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:26:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:27:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:27:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:28:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:28:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:29:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:29:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:31:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:31:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:32:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:32:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:33:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:33:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:34:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:34:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:36:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:36:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:36:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:36:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:37:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:37:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:38:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:38:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:39:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:39:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:40:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:40:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:40:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:40:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:41:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:41:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:42:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:42:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:42:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:42:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:43:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:43:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:44:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:44:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:45:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:45:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:46:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:46:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:47:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:47:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:48:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:48:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:49:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:49:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:50:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:50:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:51:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:51:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:52:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:52:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:53:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:53:09 --> Unable to connect to the database
ERROR - 2025-11-07 12:54:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:54:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:54:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:54:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 12:56:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:56:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:57:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:57:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:58:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:58:07 --> Unable to connect to the database
ERROR - 2025-11-07 12:59:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 12:59:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:01:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:01:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:02:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:02:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:03:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:03:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:04:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:05:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:06:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:06:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:07:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:07:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:08:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:08:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:09:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:09:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:10:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:10:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:11:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:11:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:12:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:12:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:13:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:13:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:14:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:14:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:15:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:15:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:16:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:16:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:17:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:17:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:18:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:18:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:18:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:18:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:19:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:19:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:20:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:21:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:21:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:21:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:21:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:22:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:22:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:23:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:23:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:24:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:24:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:25:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:25:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:25:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:25:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:26:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:26:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:27:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:27:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:28:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:28:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:29:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:29:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:30:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:30:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:31:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:31:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:32:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:32:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:33:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:33:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:34:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:34:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:36:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:36:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:36:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:36:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:37:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:37:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:38:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:38:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:39:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:39:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:41:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:41:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:42:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:42:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:42:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:42:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:43:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:43:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:44:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:44:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:45:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:45:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:46:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:46:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:47:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:47:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:48:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:48:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:49:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:49:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:51:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:51:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:52:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:52:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:53:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:53:09 --> Unable to connect to the database
ERROR - 2025-11-07 13:54:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:54:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:54:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:54:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:55:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:55:08 --> Unable to connect to the database
ERROR - 2025-11-07 13:56:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:56:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:57:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:57:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:58:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:58:07 --> Unable to connect to the database
ERROR - 2025-11-07 13:59:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 13:59:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:01:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:01:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:02:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:02:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:03:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:03:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:04:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:05:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:05:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:05:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:05:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:05:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:06:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:06:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:07:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:07:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:08:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:08:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:09:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:09:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:10:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:10:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:10:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:10:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:10:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:10:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:10:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:10:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:11:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:11:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:12:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:12:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:13:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:13:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:14:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:14:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:16:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:16:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:17:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:17:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:18:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:18:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:18:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:18:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:19:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:19:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:20:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:20:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:20:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:20:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:20:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:21:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:21:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:21:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:21:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:22:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:22:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:23:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:23:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:24:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:24:10 --> Unable to connect to the database
ERROR - 2025-11-07 14:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:25:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:25:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:25:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:25:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:25:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:25:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:26:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:26:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:27:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:27:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:28:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:28:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:29:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:29:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:30:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:30:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:31:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:31:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:32:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:32:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:33:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:33:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:34:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:34:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:35:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:35:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:36:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:36:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:36:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:36:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:37:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:37:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:38:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:38:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:39:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:39:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:40:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:41:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:41:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:42:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:42:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:42:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:42:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:43:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:43:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:44:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:44:10 --> Unable to connect to the database
ERROR - 2025-11-07 14:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:45:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:45:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:45:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:45:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:45:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:45:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:45:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:45:10 --> Unable to connect to the database
ERROR - 2025-11-07 14:48:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:48:10 --> Unable to connect to the database
ERROR - 2025-11-07 14:49:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:49:10 --> Unable to connect to the database
ERROR - 2025-11-07 14:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:50:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:50:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:51:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:51:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:52:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:52:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:53:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:53:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:54:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:54:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:54:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:54:08 --> Unable to connect to the database
ERROR - 2025-11-07 14:55:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:55:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:55:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:55:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:55:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:55:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:55:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:55:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:55:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:55:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:56:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:56:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:57:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:57:09 --> Unable to connect to the database
ERROR - 2025-11-07 14:58:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:58:07 --> Unable to connect to the database
ERROR - 2025-11-07 14:59:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 14:59:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:00:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:00:10 --> Unable to connect to the database
ERROR - 2025-11-07 15:01:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:01:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:02:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:02:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:03:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:03:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:04:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:05:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:05:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:06:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:06:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:07:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:07:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:08:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:08:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:09:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:09:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:10:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:10:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:11:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:11:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:12:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:12:07 --> Unable to connect to the database
ERROR - 2025-11-07 15:13:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:13:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:14:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:14:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:09 --> Unable to connect to the database
ERROR - 2025-11-07 15:15:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:15:10 --> Unable to connect to the database
ERROR - 2025-11-07 15:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:26:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:26:08 --> Unable to connect to the database
ERROR - 2025-11-07 15:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:30:03 --> Unable to connect to the database
ERROR - 2025-11-07 15:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:32:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:37:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:46:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:48:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:51:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 15:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:58:02 --> Unable to connect to the database
ERROR - 2025-11-07 15:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 15:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:03:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:08:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:15:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:15:03 --> Unable to connect to the database
ERROR - 2025-11-07 16:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:16:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:24:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:33:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:38:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:43:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 16:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 16:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 16:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:04:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:06:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:17:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:24:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:27:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:39:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:44:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:51:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 17:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:58:02 --> Unable to connect to the database
ERROR - 2025-11-07 17:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 17:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 18:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 18:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:02:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:06:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:12:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:16:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:29:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:33:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:38:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:51:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 18:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 18:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 18:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 19:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:02:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:09:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:11:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:23:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:26:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:41:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:48:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 19:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 19:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 19:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:07:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:14:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:27:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:34:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:42:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:51:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 20:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:58:02 --> Unable to connect to the database
ERROR - 2025-11-07 20:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 20:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:03:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:17:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:19:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:19:06 --> Unable to connect to the database
ERROR - 2025-11-07 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:26:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:30:03 --> Unable to connect to the database
ERROR - 2025-11-07 21:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:32:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:36:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:44:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:51:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 21:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 21:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 21:59:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:02:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:03:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:06:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:12:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:13:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:18:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:19:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:24:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:27:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:28:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:31:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:33:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:37:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:38:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:43:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:44:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:46:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:47:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:49:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:52:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:54:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:54:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:57:02 --> Unable to connect to the database
ERROR - 2025-11-07 22:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 22:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 22:59:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 23:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:00:03 --> Unable to connect to the database
ERROR - 2025-11-07 23:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:01:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:02:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:03:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:04:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:05:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:06:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:07:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:08:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:09:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:10:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:11:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:12:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:13:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:14:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:16:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:17:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:18:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:19:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:21:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:21:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:22:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:23:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:24:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:26:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:27:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:28:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:29:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:31:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:32:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:33:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:34:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:36:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:37:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:38:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:39:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:40:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:41:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:42:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:43:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:44:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:46:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:47:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:48:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:49:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:51:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:52:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:53:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:54:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-07 23:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:56:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:57:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:58:01 --> Unable to connect to the database
ERROR - 2025-11-07 23:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-07 23:59:02 --> Unable to connect to the database
