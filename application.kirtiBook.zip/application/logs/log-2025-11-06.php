<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-06 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:03:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:17:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:26:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:43:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 00:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 00:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 00:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 01:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 01:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:14:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:17:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:27:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 01:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 01:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 01:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:13:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:16:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:23:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:26:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:31:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:39:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:43:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 02:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:58:02 --> Unable to connect to the database
ERROR - 2025-11-06 02:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 02:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:02:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:06:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:23:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:27:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:31:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:36:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:36:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:41:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:46:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:51:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 03:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:58:02 --> Unable to connect to the database
ERROR - 2025-11-06 03:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 03:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:04:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:09:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:13:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:32:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:36:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:36:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:39:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:41:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:52:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:56:02 --> Unable to connect to the database
ERROR - 2025-11-06 04:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 04:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 04:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 05:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:03:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:12:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:32:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 05:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:58:02 --> Unable to connect to the database
ERROR - 2025-11-06 05:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 05:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:03:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:12:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:16:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:33:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:51:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 06:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 06:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 06:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 07:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 07:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:02:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:09:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:13:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:17:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:26:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:31:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:43:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:52:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:56:02 --> Unable to connect to the database
ERROR - 2025-11-06 07:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 07:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 07:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:02:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:06:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:23:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:32:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:39:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:43:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 08:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 08:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 08:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:03:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:07:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:52:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 09:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 09:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 09:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:04:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:09:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:14:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:23:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:27:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:31:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:44:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:56:02 --> Unable to connect to the database
ERROR - 2025-11-06 10:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 10:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 10:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 11:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 11:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:04:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:06:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:12:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:15:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:15:03 --> Unable to connect to the database
ERROR - 2025-11-06 11:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:31:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:36:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:36:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:43:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 11:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 11:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 11:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 12:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 12:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:03:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:09:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:14:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:22:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:32:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:44:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:46:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 12:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 12:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 12:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:03:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:24:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:33:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-06 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-06 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-06 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-06 13:35:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:35:07 --> Unable to connect to the database
ERROR - 2025-11-06 13:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:41:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:51:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 13:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 13:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 13:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:07:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:16:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:32:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:46:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:49:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 14:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 14:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 14:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 15:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 15:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:33:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:43:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:46:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:51:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 15:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 15:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 15:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 16:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 16:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:27:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:41:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:49:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 16:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 16:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 16:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:22:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:33:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:49:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:51:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 17:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 17:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 17:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:04:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:06:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:16:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:31:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:44:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:57:02 --> Unable to connect to the database
ERROR - 2025-11-06 18:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 18:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 18:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:02:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:09:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:23:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:30:03 --> Unable to connect to the database
ERROR - 2025-11-06 19:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:33:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:38:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:41:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:45:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:45:03 --> Unable to connect to the database
ERROR - 2025-11-06 19:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:52:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 19:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:58:02 --> Unable to connect to the database
ERROR - 2025-11-06 19:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 19:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 20:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 20:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:04:07 --> Unable to connect to the database
ERROR - 2025-11-06 20:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:06:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:12:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:15:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:15:03 --> Unable to connect to the database
ERROR - 2025-11-06 20:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:19:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:37:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:39:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:44:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:46:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-06 20:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 20:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 20:59:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:14:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:22:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:29:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:45:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:45:03 --> Unable to connect to the database
ERROR - 2025-11-06 21:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:56:02 --> Unable to connect to the database
ERROR - 2025-11-06 21:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 21:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 21:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 22:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:00:03 --> Unable to connect to the database
ERROR - 2025-11-06 22:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:01:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:04:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:05:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:06:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:08:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:11:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:13:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:14:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:18:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:21:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:23:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:26:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:28:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:33:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:34:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:41:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:42:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:47:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:48:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:53:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:54:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:56:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 22:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:58:02 --> Unable to connect to the database
ERROR - 2025-11-06 22:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 22:59:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:01:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:02:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:03:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:04:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:06:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:07:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:08:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:09:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:10:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:11:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:12:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:13:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:14:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:16:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:17:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:18:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:19:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:21:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:22:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:23:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:24:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:26:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:27:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:28:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:29:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:31:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:32:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:33:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:34:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:35:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:36:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:37:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:38:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:39:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:40:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:41:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:42:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:43:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:44:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:46:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:47:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:48:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:49:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:50:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:51:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:52:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:53:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:54:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:56:02 --> Unable to connect to the database
ERROR - 2025-11-06 23:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:57:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:58:01 --> Unable to connect to the database
ERROR - 2025-11-06 23:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-06 23:59:02 --> Unable to connect to the database
