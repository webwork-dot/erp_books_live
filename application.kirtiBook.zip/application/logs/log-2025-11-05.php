<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-05 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-05 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:22:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:23:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:24:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:26:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:27:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:28:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:29:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:31:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:32:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:33:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:34:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:37:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:38:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:39:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:41:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:42:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:42:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:43:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:44:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:46:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:47:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:48:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:49:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:51:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:52:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:53:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 18:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:56:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:57:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:58:01 --> Unable to connect to the database
ERROR - 2025-11-05 18:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 18:59:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:01:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:02:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:03:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:04:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:04:06 --> Unable to connect to the database
ERROR - 2025-11-05 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:06:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:07:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:08:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:09:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:11:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:12:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:13:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:14:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:16:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:17:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:19:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:21:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:22:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:23:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:24:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:26:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:27:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:28:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:29:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:31:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:32:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:32:08 --> Unable to connect to the database
ERROR - 2025-11-05 19:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:33:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:34:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:35:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:35:03 --> Unable to connect to the database
ERROR - 2025-11-05 19:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:36:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:36:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:37:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:38:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:39:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:40:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:40:07 --> Unable to connect to the database
ERROR - 2025-11-05 19:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:40:08 --> Unable to connect to the database
ERROR - 2025-11-05 19:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:41:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:43:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:44:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:46:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:47:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:48:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:49:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:51:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:52:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:53:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 19:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:56:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:57:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:58:01 --> Unable to connect to the database
ERROR - 2025-11-05 19:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 19:59:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:01:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:02:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:03:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:04:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:06:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:07:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:08:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:09:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:11:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:12:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:13:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:14:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:16:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:17:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:19:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:21:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:21:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:22:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:23:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:24:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:26:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:27:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:28:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:29:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:30:03 --> Unable to connect to the database
ERROR - 2025-11-05 20:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:31:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:32:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:33:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:34:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:37:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:38:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:39:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:41:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:43:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:44:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:46:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:47:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:48:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:49:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:51:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:52:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:53:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:56:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:57:02 --> Unable to connect to the database
ERROR - 2025-11-05 20:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:58:01 --> Unable to connect to the database
ERROR - 2025-11-05 20:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 20:59:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:00:03 --> Unable to connect to the database
ERROR - 2025-11-05 21:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:01:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:02:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:03:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:04:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:06:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:07:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:08:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:09:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:10:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:11:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:12:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:13:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:14:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:16:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:17:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:19:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:21:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:21:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:22:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:23:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:24:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:26:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:27:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:28:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:29:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:31:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:32:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:33:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:34:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:35:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:37:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:38:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:39:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:41:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:43:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:44:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:46:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:47:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:48:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:49:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:50:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:51:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:52:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:53:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:56:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:57:02 --> Unable to connect to the database
ERROR - 2025-11-05 21:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:58:01 --> Unable to connect to the database
ERROR - 2025-11-05 21:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 21:59:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:00:03 --> Unable to connect to the database
ERROR - 2025-11-05 22:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:01:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:02:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:03:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:04:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:06:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:07:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:08:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:09:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:11:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:12:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:13:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:14:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:16:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:17:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:18:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:18:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:19:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:22:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:23:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:24:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:25:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:26:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:27:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:28:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:29:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:31:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:32:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:33:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:34:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:36:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:37:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:38:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:39:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:40:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:41:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:42:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:42:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:43:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:44:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:46:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:47:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:48:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:49:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:51:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:52:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:53:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:56:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:57:01 --> Unable to connect to the database
ERROR - 2025-11-05 22:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:58:02 --> Unable to connect to the database
ERROR - 2025-11-05 22:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 22:59:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:00:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:01:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:02:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:03:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:04:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:05:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:05:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:06:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:07:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:08:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:09:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:10:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:11:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:12:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:13:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:14:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:15:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:16:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:17:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:18:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:19:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:20:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:20:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:21:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:22:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:23:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:24:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:25:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:26:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:27:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:28:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:29:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:30:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:31:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:32:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:33:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:34:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:35:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:36:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:36:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:37:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:38:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:39:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:40:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:41:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:42:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:43:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:44:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:45:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:46:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:47:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:48:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:49:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:50:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:51:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:52:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:53:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:54:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:55:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:55:02 --> Unable to connect to the database
ERROR - 2025-11-05 23:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:56:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:57:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:58:01 --> Unable to connect to the database
ERROR - 2025-11-05 23:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-05 23:59:02 --> Unable to connect to the database
