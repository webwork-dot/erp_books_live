<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-08 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:03:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:14:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:17:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:28:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:32:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:41:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:45:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:45:03 --> Unable to connect to the database
ERROR - 2025-11-08 00:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:53:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 00:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 00:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 00:59:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:02:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:08:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:14:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:19:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:26:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:33:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:39:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:51:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:56:02 --> Unable to connect to the database
ERROR - 2025-11-08 01:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 01:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 01:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 02:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 02:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:01:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:07:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:12:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:32:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:37:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:44:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:47:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:53:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 02:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 02:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 02:59:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:02:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:08:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:13:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:31:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:41:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:44:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:47:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:53:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 03:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:58:02 --> Unable to connect to the database
ERROR - 2025-11-08 03:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 03:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:04:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:07:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:13:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:17:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:28:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:32:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:41:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:56:02 --> Unable to connect to the database
ERROR - 2025-11-08 04:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 04:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 04:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:03:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:09:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:11:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:14:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:28:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:34:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:37:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:49:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:51:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 05:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 05:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 06:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:04:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:06:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:09:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:09:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:11:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:23:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:28:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:33:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:37:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:49:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:51:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:56:02 --> Unable to connect to the database
ERROR - 2025-11-08 06:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 06:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 06:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 07:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:01:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:07:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:12:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:16:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:33:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:38:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:43:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:46:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:49:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:51:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:51:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:57:02 --> Unable to connect to the database
ERROR - 2025-11-08 07:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 07:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 07:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 08:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 08:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:03:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:06:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:11:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:17:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:28:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:31:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:43:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:46:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:57:02 --> Unable to connect to the database
ERROR - 2025-11-08 08:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 08:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 08:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 09:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 09:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:01:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:07:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:11:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:15:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:15:03 --> Unable to connect to the database
ERROR - 2025-11-08 09:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:17:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:39:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:47:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:53:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:56:02 --> Unable to connect to the database
ERROR - 2025-11-08 09:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 09:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 09:59:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:03:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:11:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:16:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:16:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:20:07 --> Unable to connect to the database
ERROR - 2025-11-08 10:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:28:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:28:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:33:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:38:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:52:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 10:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 10:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 10:59:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:04:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:06:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:13:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:31:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:31:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:38:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:41:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:57:02 --> Unable to connect to the database
ERROR - 2025-11-08 11:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 11:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 11:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 12:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:07:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:13:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:19:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:24:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:26:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:03 --> Unable to connect to the database
ERROR - 2025-11-08 12:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:30:03 --> Unable to connect to the database
ERROR - 2025-11-08 12:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:34:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:37:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:41:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:45:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:45:03 --> Unable to connect to the database
ERROR - 2025-11-08 12:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:57:02 --> Unable to connect to the database
ERROR - 2025-11-08 12:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 12:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 12:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:03:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:03:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:12:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:03 --> Unable to connect to the database
ERROR - 2025-11-08 13:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:30:03 --> Unable to connect to the database
ERROR - 2025-11-08 13:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:39:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:39:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:44:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:47:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:52:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 13:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 13:59:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 13:59:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:02:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:02:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:08:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:08:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:14:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:18:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:23:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:26:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:30:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:30:03 --> Unable to connect to the database
ERROR - 2025-11-08 14:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:33:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:33:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:37:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:44:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:44:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:57:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:57:02 --> Unable to connect to the database
ERROR - 2025-11-08 14:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 14:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 14:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 15:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 15:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:04:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:06:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:12:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:17:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:21:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:21:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:32:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:32:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:34:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:34:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:38:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:43:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:55:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:56:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:56:02 --> Unable to connect to the database
ERROR - 2025-11-08 15:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:58:01 --> Unable to connect to the database
ERROR - 2025-11-08 15:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 15:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 16:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 16:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:01:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:04:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:04:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:05:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:05:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:06:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:06:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:07:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:07:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:11:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:11:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:13:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:13:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:17:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:19:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:19:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:22:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:24:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:24:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:27:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:27:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:29:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:29:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:32:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:36:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:36:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:37:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:37:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:41:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:41:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:42:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:42:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:47:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:48:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:52:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:54:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:55:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:55:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:56:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:56:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:57:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:57:01 --> Unable to connect to the database
ERROR - 2025-11-08 16:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:58:02 --> Unable to connect to the database
ERROR - 2025-11-08 16:59:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 16:59:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:00:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:00:03 --> Unable to connect to the database
ERROR - 2025-11-08 17:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:01:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:02:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:02:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:03:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:03:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:04:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:04:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:05:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:05:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:06:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:07:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:07:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:08:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:08:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:09:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:09:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:10:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:10:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:10:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:11:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:11:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:12:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:12:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:13:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:13:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:14:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:15:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:15:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:16:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:16:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:17:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:17:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:18:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:19:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:19:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:20:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:20:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:20:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:21:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:21:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:22:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:22:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:23:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:24:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:24:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:25:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:25:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:25:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:26:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:26:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:27:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:27:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:28:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:29:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:29:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:30:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:30:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:31:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:31:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:32:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:32:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:33:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:33:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:34:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:35:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:35:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:35:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:36:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:36:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:37:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:37:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:38:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:38:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:39:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:39:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:40:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:40:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:40:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:41:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:41:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:42:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:42:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:43:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:44:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:44:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:45:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:46:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:46:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:47:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:48:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:49:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:49:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:50:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:50:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:50:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:51:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:52:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:52:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:53:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:53:01 --> Unable to connect to the database
ERROR - 2025-11-08 17:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:54:02 --> Unable to connect to the database
ERROR - 2025-11-08 17:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-08 17:54:02 --> Unable to connect to the database
