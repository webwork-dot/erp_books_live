<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-04 14:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/system/database/drivers/mysqli/mysqli_driver.php 149
ERROR - 2025-11-04 14:48:04 --> Unable to connect to the database
