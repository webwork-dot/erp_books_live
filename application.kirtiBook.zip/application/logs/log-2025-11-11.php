<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-11 12:01:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/models/Product_master_model.php 1084
