<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-06-21 12:13:03 --> Severity: Warning --> usort() expects parameter 1 to be array, null given /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/models/Shipping_model.php 100
