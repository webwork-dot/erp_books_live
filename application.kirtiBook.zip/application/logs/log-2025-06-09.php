<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-06-09 18:54:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/libraries/dompdf/lib/php-svg-lib/src/Svg/Document.php 259
ERROR - 2025-06-09 18:54:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/libraries/dompdf/src/Adapter/CPDF.php:1131) /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/helpers/json_output_helper.php 13
ERROR - 2025-06-09 19:00:09 --> Severity: error --> Exception: Call to undefined method Cron_model::add_cronjob_track() /www/wwwroot/kirtibook.in/liveapi.kirtibook.in/vendor/v1/application/models/Cron_model.php 1028
