<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Packaging_material_model extends CI_Model
{
  
    public function get_paginated_stock_allocate($vendor_id, $per_page, $offset, $filter)
    {
        $report_data = array();
        $warehouse_id = $filter['warehouse_id'];
		
		$count = $this->db->query("SELECT sh.id,s.name as stock_name,sh.quantity as stock_quantity
        FROM vendor_stock_manage as sh
        INNER JOIN stock_manage as sm ON sh.stock_id = sm.id
        INNER JOIN stock as s ON sm.stock_id = s.id
        where sh.warehouse_id = '$warehouse_id'")->num_rows();
		$query = $this->db->query("SELECT sh.id,s.name as stock_name,sh.quantity as stock_quantity,sh.stock_id as category_id
        FROM vendor_stock_manage as sh
        INNER JOIN stock_manage as sm ON sh.stock_id = sm.id
        INNER JOIN stock as s ON sm.stock_id = s.id
        where sh.warehouse_id = '$warehouse_id' LIMIT $offset,$per_page");
        // echo $this->db->last_query();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                /*$dispatched_date=$row['dispatched_date'];
                if($dispatched_date!=NULL){
                 $date_out_ = date("Y-m-d H:i:s", strtotime($row['dispatched_date']));
                $pending_out_for_delivery = get_time_difference($date_out_);
                }
                else{
                  $pending_out_for_delivery='';  
                }*/
                
                $report_data[] = array(
                    "id" => $row['id'],
                    "category_id" => $row['category_id'],
                    "stock_name" => $row['stock_name'],
                    "stock_quantity" => $row['stock_quantity'],
                );
            }
        }
        
      
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $report_data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function packaging_materials_history($vendor_id, $per_page, $offset, $filter)
    {
        $report_data = array();
        $warehouse_id = $filter['warehouse_id'];
        $stock_id = $filter['id'];
        $count = $this->db->query("SELECT s.name as stock_name,sh.quantity as stock_quantity,sh.date,sh.type
        FROM vendor_stock_history as sh
        INNER JOIN stock_manage as sm ON sh.stock_manege_id = sm.id
        INNER JOIN stock as s ON sm.stock_id = s.id
        where sh.parent_id = '$stock_id'")->num_rows();
		$query = $this->db->query("SELECT sh.from_name,s.name as stock_name,sh.quantity as stock_quantity,sh.date,sh.type
        FROM vendor_stock_history as sh 
        INNER JOIN stock_manage as sm ON sh.stock_manege_id = sm.id
        INNER JOIN stock as s ON sm.stock_id = s.id
        where sh.parent_id = '$stock_id' LIMIT $offset,$per_page");
        
        
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $report_data[] = array(
                    // "id" => $row['id'],
                    "stock_name" => $row['stock_name'],
                    "stock_quantity" => $row['stock_quantity'],
                    "from_name" => ucfirst($row['from_name']),
                    "date" => $row['date'],
                    "type" => $row['type'],
                );
            }
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $report_data,
                'total_data' => $count,
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'error',
                'data' => $report_data,
                'total_data' => $count,
            );
        }
        
        return $resultpost;
    }
    
    
}