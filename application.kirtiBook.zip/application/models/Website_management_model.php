<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website_management_model extends CI_Model
{
    public function check_duplicate_entry($table_name,$column_name,$value,$product_id, $type)
    {
        if ($type == 'on_create') {
            $count = $this->db->get_where($table_name, array(
                $column_name => $value,
            ))->num_rows();
            
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }
        
        if ($type == 'on_update') {
            $count = $this->db->get_where($table_name, array(
                'id!=' => $product_id,
                $column_name => $value,
            ))->num_rows();
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }
    }
    
    public function get_publisher_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `publisher` WHERE id!='' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `publisher` WHERE id!='' $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            
            
            
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_publisher_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM publisher where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_publisher($data,$user_id)
    {
        $this->db->insert('publisher', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_publisher($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('publisher', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function publisher_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('publisher');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_board_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `board` WHERE id!='' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `board` WHERE id!='' $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_board_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM board where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_board($data,$user_id)
    {
        $this->db->insert('board', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_board($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('board', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function board_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('board');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_subject_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `subject` WHERE id!='' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `subject` WHERE id!='' $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_subject_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM subject where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_subject($data,$user_id)
    {
        $this->db->insert('subject', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_subject($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('subject', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function subject_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('subject');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_grade_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `grade_list` WHERE id!='' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name,sort FROM `grade_list` WHERE id!='' $where order by sort asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "sort" => $row['sort'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_grade_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name,sort FROM grade_list where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "sort" => $row['sort'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_grade($data,$user_id)
    {
        $this->db->insert('grade_list', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_grade($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('grade_list', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function grade_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('grade_list');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_brand_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `brand` WHERE id!='' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `brand` WHERE id!='' $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_brand_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM brand where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_brand($data,$user_id)
    {
        $this->db->insert('brand', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_brand($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('brand', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function brand_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('brand');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_binding_type_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `binding_type` WHERE id!='' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `binding_type` WHERE id!='' $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_binding_type_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM binding_type where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_binding_type($data,$user_id)
    {
        $this->db->insert('binding_type', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_binding_type($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('binding_type', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function binding_type_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('binding_type');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_categories_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `categories` WHERE id!='' and parent_id='0' $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `categories` WHERE id!='' and parent_id='0' $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_categories_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM categories where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_categories($data,$user_id)
    {
        $this->db->insert('categories', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_categories($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('categories', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function categories_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('categories');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function get_subcategories_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND ((sc.name  LIKE '%$keyword%') OR (c.name  LIKE '%$keyword%'))";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT sc.id,sc.name,c.name as category_name FROM categories as sc INNER JOIN categories as c ON sc.parent_id = c.id where sc.parent_id!='0' and c.parent_id!='0' and (c.parent_id='7' || c.parent_id='6') $where order by c.name asc")->num_rows();	
        $query = $this->db->query("SELECT sc.id,sc.name,c.name as category_name FROM categories as sc INNER JOIN categories as c ON sc.parent_id = c.id where sc.parent_id!='0' and c.parent_id!='0' and (c.parent_id='7' || c.parent_id='6') $where order by c.name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "category_name" => $row['category_name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_subcategories_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name,parent_id FROM categories where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $parent_id = $row['parent_id'];
            $query_cat = $this->db->query("SELECT name FROM categories where id='$parent_id' limit 1")->row_array();
            
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "parent_id" => $row['parent_id'],
                "parent_name" => $query_cat['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function get_category_by_parent($parent_id="")
    {
        $query = $this->db->query("SELECT id,name FROM `categories` WHERE (`parent_id`!='0') and (`parent_id`='6' OR `parent_id`='7') order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    } 
    
    public function get_size_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $where = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  .= "AND (name  LIKE '%$keyword%')";
        } else {
            $where .= '';
        }
        
        $count = $this->db->query("SELECT id FROM `size` WHERE `category_id`=10 $where order by name asc")->num_rows();	
        $query = $this->db->query("SELECT id,name FROM `size` WHERE `category_id`=10 $where order by name asc LIMIT $offset,$per_page");	
        
        // echo $this->db->last_query();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    public function get_size_details($user_id, $id)
    {
        $data = array();
        $query = $this->db->query("SELECT id,name FROM size where id='$id' limit 1");
        if($query->num_rows() > 0){
            $row     = $query->row_array();
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
            );
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $query->num_rows()
        );
        
        
        return $resultpost;
    }
    
    public function add_size($data,$user_id)
    {
        $this->db->insert('size', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function edit_size($data,$user_id,$id)
    {
        $this->db->where('id',$id);
        $this->db->update('size', $data);
        $product_id = $this->db->insert_id();
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        return $resultpost;
    }
    
    public function size_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
            $this->db->where('id', $ids);
            $this->db->delete('size');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    
}