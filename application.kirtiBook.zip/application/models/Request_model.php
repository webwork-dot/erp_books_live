<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Request_model extends CI_Model
{
    
    public function category_list($user_id,$parent_id){ 
        $data = array(); 
        $where = '';
        if($parent_id == 0){
            $where = 'and id IN (6,7,22)';
        }
        
        $query = $this->db->query("SELECT name, id FROM categories WHERE parent_id='$parent_id' $where ORDER BY name asc");
        foreach($query->result_array() as $item){
		    
            $data[] = array(	
                "id" => $item['id'],				
                "name" => $item['name'],	           				
            );       
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
        );
        
        return  $resultpost;
    }
    
    public function school_list($user_id){ 
        $data = array(); 
        $query = $this->db->query("SELECT name,id,status FROM school WHERE vendor_id ='$user_id' ORDER BY name asc");
        foreach($query->result_array() as $item){
		    if($item['status'] == 1){
		        $status = 'Active';
		        $color = 'sch-green';
		    }else{
		        $status = 'Inactive';
		        $color = 'sch-red';
		    }
            $data[] = array(	
                "id" => $item['id'],				
                "name" => $item['name'],	           				
                "status" => $status,	           				
                "color" => $color,	           				
            );       
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
        );
        
        return  $resultpost;
    }
    
    public function order_list($user_id,$order_status){ 
        $data = array(); 
        if($order_status == 'Pending Orders'){
            $order_status = 'pending';
        }elseif($order_status == 'Processing Order'){
            $order_status = 'processing';
        }elseif($order_status == 'Ready For Shipment'){
            $order_status = 'shipment';
        }elseif($order_status == 'Out For Delivery'){
            $order_status = 'out_for_delivery';
        }elseif($order_status == 'Delivered Order'){
            $order_status = 'delivered';
        }elseif($order_status == 'Cancelled Order'){
            $order_status = 'cancelled';
        }
        
        $query  = $this->db->query("SELECT id,order_number FROM orders WHERE (vendor_id = '$user_id') AND (payment_status='payment_received') AND (order_slot!='') and order_status='$order_status' ORDER BY id desc");
        foreach($query->result_array() as $item){
		    
            $data[] = array(	
                "id" => $item['id'],				
                "name" => $item['order_number'],	           				
            );       
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
        );
        
        return  $resultpost;
    }
    
    public function add_product_request($user_id,$type,$category,$sub_category,$message,$title)   {
        date_default_timezone_set('Asia/Kolkata');
        $data['user_id'] = $user_id;
        $data['type'] = $type;
        $data['category'] = $category;
        $data['sub_category'] = $sub_category;
        $data['message'] = $message;
        $data['title'] = $title;
        $data['added_date']    = date('Y-m-d H:i:s');
        $data['dept_id'] = '2';
        $data['dept_name'] = 'Catalogue team';
        
        if($this->db->insert('request_log', $data)){
            $insert_id = $this->db->insert_id();
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'id' => $insert_id,
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'Request Not Submitted',
            );
        }
        
        return $resultpost;
    }
    
    public function upload_product_doc($user_id,$id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');
        
        $upload_path = vendor_download_url().'/uploads/request/';
        
        if (isset($_FILES['file1']) && is_uploaded_file($_FILES['file1']['tmp_name'])) {
            $ext1                    = pathinfo($_FILES['file1']['name'], PATHINFO_EXTENSION);
            $data['document'] = 'document_' . generate_unique_id() . '.' . $ext1;
            move_uploaded_file($_FILES['file1']['tmp_name'], $upload_path . $data['document']);
        }
        
        $this->db->where('user_id', $user_id);
        $this->db->where('id', $id);
        $this->db->update('request_log', $data);
        
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
        );
        return $resultpost;
    }
    
    
    public function add_school_request($user_id,$type,$school_type,$school_name,$school_for,$board,$school_id,$school_status,$message,$title)   {
        date_default_timezone_set('Asia/Kolkata');
        $data['user_id'] = $user_id;
        $data['type'] = $type;
        $data['school_type'] = $school_type;
        $data['school_name'] = $school_name;
        $data['school_for'] = $school_for;
        $data['board'] = $board;
        $data['school_id'] = $school_id;
        $data['school_status'] = $school_status;
        $data['message'] = $message;
        $data['title'] = $title;
        $data['added_date']    = date('Y-m-d H:i:s');
        $data['dept_id'] = '2';
        $data['dept_name'] = 'Catalogue team';
        
        
        
        if($this->db->insert('request_log', $data)){
            $insert_id = $this->db->insert_id();
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'id' => $insert_id,
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'error',
            );
        }
        
        return $resultpost;
    }
    
    public function upload_school_doc($user_id,$id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');
        
        $upload_path = vendor_download_url().'/uploads/request/';
        
        if (isset($_FILES['file1']) && is_uploaded_file($_FILES['file1']['tmp_name'])) {
            $ext1                    = pathinfo($_FILES['file1']['name'], PATHINFO_EXTENSION);
            $data['school_logo'] = 'school_logo_' . generate_unique_id() . '.' . $ext1;
            move_uploaded_file($_FILES['file1']['tmp_name'], $upload_path . $data['school_logo']);
        }
        
        if (isset($_FILES['file2']) && is_uploaded_file($_FILES['file2']['tmp_name'])) {
            $ext1                    = pathinfo($_FILES['file2']['name'], PATHINFO_EXTENSION);
            $data['bookset_data'] = 'bookset_data_' . generate_unique_id() . '.' . $ext1;
            move_uploaded_file($_FILES['file2']['tmp_name'], $upload_path . $data['bookset_data']);
        }
        
        $this->db->where('user_id', $user_id);
        $this->db->where('id', $id);
        $this->db->update('request_log', $data);
        
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
        );
        return $resultpost;
    }
    
    public function add_order_request($user_id,$type,$order_status,$order_no,$message,$title)   {
        date_default_timezone_set('Asia/Kolkata');
        $order_no = implode(',',$order_no);
        $data['user_id'] = $user_id;
        $data['type'] = $type;
        $data['order_status'] = $order_status;
        $data['order_no'] = $order_no;
        $data['message'] = $message;
        $data['title'] = $title;
        $data['added_date']    = date('Y-m-d H:i:s');
        $data['dept_id'] = '3';
        $data['dept_name'] = 'Logistics Team';
        
        
        
        
        
        
        if($this->db->insert('request_log', $data)){
            $insert_id = $this->db->insert_id();
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'id' => $insert_id,
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'Request Not Submitted',
            );
        }
        
        return $resultpost;
    }
    
    public function add_account_request($user_id,$type,$accounts,$message,$title)   {
        date_default_timezone_set('Asia/Kolkata');
        
        $data['user_id'] = $user_id;
        $data['type'] = $type;
        $data['accounts'] = $accounts;
        $data['message'] = $message;
        $data['title'] = $title;
        $data['added_date']    = date('Y-m-d H:i:s');
        $data['dept_id'] = '1';
        $data['dept_name'] = 'Accounts Team';
        
        
        
        if($this->db->insert('request_log', $data)){
            $insert_id = $this->db->insert_id();
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'id' => $insert_id,
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'Request Not Submitted',
            );
        }
        
        return $resultpost;
    }
    
    public function add_profile_request($user_id,$type,$profile,$message,$title) {
        date_default_timezone_set('Asia/Kolkata');
        
        $data['user_id'] = $user_id;
        $data['type'] = $type;
        $data['profile'] = $profile;
        $data['message'] = $message;
        $data['title'] = $title;
        $data['added_date']    = date('Y-m-d H:i:s');
        $data['dept_id'] = '2';
        $data['dept_name'] = 'Catalogue team';
        
        
        
        if($this->db->insert('request_log', $data)){
            $insert_id = $this->db->insert_id();
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'id' => $insert_id,
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'Request Not Submitted',
            );
        }
        
        return $resultpost;
    }
    
    
    
    public function request_log($user_id,$per_page,$offset){ 
        $data = array(); 
        
        
        $count  = $this->db->query("SELECT id FROM request_log WHERE user_id = '$user_id' ORDER BY added_date asc")->num_rows();
        $query  = $this->db->query("SELECT * FROM request_log WHERE user_id = '$user_id' ORDER BY added_date desc LIMIT $offset,$per_page");
        $i=1;
        foreach($query->result_array() as $item){
		    $id = $item['id'];
		    $status = $item['status'];
		    $type = $item['type'];
		    $title = $item['title'];
		    $added_date = $item['added_date'];
		    $updated_date = $item['updated_date'];
		    
		    
		    
		    $added_date         = date("d M Y h:i A", strtotime($item['added_date']));
		    $updated_date         = date("d M Y h:i A", strtotime($updated_date));
		    $date_         = date("Y-m-d H:i:s", strtotime($item['added_date']));
            $pending_since = get_time_difference($date_);
            
            
            
            
            
            $data[] = array(	
                "sr" => $i,				
                "id" => $id,				
                "title" => $title,	           				
                "status" => $status,	           				
                "type" => ucfirst($type),		           				
                "pending_since" => $pending_since,	           					           				
                "added_date" => $added_date,	           					           				
                "updated_date" => $updated_date,	           					           				
            ); 
            $i++;      
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count,
        );
        
        return  $resultpost;
    }
    
    public function request_log_details($user_id,$id){ 
        $data = array(); 
        
        
        $count  = $this->db->query("SELECT id FROM request_log WHERE id = '$id' ORDER BY added_date asc")->num_rows();
        $query  = $this->db->query("SELECT * FROM request_log WHERE id = '$id' ORDER BY added_date desc");
        $i=1;
        foreach($query->result_array() as $item){
		    $id = $item['id'];
		    $status = $item['status'];
		    $type = $item['type'];
		    $category = $item['category'];
		    $sub_category = $item['sub_category'];
		    $school_type = $item['school_type'];
		    $school_id = $item['school_id'];
		    $school_status = $item['school_status'];
		    $school_name = $item['school_name'];
		    $school_for = $item['school_for'];
		    $board = $item['board'];
		    $order_status = $item['order_status'];
		    $order_no = $item['order_no'];
		    $accounts = $item['accounts'];
		    $profile = $item['profile'];
		    $message = $item['message'];
		    $title = $item['title'];
		    $added_date = $item['added_date'];
		    $updated_date = $item['updated_date'];
		    
		    $document = '';
		    $school_logo = '';
		    $bookset_data = '';
		    if($item['document'] !=''){
		        $document = vendor_url().'uploads/request/'.$item['document'];
		    }
		    if($item['school_logo'] !=''){
		        $school_logo =  vendor_url().'uploads/request/'.$item['school_logo'];
		    }
		    if($item['bookset_data'] !=''){
		        $bookset_data =  vendor_url().'uploads/request/'.$item['bookset_data'];
		    }
		    
		    
		    
		    
		    $added_date         = date("d M Y h:i A", strtotime($item['added_date']));
		    $date_         = date("Y-m-d H:i:s", strtotime($item['added_date']));
            $pending_since = get_time_difference($date_);
            $updated_date         = date("d M Y h:i A", strtotime($updated_date));
            
            
            if($category != ''){
                $query_cat  = $this->db->query("SELECT name FROM categories WHERE id = '$category'")->row_array();
                $category_name = $query_cat['name'];
                
                $query_subcat  = $this->db->query("SELECT name FROM categories WHERE id = '$sub_category'")->row_array();
                $sub_category_name = $query_subcat['name'];
            }
            if($school_id != ''){
                $query_sch  = $this->db->query("SELECT name FROM school WHERE id = '$school_id'")->row_array();
                $school_name_id = $query_sch['name'];
            }
            if($board != ''){
                $query_brd  = $this->db->query("SELECT name FROM board WHERE id = '$board'")->row_array();
                $board_name = $query_brd['name'];
            }
            if($order_no != ''){
                $comma ='';
                $order_no = explode(',',$order_no);
                foreach($order_no as $order_nos){
                    $query_ord  = $this->db->query("SELECT order_number FROM orders WHERE id = '$order_nos'")->row_array();
                    $order_number .= $comma.$query_ord['order_number'];
                    $comma = ', ';
                }
            }
           
            $Replydata = array();
            $reply = $this->db->query("SELECT * FROM request_log_reply where request_id='$id'");
            foreach($reply->result_array() as $reply_item){
                $vendor_id = $reply_item['reply_id'];
                $vendor_name = '';
                if($vendor_id > 0){
                    if($reply_item['reply_name'] == 'vendor'){
                        $query_vendor = $this->db->query("SELECT username FROM users WHERE id='$vendor_id' and role='vendor' limit 1")->row_array(); 
                        $vendor_name = $query_vendor['username'];
                    }
                    
                    if($reply_item['reply_name'] == 'staff'){
                        $query_staff = $this->db->query("SELECT name FROM staff WHERE id='$vendor_id' limit 1")->row_array(); 
                        $staff_name = $query_staff['name'];
                    }
                    
                    
                }else{
                     $vendor_name = '';
                     $staff_name = '';
                }
                
                $Replydata[] = array(	
                    "id" => $reply_item['id'],
                    "request_id" => $reply_item['request_id'],
                    "reply_id" => $reply_item['reply_id'],
                    "reply_name" => $reply_item['reply_name'],
                    "reply_email" => $reply_item['reply_email'],
                    "reply_desc" => $reply_item['reply_desc'],			
                    "reply_type" => $reply_item['reply_type'],				
                    "vendor_name" => $vendor_name,				
                    "staff_name" => $staff_name,				
                    "reply_date" =>  date("F j, Y, g:i a",strtotime($reply_item['reply_date'])),             				
                );   
            }
                
                
           
            
            $data[] = array(	
                "sr" => $i,				
                "id" => $id,				
                "status" => $status,	           				
                "type" => ucfirst($type),	           				
                "category" => $category_name,	           				
                "sub_category" => $sub_category_name,	           				
                "school_type" => $school_type,	           				
                "school_id" => $school_name_id,	           				
                "school_status" => $school_status,	           				
                "school_name" => $school_name,	           				
                "school_for" => $school_for,	           				
                "board" => $board_name,	           				
                "order_status" => $order_status,	           				
                "order_no" => $order_number,	           				
                "accounts" => $accounts,	           				
                "profile" => $profile,	           					           				
                "message" => $message,	           					           				
                "title" => $title,	           					           				
                "document" => $document,	           					           				
                "school_logo" => $school_logo,	           					           				
                "bookset_data" => $bookset_data,	           					           				
                "pending_since" => $pending_since,	           					           				
                "added_date" => $added_date,
                "updated_date" => $updated_date,
                "reply" => $Replydata,
            ); 
            $i++;      
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count,
        );
        
        return  $resultpost;
    } 
      
    public function request_log_reply($user_id,$id,$reply)   {
        date_default_timezone_set('Asia/Kolkata');
        $data['reply_id'] = $user_id;
        $data['request_id'] = $id;
        $data['reply_desc'] = $reply;
        $data['reply_name'] = 'vendor';
        $data['reply_date'] = date('Y-m-d H:i:s');
        if($this->db->insert('request_log_reply', $data)){
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'error',
            );
        }
        
        return $resultpost;
    }
    
    /* Excel File Data Start */
    
    public function get_categories_by_parent($parent_id)
	{
		$this->db->order_by('name'); 
		$this->db->where('parent_id', $parent_id);
		$query = $this->db->get('categories');
		return $query;
	}
	
	public function get_school_by_vendor($vendor_id)
	{
		$this->db->order_by('name'); 
		$this->db->where('vendor_id', $vendor_id);
		$query = $this->db->get('school');
		return $query;
	}
	
	public function get_uniform_color()
	{
		$this->db->order_by('name'); 
		$this->db->where('category_id', '22');
		$query = $this->db->get('product_color');
		return $query;
	}
	
	public function get_publisher_list() {
		$this->db->order_by('name'); 
        return $this->db->get_where('publisher');
    }
    
    public function get_board_list() {
		$this->db->order_by('name'); 
        return $this->db->get_where('board');
    }
    
    public function get_grade_list() {
		$this->db->order_by('sort'); 
        return $this->db->get_where('grade_list');
    }
    
    public function get_subject_list() {
		$this->db->order_by('name'); 
        return $this->db->get_where('subject');
    }
    
    public function get_country_list() {
		$this->db->order_by('name'); 
        return $this->db->get_where('country');
    }
    
    public function get_brand_by_category($id) {
		$this->db->order_by('name'); 
        return $this->db->get_where('brand', array('category_id' => $id));
    } 
    
    public function get_size_by_category($id) {
		$this->db->order_by('name'); 
        return $this->db->get_where('size', array('category_id' => $id));
    }  
    
    public function get_binding_type_list() {
		$this->db->order_by('name'); 
        return $this->db->get_where('binding_type');
    }
    
    public function get_stationery_category_details() {
       $query= $this->get_categories_by_parent('6');
       $count = $query->num_rows();  
       $resultpost = array(); 
	   if($count>0){
       foreach ($query->result() as  $category) {			 
        $types= $this->get_categories_by_parent($category->id)->result();
        foreach ($types as  $type) {     
		   $categoryFinal= $category->id.' | '.$category->name.' > '.$type->id.' | '.$type->name;    
            $resultpost[] = array(
               "category_id" =>  $category->id,          
               "type_id" =>  $type->id,          
               "name" =>  $categoryFinal,          
            );	   
	      }			 
	     }	  
        }
        else{ 
            $resultpost = array();
        }  
		
       return $resultpost;
    }
    
    public function get_color_by_category($id) {
		$this->db->order_by('name'); 
        return $this->db->get_where('product_color', array('category_id' => $id));
    } 
    
    public function get_uniform_category_details() {
       $query= $this->get_categories_by_parent('22');
       $count = $query->num_rows();  
       $resultpost = array(); 
	   if($count>0){
       foreach ($query->result() as  $category) {			 
        $types= $this->get_categories_by_parent($category->id)->result();
        foreach ($types as  $type) {     
		   $categoryFinal= $category->id.' | '.$category->name.' > '.$type->id.' | '.$type->name;    
            $resultpost[] = array(
               "id" =>  $category->id,          
               "type_id" =>  $type->id,          
               "name" =>  $categoryFinal,          
            );	   
	      }			 
	     }	  
        }
        else{ 
            $resultpost = array();
        }  
		
       return $resultpost;
    }
    
    public function get_uniform_size_details() {
       $query= $this->get_categories_by_parent('22');
       $count = $query->num_rows();  
       $resultpost = array(); 
	   if($count>0){
       foreach ($query->result() as  $category) {			 
        $types= $this->get_categories_by_parent($category->id)->result();
        foreach ($types as  $type) {     
		   $size_query  = $this->db->query("SELECT * FROM size WHERE category_id='$type->id' order by id asc");
		   foreach($size_query->result() as $row){
		       
		       $categoryFinal= $category->name.' > '.$type->name.' > '.$row->name; 
		        $resultpost[] = array(       
                  "id" =>  $row->id,          
                  "name" =>  $categoryFinal,          
                );
		   }	   
	      }			 
	     }	  
        }
        else{ 
            $resultpost = array();
        }  
		
       return $resultpost;
    }
    
    
    
    
    /* Excel File Data End */
	
}