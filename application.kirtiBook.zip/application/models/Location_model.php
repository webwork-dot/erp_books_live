<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location_model extends CI_Model
{
  
     //get city
    public function get_city($id)
    {
        $id = clean_number($id);
        $this->db->where('cities.id', $id);
        $query = $this->db->get('cities');
        return $query->row();
    }
    //get state
    public function get_state($id)
    {
        $id = clean_number($id);
        $this->db->where('states.id', $id);
        $query = $this->db->get('states');
        return $query->row();
    }

    public function get_state_name($id)
    {
        $id = clean_number($id);
        $this->db->where('states.id', $id);
        $query = $this->db->get('states');
        $sql=$query->row();
        return $sql->name;
    }
    
    public function get_city_name($id)
    {
        $id = clean_number($id);
        $this->db->where('cities.id', $id);
        $query = $this->db->get('cities');
        $sql= $query->row();
        return $sql->name;
    }




  public function state_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM states WHERE country_id='101' order by name");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }
    
    public function city_list($user_id, $state_id)
    {
        $query = $this->db->query("SELECT * FROM cities WHERE state_id='$state_id' order by name");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }




}