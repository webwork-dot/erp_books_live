<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model
{
    public function copy_product_image()
    {
        $query = $this->db->query("SELECT id,is_flag,image FROM product_images where is_flag='0' order by id asc limit 400");
        foreach ($query->result_array() as $row) {
            $id    = $row['id'];
            $image = $row['image'];

            $source_url='https://liveapi.skoozo.com/vendor/v1/uploads/products/'.$image;

            $destination_path='./uploads/vendor_label_report/'.$image;

            copy($source_url, $destination_path);

            //copy('https://liveapi.skoozo.com/vendor/v1/uploads/products/2021/03/18/img_6052debef328b5-14981227-43804472.jpg', 'img/img_6052debef328b5-14981227-43804472.jpg');


            $data_order = array(
                'is_flag' => '1'
            );
            $this->db->where('id', $id);
            $update = $this->db->update('product_images', $data_order);

        }
    }

  public function get_user_by_id($id)
    {
        $id = clean_number($id);
        $this->db->select('id,username,firm_name,logo,email,phone_number,created_at,vendor_aproval');
        $this->db->where('id', $id);
        $query = $this->db->get('users');
        return $query->row();
    }

    public function get_bank_name($id)
    {
        $id = clean_number($id);
        $this->db->where('banks.id', $id);
        $query = $this->db->get('banks');
        $sql= $query->row();
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }
    }

    public function get_publisher_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('publisher');
       if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }

    }

    public function get_board_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('board');
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }

    }

  public function get_subject_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('subject');
         if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }
    }

    public function get_brand_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('brand');
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }

    }


    public function get_school_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('school');
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }

    }


    public function get_color_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('product_color');
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }

    }

  public function publisher_list($user_id="")   {
        $query = $this->db->query("SELECT * FROM publisher order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


  public function board_list($user_id="")   {
        $query = $this->db->query("SELECT * FROM board order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }



  public function banks_list($user_id="")
    {
        $query = $this->db->query("SELECT * FROM banks order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function all_school_list($user_id="")
    {
        $query = $this->db->query("SELECT * FROM school where status ='1' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function get_selected_school($user_id,$id)
    {
        $query_product = $this->db->query("SELECT school FROM products where id ='$id'");
        $row_product = $query_product->row_array();
        $school = explode(',',$row_product['school']);
        $school_name = '';
        $comma = '';
        $school_ids = array();
        foreach($school as $school_id){
            $query = $this->db->query("SELECT * FROM school where id ='$school_id' order by name asc");
            $count = $query->num_rows();
            $data  = array();
            foreach ($query->result_array() as $row) {

                $school_name .= $comma.$row['name'];
                $comma = ', ';
                $school_ids[] = $row['id'];


            }
        }

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $school_name,
            'school_id' => $school_ids
        );
        return $resultpost;
    }


  public function grades_list($user_id="")
    {
        $query = $this->db->query("SELECT * FROM grade_list order by sort asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


    public function brand_list($category_id="")
    {
        $query = $this->db->query("SELECT *  FROM brand WHERE category_id='$category_id' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }



    public function stationary_list($user_id="")
    {
        $query = $this->db->query("SELECT *  FROM categories  WHERE `parent_id` = 6 order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function stationary_type_list($user_id="")
    {
        $query = $this->db->query("SELECT c2.id,c2.name,c.name as category_name
                    FROM categories as c
                    INNER JOIN categories as c2
                    ON c.id = c2.parent_id
                    WHERE c.`parent_id` = 6 ;");
        // $query = $this->db->query("SELECT c.id,c.name as category_name FROM categories as c WHERE c.`parent_id` = 6 ;");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['category_name'].' - '.$row['name'];

            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }




    public function subject_list($user_id="")
    {
        $query = $this->db->query("SELECT *  FROM subject order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function category_by_service($parent_id="")
    {
        $query = $this->db->query("SELECT * FROM categories WHERE parent_id='$parent_id' order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            $sub_data  = array();
            $query2 = $this->db->query("SELECT * FROM categories WHERE parent_id='$id' order by name asc");
            foreach ($query2->result_array() as $row2) {
                $sid   = $row2['id'];
                $sname = $row2['name'];

                $sub_data[] = array(
                   "id" => (int)$sid,
                   "name" => $sname
                );
            }

            $data[] = array(
               "id" => $id,
               "name" => $name,
               "sub_data" => $sub_data
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


    public function category_by_parent($parent_id="")
    {
        $query = $this->db->query("SELECT * FROM categories WHERE parent_id='$parent_id' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
               "id" => $id,
               "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }





    public function vendor_shipping_list($user_id="")
    {
        $query = $this->db->query("SELECT * FROM vendor_shipping_details WHERE vendor_id='$user_id' AND is_deleted='0' order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
               "id" => $row['id'],
               "address" =>  $row['address'].', '.get_city_name($row['city_id']).', '.get_state_name($row['state_id']),
               "name" =>  $row['name'],
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


     public function get_category_name($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('categories');
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }
    }

     public function get_size_name_by_id($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('size');
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }
    }

    public function get_size_name($ids)
    {
        $ids = explode(',',$ids);
        $name =[];
        foreach($ids as $id){
            $this->db->where('id', $id);
            $query = $this->db->get('size');
            $sql= $query->row();
            $name[]=array(
                    "key" => $sql->id
                    );

        }
        return $name;
    }


    public function get_warehouse_address_add_by_id($id="")
    {
        $query = $this->db->query("SELECT * FROM vendor_shipping_details WHERE id='$id' AND is_deleted='0' order by id asc LIMIT 1");
        $count = $query->num_rows();
        $data  = array();
        $row= $query->row_array();
        $address= $row['name'];
        return $address;
    }




    public function size_list($category_id="",$sort="")   {
       if($sort=='')
       {
            $sort="name";
            // $query = $this->db->query("SELECT * FROM size WHERE category_id='$category_id' order by $sort asc");
            $query = $this->db->query("SELECT * FROM `size` WHERE `category_id` ='$category_id' ORDER BY CASE
            WHEN name ='Xtra Small' THEN '1'
            WHEN name ='Small' THEN '2'
            WHEN name ='Medium' THEN '3'
            WHEN name ='Large' THEN '4'
            WHEN name ='Xtra Large' THEN '5'
            WHEN name ='XXL' THEN '6'
            ELSE name END Asc;");
       }
       else{
           $sort="id";
           $query = $this->db->query("SELECT * FROM size WHERE category_id='$category_id' order by $sort asc");
       }




        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            //shoe
            if($category_id=='38'){
                $data[] = array(
                "id" => $id,
                "name" =>'IND-'.$row['indian'].', USA-'.$row['usa'].', UK-'.$row['uk']

               );
            }
            else{
                $data[] = array(
                "id" => $id,
                "name" => $name
               );
            }

        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function uniform_size_list($category_id="",$type="")   {

        $sort="id";
        $query = $this->db->query("SELECT * FROM size WHERE category_id='$category_id' and type='$type' order by $sort asc");

        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            //shoe
            if($category_id=='38'){
                $data[] = array(
                "id" => $id,
                "name" =>'IND-'.$row['indian'].', USA-'.$row['usa'].', UK-'.$row['uk']

               );
            }
            else{
                $data[] = array(
                "id" => $id,
                "name" => $name
               );
            }

        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }



  public function vendor_school_list($vendor_id)   {
        $query = $this->db->query("SELECT id,name FROM school where vendor_id='$vendor_id' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function uniform_school_list($vendor_id)   {
        $query = $this->db->query("SELECT * FROM school where vendor_id='$vendor_id' and FIND_IN_SET('22',category) order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function bookset_school_list($vendor_id)   {
        $query = $this->db->query("SELECT * FROM school where vendor_id='$vendor_id' and FIND_IN_SET('7',category) order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


    public function binding_type_list($user_id="")   {
      $query = $this->db->query("SELECT * FROM binding_type order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function color_list($category_id="")   {
      $query = $this->db->query("SELECT * FROM product_color WHERE category_id='$category_id' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function country_list($user_id="")   {
      $query = $this->db->query("SELECT * FROM country order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            $flag = $row['flag'];

            $data[] = array(
                "id" => $id,
                "name" => $name,
                "flag" => $flag
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


    public function get_school_by_vendor($vendor_id)   {
        $query = $this->db->query("SELECT id,name,board FROM school WHERE vendor_id='$vendor_id' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "board" => $row['board']
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }



    public function get_school_by_id($school_id = "")
    {
        $query = $this->db->get_where('school', array('id' => $school_id))->row_array();
        return $query;
    }



    public function get_board_by_school($school_id){
        $school = $this->get_school_by_id($school_id);
        $board_arr=explode(",",$school['board']);

         foreach ($board_arr as $board) {
           $board_name=$this->db->get_where('board', array('id'=>$board))->row()->name;
            $data[] = array(
                "id" => $board,
                "name" => $board_name
            );
        }

         $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


      public function get_categories($user_id="")   {
        $query = $this->db->query("SELECT id,name FROM categories WHERE parent_id='0'  AND visibility='1' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


    public function dashboard($user_id,$academic_year){
        //$curr_date="2023-01-01 - 2024-03-31";
        $academic_year_filter=$academic_year_filter2="";
        $academic_year = explode(" - ",$academic_year);
        $from           = date('Y-m-d', strtotime($academic_year[0]));
        $to             = date('Y-m-d', strtotime($academic_year[1]));
		
		$academic_year_filter    = "";
        $academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
		
        //$academic_year_filter2    = " AND (DATE(added_date) BETWEEN '$from' AND '$to')"; 
        $academic_year_filter2    = ""; 

        $pending_0_2_days=$pending_3_days=0;
        $processing_0_2_days=$processing_3_days=0;
        $shipment_0_2_days=$shipment_3_days=0;
        $slot_generate_0_2_days=$slot_generate_3_days=0;
        $complaints_0_2_days=$complaints_3_days=0;
        $active_products=0;
        $pending_products=0;

        $active_products = $this->db->query("SELECT id FROM products where user_id='$user_id' and status='1' and is_deleted='0'")->num_rows();
        $inactive_products = $this->db->query("SELECT id FROM products where user_id='$user_id' and status<>'1' and is_deleted='0'")->num_rows();
        $active_bookset = $this->db->query("SELECT id FROM packages where status='1'")->num_rows();
        $inactive_bookset = $this->db->query("SELECT id FROM packages where status<>'1'")->num_rows();
        $active_school = $this->db->query("SELECT id FROM school where status='1'")->num_rows();
        $inactive_school = $this->db->query("SELECT id FROM school where status<>'1'")->num_rows();
        $out_of_stock = $this->db->query("SELECT products.id FROM products INNER JOIN products_warehouse_qty on products_warehouse_qty.product_id=products.id where products.is_deleted='0' and products_warehouse_qty.quantity='0' group by products_warehouse_qty.product_id")->num_rows();

        $pending_orders = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'pending' AND complaint_status IS NULL) OR complaint_status = 'pending_') and payment_status='payment_received' $academic_year_filter")->num_rows();
        $processing_order = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') and payment_status='payment_received' $academic_year_filter group by order_slot")->num_rows();
        $ready_for_shipment = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') and payment_status='payment_received' AND (order_slot!='') $academic_year_filter group by order_slot")->num_rows();
        $handed_dtdc = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and is_picked_dtdc='1' and ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') and payment_status='payment_received' AND (order_slot!='') $academic_year_filter group by order_slot")->num_rows();
        $picked_dtdc = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'picked_dtdc' AND complaint_status IS NULL) OR complaint_status = 'picked_dtdc') and payment_status='payment_received' AND (order_slot!='') $academic_year_filter group by order_slot")->num_rows();
        $ready_for_shipment_slot_generate = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') and payment_status='payment_received' AND slot_no IS NOT NULL $academic_year_filter")->num_rows();
        $out_for_delivery = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'out_for_delivery' AND complaint_status IS NULL) OR complaint_status = 'out_for_delivery') and payment_status='payment_received' $academic_year_filter")->num_rows();
        $delivered = $this->db->query("SELECT id FROM orders where vendor_id='$user_id' and ((order_status = 'delivered' AND complaint_status IS NULL) OR complaint_status = 'delivered') and payment_status='payment_received' $academic_year_filter")->num_rows();
        $complaints = $this->db->query("SELECT id FROM oc_tickets where ticket_status<>'3'")->num_rows();

        $sales_orders=array();
        //$new_order_q = $this->db->query("SELECT DATE(created_at) AS `date`, SUM(price_total) AS `total` FROM orders WHERE (vendor_id='$user_id' and payment_status='payment_received') and created_at >= CURRENT_DATE - INTERVAL 365 DAY GROUP BY DATE(created_at)");
        //foreach ($new_order_q->result_array() as $new_order) {
        //    $sales_orders[] = array(
        //        "total" => $new_order['total'],
        //        "date" => date("d M y", strtotime($new_order['date'])),
        //    );
       // }

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pending_orders' => $pending_orders,
            'sales_orders' => $sales_orders,
            'processing_order' => $processing_order,
            'ready_for_shipment' => $ready_for_shipment,
            'handed_dtdc' => $handed_dtdc,
            'picked_dtdc' => $picked_dtdc,
            'ready_for_shipment_slot_generate' => $ready_for_shipment_slot_generate,
            'out_for_delivery' => $out_for_delivery,
            'delivered' => $delivered,
            'complaints' => $complaints,
            'active_products' => $active_products,
            'pending_products' => $pending_products,
            'pending_days' => $pending_days,
            'processing_days' => $processing_days,
            'inactive_products' => $inactive_products,
            'out_of_stock' => $out_of_stock,
            'active_school' => $active_school,
            'inactive_school' => $inactive_school,
            'active_bookset' => $active_bookset,
            'inactive_bookset' => $inactive_bookset,
            'low_stock' => $inactive_products,
            'pending_0_2_days' => $pending_0_2_days,
            'pending_3_days' => $pending_3_days,
            'processing_0_2_days' => $processing_0_2_days,
            'processing_3_days' => $processing_3_days,
            'shipment_0_2_days' => $shipment_0_2_days,
            'shipment_3_days' => $shipment_3_days,
            'slot_generate_0_2_days' => $slot_generate_0_2_days,
            'slot_generate_3_days' => $slot_generate_3_days,
            'out_for_delivery_0_2_days' => $out_for_delivery_0_2_days,
            'out_for_delivery_3_days' => $out_for_delivery_3_days,
            'delivered_0_2_days' => 0,
            'delivered_3_days' => 0,
            'complaints_0_2_days' => $complaints_0_2_days,
            'complaints_3_days' => $complaints_3_days,
            'total_sales' => 0,
            'amount_received' => 0,
            'balance_receivable' => 0,
        );
        return $resultpost;
    }


    public function shorter($text, $chars_limit)
    {
        // Check if length is larger than the character limit
        if (strlen($text) > $chars_limit)
        {
            // If so, cut the string at the character limit
            $new_text = substr($text, 0, $chars_limit);
            // Trim off white space
            $new_text = trim($new_text);
            // Add at end of text ...
            return $new_text . "...";
        }
        // If not just return the text as is
        else
        {
        return $text;
        }
    }

    //product_id size_id warehouse_id
    public function get_warehouse_by_size($product_id,$warehouse_id,$size_id)
    {
        $query = $this->db->query("SELECT * FROM products_warehouse_qty WHERE product_id='$product_id' AND size_id='$size_id' AND warehouse_id='$warehouse_id' order by id asc LIMIT 1");
         return $query;
    }


     public function get_order_products_category_count($order_id,$category_id)  {
        $count=0;
        $count = $this->db->query("SELECT id FROM order_products WHERE order_id='$order_id' AND category_id='$category_id'")->num_rows();
        return $count;
    }


     public function get_order_products_packages($order_id)  {
        $details='';
        $details_arr=array();
        $query = $this->db->query("SELECT count(*) as package_count,package_name,package_is_it,GROUP_CONCAT(product_name) as product_name FROM order_products WHERE order_id='$order_id' GROUP BY package_id order by package_id asc");
        if ($query->num_rows() > 0) {
		  foreach ($query->result_array() as $row) {
		      if($row['package_is_it']=='2'){
		        $details_arr[]='<p>'.$row['package_name'].' - ('.$row['product_name'].')</p>';
		      }
		      else{
		        $details_arr[]='<p>'.$row['package_name'].' - ('.$row['package_count'].')</p>';
		      }

		  }
         $details = implode(', ', $details_arr);
         $details  = str_replace(',', '', $details);
        }
        return $details;
    }

    public function get_color_name_by_product($id)
    {  //
        $color ='';
        $query  = $this->db->query("SELECT master_id FROM products WHERE id='$id'");
       if($query->num_rows()>0){
         $master_id= $query->row()->master_id;
         $color_id  = $this->db->query("SELECT color FROM product_master WHERE id='$master_id'")->row()->color;
         return $this->common_model->get_color_name($color_id);
        }
        else{
         return '';
        }

    }



	public function get_consolidated_order_packages($order_id)
	{
		$this->db->select('count(op.package_id) as total_products,package_category.package_name');
		$this->db->from('orders');
        $this->db->join('order_products AS op','orders.id=op.order_id');
        $this->db->join('package_category','op.package_id=package_category.id');
		$this->db->where('orders.id', $order_id);
		$this->db->where('orders.payment_status', 'payment_received');
		$this->db->group_by('op.package_id');
		$query = $this->db->get();
		return $query->result();
	}

    public function get_school_city($school_id){
       $query= $this->db->query("SELECT cities.name as school_city FROM school INNER JOIN cities ON school.city_id = cities.id WHERE school.id='$school_id'");
      if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->school_city;
      }
      else{
         return '';
      }
    }



    public function get_grade_name($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('grade_list');
        $sql= $query->row();
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->name;
        }
        else{
         return '';
        }
    }

     public function vendor_grade_list($vendor_id)   {
        $query = $this->db->query("SELECT grade_id FROM packages where vendor_id='$vendor_id' GROUP BY grade_id order by grade_id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $grade_id   = $row['grade_id'];
            $grade_name = $this->common_model->get_grade_name($grade_id);

            $data[] = array(
                "id" => $grade_id,
                "name" => $grade_name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }



      public function vendor_complaint_category($vendor_id)   {
        $catrgory = "1,2,3,4";
        $query = $this->db->query("SELECT id,name,short_name FROM scd_category WHERE id IN ($catrgory)  order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];

            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }


    public function get_complaints_order_products_packages($order_id,$complaint_product_id)  {
        $details='';
        $details_arr=array();
        $query = $this->db->query("SELECT count(*) as package_count,package_name,package_is_it,GROUP_CONCAT(product_name SEPARATOR ', ') as product_name FROM order_products WHERE order_id='$order_id' AND (FIND_IN_SET(id,'$complaint_product_id')) order by id asc");
        if ($query->num_rows() > 0) {
		  foreach ($query->result_array() as $row) {
		      $details_arr[]='<p>'.$row['product_name'].'</p>';
		/*      if($row['package_is_it']=='2'){
		        $details_arr[]='<p>'.$row['package_name'].' - ('.$row['product_name'].')</p>';
		      }
		      else{
		        $details_arr[]='<p>'.$row['package_name'].' - ('.$row['product_name'].')</p>';
		      }*/

		  }
         $details = implode(', ', $details_arr);
        }
        return $details;
    }

    public function get_academic_year()   {
        $query = $this->db->query("SELECT year,date_range FROM oc_academic_year order by sort asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "year" => $row['year'],
                "date_range" => $row['date_range']
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }



    public function get_order_status_list()   {
        $query = $this->db->query("SELECT name,display FROM order_status WHERE status='1' order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "name" => $row['name'],
                "display" => $row['display']
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function check_category_slug()   {
        $query = $this->db->query("SELECT id,name FROM `categories` WHERE (`parent_id` = 8 OR `parent_id` = 10)");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $data = array();
            $data['slug'] = str_slug($row['name']);
            $data['title_meta_tag'] = $row['name'];
            $data['description'] = $row['name'];
            $data['keywords'] = $row['name'];

            $this->db->where('id',$id);
            $this->db->update('categories',$data);
        }
    }
	
	public function getNameByVar($table,$field,$where) {
        $this->db->select($field);
        $this->db->where($where);
        $query = $this->db->get($table);
        if($query->num_rows()>0){
         $sql= $query->row();
         return $sql->$field;
        }
        else{
         return '';
        }
    }    
	
	public function getRowById($table,$field,$where) {
        $this->db->select($field);
        $this->db->where($where);
        $query = $this->db->get($table);
        if($query->num_rows()>0){
         $sql= $query->row_array();
         return $sql;
        }
        else{
         return '';
        }
    }  

	public function getResultById($table,$field,$where) {
        $this->db->select($field);
        $this->db->where($where);
        $query = $this->db->get($table);
        if($query->num_rows()>0){
         $sql= $query->result_array();
         return $sql;
        }
        else{
         return '';
        }
    } 
	
	function sanitizeAddress($address) {
		$pattern = '/[^a-zA-Z0-9\s\'.,\-\\\\\/]/';
		$sanitizedAddress = preg_replace($pattern, '', $address);		
		return $sanitizedAddress;
	}  


	function sanitizeString($lastName) {
		// This pattern allows only alphabets, dots, and spaces
		$pattern = '/[^a-zA-Z\s.]/';
		$sanitizedLastName = preg_replace($pattern, '', $lastName);
		return $sanitizedLastName;
	} 
	
	function sanitize_allowed_chars($input) {
        $pattern = '/[^A-Za-z0-9\s\-\/\\\\]/';
        return preg_replace($pattern, '', $input);
    }
}
