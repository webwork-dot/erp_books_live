<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class ErpModel extends CI_Model
{
    
    public function files_upload($file_name)
    {
        $config['upload_path']   = 'uploads/files/';
        $config['allowed_types'] = 'pdf';
        $config['file_name']     = 'pdf_' . uniqid();
        $this->load->library('upload', $config);
        
        if ($this->upload->do_upload($file_name)) {
            $data = array(
                'upload_data' => $this->upload->data()
            );
            if (isset($data['upload_data']['full_path'])) {
                return 'uploads/files/' . $data['upload_data']['file_name'];
            }
        }
        return null;
    }
    
    public function image_upload($file_name)
    {
        $config['upload_path']   = 'uploads/images/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['file_name']     = 'image_' . uniqid();
        $this->load->library('upload', $config);
        
        if ($this->upload->do_upload($file_name)) {
            $data = array(
                'upload_data' => $this->upload->data()
            );
            if (isset($data['upload_data']['full_path'])) {
                return 'uploads/images/' . $data['upload_data']['file_name'];
            }
        }
        return null;
    }
    
    public function check_file_mime_type($file_name, $allowed_types)
    {
        if (!isset($_FILES[$file_name])) {
            return false;
        }
        if (empty($_FILES[$file_name]['name'])) {
            return false;
        }
        $ext = pathinfo($_FILES[$file_name]['name'], PATHINFO_EXTENSION);
        if (in_array($ext, $allowed_types)) {
            return true;
        }
        return false;
    }
    
    public function video_upload($file_name)
    {
        $allowed_types = array(
            'mp4',
            'MP4',
            'webm',
            'WEBM'
        );
        if (!$this->check_file_mime_type($file_name, $allowed_types)) {
            return false;
        }
        $config['upload_path']   = 'uploads/videos/';
        $config['allowed_types'] = '*';
        $config['file_name']     = 'video_' . generate_unique_id();
        $this->load->library('upload', $config);
        
        if ($this->upload->do_upload($file_name)) {
            $data = array(
                'upload_data' => $this->upload->data()
            );
            if (isset($data['upload_data']['full_path'])) {
                return $data['upload_data']['file_name'];
            }
            return null;
        } else {
            return null;
        }
    }
    
    public function add_program($user_id, $name, $fee, $type, $days, $age_from_year, $age_from_month, $age_to_year, $age_to_month, $timing_from, $timing_to, $child, $staff)
    {
        date_default_timezone_set('Asia/Kolkata');
        $days       = implode(',', $days);
        $added_date = date('Y-m-d H:i');
        
        $add_school = array(
            'user_id' => $user_id,
            'name' => $name,
            'fee' => $fee,
            'fee_type' => $type,
            'days' => $days,
            'age_from_year' => $age_from_year,
            'age_from_month' => $age_from_month,
            'age_to_year' => $age_to_year,
            'age_to_month' => $age_to_month,
            'timing_from' => $timing_from,
            'timing_to' => $timing_to,
            'staff' => $staff,
            'children' => $child,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('program', $add_school);
        if ($insert) {
            $school_id = $this->db->insert_id();
            
            // $admin_name   = explode(",", rtrim($admin_name));
            // $admin_number = explode(",", rtrim($admin_number));
            // $admin_email  = explode(",", rtrim($admin_email));
            // $cnt       = count($admin_name);
            
            //  for($i = 0; $i < $cnt; $i++) {
            //     $school_admin_data = array(
            //         'school_id    ' => $school_id,
            //         'name' => $admin_name[$i],
            //         'number' => $admin_number[$i],
            //         'email' => $admin_email[$i],
            //     );
            //     $this->db->insert('school_admin', $school_admin_data);
            // }
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function edit_program($program_id, $user_id, $name, $fee, $type, $days, $age_from_year, $age_from_month, $age_to_year, $age_to_month, $timing_from, $timing_to, $child, $staff)
    {
        date_default_timezone_set('Asia/Kolkata');
        $days       = implode(',', $days);
        $added_date = date('Y-m-d H:i');
        
        $add_school = array(
            'user_id' => $user_id,
            'name' => $name,
            'fee' => $fee,
            'fee_type' => $type,
            'days' => $days,
            'age_from_year' => $age_from_year,
            'age_from_month' => $age_from_month,
            'age_to_year' => $age_to_year,
            'age_to_month' => $age_to_month,
            'timing_from' => $timing_from,
            'timing_to' => $timing_to,
            'staff' => $staff,
            'children' => $child,
            'added_date' => $added_date
        );
        $this->db->where('id', $program_id);
        $insert = $this->db->update('program', $add_school);
        if ($insert) {
            $school_id = $this->db->insert_id();
            
            // $admin_name   = explode(",", rtrim($admin_name));
            // $admin_number = explode(",", rtrim($admin_number));
            // $admin_email  = explode(",", rtrim($admin_email));
            // $cnt       = count($admin_name);
            
            //  for($i = 0; $i < $cnt; $i++) {
            //     $school_admin_data = array(
            //         'school_id    ' => $school_id,
            //         'name' => $admin_name[$i],
            //         'number' => $admin_number[$i],
            //         'email' => $admin_email[$i],
            //     );
            //     $this->db->insert('school_admin', $school_admin_data);
            // }
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_diary($user_id, $program_id, $children_id, $communication_type, $like_type, $comment_type, $notification_type, $details, $image, $video, $file)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        
        $children_id = implode(',', $children_id);
        
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'children_id' => $children_id,
            'communication_type' => $communication_type,
            'like_type' => $like_type,
            'comment_type' => $comment_type,
            'notification_type' => $notification_type,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('dairy', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_food($user_id, $program_id, $children_id, $meal_type, $quantity, $item_name, $details, $image, $video, $file)
    {
        
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $item_name  = implode(',', $item_name);
        
        $children_id = implode(',', $children_id);
        
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'children_id' => $children_id,
            'meal_type' => $meal_type,
            'quantity' => $quantity,
            'item_name' => $item_name,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('food', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_star($user_id, $program_id, $children_id, $star_type, $details, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        
        $children_id = implode(',', $children_id);
        
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'child_id' => $children_id,
            'star_type' => $star_type,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('star', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_potty($user_id, $program_id, $children_id, $type, $sub_type, $details, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        
        $children_id = implode(',', $children_id);
        
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'children_id' => $children_id,
            'type' => $type,
            'sub_type' => $sub_type,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('potty', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function add_observation($user_id, $program_id, $children_id, $time, $observation_type, $details, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        date_default_timezone_set('Asia/Kolkata');
        $observation_type = implode(',', $observation_type);
        
        $children_id = implode(',', $children_id);
        
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'children_id' => $children_id,
            'observation_type' => $observation_type,
            'time' => $time,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('observation', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_play_learn($user_id, $program_id, $children_id, $activity_type, $start_time, $details, $end_time, $item_name, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        date_default_timezone_set('Asia/Kolkata');
        $item_name  = implode(',', $item_name);
        $added_date = date('Y-m-d H:i');
        
        $children_id = implode(',', $children_id);
        
        $add_school = array(
            'user_id' => $user_id,
            'children_id' => $children_id,
            'program_id' => $program_id,
            'activity_type' => $activity_type,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'item_name' => $item_name,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('play_learn', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_sleep($user_id, $program_id, $children_id, $start_time, $details, $end_time, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        
        $children_id = implode(',', $children_id);
        
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'child_id' => $children_id,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('sleep', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    
    
    public function add_event($user_id, $type, $title, $locatoin, $start_date, $end_date, $program, $all_day, $notify, $details, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'type' => $type,
            'title' => $title,
            'locatoin' => $locatoin,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'program' => $program,
            'details' => $details,
            'all_day' => $all_day,
            'notify' => $notify,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('event', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function edit_event($user_id, $event_id, $type, $title, $locatoin, $start_date, $end_date, $program, $all_day, $notify, $details, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'type' => $type,
            'title' => $title,
            'locatoin' => $locatoin,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'program' => $program,
            'details' => $details,
            'all_day' => $all_day,
            'notify' => $notify,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $this->db->where('id', $event_id);
        $insert = $this->db->update('event', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_noticeboard($user_id, $program_id, $children_id, $title, $is_important, $is_archive, $details, $image, $video, $file)
    {
        
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        
        // $children_id = implode(',',$children_id);
        $program_id = implode(',', $program_id);
        
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'children_id' => $children_id,
            'program_id' => $program_id,
            'title' => $title,
            
            'is_important' => $is_important,
            'is_archive' => $is_archive,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('notice_board', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function edit_noticeboard($user_id, $program_id, $notice_id, $title, $is_important, $is_archive, $details, $image, $video, $file)
    {
        $image_url = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        date_default_timezone_set('Asia/Kolkata');
        
        $program_id = implode(',', $program_id);
        
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'title' => $title,
            
            'is_important' => $is_important,
            'is_archive' => $is_archive,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $this->db->where('id', $notice_id);
        $insert = $this->db->update('notice_board', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function view_program($user_id)
    {
        $query = $this->db->query("SELECT * FROM program where user_id ='$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            $fee  = $row['fee'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "fee" => $fee
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function program_details($user_id, $program_id)
    {
        $query = $this->db->query("SELECT * FROM program where user_id ='$user_id' and id='$program_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id             = $row['id'];
            $name           = $row['name'];
            $fee            = $row['fee'];
            $fee_type       = $row['fee_type'];
            $days           = $row['days'];
            $age_from_year  = $row['age_from_year'];
            $age_from_month = $row['age_from_month'];
            $age_to_year    = $row['age_to_year'];
            $age_to_month   = $row['age_to_month'];
            $timing_from    = $row['timing_from'];
            $timing_to      = $row['timing_to'];
            $staff          = explode(',',$row['staff']);
            $children       = explode(',',$row['children']);
            
            $days = explode(',', $days);
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "fee" => $fee,
                "fee_type" => $fee_type,
                "days" => $days,
                "age_from_year" => $age_from_year,
                "age_from_month" => $age_from_month,
                "age_to_year" => $age_to_year,
                "age_to_month" => $age_to_month,
                "timing_from" => $timing_from,
                "timing_to" => $timing_to,
                "staff" => $staff,
                "children" => $children
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function view_staff($user_id)
    {
        $query = $this->db->query("SELECT * FROM staff where user_id ='$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id           = $row['id'];
            $first_name   = $row['first_name'];
            $last_name    = $row['last_name'];
            $mobile       = $row['mobile'];
            $email        = $row['email'];
            $gender       = $row['gender'];
            $address      = $row['address'];
            $birthday     = $row['birthday'];
            $blood_group  = $row['blood_group'];
            $joining_date = $row['joining_date'];
            $permision    = $row['permision'];
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "mobile" => $mobile,
                "email" => $email,
                "gender" => $gender,
                "address" => $address,
                "birthday" => $birthday,
                "blood_group" => $blood_group,
                "joining_date" => $joining_date,
                "permision" => $permision
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function staff_details($user_id, $staff_id)
    {
        $query = $this->db->query("SELECT * FROM staff where user_id ='$user_id' and id='$staff_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id           = $row['id'];
            $first_name   = $row['first_name'];
            $last_name    = $row['last_name'];
            $mobile       = $row['mobile'];
            $email        = $row['email'];
            $gender       = $row['gender'];
            $address      = $row['address'];
            $birthday     = $row['birthday'];
            $blood_group  = $row['blood_group'];
            $joining_date = $row['joining_date'];
            $permision    = $row['permision'];
            $program_id    = $row['program_id'];
            
            $permision = explode(',', $permision);
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "mobile" => $mobile,
                "email" => $email,
                "gender" => $gender,
                "address" => $address,
                "birthday" => $birthday,
                "blood_group" => $blood_group,
                "joining_date" => $joining_date,
                "program_id" => $program_id,
                "permision" => $permision
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function add_staff($user_id,$program_id, $first_name, $last_name, $mobile, $email, $gender, $address, $birthday, $blood_group, $joining_date, $permision)
    {
        
        date_default_timezone_set('Asia/Kolkata');
        $permision  = implode(',', $permision);
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'mobile' => $mobile,
            
            'email' => $email,
            'gender' => $gender,
            'address' => $address,
            'birthday' => $birthday,
            'blood_group' => $blood_group,
            'joining_date' => $joining_date,
            'permision' => $permision,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('staff', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function edit_staff($staff_id,$program_id, $user_id, $first_name, $last_name, $mobile, $email, $gender, $address, $birthday, $blood_group, $joining_date, $permision)
    {
        
        date_default_timezone_set('Asia/Kolkata');
        $permision  = implode(',', $permision);
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'mobile' => $mobile,
            'email' => $email,
            'gender' => $gender,
            'address' => $address,
            'birthday' => $birthday,
            'blood_group' => $blood_group,
            'joining_date' => $joining_date,
            'permision' => $permision,
            'added_date' => $added_date
        );
        $this->db->where('id', $staff_id);
        $insert = $this->db->update('staff', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function add_student($user_id,$program_id, $first_name, $last_name, $birthday, $blood_group, $gender, $joining_date, $unique_id, $address, $allergies, $notes, $parent_first_name, $parent_last_name, $parent_mobile, $parent_relation, $parent_email)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        
        $parent_ids = '';
        
        $cnt = count($parent_first_name);
            
            for ($i = 0; $i < $cnt; $i++) {
                $school_admin_data = array(
                    'user_id    ' => $user_id,
                    'first_name' => $parent_first_name[$i],
                    'last_name' => $parent_last_name[$i],
                    'mobile' => $parent_mobile[$i],
                    'relation' => $parent_relation[$i],
                    'email' => $parent_email[$i],
                    'added_date' => $added_date
                );
                if($parent_first_name[$i] != ''){
               $insert     =  $this->db->insert('parents', $school_admin_data);
               $parent_id = $this->db->insert_id();
               $parent_ids .= $parent_id.',';
                }
            }
            
       
        if ($insert) {
            
           
            $add_school = array(
                'user_id' => $user_id,
                'parent_id' => $parent_ids,
                'program_id' => $program_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'birthday' => $birthday,
                'unique_id' => $unique_id,
                'blood_group' => $blood_group,
                'gender' => $gender,
                'joining_date' => $joining_date,
                'address' => $address,
                'allergies' => $allergies,
                'notes' => $notes,
                'added_date' => $added_date
            );
            $this->db->insert('student', $add_school);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function edit_student($id,$user_id,$program_id,$first_name,$last_name,$birthday,$blood_group,$gender,$joining_date,$unique_id,$address,$allergies,$notes,$parent_first_name,$parent_last_name,$parent_mobile,$parent_relation,$parent_email,$parent_id,$delete_parent)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
            
            
            $parent_ids = '';
            $cnt = count($parent_first_name);
            
            $deletecnt = count($delete_parent);
            for ($i = 0; $i < $deletecnt; $i++) {
                
                if($delete_parent[$i] != ''){
                    $this->db->where('id', $delete_parent[$i]);
                    $this->db->delete('parents');
                }
                
            }
            
            for ($i = 0; $i < $cnt; $i++) {
                
                
                $school_admin_data = array(
                    'user_id' => $user_id,
                    'first_name' => $parent_first_name[$i],
                    'last_name' => $parent_last_name[$i],
                    'mobile' => $parent_mobile[$i],
                    'relation' => $parent_relation[$i],
                    'email' => $parent_email[$i],
                    'added_date' => $added_date
                );
                if($parent_first_name[$i] != ''){
                if($parent_id[$i] != ''){    
                    $this->db->where('id',$parent_id[$i]);    
                    $insert     =  $this->db->update('parents', $school_admin_data);
                }else{
                    $insert     =  $this->db->insert('parents', $school_admin_data);
                    $insert_id = $this->db->insert_id();
                    $parent_ids .= ','.$insert_id;
                }
                
                }
            }
        
            $parent_id = implode(',',$parent_id);
            $final = $parent_id.$parent_ids;
        
        if ($insert) {
                $add_school = array(
                'user_id' => $user_id,
                'parent_id' => $final,
                'program_id' => $program_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'birthday' => $birthday,
                'unique_id' => $unique_id,
                'blood_group' => $blood_group,
                'gender' => $gender,
                'joining_date' => $joining_date,
                'address' => $address,
                'allergies' => $allergies,
                'notes' => $notes,
                'added_date' => $added_date
            );
            $this->db->where('id',$id);
            $this->db->update('student', $add_school);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function school_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM school where user_id ='$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $query_ = $this->db->query("SELECT * FROM favourite_school where user_id ='$user_id' and school_id = '$id'");
            $count_ = $query_->num_rows();
            if ($count_ > 0) {
                $favourite = 1;
            } else {
                $favourite = 0;
            }
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "favourite" => $favourite
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function add_favourite_school($user_id, $school_id)
    {
        $query_ = $this->db->query("SELECT * FROM favourite_school where user_id ='$user_id'");
        $count_ = $query_->num_rows();
        
        if ($count_ > 0) {
            $this->db->where('user_id', $user_id);
            $this->db->delete('favourite_school');
            
            $add_school = array(
                'user_id' => $user_id,
                'school_id' => $school_id
            );
            $insert     = $this->db->insert('favourite_school', $add_school);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $add_school = array(
                'user_id' => $user_id,
                'school_id' => $school_id
            );
            $insert     = $this->db->insert('favourite_school', $add_school);
            if ($insert) {
                $resultpost = array(
                    'status' => 200,
                    'message' => 'success'
                );
            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'Fail'
                );
            }
            
        }
        
        return $resultpost;
    }
    
    
    public function tag_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM tag_type order by id");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id    = $row['id'];
            $name  = $row['name'];
            $image = 'https://erp.demo.webwork.co.in/uploads/images/' . $row['image'];
            
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "image" => $image
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function tag_details($user_id, $type)
    {
        $query = $this->db->query("SELECT * FROM tags where type = '$type'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function tag_add($user_id, $type, $name)
    {
        
        $add_school = array(
            'type' => $type,
            'name' => $name
        );
        $insert     = $this->db->insert('tags', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function tag_edit($user_id, $tag_id, $name)
    {
        
        $add_school = array(
            'name' => $name
        );
        $this->db->where('id', $tag_id);
        $insert = $this->db->update('tags', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function tag_type_details($user_id, $tag_id)
    {
        $query = $this->db->query("SELECT * FROM tags where id = '$tag_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function tag_delete($user_id, $tag_id)
    {
        
        $this->db->where('id', $tag_id);
        $this->db->delete('tags');
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    
    public function cctv_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM cctv where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id        = $row['id'];
            $name      = $row['name'];
            $url       = $row['url'];
            $is_parent = $row['is_parent'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "url" => $url,
                "is_parent" => $is_parent
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function cctv_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM cctv where user_id = '$user_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id        = $row['id'];
            $name      = $row['name'];
            $url       = $row['url'];
            $is_parent = $row['is_parent'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "url" => $url,
                "is_parent" => $is_parent
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function cctv_add($user_id, $url, $name, $is_parent)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'url' => $url,
            'name' => $name,
            'is_parent' => $is_parent,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('cctv', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function cctv_edit($user_id, $url, $name, $is_parent, $id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'url' => $url,
            'name' => $name,
            'is_parent' => $is_parent,
            'added_date' => $added_date
        );
        $this->db->where('id', $id);
        $insert = $this->db->update('cctv', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function cctv_delete($user_id, $id)
    {
        
        $this->db->where('id', $id);
        $this->db->delete('cctv');
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    public function driver_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM driver where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id      = $row['id'];
            $name    = $row['name'];
            $mobile  = $row['mobile'];
            $licence = $row['licence'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "mobile" => $mobile,
                "licence" => $licence
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function driver_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM driver where user_id = '$user_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id      = $row['id'];
            $name    = $row['name'];
            $mobile  = $row['mobile'];
            $licence = $row['licence'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "mobile" => $mobile,
                "licence" => $licence
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function driver_add($user_id, $mobile, $name, $licence)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'mobile' => $mobile,
            'name' => $name,
            'licence' => $licence,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('driver', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function driver_edit($user_id, $mobile, $name, $licence, $id)
    {
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'mobile' => $mobile,
            'name' => $name,
            'licence' => $licence,
            'added_date' => $added_date
        );
        $this->db->where('id', $id);
        $insert = $this->db->update('driver', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function pickup_point_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM pickup_point where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id           = $row['id'];
            $pickup_point = $row['pickup_point'];
            $pickup_time  = $row['pickup_time'];
            $drop_time    = $row['drop_time'];
            
            
            $data[] = array(
                "id" => $id,
                "pickup_point" => $pickup_point,
                "pickup_time" => $pickup_time,
                "drop_time" => $drop_time
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    
    public function pickup_point_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM pickup_point where user_id = '$user_id' and id = '$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id           = $row['id'];
            $pickup_point = $row['pickup_point'];
            $pickup_time  = $row['pickup_time'];
            $drop_time    = $row['drop_time'];
            $child_id    = explode(',',$row['child_id']);
            
            
            $data[] = array(
                "id" => $id,
                "pickup_point" => $pickup_point,
                "pickup_time" => $pickup_time,
                "drop_time" => $drop_time,
                "child_id" => $child_id,
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function pickup_point_add($user_id, $child_id, $pickup_point, $pickup_time, $drop_time)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'child_id' => $child_id,
            'pickup_point' => $pickup_point,
            'pickup_time' => $pickup_time,
            'drop_time' => $drop_time,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('pickup_point', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function pickup_point_edit($user_id, $child_id, $pickup_point, $pickup_time, $drop_time, $id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'child_id' => $child_id,
            'pickup_point' => $pickup_point,
            'pickup_time' => $pickup_time,
            'drop_time' => $drop_time,
            'added_date' => $added_date
        );
        $this->db->where('id', $id);
        $insert = $this->db->update('pickup_point', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function expenses_category_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM expenses_category where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function expenses_category_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM expenses_category where user_id = '$user_id' and id ='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id          = $row['id'];
            $name        = $row['name'];
            $description = $row['description'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "description" => $description
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function expenses_category_add($user_id, $name, $description, $popup_title)
    {
        
        if ($popup_title == 'Add Category') {
            $table = 'expenses_category';
        }
        if ($popup_title == 'Add Payee') {
            $table = 'expenses_payee';
        }
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'user_id' => $user_id,
            'name' => $name,
            'description' => $description
        );
        $insert     = $this->db->insert($table, $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function expenses_category_edit($user_id, $name, $description, $category_id)
    {
        
        
        
        $add_school = array(
            'user_id' => $user_id,
            'name' => $name,
            'description' => $description
        );
        $this->db->where('id', $category_id);
        $insert = $this->db->update('expenses_category', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function expenses_payee_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM expenses_payee where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function expenses_payee_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM expenses_payee where user_id = '$user_id' and id ='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id          = $row['id'];
            $name        = $row['name'];
            $description = $row['description'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "description" => $description
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    
    public function expenses_payee_edit($user_id, $name, $description, $category_id)
    {
        
        $add_school = array(
            'user_id' => $user_id,
            'name' => $name,
            'description' => $description
        );
        $this->db->where('id', $category_id);
        $insert = $this->db->update('expenses_payee', $add_school);
        if ($insert) {
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    
    public function expenses_add($user_id, $header, $amount, $category, $payee, $payment_date, $payment_status, $reference_number, $comment, $description, $split_amount, $tax, $total)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        
        $add_school = array(
            'user_id' => $user_id,
            'header' => $header,
            'amount' => $amount,
            'category' => $category,
            'payee' => $payee,
            'payment_date' => $payment_date,
            'payment_status' => $payment_status,
            'reference_number' => $reference_number,
            'comment' => $comment,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('expenses', $add_school);
        if ($insert) {
            $school_id = $this->db->insert_id();
            
            $cnt = count($description);
            
            // $description   = explode(",", $description);
            // $split_amount = explode(",", $split_amount);
            // $tax  = explode(",", $tax);
            // $total  = explode(",", $total);
            
            for ($i = 0; $i < $cnt; $i++) {
                $school_admin_data = array(
                    'expenses_id    ' => $school_id,
                    'description' => $description[$i],
                    'amount' => $split_amount[$i],
                    'tax' => $tax[$i],
                    'total' => $total[$i]
                );
                $this->db->insert('expenses_split', $school_admin_data);
            }
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function expenses_edit($id, $user_id, $header, $amount, $category, $payee, $payment_date, $payment_status, $reference_number, $comment, $description, $split_amount, $tax, $total)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        
        $add_school = array(
            'user_id' => $user_id,
            'header' => $header,
            'amount' => $amount,
            'category' => $category,
            'payee' => $payee,
            'payment_date' => $payment_date,
            'payment_status' => $payment_status,
            'reference_number' => $reference_number,
            'comment' => $comment,
            'added_date' => $added_date
        );
        $this->db->where('id', $id);
        $insert = $this->db->update('expenses', $add_school);
        if ($insert) {
            $this->db->where('expenses_id', $id);
            $this->db->delete('expenses_split');
            
            $cnt = count($description);
            
            // $description   = explode(",", $description);
            // $split_amount = explode(",", $split_amount);
            // $tax  = explode(",", $tax);
            // $total  = explode(",", $total);
            
            for ($i = 0; $i < $cnt; $i++) {
                $school_admin_data = array(
                    'expenses_id    ' => $id,
                    'description' => $description[$i],
                    'amount' => $split_amount[$i],
                    'tax' => $tax[$i],
                    'total' => $total[$i]
                );
                if($split_amount[$i] != ''){
                $this->db->insert('expenses_split', $school_admin_data);
                }
            }
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function student_list($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM student where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            
            $query_att = $this->db->query("SELECT * FROM attendance where child_id = '$id' and date='$date' ");
            $row_att   = $query_att->row_array();
            
            $student_in     = $row_att['student_in'];
            $student_out    = $row_att['student_out'];
            $student_absent = $row_att['student_absent'];
            $student_leave  = $row_att['student_leave'];
            $student_unmark = $row_att['student_unmark'];
            $in_time        = $row_att['in_time'];
            $out_time       = $row_att['out_time'];
            
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "student_in" => $student_in,
                "student_out" => $student_out,
                "student_absent" => $student_absent,
                "student_leave" => $student_leave,
                "student_unmark" => $student_unmark,
                "in_time" => $in_time,
                "out_time" => $out_time
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function student_details($user_id,$child_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM student where user_id = '$user_id' and id = '$child_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            $birthday  = $row['birthday'];
            $blood_group  = $row['blood_group'];
            $gender  = $row['gender'];
            $joining_date  = $row['joining_date'];
            $unique_id  = $row['unique_id'];
            $address  = $row['address'];
            $allergies  = $row['allergies'];
            $notes  = $row['notes'];
            $program_id  = $row['program_id'];
            $parent_id  = $row['parent_id'];
            
            $query_att = $this->db->query("SELECT * FROM parents where FIND_IN_SET(id, '$parent_id')");
            $data_ = array();
            foreach ($query_att->result_array() as $row_att) {
            $p_id    = $row_att['id'];
            $p_first_name     = $row_att['first_name'];
            $p_last_name    = $row_att['last_name'];
            $p_mobile = $row_att['mobile'];
            $p_relation  = $row_att['relation'];
            $p_email = $row_att['email'];
                $data_[] = array(
                    "id" => $p_id,
                    "first_name" => $p_first_name,
                    "last_name" => $p_last_name,
                    "mobile" => $p_mobile,
                    "relation" => $p_relation,
                    "email" => $p_email,
                   
                );
            
            }
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "birthday" => $birthday,
                "blood_group" => $blood_group,
                "gender" => $gender,
                "joining_date" => $joining_date,
                "unique_id" => $unique_id,
                "address" => $address,
                "allergies" => $allergies,
                "notes" => $notes,
                "program_id" => $program_id,
                "parents" => $data_,
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function student_list_($user_id, $program_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM student where program_id = '$program_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    
    public function expenses_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM expenses where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id               = $row['id'];
            $header           = $row['header'];
            $amount           = $row['amount'];
            $category         = $row['category'];
            $payee            = $row['payee'];
            $payment_date     = $row['payment_date'];
            $payment_status   = $row['payment_status'];
            $reference_number = $row['reference_number'];
            $comment          = $row['comment'];
            $added_date       = $row['added_date'];
            
            $data[] = array(
                "id" => $id,
                "header" => $header,
                "amount" => $amount,
                "category" => $category,
                "payee" => $payee,
                "payment_date" => $payment_date,
                "payment_status" => $payment_status,
                "reference_number" => $reference_number,
                "comment" => $comment,
                "added_date" => $added_date
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    
    public function expenses_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM expenses where user_id = '$user_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id               = $row['id'];
            $header           = $row['header'];
            $amount           = $row['amount'];
            $category         = $row['category'];
            $payee            = $row['payee'];
            $payment_date     = $row['payment_date'];
            $payment_status   = $row['payment_status'];
            $reference_number = $row['reference_number'];
            $comment          = $row['comment'];
            
            
            $query_split = $this->db->query("SELECT * FROM expenses_split where expenses_id = '$id'");
            $data_split  = array();
            foreach ($query_split->result_array() as $row_split) {
                $description  = $row_split['description'];
                $amount_      = $row_split['amount'];
                $tax          = $row_split['tax'];
                $total        = $row_split['total'];
                $data_split[] = array(
                    "description" => $description,
                    "amount" => $amount_,
                    "tax" => $tax,
                    "total" => $total
                );
            }
            
            $data[] = array(
                "id" => $id,
                "header" => $header,
                "amount" => $amount,
                "category" => $category,
                "payee" => $payee,
                "payment_date" => $payment_date,
                "payment_status" => $payment_status,
                "reference_number" => $reference_number,
                "comment" => $comment,
                "data_split" => $data_split
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function attendance_in($user_id, $date, $time,$attendance_type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d');
        $added_time = date('H:i');
        
        if($attendance_type == 'staff'){
            $attendance_type = 'staff';
        }else{
            $attendance_type = 'student';
        }
        
        foreach ($user_id as $user_ids) {
            $add_school = array(
                'type' => $attendance_type,
                'child_id' => $user_ids,
                'date' => $date,
                'student_in' => 1,
                'in_time' => $time
            );
            $insert     = $this->db->insert('attendance', $add_school);
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    public function attendance_out($user_id, $date, $time,$attendance_type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d');
        $added_time = date('H:i');
        
        if($attendance_type == 'staff'){
            $attendance_type = 'staff';
        }else{
            $attendance_type = 'student';
        }
        
        foreach ($user_id as $user_ids) {
            $add_school = array(
                'student_out' => 1,
                'out_time' => $time
            );
            $this->db->where('child_id', $user_ids);
            $this->db->where('date', $date);
            $insert = $this->db->update('attendance', $add_school);
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    public function attendance_absent($user_id, $date, $time,$attendance_type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d');
        $added_time = date('H:i');
        
        if($attendance_type == 'staff'){
            $attendance_type = 'staff';
        }else{
            $attendance_type = 'student';
        }
        
        foreach ($user_id as $user_ids) {
            $add_school = array(
                'type' => $attendance_type,
                'child_id' => $user_ids,
                'date' => $date,
                'student_absent' => 1
            );
            $insert     = $this->db->insert('attendance', $add_school);
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    public function attendance_leave($user_id, $date, $time,$attendance_type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d');
        $added_time = date('H:i');
        
        if($attendance_type == 'staff'){
            $attendance_type = 'staff';
        }else{
            $attendance_type = 'student';
        }
        
        foreach ($user_id as $user_ids) {
            $add_school = array(
                'type' => $attendance_type,
                'child_id' => $user_ids,
                'date' => $date,
                'student_leave' => 1
            );
            $insert     = $this->db->insert('attendance', $add_school);
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    public function attendance_unmark($user_id, $date, $time,$attendance_type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d');
        $added_time = date('H:i');
        
        if($attendance_type == 'staff'){
            $attendance_type = 'staff';
        }else{
            $attendance_type = 'student';
        }
        
        foreach ($user_id as $user_ids) {
            $add_school = array(
                'type' => $attendance_type,
                'child_id' => $user_ids,
                'date' => $date,
                'student_unmark' => 1
            );
            $insert     = $this->db->insert('attendance', $add_school);
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        
        return $resultpost;
    }
    
    public function attendance_list($user_id, $date, $attendance_type)
    {
        if ($attendance_type == 'staff') {
            $query = $this->db->query("SELECT * FROM staff where user_id = '$user_id'");
        } else {
            $query = $this->db->query("SELECT * FROM student where user_id = '$user_id' AND program_id='$attendance_type'");
        }
        
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            
            $query_att = $this->db->query("SELECT * FROM attendance where child_id = '$id' and date='$date' ");
            $row_att   = $query_att->row_array();
            
            $student_in     = $row_att['student_in'];
            $student_out    = $row_att['student_out'];
            $student_absent = $row_att['student_absent'];
            $student_leave  = $row_att['student_leave'];
            $student_unmark = $row_att['student_unmark'];
            $in_time        = $row_att['in_time'];
            $out_time       = $row_att['out_time'];
            
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "student_in" => $student_in,
                "student_out" => $student_out,
                "student_absent" => $student_absent,
                "student_leave" => $student_leave,
                "student_unmark" => $student_unmark,
                "in_time" => $in_time,
                "out_time" => $out_time
            );
        }
        
        $total_school = count($data);
        $query_in     = $this->db->query("SELECT * FROM attendance where student_in = '1' and date='$date' ")->num_rows();
        $query_out    = $this->db->query("SELECT * FROM attendance where student_out = '1' and date='$date' ")->num_rows();
        $query_absent = $this->db->query("SELECT * FROM attendance where student_absent = '1' and date='$date' ")->num_rows();
        $query_leave  = $this->db->query("SELECT * FROM attendance where student_leave = '1' and date='$date' ")->num_rows();
        $query_unmark = $this->db->query("SELECT * FROM attendance where student_unmark = '1' and date='$date' ")->num_rows();
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_student' => $total_school,
            'total_in' => $query_in,
            'total_out' => $query_out,
            'total_absent' => $query_absent,
            'total_leave' => $query_leave,
            'total_unmark' => $query_unmark
        );
        return $resultpost;
    }
    
    public function noticeboard_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM notice_board where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id           = $row['id'];
            $title        = $row['title'];
            $details      = $row['details'];
            $is_important = $row['is_important'];
            $is_archive   = $row['is_archive'];
            $is_archive   = $row['is_archive'];
            
            
            $data[] = array(
                "id" => $id,
                "title" => $title,
                "details" => $details,
                "is_important" => $is_important,
                "is_archive" => $is_archive
            );
        }
        
        $total_school = count($data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_student' => $total_school
        );
        return $resultpost;
    }
    
    public function noticeboard_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM notice_board where user_id = '$user_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id           = $row['id'];
            $title        = $row['title'];
            $details      = $row['details'];
            $is_important = $row['is_important'];
            $is_archive   = $row['is_archive'];
            // $program_id      = $row['program_id'];
            $program_id   = explode(',', $row['program_id']);
            
            $data[] = array(
                "id" => $id,
                "title" => $title,
                "details" => $details,
                "is_important" => $is_important,
                "is_archive" => $is_archive,
                "program_id" => $program_id
            );
        }
        
        $total_school = count($data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_student' => $total_school
        );
        return $resultpost;
    }
    
    
    
    public function add_health($user_id, $program_id, $children_id, $time, $health_type, $height, $height_type, $weight, $weight_type, $head, $head_type, $details, $image, $video, $file)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date  = date('Y-m-d H:i');
        $children_id = implode(',', $children_id);
        $image_url   = $this->image_upload('image');
        if (!empty($image_url)) {
            $image_url = $image_url;
        } else {
            $image_url = '';
        }
        
        $file_url = $this->files_upload('file');
        if (!empty($file)) {
            $file_url = $file_url;
        } else {
            $file_url = '';
        }
        
        $video_url = $this->video_upload('video');
        if (!empty($video_url)) {
            $video_url = $video_url;
        } else {
            $video_url = '';
        }
        
        
        $add_school = array(
            'user_id' => $user_id,
            'program_id' => $program_id,
            'children_id' => $children_id,
            'time' => $time,
            'health_type' => $health_type,
            'height' => $height,
            'height_type' => $height_type,
            'weight' => $weight,
            'weight_type' => $weight_type,
            'head' => $head,
            'head_type' => $head_type,
            'details' => $details,
            'image' => $image_url,
            'video' => $video_url,
            'file' => $file_url,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('health', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function student_list_selected($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM student where id IN ($user_id)");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            
            $query_att = $this->db->query("SELECT * FROM attendance where child_id = '$id' and date='$date' ");
            $row_att   = $query_att->row_array();
            
            $student_in     = $row_att['student_in'];
            $student_out    = $row_att['student_out'];
            $student_absent = $row_att['student_absent'];
            $student_leave  = $row_att['student_leave'];
            $student_unmark = $row_att['student_unmark'];
            $in_time        = $row_att['in_time'];
            $out_time       = $row_att['out_time'];
            
            
            $data[] = array(
                "id" => $id,
                "first_name" => $first_name,
                "last_name" => $last_name,
                "student_in" => $student_in,
                "student_out" => $student_out,
                "student_absent" => $student_absent,
                "student_leave" => $student_leave,
                "student_unmark" => $student_unmark,
                "in_time" => $in_time,
                "out_time" => $out_time
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function program_list_selected($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM program where id IN ($user_id)");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    
    public function selected_staff_list($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM staff where id IN ($user_id)");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['first_name'].' '.$row['last_name'] ;
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function parents_note_list($list_id, $program_id)
    {
        $query = $this->db->query("SELECT * FROM parents_note where school_id ='$list_id' and program_id = '$program_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id          = $row['id'];
            $user_id     = $row['user_id'];
            $program_id  = $row['program_id'];
            $type        = $row['type'];
            $start_date  = $row['start_date'];
            $end_date    = $row['end_date'];
            $is_resolved = $row['is_resolved'];
            $added_date  = $row['added_date'];
            
            $query_user = $this->db->query("SELECT * FROM student where id ='$user_id'");
            $row_user   = $query_user->row_array();
            $user_name  = $row_user['first_name'] . ' ' . $row_user['last_name'];
            
            $data_details = array();
            $query_       = $this->db->query("SELECT * FROM parents_note_details where note_id ='$id'");
            foreach ($query_->result_array() as $row_) {
                $details            = $row_['details'];
                $image              = $row_['image'];
                $video              = $row_['video'];
                $file               = $row_['file'];
                $details_added_date = $row_['added_date'];
                
                $data_details[] = array(
                    "details" => $details,
                    "image" => $image,
                    "video" => $video,
                    "file" => $file,
                    "added_date" => $details_added_date
                );
            }
            
            $data_admin  = array();
            $query_admin = $this->db->query("SELECT * FROM parents_note_reply where note_id ='$id'");
            foreach ($query_admin->result_array() as $row_admin) {
                $admin_details    = $row_admin['details'];
                $admin_image      = $row_admin['image'];
                $admin_video      = $row_admin['video'];
                $admin_file       = $row_admin['file'];
                $admin_added_date = $row_admin['added_date'];
                
                $data_admin[] = array(
                    "details" => $admin_details,
                    "image" => $admin_image,
                    "video" => $admin_video,
                    "file" => $admin_file,
                    "added_date" => $admin_added_date
                );
            }
            
            $data[] = array(
                "id" => $id,
                "user_name" => $user_name,
                "type" => $type,
                "start_date" => $start_date,
                "end_date" => $end_date,
                "is_resolved" => $is_resolved,
                "added_date" => $added_date,
                "details" => $data_details,
                "admin_reply" => $data_admin
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function parents_note_details($list_id, $id)
    {
        $query = $this->db->query("SELECT * FROM parents_note where school_id ='$list_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id          = $row['id'];
            $user_id     = $row['user_id'];
            $program_id  = $row['program_id'];
            $type        = $row['type'];
            $start_date  = $row['start_date'];
            $end_date    = $row['end_date'];
            $is_resolved = $row['is_resolved'];
            $added_date  = $row['added_date'];
            
            $query_user = $this->db->query("SELECT * FROM student where id ='$user_id'");
            $row_user   = $query_user->row_array();
            $user_name  = $row_user['first_name'];
            
            $data_details = array();
            $query_       = $this->db->query("SELECT * FROM parents_note_details where note_id ='$id'");
            foreach ($query_->result_array() as $row_) {
                $details            = $row_['details'];
                $image              = $row_['image'];
                $video              = $row_['video'];
                $file               = $row_['file'];
                $details_added_date = $row_['added_date'];
                
                $data_details[] = array(
                    "details" => $details,
                    "image" => $image,
                    "video" => $video,
                    "file" => $file,
                    "added_date" => $details_added_date
                );
            }
            
            $data_admin  = array();
            $query_admin = $this->db->query("SELECT * FROM parents_note_reply where note_id ='$id'");
            foreach ($query_admin->result_array() as $row_admin) {
                $admin_details    = $row_admin['details'];
                $admin_image      = $row_admin['image'];
                $admin_video      = $row_admin['video'];
                $admin_file       = $row_admin['file'];
                $admin_added_date = $row_admin['added_date'];
                
                $data_admin[] = array(
                    "details" => $admin_details,
                    "image" => $admin_image,
                    "video" => $admin_video,
                    "file" => $admin_file,
                    "added_date" => $admin_added_date
                );
            }
            
            $data[] = array(
                "id" => $id,
                "user_name" => $user_name,
                "type" => $type,
                "start_date" => $start_date,
                "end_date" => $end_date,
                "is_resolved" => $is_resolved,
                "added_date" => $added_date,
                "details" => $data_details,
                "admin_reply" => $data_admin
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    
    public function parents_note_admin_reply($school_id, $note_id, $details, $image, $video, $file)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'school_id' => $school_id,
            'note_id' => $note_id,
            'details' => $details,
            'image' => $image,
            'video' => $video,
            'file' => $file,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('parents_note_reply', $add_school);
        if ($insert) {
            
            $parents_note = array(
                'is_resolved' => 1
            );
            $this->db->where('id', $note_id);
            $this->db->update('parents_note', $parents_note);
            
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function add_enquiry($school_id, $name, $assign_label, $primary_mobile, $secondry_mobile, $email, $locality, $city, $relation, $child_name, $gender, $birthday, $age, $program_intrested, $notes, $date_of_enquiry, $follow_up_date, $how_know, $academic_year, $is_important)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'school_id' => $school_id,
            'name' => $name,
            'assign_label' => $assign_label,
            'primary_mobile' => $primary_mobile,
            'secondry_mobile' => $secondry_mobile,
            'email' => $email,
            'locality' => $locality,
            'city' => $city,
            'relation' => $relation,
            'child_name' => $child_name,
            'gender' => $gender,
            'birthday' => $birthday,
            'age' => $age,
            'program_intrested' => $program_intrested,
            'notes' => $notes,
            'date_of_enquiry' => $date_of_enquiry,
            'follow_up_date' => $follow_up_date,
            'how_know' => $how_know,
            'academic_year' => $academic_year,
            'is_important' => $is_important,
            'added_date' => $added_date
        );
        $insert     = $this->db->insert('enquiries', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    public function edit_enquiry($id, $school_id, $name, $assign_label, $primary_mobile, $secondry_mobile, $email, $locality, $city, $relation, $child_name, $gender, $birthday, $age, $program_intrested, $notes, $date_of_enquiry, $follow_up_date, $how_know, $academic_year, $is_important)
    {
        date_default_timezone_set('Asia/Kolkata');
        $added_date = date('Y-m-d H:i');
        $add_school = array(
            'school_id' => $school_id,
            'name' => $name,
            'assign_label' => $assign_label,
            'primary_mobile' => $primary_mobile,
            'secondry_mobile' => $secondry_mobile,
            'email' => $email,
            'locality' => $locality,
            'city' => $city,
            'relation' => $relation,
            'child_name' => $child_name,
            'gender' => $gender,
            'birthday' => $birthday,
            'age' => $age,
            'program_intrested' => $program_intrested,
            'notes' => $notes,
            'date_of_enquiry' => $date_of_enquiry,
            'follow_up_date' => $follow_up_date,
            'how_know' => $how_know,
            'academic_year' => $academic_year,
            'is_important' => $is_important,
            'added_date' => $added_date
        );
        $this->db->where('id', $id);
        $insert = $this->db->update('enquiries', $add_school);
        if ($insert) {
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Fail'
            );
        }
        return $resultpost;
    }
    
    
    public function enquiries_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM enquiries where school_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id              = $row['id'];
            $name            = $row['name'];
            $primary_mobile  = $row['primary_mobile'];
            $child_name      = $row['child_name'];
            $date_of_enquiry = $row['date_of_enquiry'];
            $assign_label    = $row['assign_label'];
            
            $date_of_enquiry = date("d M Y", strtotime($date_of_enquiry));
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "primary_mobile" => $primary_mobile,
                "child_name" => $child_name,
                "date_of_enquiry" => $date_of_enquiry,
                "assign_label" => $assign_label
            );
        }
        
        $total_school = count($data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_student' => $total_school
        );
        return $resultpost;
    }
    
    
    public function enquiries_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM enquiries where school_id = '$user_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id                = $row['id'];
            $name              = $row['name'];
            $assign_label      = $row['assign_label'];
            $primary_mobile    = $row['primary_mobile'];
            $secondry_mobile   = $row['secondry_mobile'];
            $email             = $row['email'];
            $locality          = $row['locality'];
            $city              = $row['city'];
            $relation          = $row['relation'];
            $child_name        = $row['child_name'];
            $gender            = $row['gender'];
            $birthday          = $row['birthday'];
            $age               = $row['age'];
            $program_intrested = $row['program_intrested'];
            $notes             = $row['notes'];
            $date_of_enquiry   = $row['date_of_enquiry'];
            $follow_up_date    = $row['follow_up_date'];
            $how_know          = $row['how_know'];
            $academic_year     = $row['academic_year'];
            $is_important      = $row['is_important'];
            
            
            $data[] = array(
                "id" => $id,
                "name" => $name,
                "assign_label" => $assign_label,
                "primary_mobile" => $primary_mobile,
                "child_name" => $child_name,
                "secondry_mobile" => $secondry_mobile,
                "email" => $email,
                "locality" => $locality,
                "city" => $city,
                "relation" => $relation,
                "child_name" => $child_name,
                "gender" => $gender,
                "age" => $age,
                "program_intrested" => $program_intrested,
                "notes" => $notes,
                "date_of_enquiry" => $date_of_enquiry,
                "follow_up_date" => $follow_up_date,
                "academic_year" => $academic_year,
                "is_important" => $is_important,
                "how_know" => $how_know,
                "birthday" => $birthday
            );
        }
        
        $total_school = count($data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_student' => $total_school
        );
        return $resultpost;
    }
    
    
    public function program_list($user_id)
    {
        $query = $this->db->query("SELECT * FROM program where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id     = $row['id'];
            $name   = $row['name'];
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function event_list($user_id,$event_type,$month,$year)
    {
        $where = '';
        if($user_id != ''){
            $where .= " where user_id = ".$user_id." HAVING month = '$month' AND year = '$year'"; 
        }
        if($event_type != ''){
            $where .= " and type = ".$event_type; 
        }
        $query = $this->db->query("SELECT id,user_id,type,title,locatoin,start_date,end_date,MONTH(start_date) AS month,YEAR(start_date) AS year FROM event ".$where);
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $title      = $row['title'];
            $type       = $row['type'];
            $locatoin   = $row['locatoin'];
            $start_date = date("d-m-Y", strtotime($row['start_date']));
            $end_date   = date("d-m-Y", strtotime($row['end_date']));
            
            $query_type = $this->db->query("SELECT * FROM events_type where id = '$type'");
            $row_type   = $query_type->row_array();
            
            $type_name = $row_type['name'];
            
            $data[] = array(
                "id" => $id,
                "title" => $title,
                "type" => $type,
                "type_name" => $type_name,
                "location" => $locatoin,
                "start_date" => $start_date,
                "end_date" => $end_date
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function event_details($user_id, $id)
    {
        $query = $this->db->query("SELECT * FROM event where user_id = '$user_id' and id='$id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id         = $row['id'];
            $title      = $row['title'];
            $type       = $row['type'];
            $locatoin   = $row['locatoin'];
            $start_date = $row['start_date'];
            $end_date   = $row['end_date'];
            $program    = $row['program'];
            $details    = $row['details'];
            $all_day    = $row['all_day'];
            $notify     = $row['notify'];
            
            $query_type = $this->db->query("SELECT * FROM program where id = '$program'");
            $row_type   = $query_type->row_array();
            
            $type_name = $row_type['name'];
            
            $data[] = array(
                "id" => $id,
                "title" => $title,
                "type" => $type,
                "type_name" => $type_name,
                "locatoin" => $locatoin,
                "start_date" => $start_date,
                "end_date" => $end_date,
                "program" => $program,
                "details" => $details,
                "all_day" => $all_day,
                "notify" => $notify
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function daily_report($list_id, $child_id)
    {
        $query = $this->db->query("SELECT * FROM student where user_id = '$list_id' and id='$child_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            
            $daily_report       = array();
            $query_sleep = $this->db->query("SELECT * FROM sleep where user_id = '$list_id' and FIND_IN_SET($child_id,child_id)");
            foreach ($query_sleep->result_array() as $row_sleep) {
                $added_date = $row_sleep['added_date'];
                $details    = $row_sleep['details'];
                $start_time = $row_sleep['start_time'];
                $end_time   = $row_sleep['end_time'];
                $title      = $first_name . ' ' . $last_name . ' slept from ' . $start_time . ' to ' . $end_time;
                $daily_report[]    = array(
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" => date("Y-m-d", strtotime($added_date)),
                    "details" => $details,
                    "details_ex" => '',
                    "title" => $title,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/sleeping.png'
                );
            }
            
            $play_learn = array();
            $query_play = $this->db->query("SELECT * FROM play_learn where user_id = '$list_id' and FIND_IN_SET($child_id,children_id)");
            foreach ($query_play->result_array() as $query_play) {
                $added_date    = $query_play['added_date'];
                $item_name     = $query_play['item_name'];
                $activity_type = $query_play['activity_type'];
                $start_time    = $query_play['start_time'];
                $end_time      = $query_play['end_time'];
                $title         = $first_name . ' ' . $last_name . ' participate in ' . $activity_type . ' From ' . $start_time . ' to ' . $end_time;
                $daily_report[]  = array(
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" => date("Y-m-d", strtotime($added_date)),
                    "details" => 'Activity Names : ' . $item_name,
                    "details_ex" => '',
                    "title" => $title,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/play_learn.png'
                );
            }
            
            $potty       = array();
            $query_potty = $this->db->query("SELECT * FROM potty where user_id = '$list_id' and FIND_IN_SET($child_id,children_id)");
            foreach ($query_potty->result_array() as $row_potty) {
                $added_date    = $row_potty['added_date'];
                $type          = $row_potty['type'];
                $sub_type      = $row_potty['sub_type'];
                $potty_details = $row_potty['details'];
                $start_time    = date("g:i a", strtotime($row_potty['added_date']));
                if ($type == 'POTTY') {
                    $title = $first_name . ' ' . $last_name . ' went to ' . $type . ' at ' . $start_time;
                }
                if ($type == 'DIAPER') {
                    $title = $first_name . ' ' . $last_name . ' ' . $sub_type . ' ' . $type . ' was change at ' . $start_time;
                }
                $daily_report[] = array(
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" => date("Y-m-d", strtotime($added_date)),
                    "details" => $potty_details,
                    "details_ex" => '',
                    "title" => $title,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/washroom.png'
                );
            }
            
            $health       = array();
            $query_health = $this->db->query("SELECT * FROM health where user_id = '$list_id' and FIND_IN_SET($child_id,children_id)");
            foreach ($query_health->result_array() as $row_health) {
                $added_date    = $row_health['added_date'];
                $time          = $row_health['time'];
                $health_type   = $row_health['health_type'];
                $height        = $row_health['height'];
                $height_type   = $row_health['height_type'];
                $weight        = $row_health['weight'];
                $weight_type   = $row_health['weight_type'];
                $head          = $row_health['head'];
                $head_type     = $row_health['head_type'];
                $details_ex    = $row_health['details'];
                $healthdetails = '';
                $health_title  = '';
                $start_time    = date("g:i a", strtotime($row_health['added_date']));
                if ($health_type == 'Medicine') {
                    $health_title  = $health_type . ' was given to ' . $first_name . ' ' . $last_name;
                    $healthdetails = '';
                }
                if ($health_type == 'Sick') {
                    $health_title  = 'Alert ! Sickness observed in' . $first_name . ' ' . $last_name;
                    $healthdetails = '';
                }
                if ($health_type == 'Incident') {
                    $health_title  = 'Ouch! ' . $first_name . ' ' . $last_name . ' had an incident';
                    $healthdetails = '';
                }
                if ($health_type == 'Growth') {
                    $health_title  = $first_name . ' ' . $last_name . ' Growth was measured';
                    $healthdetails = 'Height : ' . $height . ' ' . $height_type . ', Weight : ' . $weight . ' ' . $weight_type . ', Circumference : ' . $head . ' ' . $head_type;
                }
                $daily_report[] = array(
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" => date("Y-m-d", strtotime($added_date)),
                    "details_ex" => $details_ex,
                    "details" => $healthdetails,
                    "title" => $health_title,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/hospital.png'
                );
            }
            $this->sort_array_of_array($daily_report, 'date');
            
          $grouped_array = $this->group_array($daily_report, "date", true);
         
          $report_data=[];
          foreach ($grouped_array as $key => $value) {
           $list=[];
            foreach ($value as $value2) {
                $list[] = array( 
                     "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details_ex" => $value2['details_ex'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "image" => $value2['image']
            );   
           }
             $report_data[] = array( 
                "added_date" => $key,
                "list" => $list
            );
           
          }
            
            $data[] = array( 
                "first_name" => $first_name,
                "last_name" => $last_name,
                "daily_report" => $report_data
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }
    
   
    public function history($list_id, $child_id, $program,$activity,$from_date,$to_date)
    {
        $where = '';
        $queryCondition  = '';
        if ($list_id != '') {
            $where .= ' where user_id =  ' . $list_id;
        }
        if ($program != '' || $program != 0) {
            $where .= ' and program_id = ' . $program;
        }
        if ($child_id != '' || $child_id != 0) {
            $where .= ' and id = ' . $child_id;
        }
         if ($from_date != '') {
             $queryCondition .= "and added_date  BETWEEN '$from_date' AND '$to_date'"; 
         }
       
        $query = $this->db->query("SELECT * FROM student" . $where);
        // print_r($test);
        $count = $query->num_rows();
        $data  = array();    
        $daily_report       = array();
        foreach ($query->result_array() as $row) {
            
            $user_id    = $row['id'];
            $first_name = $row['first_name'];
            $last_name  = $row['last_name'];
            $program_id  = $row['program_id'];
            
            $query_program = $this->db->query("SELECT * FROM program where id='$program_id'");
            $row_prog =  $query_program->row_array();      
            $program_name = $row_prog['name'];
            
  
            $query_sleep = $this->db->query("SELECT * FROM sleep where user_id = '$list_id' and FIND_IN_SET($user_id,child_id)".$queryCondition);
            foreach ($query_sleep->result_array() as $row_sleep) {
                $added_date = $row_sleep['added_date'];
                $details    = $row_sleep['details'];
                $start_time = $row_sleep['start_time'];
                $end_time   = $row_sleep['end_time'];
                $title      = 'Sleep ';
                $modal_title = 'History Details - Sleep';
				
			
				
                $daily_report[]    = array(
                    "case" => 'sleep',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'sleep_'.$row_sleep['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" => date("Y-m-d", strtotime($added_date)),
                    "details" => $details,
                    "title" => $title,
                    "modal_title" => $modal_title,
                    "item_name" => '',
                    "activity_type" => '',
                    "start_time" => $start_time,
                    "end_time" => $end_time,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/sleeping.png'
                );
            }
            
            $play_learn = array();
            $query_play = $this->db->query("SELECT * FROM play_learn where user_id = '$list_id' and FIND_IN_SET($user_id,children_id)".$queryCondition);
            foreach ($query_play->result_array() as $query_play) {
                $added_date    = $query_play['added_date'];
                $item_name     = $query_play['item_name'];
                $activity_type = $query_play['activity_type'];
                $start_time    = $query_play['start_time'];
                $end_time      = $query_play['end_time'];
                $details       = $query_play['details'];
                $title         = 'Play Learn | ' . $activity_type;
                $modal_title = 'History Details - Play Learn';
                $daily_report[]  = array( 
                    "case" => 'play_learn',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'play_'.$query_play['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $details,
                    "title" => $title,
                    "modal_title" => $modal_title,
                    "item_name" => $item_name,
                    "activity_type" => $activity_type,
                    "start_time" => $start_time,
                    "end_time" => $end_time,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/play_learn.png'
                );
            }
            
            $potty       = array();
            $query_potty = $this->db->query("SELECT * FROM potty where user_id = '$list_id' and FIND_IN_SET($user_id,children_id)".$queryCondition);
            foreach ($query_potty->result_array() as $row_potty) {
                $added_date    = $row_potty['added_date'];
                $type          = $row_potty['type'];
                $sub_type      = $row_potty['sub_type'];
                $potty_details = $row_potty['details'];
                $start_time    = date("g:i a", strtotime($row_potty['added_date']));
                $modal_title = 'History Details - Potty';
                if ($type == 'POTTY') {
                    $title = 'Potty';
                }
                if ($type == 'DIAPER') {
                    $title = 'Potty | ' . $type . ' | ' . $sub_type;
                }
                $daily_report[] = array(
                    "case" => 'potty',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'potty_'.$row_potty['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $potty_details,
                    "item_name" => '',
                    "activity_type" => '',
                    "title" => $title,
                    "modal_title" => $modal_title,
                    "type" => $type,
                    "sub_type" => $sub_type,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/washroom.png'
                );
            }
            
            $health       = array();
            $query_health = $this->db->query("SELECT * FROM health where user_id = '$list_id' and FIND_IN_SET($user_id,children_id)".$queryCondition);
            foreach ($query_health->result_array() as $row_health) {
                $added_date    = $row_health['added_date'];
                $time          = $row_health['time'];
                $health_type   = $row_health['health_type'];
                $height        = $row_health['height'];
                $height_type   = $row_health['height_type'];
                $weight        = $row_health['weight'];
                $weight_type   = $row_health['weight_type'];
                $head          = $row_health['head'];
                $head_type     = $row_health['head_type'];
                $details_ex    = $row_health['details'];
                $healthdetails = '';
                $health_title  = '';
                $start_time    = date("g:i a", strtotime($row_health['added_date']));
                
                $health_title  = 'Health | ' . $health_type;
                $modal_title = 'History Details - Health';
                $healthdetails = '';
                
                $daily_report[] = array(
                    "case" => 'health',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'health_'.$row_health['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $details_ex,
                    "title" => $health_title,
                    "modal_title" => $modal_title,
                    "time" => $time,
                    "health_type" => $health_type,
                    "height" => $height . ' ' . $height_type,
                    "weight" => $weight . ' ' . $weight_type,
                    "head" => $head . ' ' . $head_type,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/hospital.png'
                );
            }
            
            $health       = array();
            $query_observation = $this->db->query("SELECT * FROM observation where user_id = '$list_id' and FIND_IN_SET($user_id,children_id)".$queryCondition);
            foreach ($query_observation->result_array() as $row_observation) {
                $added_date    = $row_observation['added_date'];
                $time          = $row_observation['time'];
                $observation_type   = $row_observation['observation_type'];
                $details_ex    = $row_observation['details'];
                $healthdetails = '';
                $health_title  = '';
                $start_time    = date("g:i a", strtotime($row_observation['added_date']));
                
                $health_title  = 'Observation' ;
                $modal_title = 'History Details - Observation';
                $healthdetails = '';
                
                $daily_report[] = array(
                    "case" => 'observation',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'observation_'.$row_observation['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $details_ex,
                    "title" => $health_title,
                    "modal_title" => $modal_title,
                    "observation_type" => $observation_type,
                    "time" => $time,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/search.png'
                );
            }
            
            $query_dairy = $this->db->query("SELECT * FROM dairy where user_id = '$list_id' and FIND_IN_SET($user_id,children_id)".$queryCondition);
           
            foreach ($query_dairy->result_array() as $row_dairy) {
                $added_date    = $row_dairy['added_date'];
                $communication_type   = $row_dairy['communication_type'];
                $like_type   = $row_dairy['like_type'];
                $comment_type   = $row_dairy['comment_type'];
                $notification_type   = $row_dairy['notification_type'];
                $details_ex    = $row_dairy['details'];
                $healthdetails = '';
                $health_title  = '';
                $start_time    = date("g:i a", strtotime($row_dairy['added_date']));
                
                $health_title  = 'Dairy | '.$communication_type ;
                $modal_title = 'History Details - Dairy';
                $healthdetails = '';
                
                $daily_report[] = array(
                    "case" => 'dairy',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'dairy_'.$row_dairy['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $details_ex,
                    "title" => $health_title,
                    "modal_title" => $modal_title,
                    "communication_type" => $communication_type,
                    "like_type" => $like_type,
                    "comment_type" => $comment_type,
                    "notification_type" => $notification_type,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/book.png'
                );
            }
            
            $query_food = $this->db->query("SELECT * FROM food where user_id = '$list_id' and FIND_IN_SET($user_id,children_id)".$queryCondition);
            foreach ($query_food->result_array() as $row_food) {
                $added_date    = $row_food['added_date'];
                $meal_type   = $row_food['meal_type'];
                $quantity   = $row_food['quantity'];
                $item_name   = $row_food['item_name'];
                $details_ex    = $row_food['details'];
                $healthdetails = '';
                $health_title  = '';
                $start_time    = date("g:i a", strtotime($row_food['added_date']));
                
                $health_title  = 'Food | '.$meal_type .' | '.$quantity ;
                $modal_title = 'History Details - Food';
                $healthdetails = '';
                
                $daily_report[] = array(
                    "case" => 'food',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'food_'.$row_food['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $details_ex,
                    "title" => $health_title,
                    "modal_title" => $modal_title,
                    "meal_type" => $meal_type,
                    "quantity" => $quantity,
                    "food_item_name" => $item_name,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/healthy-food.png'
                );
            }
            
            $query_star = $this->db->query("SELECT * FROM star where user_id = '$list_id' and FIND_IN_SET($user_id,child_id)".$queryCondition);
            foreach ($query_star->result_array() as $row_star) {
                $added_date    = $row_star['added_date'];
                $star_type   = $row_star['star_type'];
                $details_ex    = $row_star['details'];
                $healthdetails = '';
                $health_title  = '';
                $start_time    = date("g:i a", strtotime($row_star['added_date']));
                
                $health_title  = 'Star | '.$star_type ;
                $modal_title = 'History Details - Star';
                $healthdetails = '';
                
                $daily_report[] = array(
                    "case" => 'star',	
					"first_name" => $first_name,
					"last_name" => $last_name,
					"program_name" => $program_name,
                    "id" => 'star_'.$row_star['id'],
                    "added_time" => date("g:i a", strtotime($added_date)),
                    "added_date" => date("d M Y", strtotime($added_date)),
                    "date" =>  date("Y-m-d", strtotime($added_date)),
                    "details" => $details_ex,
                    "title" => $health_title,
                    "modal_title" => $modal_title,
                    "star_type" => $star_type,
                    "image" => 'https://erp.demo.webwork.co.in/uploads/images/favorite.png'
                );
            }
        }  
       
        $this->sort_array_of_array($daily_report, 'date');
        $grouped_array = $this->group_array($daily_report, "date", true);
      
          $report_data=[];
          foreach ($grouped_array as $key => $value) {
          $list=[];
            foreach ($value as $value2) {
                
                if($activity == 'sleep'){
                if($value2['case']=='sleep'){   
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "item_name" => $value2['item_name'],
                    "activity_type" => $value2['activity_type'],
                    "start_time" => $value2['start_time'],
                    "end_time" => $value2['end_time'],
                    "image" => $value2['image'],
                    );
                }
                }
                if($activity == 'play_learn'){
                    if($value2['case']=='play_learn'){     
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "item_name" => $value2['item_name'],
                        "activity_type" => $value2['activity_type'],
                        "start_time" => $value2['start_time'],
                        "end_time" => $value2['end_time'],
                        "image" => $value2['image'],
                        );  
                        
                    } 
                }
                if($activity == 'potty'){
                    if($value2['case']=='potty'){     
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "item_name" => $value2['item_name'],
                        "activity_type" => $value2['activity_type'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "type" => $value2['type'],
                        "sub_type" => $value2['sub_type'],
                        "image" => $value2['image'],
                        );  
                        
                    }
                }
                if($activity == 'health'){
                    if($value2['case']=='health'){
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "time" => $value2['time'],
                        "health_type" => $value2['health_type'],
                        "height" => $value2['height'],
                        "weight" => $value2['weight'],
                        "head" => $value2['head'],
                        "image" => $value2['image'],
                        );  
                        
                    }
                }
                if($activity == 'observation'){
                    if($value2['case']=='observation'){    
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "observation_type" => $value2['observation_type'],
                        "time" => $value2['time'],
                        "image" => $value2['image'],
                        );  
                        
                    }
                }
                if($activity == 'dairy'){
                    if($value2['case']=='dairy'){    
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "communication_type" => $value2['communication_type'],
                        "like_type" => $value2['like_type'],
                        "comment_type" => $value2['comment_type'],
                        "notification_type" => $value2['notification_type'],
                        "image" => $value2['image'],
                        );  
                        
                    }
                }
                if($activity == 'food'){
                    if($value2['case']=='food'){   
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "meal_type" => $value2['meal_type'],
                        "quantity" => $value2['quantity'],
                        "food_item_name" => $value2['food_item_name'],
                        "image" => $value2['image'],
                        );  
                        
                    }
                }
                if($activity == 'star'){
                    if($value2['case']=='star'){  
                        $list[] = array( 
                        "case" => $value2['case'],
    					"first_name" => $value2['first_name'],
                        "last_name" => $value2['last_name'],
                        "program_name" => $value2['program_name'],
                        "id" => $value2['id'],
                        "added_time" => $value2['added_time'],
                        "added_date" => $value2['added_date'],
                        "date" => $value2['date'],
                        "details" =>$value2['details'],
                        "title" =>$value2['title'],
                        "modal_title" => $value2['modal_title'],
                        "star_type" => $value2['star_type'],
                        "image" => $value2['image'],
                        );  
                        
                    }
                }
                
                if($activity == ''){
                    
                if($value2['case']=='sleep'){   
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "item_name" => $value2['item_name'],
                    "activity_type" => $value2['activity_type'],
                    "start_time" => $value2['start_time'],
                    "end_time" => $value2['end_time'],
                    "image" => $value2['image'],
                    );  
                    
                }  
                
               elseif($value2['case']=='play_learn'){     
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "item_name" => $value2['item_name'],
                    "activity_type" => $value2['activity_type'],
                    "start_time" => $value2['start_time'],
                    "end_time" => $value2['end_time'],
                    "image" => $value2['image'],
                    );  
                    
                }  
                
                elseif($value2['case']=='potty'){     
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "item_name" => $value2['item_name'],
                    "activity_type" => $value2['activity_type'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "type" => $value2['type'],
                    "sub_type" => $value2['sub_type'],
                    "image" => $value2['image'],
                    );  
                    
                }
                
                elseif($value2['case']=='health'){
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "time" => $value2['time'],
                    "health_type" => $value2['health_type'],
                    "height" => $value2['height'],
                    "weight" => $value2['weight'],
                    "head" => $value2['head'],
                    "image" => $value2['image'],
                    );  
                    
                }
                
                
                elseif($value2['case']=='observation'){    
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "observation_type" => $value2['observation_type'],
                    "time" => $value2['time'],
                    "image" => $value2['image'],
                    );  
                    
                }
                
                
                elseif($value2['case']=='dairy'){    
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "communication_type" => $value2['communication_type'],
                    "like_type" => $value2['like_type'],
                    "comment_type" => $value2['comment_type'],
                    "notification_type" => $value2['notification_type'],
                    "image" => $value2['image'],
                    );  
                    
                }
                
                
                elseif($value2['case']=='food'){   
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "meal_type" => $value2['meal_type'],
                    "quantity" => $value2['quantity'],
                    "food_item_name" => $value2['food_item_name'],
                    "image" => $value2['image'],
                    );  
                    
                }
                
             
                elseif($value2['case']=='star'){  
                    $list[] = array( 
                    "case" => $value2['case'],
					"first_name" => $value2['first_name'],
                    "last_name" => $value2['last_name'],
                    "program_name" => $value2['program_name'],
                    "id" => $value2['id'],
                    "added_time" => $value2['added_time'],
                    "added_date" => $value2['added_date'],
                    "date" => $value2['date'],
                    "details" =>$value2['details'],
                    "title" =>$value2['title'],
                    "modal_title" => $value2['modal_title'],
                    "star_type" => $value2['star_type'],
                    "image" => $value2['image'],
                    );  
                    
                }
                }
                
               } 
                  
                  
                 $report_data[] = array( 
                    "added_date" => $key,
                    "list" => $list
                );
              }
     
            
            $data[] = array(
                "daily_report" => $report_data,
            );
     
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }
    
    function sort_array_of_array(&$array, $subfield)
    {
        $sortarray = array();
        foreach ($array as $key => $row_)
        {
            $sortarray[$key] = $row_[$subfield];
        }
        array_multisort($sortarray, SORT_DESC, $array);
    }
    
  public function group_array($arr, $group, $preserveGroupKey = false, $preserveSubArrays = false) {
    $temp = array();
    foreach($arr as $key => $value) {
        $groupValue = $value[$group];
        if(!$preserveGroupKey)
        {
            unset($arr[$key][$group]);
        }
        if(!array_key_exists($groupValue, $temp)) {
            $temp[$groupValue] = array();
        }

        if(!$preserveSubArrays){
            $data = count($arr[$key]) == 1? array_pop($arr[$key]) : $arr[$key];
        } else {
            $data = $arr[$key];
        }
        $temp[$groupValue][] = $data;
    }
    return $temp;
} 

    public function check_email_duplication($email)
    {
        $query = $this->db->query("SELECT email FROM `parents` WHERE email='$email'");
        return $count = $query->num_rows();
    }
    
    public function check_edit_email_duplication($email,$id)
    {
        $query = $this->db->query("SELECT email FROM `parents` WHERE email='$email' and id<>$id");
        return $count = $query->num_rows();
    }
    
    public function check_mobile_duplication($mobile)
    {
        $query = $this->db->query("SELECT mobile FROM `parents` WHERE mobile='$mobile'");
        return $count = $query->num_rows();
    }
    
    public function check_edit_mobile_duplication($mobile,$id)
    {
        $query = $this->db->query("SELECT mobile FROM `parents` WHERE mobile='$mobile' and id<>$id ");
        return $count = $query->num_rows();
    }
    
    
    
    public function pickuppoint_list($user_id,$type)
    {
        $pickup_time = '';
        $query = $this->db->query("SELECT * FROM pickup_point where user_id = '$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id     = $row['id'];
            $pickup_point   = $row['pickup_point'];
            if($type == 'Pickup'){
            $pickup_time   = $row['pickup_time'];
            }
            if($type == 'Drop'){
            $pickup_time   = $row['drop_time'];
            }
            
            $data[] = array(
                "id" => $id,
                "pickup_point" => $pickup_point,
                "pickup_time" => $pickup_time,
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
        );
        return $resultpost;
    }
    
    public function driver_list_selected($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM driver where id IN ($user_id)");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
    
    public function pickup_list_selected($user_id,$type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date  = date('Y-m-d');
        $query = $this->db->query("SELECT * FROM pickup_point where id IN ($user_id)");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $pickup_point   = $row['pickup_point'];
            if($type == 'Pickup'){
            $pickup_time   = $row['pickup_time'];
            }
            if($type == 'Drop'){
            $pickup_time   = $row['drop_time'];
            }
            
            $data[] = array(
                "id" => $id,
                "pickup_point" => $pickup_point,
                "pickup_time" => $pickup_time,
            );
        }
        
        $total_school = count($data);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_school' => $total_school
        );
        return $resultpost;
    }
	
    
    
}