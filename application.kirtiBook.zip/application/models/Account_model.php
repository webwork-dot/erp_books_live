<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account_model extends CI_Model
{
    public function get_credit_note($user_id,$per_page,$offset,$filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        $query = $this->db->query("SELECT id,buyer_id,order_slot,address_id,order_number,txn_id,username,phone_number,email,order_status,product_id,school_name,slot_no,product_name,order_type,price_shipping,price_subtotal,price_shipping,internet_charges,courier,price_discount,price_total,created_at,username,phone_number,firm_name,board_name,grade_name,warehouse_id,delivered_date,cancelled_date,cancel_type,cancel_amt,cancel_per,cancel_staff_id,refunded_id,refunded_date,invoice_no,invoice_cn,invoice_cn_url FROM orders WHERE (payment_status = 'payment_received') AND (order_status='cancelled' OR order_status='applied_for_exchange') AND (invoice_cn IS NOT NULL) AND (vendor_id = '$user_id')  ORDER BY id desc  LIMIT $offset,$per_page");
        $row = $this->db->query("SELECT id FROM orders WHERE (payment_status = 'payment_received') AND (order_status='cancelled' OR order_status='applied_for_exchange') AND (invoice_cn IS NOT NULL) AND (vendor_id = '$user_id')  ORDER BY id desc");
        $count = $row->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $order_type = $row['order_type'];
            $address_id = $row['address_id'];
            $order_id = $row['id'];
            
            if ($order_type == 'individual') {
                $product_name = $row['product_name'];
            } else {
                $product_name = $row['school_name'];
            }                
            
            $product_name = str_replace(' ', '-', $product_name);
            $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
            $product_name = strtolower(str_replace('-', ' ', $product_name));
            $product_name = ucfirst($product_name);
                  
            $slot_no = $row['order_slot'];                 
                     
            if($row['cancelled_date']!=NULL){
                $cancelled_date = date("d M Y h:i a", strtotime($row['cancelled_date']));
            }
            else{
               $cancelled_date='-';
            } 	                
       
           $created_at = date("d M Y h:i a", strtotime($row['created_at'])); 
            
            $data[] = array(
                    "id" => $row['id'],
                    "address_id" => $address_id,
                    "order_slot_no" => $slot_no,
                    "buyer_id" => $row['buyer_id'],
                    "order_type" => ucfirst($row['order_type']),
                    "order_number" => $row['order_number'],
                    "username" => $row['username'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['order_slot'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "price_total" => price_format_decimal($row['price_total']- $row['price_shipping']),
                    "order_status" => $row['order_status'],
                    "payment_id" => $row['txn_id'],
                    "txn_id" => $row['txn_id'],
                    "firm_name" => $row['firm_name'],
                    "username" => $row['username'],
                    "phone_number" => $row['phone_number'],
                    "email" => $row['email'], 
                    "created_at" => $created_at,
                    "product_name" => $product_name,
                    "cancelled_date"  => $cancelled_date,
                    "invoice_cn" => ($row['invoice_cn']!=NULL?$row['invoice_cn']:'Not Generated'),
                    "invoice_url" => $row['invoice_cn_url'],
                    "price_shipping" => $row['price_shipping'],
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function check_order_by_id($order_id,$user_id)
	{
        $this->db->select('id,invoice_cn_url,invoice_url');
		$this->db->where('vendor_id', $user_id);
		$this->db->where('id', $order_id);
		$query = $this->db->get('orders');
		return $query;
	}
	
	public function get_order_by_id($order_id)
	{
        $this->db->select('id,invoice_cn_url');
		$this->db->where('id', $order_id);
		$query = $this->db->get('orders');
		return $query;
	}
	
	public function get_paid_amount_by_order($order_id){
	 	$this->db->select('sum(paid_amount) AS paid_amount');
	 	$this->db->group_by('order_id');
		$this->db->where('order_id', $order_id);
		$this->db->where('utr_no !=', '');
		$query = $this->db->get('vendor_payments');
		return $query;
	}
	
	public function received_payments($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $date_filter="";
        $vendor_id = $user_id;
             
        if(isset($filter['keywords']) && $filter['keywords']!="") :
          $keywords=$filter['keywords'];
          $keywords_filter =" AND (orders.vendor_id LIKE '%$keywords%')"; 
        endif;	
        
    if(isset($filter['start_end_date']) && $filter['start_end_date']!="") :
       $start_end_date = $filter['start_end_date']; 
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(vp.payment_date) BETWEEN '$from' AND '$to')";
    endif; 
    
                
    	$orders = $this->db->query("SELECT vp.`payment_date`,vp.`utr_no`,SUM(vp.paid_amount) as payment_made FROM `vendor_payments` as vp INNER JOIN orders on vp.order_id=orders.id 
    	WHERE (vp.vendor_id= '$vendor_id') AND orders.payment_status = 'payment_received' AND vp.utr_no IS NOT NULL $keywords_filter $date_filter GROUP BY vp.utr_no ORDER BY vp.id desc LIMIT $offset,$per_page");
    
    	$count = $this->db->query("SELECT vp.`payment_date`,vp.`utr_no`,SUM(vp.paid_amount) as payment_made FROM `vendor_payments` as vp INNER JOIN orders on vp.order_id=orders.id 
    	WHERE (vp.vendor_id= '$vendor_id') AND orders.payment_status = 'payment_received' AND vp.utr_no IS NOT NULL $keywords_filter $date_filter GROUP BY vp.utr_no ORDER BY vp.id desc")->num_rows();
    	
    	$orders_count = $orders->num_rows();
    	$data = array();
    	if($orders_count > 0){
    	foreach ($orders->result_array() as $order) { 
    		$payment_date=date('d-m-Y', strtotime($order['payment_date']));
    				
    		$data[]= array(
                'payment_date'  =>  $order['payment_date'],
                'utr_no' 		=>  $order['utr_no'],
                'payment_made'  =>  $order['payment_made']            
                );
    		}
    		
    		$resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $count,
            );
    	}else{
    		$resultpost = array(
                'status' => 400,
                'message' => 'No Entry Found',
                'total_data' => $count,
            );
    	}
    	return $resultpost;		
	}
	
	public function received_payments_details($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $utr_filter="";
        $vendor_id = $user_id;
             
        if(isset($filter['keywords']) && $filter['keywords']!="") :
          $keywords=$filter['keywords'];
          $keywords_filter =" AND (orders.vendor_id LIKE '%$keywords%')"; 
        endif;	
        
        if(isset($filter['utr']) && $filter['utr']!="") :
          $utr=$filter['utr'];
          $utr_filter =" AND (vendor_payments.utr_no= '$utr')"; 
        endif;	
                
    	$orders = $this->db->query("SELECT orders.is_adj_settled,GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable
	    FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id 	WHERE orders.payment_status = 'payment_received' AND vendor_payments.utr_no IS NOT NULL  $utr_filter GROUP BY orders.id  ORDER BY orders.id desc LIMIT $offset,$per_page");
       
	    $count = $this->db->query("SELECT orders.id FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id
		WHERE orders.payment_status = 'payment_received' AND vendor_payments.utr_no IS NOT NULL  $utr_filter GROUP BY orders.id  ORDER BY orders.id desc")->num_rows();
	   // echo $this->db->last_query();
	   // exit();
		$orders_count = $orders->num_rows();
		if($orders_count > 0){
		$data = array();    
		foreach ($orders->result_array() as $order) { 
				$total_price_excl = 0;
			$price_total_wsh = 0;
		    $net_amount = 0;
		 	$order_id    = $order['id'];
		    $total_price_excl = $order['total_price_excl'];	
		
			$order_vpay = $this->db->query("SELECT GROUP_CONCAT(paid_amount ORDER BY id ASC) as payment_made,GROUP_CONCAT(payment_date ORDER BY id ASC) as payment_date,GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per,GROUP_CONCAT(utr_no ORDER BY id ASC) as utr_no, GROUP_CONCAT(advise_no ORDER BY id ASC) as advise_no, GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per FROM `vendor_payments` WHERE `order_id`='$order_id' GROUP BY order_id order by id asc");
			$vpay=$order_vpay->row_array();			
				$vendor          = $order['company_name'];
				$order_number    = $order['order_number'];
				$invoice_no    	 = $order['invoice_no'];
				$price_subtotal  = $order['price_subtotal'];
				$price_shipping  = $order['price_shipping'];
				$price_discount  = $order['price_discount'];
				$price_total     = $order['price_total']-$price_shipping;
				$created_at    	 = $order['created_at'];
				$processing_date = $order['processing_date'];
				$shipping_date   = $order['shipping_date'];
				$delivered_date  = $order['delivered_date'];			
				$dispatched_date  = $order['dispatched_date'];
				$price_total_wsh=$price_total;					
				$tds = $order['tds'];
				$tcs = $order['tcs'];				
				$commision_amount_final=$order['commision_amt'];				
				$net_amount=$order['net_payable'];				
				$order_date= date('d-m-Y H:i', strtotime($created_at));
				$order_date_ago=days_left($order_date);
				
				if($dispatched_date!=''){
				$dispatched_date= date('d-m-Y H:i', strtotime($dispatched_date));
				$dispatched_date_ago=days_left($dispatched_date);
				}
				else{
				   $dispatched_date=$dispatched_date_ago='-';
				}
								
				if($delivered_date!=''){
				$delivered_date= date('d-m-Y H:i', strtotime($delivered_date));
				$delivered_date_ago=days_left($delivered_date);
				}
				else{
				   $delivered_date=$delivered_date_ago='-';
				}
				
			$paid_amount=0;
			
			$pamount_query=$this->get_paid_amount_by_order($order_id);	
			if($pamount_query->num_rows()>0):
			$gpaid=$pamount_query->row();
			$paid_amount=$gpaid->paid_amount;
			endif;	
// 			$balance_amt = 0;
			if($order['is_adj_settled']=='1'){
		     	$final_net_amt=0;
			} 
		   else{
	     	    $final_net_amt = price_format_decimal($net_amount - $paid_amount);
		   }
			$balance_amt=($final_net_amt<0 ? '0.00':$final_net_amt);
				
			$data[]= array(
                'order_id' => $order_id,
                'vendor' => $vendor,
                'order_number' => $order_number,
                'invoice_no' => $invoice_no,
                'invoice_amt' => price_format_decimal($price_total),
                'tds' => price_format_decimal($tds),
                'tcs' => price_format_decimal($tcs),
                'commision_amount' => price_format_decimal($commision_amount_final),
                'price_shipping' => price_format_decimal($price_shipping),
                'net_amount' => price_format_decimal($net_amount),
                'order_date' => $order_date,
                'order_date_ago' => $order_date_ago,
                'dispatched_date' => $dispatched_date,
                'dispatched_date_ago' => $dispatched_date_ago,
                'delivered_date' => $delivered_date,
                'delivered_date_ago' => $delivered_date_ago,
                'utr_no' =>  $vpay['utr_no'],
                'payment_made' =>  $vpay['payment_made'],
                'payment_date' =>  $vpay['payment_date'],
                'payment_per' =>    $vpay['payment_per'],
                'paid_amount' => $paid_amount,
                'net_amount_final' =>  $order['net_amount'],
                'advise_no' =>  $vpay['advise_no'],
                'vendor_id' =>  $order['vendor_id'],
                'is_adj_settled' =>  $order['is_adj_settled'],
                'balance_amt' =>  $balance_amt,
            );
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $count,
            );
		}
		}else{
    		$resultpost = array(
                'status' => 400,
                'message' => 'No Entry Found',
                'total_data' => $count,
            );
    	}
    	return $resultpost;		
	}
	
	public function pending_payments($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $date_filter="";
        $vendor_id = $user_id;
             
        if(isset($filter['keywords']) && $filter['keywords']!="") :
          $keywords=$filter['keywords'];
          $keywords_filter =" AND (orders.vendor_id LIKE '%$keywords%')"; 
        endif;
        
     if(isset($filter['start_end_date']) && $filter['start_end_date']!="") :
       $start_end_date = $filter['start_end_date']; 
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(orders.created_at) BETWEEN '$from' AND '$to')";
      endif; 
                
    	$orders = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable  FROM orders  LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id WHERE (orders.vendor_id= '$vendor_id') AND orders.payment_status = 'payment_received' AND orders.is_settled=0  $keywords_filter $date_filter GROUP BY orders.id ORDER BY orders.id desc LIMIT $offset,$per_page");
    
    	$count = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount,orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable
	    FROM orders  LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id WHERE (orders.vendor_id= '$vendor_id') AND orders.payment_status = 'payment_received' AND orders.is_settled=0  $keywords_filter $date_filter GROUP BY orders.id ORDER BY orders.id desc")->num_rows();
    	
    	$orders_count = $orders->num_rows();
    	$data = array();
    	if($orders_count > 0){
    	foreach ($orders->result_array() as $order) { 
    		$total_price_excl = 0;
			$price_total_wsh = 0;
		    $net_amount = 0;
		 	$order_id    = $order['id'];
		    $total_price_excl = $order['total_price_excl'];	
		
			$order_vpay = $this->db->query("SELECT GROUP_CONCAT(paid_amount ORDER BY id ASC) as payment_made,GROUP_CONCAT(payment_date ORDER BY id ASC) as payment_date,GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per,GROUP_CONCAT(utr_no ORDER BY id ASC) as utr_no, GROUP_CONCAT(advise_no ORDER BY id ASC) as advise_no, GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per FROM `vendor_payments` WHERE `order_id`='$order_id' GROUP BY order_id order by id asc");
			$vpay=$order_vpay->row_array();			
				$vendor          = $order['company_name'];
				$order_number    = $order['order_number'];
				$invoice_no    	 = $order['invoice_no'];
				$price_subtotal  = $order['price_subtotal'];
				$price_shipping  = $order['price_shipping'];
				$price_discount  = $order['price_discount'];
				$price_total     = $order['price_total']-$price_shipping;
				$created_at    	 = $order['created_at'];
				$processing_date = $order['processing_date'];
				$shipping_date   = $order['shipping_date'];
				$delivered_date  = $order['delivered_date'];			
				$dispatched_date  = $order['dispatched_date'];
				$price_total_wsh=$price_total;					
				$tds = $order['tds'];
				$tcs = $order['tcs'];				
				$commision_amount_final=$order['commision_amt'];				
				$net_amount=$order['net_payable'];				
				$order_date= date('d-m-Y H:i', strtotime($created_at));
				$order_date_ago=days_left($order_date);
				
				if($dispatched_date!='' || $dispatched_date != null){
				$dispatched_date= date('d-m-Y H:i', strtotime($dispatched_date));
				$dispatched_date_ago=days_left($dispatched_date);
				}
				else{
				   $dispatched_date=$dispatched_date_ago='-';
				}
				
				
				if($delivered_date!='' || $delivered_date != null){
				$delivered_date= date('d-m-Y H:i', strtotime($delivered_date));
				$delivered_date_ago=days_left($delivered_date);
				}
				else{
				   $delivered_date=$delivered_date_ago='-';
				}
				
			$paid_amount=0;
			
			$pamount_query=$this->get_paid_amount_by_order($order_id);	
			if($pamount_query->num_rows()>0):
			$gpaid=$pamount_query->row();
			$paid_amount=$gpaid->paid_amount;
			endif;					
			
			if($vpay['utr_no'] !='' || $vpay['utr_no'] != null)
			{ 
			    $utr_no = $vpay['utr_no']; 
			}else{
			    $utr_no = '-';
			}
			if($vpay['payment_made'] !='' || $vpay['payment_made'] != null)
			{ 
			    $payment_made = $vpay['payment_made']; 
			}else{
			    $payment_made = '-';
			}
			if($vpay['payment_date'] !='' || $vpay['payment_date'] != null)
			{ 
			    $payment_date = $vpay['payment_date']; 
			}else{
			    $payment_date = '-';
			}
			if($vpay['payment_per'] !='' || $vpay['payment_per'] != null)
			{ 
			    $payment_per = $vpay['payment_per']; 
			}else{
			    $payment_per = '-';
			}
			if($vpay['advise_no'] !='' || $vpay['advise_no'] != null)
			{ 
			    $advise_no = $vpay['advise_no']; 
			}else{
			    $advise_no = '-';
			}
			
			
	     	$final_net_amt = price_format_decimal($net_amount - $paid_amount);
			$balance_amt=($final_net_amt<0 ? '0.00':$final_net_amt);
				
			$data[]= array(
                'order_id' => $order_id,
                'vendor' => $vendor,
                'order_number' => $order_number,
                'invoice_no' => $invoice_no,
                'invoice_amt' => price_format_decimal($price_total),
                'tds' => price_format_decimal($tds),
                'tcs' => price_format_decimal($tcs),
                'commision_amount' => price_format_decimal($commision_amount_final),
                'price_shipping' => price_format_decimal($price_shipping),
                'net_amount' => price_format_decimal($net_amount),
                'order_date' => $order_date,
                'order_date_ago' => $order_date_ago,
                'dispatched_date' => $dispatched_date,
                'dispatched_date_ago' => $dispatched_date_ago,
                'delivered_date' => $delivered_date,
                'delivered_date_ago' => $delivered_date_ago,
                'utr_no' =>  $utr_no,
                'payment_made' =>  $payment_made,
                'payment_date' =>  $payment_date,
                'payment_per' =>  $payment_per,
                'paid_amount' => $paid_amount,
                'net_amount_final' =>  $order['net_amount'],
                'advise_no' =>  $advise_no,
                'vendor_id' =>  $order['vendor_id'],
                'balance_amt' => $balance_amt,
            );
    		    
    		}
    		
    		$resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $count,
            );
    	}else{
    		$resultpost = array(
                'status' => 400,
                'message' => 'No Entry Found',
                'total_data' => $count,
            );
    	}
    	return $resultpost;		
	}
	
	
	public function completed_payments($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $date_filter="";
        $vendor_id = $user_id;
             
        if(isset($filter['keywords']) && $filter['keywords']!="") :
          $keywords=$filter['keywords'];
          $keywords_filter =" AND (orders.vendor_id LIKE '%$keywords%')"; 
        endif;
        
        if(isset($filter['start_end_date']) && $filter['start_end_date']!="") :
       $start_end_date = $filter['start_end_date']; 
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(orders.created_at) BETWEEN '$from' AND '$to')";
      endif; 
                
    	$orders = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable 
	    FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id
		WHERE  (orders.vendor_id= '$vendor_id') and orders.payment_status = 'payment_received' AND orders.is_settled=1 $date_filter GROUP BY orders.id ORDER BY orders.id desc LIMIT $offset,$per_page");
    
    	$count = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable 
	    FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id
		WHERE  (orders.vendor_id= '$vendor_id') and orders.payment_status = 'payment_received' AND orders.is_settled=1 $date_filter  GROUP BY orders.id ORDER BY orders.id desc")->num_rows();
    	
    	$orders_count = $orders->num_rows();
    	$data = array();
    	if($orders_count > 0){
    	foreach ($orders->result_array() as $order) { 
    		$total_price_excl = 0;
			$price_total_wsh = 0;
		    $net_amount = 0;
		 	$order_id    = $order['id'];
		    $total_price_excl = $order['total_price_excl'];	
		
			$order_vpay = $this->db->query("SELECT GROUP_CONCAT(paid_amount ORDER BY id ASC) as payment_made,GROUP_CONCAT(payment_date ORDER BY id ASC) as payment_date,GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per,GROUP_CONCAT(utr_no ORDER BY id ASC) as utr_no, GROUP_CONCAT(advise_no ORDER BY id ASC) as advise_no, GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per FROM `vendor_payments` WHERE `order_id`='$order_id' GROUP BY order_id order by id asc");
			$vpay=$order_vpay->row_array();			
				$vendor          = $order['company_name'];
				$order_number    = $order['order_number'];
				$invoice_no    	 = $order['invoice_no'];
				$price_subtotal  = $order['price_subtotal'];
				$price_shipping  = $order['price_shipping'];
				$price_discount  = $order['price_discount'];
				$price_total     = $order['price_total']-$price_shipping;
				$created_at    	 = $order['created_at'];
				$processing_date = $order['processing_date'];
				$shipping_date   = $order['shipping_date'];
				$delivered_date  = $order['delivered_date'];			
				$dispatched_date  = $order['dispatched_date'];
				$price_total_wsh=$price_total;					
				$tds = $order['tds'];
				$tcs = $order['tcs'];				
				$commision_amount_final=$order['commision_amt'];				
				$net_amount=$order['net_payable'];				
				$order_date= date('d-m-Y H:i', strtotime($created_at));
				$order_date_ago=days_left($order_date);
				
				if($dispatched_date!=''){
				$dispatched_date= date('d-m-Y H:i', strtotime($dispatched_date));
				$dispatched_date_ago=days_left($dispatched_date);
				}
				else{
				   $dispatched_date=$dispatched_date_ago='-';
				}
				
				
				if($delivered_date!=''){
				$delivered_date= date('d-m-Y H:i', strtotime($delivered_date));
				$delivered_date_ago=days_left($delivered_date);
				}
				else{
				   $delivered_date=$delivered_date_ago='-';
				}
				
			$paid_amount=0;
			
			$pamount_query=$this->get_paid_amount_by_order($order_id);	
			if($pamount_query->num_rows()>0):
			$gpaid=$pamount_query->row();
			$paid_amount=$gpaid->paid_amount;
			endif;						
			
			if($vpay['utr_no'] !='' || $vpay['utr_no'] != null)
			{ 
			    $utr_no = $vpay['utr_no']; 
			}else{
			    $utr_no = '-';
			}
			if($vpay['payment_made'] !='' || $vpay['payment_made'] != null)
			{ 
			    $payment_made = $vpay['payment_made']; 
			}else{
			    $payment_made = '-';
			}
			if($vpay['payment_date'] !='' || $vpay['payment_date'] != null)
			{ 
			    $payment_date = $vpay['payment_date']; 
			}else{
			    $payment_date = '-';
			}
			if($vpay['payment_per'] !='' || $vpay['payment_per'] != null)
			{ 
			    $payment_per = $vpay['payment_per']; 
			}else{
			    $payment_per = '-';
			}
			if($vpay['advise_no'] !='' || $vpay['advise_no'] != null)
			{ 
			    $advise_no = $vpay['advise_no']; 
			}else{
			    $advise_no = '-';
			}
			
			
	     	$final_net_amt = price_format_decimal($net_amount - $paid_amount);
			$balance_amt=($final_net_amt<0 ? '0.00':$final_net_amt);
				
			$data[]= array(
                'order_id' => $order_id,
                'vendor' => $vendor,
                'order_number' => $order_number,
                'invoice_no' => $invoice_no,
                'invoice_amt' => price_format_decimal($price_total),
                'tds' => price_format_decimal($tds),
                'tcs' => price_format_decimal($tcs),
                'commision_amount' => price_format_decimal($commision_amount_final),
                'price_shipping' => price_format_decimal($price_shipping),
                'net_amount' => price_format_decimal($net_amount),
                'order_date' => $order_date,
                'order_date_ago' => $order_date_ago,
                'dispatched_date' => $dispatched_date,
                'dispatched_date_ago' => $dispatched_date_ago,
                'delivered_date' => $delivered_date,
                'delivered_date_ago' => $delivered_date_ago,
                'utr_no' =>  $vpay['utr_no'],
                'payment_made' =>  $vpay['payment_made'],
                'payment_date' =>  $vpay['payment_date'],
                'payment_per' =>  $vpay['payment_per'],
                'paid_amount' => $paid_amount,
                'net_amount_final' =>  $order['net_amount'],
                'advise_no' =>  $vpay['advise_no'],
                'vendor_id' =>  $order['vendor_id'],
                'balance_amt' =>  $balance_amt,
            );
    		    
    		}
    		
    		$resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $count,
            );
    	}else{
    		$resultpost = array(
                'status' => 400,
                'message' => 'No Entry Found',
                'total_data' => $count,
            );
    	}
    	return $resultpost;		
	}
	
	public function kirtibook_invoice($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $vendor_id = $user_id;
             
        if(isset($filter['keywords']) && $filter['keywords']!="") :
          $keywords=$filter['keywords'];
          $keywords_filter =" AND (orders.vendor_id LIKE '%$keywords%')"; 
        endif;	
                
    	$orders = $this->db->query("SELECT COUNT(id) as total_order,vendor_invoice,vendor_invoice_date,vendor_id
	  FROM orders WHERE payment_status = 'payment_received' AND order_status = 'delivered' AND  orders.vendor_invoice IS NOT NULL AND vendor_id='$vendor_id'  GROUP BY vendor_invoice ORDER BY orders.id desc LIMIT $offset,$per_page");
    
    	$count = $this->db->query("SELECT COUNT(id) as total_order,vendor_invoice,vendor_invoice_date,vendor_id
	  FROM orders WHERE payment_status = 'payment_received' AND order_status = 'delivered' AND  orders.vendor_invoice IS NOT NULL AND vendor_id='$vendor_id'  GROUP BY vendor_invoice ORDER BY orders.id desc")->num_rows();
    	
    	$orders_count = $orders->num_rows();
    	$data = array();
    	if($orders_count > 0){
    	foreach ($orders->result_array() as $order) { 
    		$vendor_invoice_date=date('d-m-Y', strtotime($order['vendor_invoice_date']));
    				
    		$data[]= array(
                'vendor_invoice_date'  =>  $order['vendor_invoice_date'],
                'vendor_invoice' 		=>  $order['vendor_invoice'],
                'total_order'  =>  $order['total_order']            
                );
    		}
    		
    		$resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $count,
            );
    	}else{
    		$resultpost = array(
                'status' => 400,
                'message' => 'No Entry Found',
                'total_data' => $count,
            );
    	}
    	return $resultpost;		
	}
	
	public function kirtibook_invoice_details($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $vendor_filter="";
        $utr_filter="";
        $vendor_id = $user_id;
        $invoice_no =$filter['invoice_no'];
        
        $vendor_filter =" AND (orders.vendor_id= '$vendor_id')"; 
     
             
        if(isset($filter['keywords']) && $filter['keywords']!="") :
          $keywords=$filter['keywords'];
          $keywords_filter =" AND (orders.vendor_id LIKE '%$keywords%')"; 
        endif;	
        
        
                
    	$orders = $this->db->query("SELECT orders.is_adj_settled,GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable 
	  FROM orders  LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id
	  WHERE orders.payment_status = 'payment_received' AND orders.order_status = 'delivered' AND orders.vendor_invoice IS NOT NULL AND orders.vendor_invoice='$invoice_no' $vendor_filter  GROUP BY orders.id ORDER BY orders.id desc LIMIT $offset,$per_page");
       
	    $count = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable 
	  FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id
	  WHERE orders.payment_status = 'payment_received' AND orders.order_status = 'delivered' AND orders.vendor_invoice IS NOT NULL AND orders.vendor_invoice='$invoice_no' $vendor_filter  GROUP BY orders.id ORDER BY orders.id desc")->num_rows();
	   // echo $this->db->last_query();
	   // exit();
		$orders_count = $orders->num_rows();
		if($orders_count > 0){
		$data = array();    
		foreach ($orders->result_array() as $order) { 
		    
		    $total_price_excl = 0;
			$price_total_wsh = 0;
		    $net_amount = 0;
		 	$order_id    = $order['id'];
		    $total_price_excl = $order['total_price_excl'];	
		
			$order_vpay = $this->db->query("SELECT GROUP_CONCAT(paid_amount ORDER BY id ASC) as payment_made,GROUP_CONCAT(payment_date ORDER BY id ASC) as payment_date,GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per,GROUP_CONCAT(utr_no ORDER BY id ASC) as utr_no, GROUP_CONCAT(advise_no ORDER BY id ASC) as advise_no, GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per FROM `vendor_payments` WHERE `order_id`='$order_id' GROUP BY order_id order by id asc");
			$vpay=$order_vpay->row_array();			
				$vendor          = $order['company_name'];
				$order_number    = $order['order_number'];
				$invoice_no    	 = $order['invoice_no'];
				$price_subtotal  = $order['price_subtotal'];
				$price_shipping  = $order['price_shipping'];
				$price_discount  = $order['price_discount'];
				$price_total     = $order['price_total']-$price_shipping;
				$created_at    	 = $order['created_at'];
				$processing_date = $order['processing_date'];
				$shipping_date   = $order['shipping_date'];
				$delivered_date  = $order['delivered_date'];			
				$dispatched_date  = $order['dispatched_date'];
				$price_total_wsh=$price_total;					
				$tds = $order['tds'];
				$tcs = $order['tcs'];				
				$commision_amount_final=$order['commision_amt'];				
				$net_amount=$order['net_payable'];				
				$order_date= date('d-m-Y H:i', strtotime($created_at));
				$order_date_ago=days_left($order_date);
				
				if($dispatched_date!=''){
				$dispatched_date= date('d-m-Y H:i', strtotime($dispatched_date));
				$dispatched_date_ago=days_left($dispatched_date);
				}
				else{
				   $dispatched_date=$dispatched_date_ago='-';
				}
				
				
				if($delivered_date!=''){
				$delivered_date= date('d-m-Y H:i', strtotime($delivered_date));
				$delivered_date_ago=days_left($delivered_date);
				}
				else{
				   $delivered_date=$delivered_date_ago='-';
				}
				
			$paid_amount=0;
			
			$pamount_query=$this->get_paid_amount_by_order($order_id);	
			if($pamount_query->num_rows()>0):
			$gpaid=$pamount_query->row();
			$paid_amount=$gpaid->paid_amount;
			endif;	
		    
		    
			if($order['is_adj_settled']=='1'){
		     	$final_net_amt=0;
			} 
		   else{
	     	    $final_net_amt = price_format_decimal($net_amount - $paid_amount);
		   }
			$balance_amt=($final_net_amt<0 ? '0.00':$final_net_amt);
				
			$data[]= array(
                'order_id' => $order_id,
                'vendor' => $vendor,
                'order_number' => $order_number,
                'invoice_no' => $invoice_no,
                'invoice_amt' => price_format_decimal($price_total),
                'tds' => price_format_decimal($tds),
                'tcs' => price_format_decimal($tcs),
                'commision_amount' => price_format_decimal($commision_amount_final),
                'price_shipping' => price_format_decimal($price_shipping),
                'net_amount' => price_format_decimal($net_amount),
                'order_date' => $order_date,
                'order_date_ago' => $order_date_ago,
                'dispatched_date' => $dispatched_date,
                'dispatched_date_ago' => $dispatched_date_ago,
                'delivered_date' => $delivered_date,
                'delivered_date_ago' => $delivered_date_ago,
                'utr_no' =>  $vpay['utr_no'],
                'payment_made' =>  $vpay['payment_made'],
                'payment_date' =>  $vpay['payment_date'],
                'payment_per' =>  $vpay['payment_per'],
                'paid_amount' => $paid_amount,
                'net_amount_final' =>  $order['net_amount'],
                'advise_no' =>  $vpay['advise_no'],
                'vendor_id' =>  $order['vendor_id'],
                'balance_amt' =>  $balance_amt,
            );
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $count,
            );
		}
		}else{
    		$resultpost = array(
                'status' => 400,
                'message' => 'No Entry Found',
                'total_data' => $count,
            );
    	}
    	return $resultpost;		
	}
	
	
	
	public function get_invoice_report($start_end_date,$keyword,$vendor_id){
     $date_filter="";
     $order_filter="";
     
   if($start_end_date!=""):
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(orders.created_at) BETWEEN '$from' AND '$to')";
    endif;   
    
    if ($keyword!= '') {
            $order_filter =" AND (order_number like '%".$keyword."%'  
              or invoice_no like '%".$keyword."%')"; 
        }
	    
	$orders = $this->db->query("SELECT orders.id,orders.is_invoice,orders.invoice_url FROM orders 		
		WHERE (orders.vendor_id = '$vendor_id')
    	AND (orders.payment_status='payment_received')
    	AND (orders.order_status!='cancelled')
    	 $date_filter $order_filter ORDER BY id asc");    
    	 
        return $orders->result(); 		
	}
	
	
  public function accounts_statistics($vendor_id,$filter){  
   $data= array();
   $total_order=0;
   $order_amount=0;
   $price_total=0;
   $amount_received=0;	
   $balance_receivable=0;	
   $tds=0;	//total amount's 1%	
   $tcs=0;	//excluding gst and shippping charges total's 1%		
   $govt_tax=0;	//excluding gst and shippping charges total's 1%	
   
     $academic_year_filter =$academic_year_filter2= '';  
    
    if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
        $academic_year = explode(" - ",$filter['academic_year']);
        $from           = date('Y-m-d', strtotime($academic_year[0]));
        $to             = date('Y-m-d', strtotime($academic_year[1]));
        //$academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        //$academic_year_filter2   = " AND (DATE(orders.created_at) BETWEEN '$from' AND '$to')";
    endif;
   
	//orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable 
	$total_order = $this->db->query("SELECT id FROM `orders` WHERE payment_status='payment_received' AND order_status!='cancelled' AND vendor_id='$vendor_id' $academic_year_filter")->num_rows();

    $order_query = $this->db->query("SELECT SUM(`price_total`) AS price_total,SUM(price_shipping) AS price_shipping ,SUM(tds) AS tds ,SUM(tcs) AS tcs ,SUM(commision_amt) AS commision_amt ,SUM(net_payable) AS net_payable FROM `orders` WHERE payment_status='payment_received' AND order_status!='cancelled' AND vendor_id='$vendor_id' $academic_year_filter");
    $row=$order_query->row();		 
	 
    $orders = $this->db->query("SELECT SUM(vendor_payments.paid_amount) as paid_amount
	FROM orders INNER JOIN vendor_payments ON orders.id=vendor_payments.order_id
	WHERE orders.payment_status = 'payment_received' AND vendor_payments.utr_no IS NOT NULL AND (orders.vendor_id='$vendor_id') $academic_year_filter2 GROUP BY vendor_payments.vendor_id");
	$order=$orders->row_array();	

    $order_amount=($row->price_total)-($row->price_shipping);	 
	$govt_tax =$row->tds + $row->tcs + $row->commision_amt;	
	$amount_received =$order['paid_amount']+$govt_tax;	
	$balance_receivable=$order_amount-$amount_received;
		
	$data= array(
		'total_order' => (int)$total_order,
		'order_amount' => price_format_decimal($order_amount),
		'govt_tax' => price_format_decimal($govt_tax),
		'amount_received' => price_format_decimal($amount_received),
		'balance_receivable' => price_format_decimal($balance_receivable),
	);
	
	$resultpost = array(
        'status' => 200,
        'message' => 'success',
        'data' => $data,
    );
	return $resultpost;		
	}
	
	public function get_accounts_school_by_vendor($user_id,$per_page,$offset,$filter){
        $keywords_filter="";
        $vendor_id = $user_id;
        $academic_year_filter = '';  
        
        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
        
        $vendor_filter =" AND (orders.vendor_id= '$vendor_id')"; 
                
    	$orders = $this->db->query("SELECT school_id,school_name,order_type  FROM orders WHERE payment_status = 'payment_received' AND order_status != 'cancelled'  AND (vendor_id='$vendor_id') $academic_year_filter GROUP BY school_id ORDER BY school_id desc LIMIT $offset,$per_page");
       
	    $count = $this->db->query("SELECT school_id,school_name,order_type  FROM orders WHERE payment_status = 'payment_received' AND order_status != 'cancelled' AND (vendor_id='$vendor_id') $academic_year_filter GROUP BY school_id ORDER BY school_id desc")->num_rows();
		
	   // echo $this->db->last_query();
	   // exit();
		$orders_count = $orders->num_rows();
		$data = array();  
		if($orders_count > 0){	  
		 foreach ($orders->result_array() as $item) {  
		       $school_id=$item['school_id'];
		       $school_name=$item['school_name'];	
		       $order_type=$item['order_type'];	
		       if($order_type=='individual'){
		          $school_name='Individual Products';
		          $school_filter= " AND (order_type='individual')";
		          $school_join_filter= " AND (orders.order_type='individual')";
		       }
		       else{
		          $school_filter= " AND (school_id='$school_id')";
		          $school_join_filter= " AND (orders.school_id='$school_id')";
		       }
			   
			   $total_order=0;
			   $order_amount=0;
			   $price_total=0;
			   $amount_received=0;	
			   $balance_receivable=0;	
			   $tds=0;	//total amount's 1%	
			   $tcs=0;	//excluding gst and shippping charges total's 1%		
			   $govt_tax=0;	//excluding gst and shippping charges total's 1%	
			   //orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable 
			   			   
			    $total_order = $this->db->query("SELECT id FROM `orders` WHERE payment_status='payment_received' AND order_status!='cancelled' AND vendor_id='$vendor_id' $school_filter $academic_year_filter")->num_rows();
			
			    $order_query = $this->db->query("SELECT SUM(`price_total`) AS price_total,SUM(price_shipping) AS price_shipping ,SUM(tds) AS tds ,SUM(tcs) AS tcs ,SUM(commision_amt) AS commision_amt ,SUM(net_payable) AS net_payable FROM `orders` WHERE payment_status='payment_received' AND order_status!='cancelled' AND vendor_id='$vendor_id' $school_filter $academic_year_filter");
				$row=$order_query->row();		 
				 
				$orders = $this->db->query("SELECT SUM(vendor_payments.paid_amount) as paid_amount
				FROM orders INNER JOIN vendor_payments ON orders.id=vendor_payments.order_id
				WHERE orders.payment_status = 'payment_received' AND vendor_payments.utr_no IS NOT NULL AND (orders.vendor_id='$vendor_id')  $school_join_filter $academic_year_filter  GROUP BY vendor_payments.vendor_id");
				$order=$orders->row_array();	

				$order_amount=($row->price_total)-($row->price_shipping);	 
				$govt_tax =$row->tds + $row->tcs + $row->commision_amt;	
				$amount_received =$order['paid_amount']+$govt_tax;	
				$balance_receivable=$order_amount-$amount_received;


                $link='/orders/individual';
                
                if($school_id>0){
                    $link='/orders/school/'.$school_id;
                }
				$data[]= array(
					'school_id' => $school_id,
					'school_name' => $school_name,
					'link' => $link,
					'total_order' => (int)$total_order,
					'order_amount' => price_format_decimal($order_amount),
					'govt_tax' => price_format_decimal($govt_tax),
					'amount_received' => price_format_decimal($amount_received),
					'balance_receivable' => price_format_decimal($balance_receivable),
				);
	
		   }
		}

    	
    	 $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
           'total_data' => $count,
        );
    	return $resultpost;		
	}	
	
	
	
}