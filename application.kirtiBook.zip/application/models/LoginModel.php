<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model
{

    var $client_service = "frontend-client";
    var $auth_key = "kirtibookapi";


    public function check_auth_client()
    {
        // $client_service = $this->input->get_request_header('Client-Service', TRUE);
        // $auth_key       = $this->input->get_request_header('Auth-Key', TRUE);

        // if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
        //     return true;
        // } else {
        //     return json_output(401, array(
        //         'status' => 401,
        //         'message' => 'Unauthorized.'
        //     ));
        // }
        return true;
    }

	public function update_isbn()
    {
		$query = $this->db->query("SELECT id,isbn FROM `product_master` where id>'3899'  order by id desc");
        foreach ($query->result_array() as $row) {
			$id = $row['id'];
			$isbn = $row['isbn'];
			$arr = explode("_", $isbn, 2);
			$isbn = $arr[0];

			$this->db->where('id', $id)->update('product_master', array(
				'is_check' => 1,
				'isbn' => $isbn
			));
		}
	}

    public function import_table()
    {
        $query = $this->db->query("SELECT * FROM `import_table` where is_check='0' order by id desc limit 400");
        foreach ($query->result_array() as $row) {
			$import_id = $row['id'];
            $type = $row['type'];
            $title = $row['title'];
            $product_description = $row['product_description'];
            $isbn = $row['isbn'];
            $model_number = $row['model_number'];
            $publisher = $row['publisher'];
            $board = $row['board'];
            $grade = $row['grade'];
            $brand = $row['brand'];
            $subject = $row['subject'];
            $no_of_pages = $row['no_of_pages'];
            $size = $row['size'];
            $gst = $row['gst'];
            $hsn = $row['hsn'];
            $length = $row['length'];
            $width = $row['width'];
            $height = $row['height'];
            $weight = $row['weight'];
            $age_grade = $row['age_grade'];
            $from_age = $row['from_age'];
            $to_age = $row['to_age'];
            $binding_type = $row['binding_type'];
            $color = $row['color'];
            $min_quantity = $row['min_quantity'];
            $base_price = $row['base_price'];
            $discount_price = $row['discount_price'];
            $day_exchange = $row['day_exchange'];
            $is_bookset = $row['is_bookset'];
            $is_individual = $row['is_individual'];
            $status = $row['status'];
            $stock = $row['stock'];

            $parent_cid=6;
            if($type!=''){
                $get_info = $this->db->query("SELECT id,parent_id FROM categories WHERE name='$type' and parent_id='$parent_cid' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$type=$get_info_r['id'];
				}
				else{
					$cdata['name'] = $type;
					$cdata['parent_id'] = $parent_cid;
					$cdata['slug'] = str_slug($type);
					$this->db->insert('categories', $cdata);
					$type = $this->db->insert_id();
				}
            }

            if($publisher!=''){
                $get_info = $this->db->query("SELECT id FROM publisher WHERE name='$publisher' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$publisher=$get_info_r['id'];
				}
				else{
					$pdata['name'] = $publisher;
					$this->db->insert('publisher', $pdata);
					$publisher = $this->db->insert_id();
				}
            }

            if($board!=''){
                $get_info = $this->db->query("SELECT id FROM board WHERE name='$board' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$board=$get_info_r['id'];
				}
				else{
					$bdata['name'] = $board;
					$bdata['slug'] = str_slug($board);
					$this->db->insert('board', $bdata);
					$board = $this->db->insert_id();
				}
            }

            if($grade!=''){
                $get_info = $this->db->query("SELECT id FROM grade_list WHERE name='$grade' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$grade=$get_info_r['id'];
				}
				else{
					$gdata['name'] = $grade;
					$this->db->insert('grade_list', $gdata);
					$grade = $this->db->insert_id();
				}
            }

            if($brand!=''){
                $get_info = $this->db->query("SELECT id FROM brand WHERE name='$brand' and category_id='$parent_cid' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$brand=$get_info_r['id'];
				}
				else{
					$brdata['name'] = $brand;
					$brdata['category_id'] = $parent_cid;
					$this->db->insert('brand', $brdata);
					$brand = $this->db->insert_id();
				}
            }

            if($subject!=''){
                $get_info = $this->db->query("SELECT id FROM subject WHERE name='$subject' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$subject=$get_info_r['id'];
				}
				else{
					$sdata['name'] = $subject;
					$this->db->insert('subject', $sdata);
					$subject = $this->db->insert_id();
				}
            }

            if($size!=''){
                $get_info = $this->db->query("SELECT id FROM size WHERE name='$size' limit 1");
                if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$size=$get_info_r['id'];
				}
				else{
					$szdata['category_id'] = $parent_cid;
					$szdata['name'] = $size;
					$this->db->insert('size', $szdata);
					$size = $this->db->insert_id();
				}
            }

            if($color!=''){
                $get_info = $this->db->query("SELECT id FROM product_color WHERE name='$color' limit 1");
				if($get_info->num_rows()>0){
					$get_info_r = $get_info->row_array();
					$color=$get_info_r['id'];
				}
				else{
					$cldata['category_id'] = $parent_cid;
					$cldata['name'] = $color;
					$this->db->insert('product_color', $cldata);
					$color = $this->db->insert_id();
				}
            }

            if($status=='Active'){
                $status=1;
            }
            else{
                $status=0;
            }

            $mdata['slug'] = str_slug($title);
            $mdata['title'] = $title;
            $mdata['product_description'] = $product_description;
            $mdata['isbn'] = $isbn;
            $mdata['publisher_id'] = $publisher;
            $mdata['board_id'] = $board;
            $mdata['grade_id'] = $grade;
            $mdata['brand_id'] = $brand;
            $mdata['subject_id'] = $subject;
            $mdata['no_of_pages'] = $no_of_pages;
            $mdata['size'] = $size;
            $mdata['gst'] = $gst;
            $mdata['hsn'] = $hsn;
            $mdata['lenght'] = $length;
            $mdata['width'] = $width;
            $mdata['height'] = $height;
            $mdata['weight'] = $weight;
            $mdata['age_grade'] = $age_grade;
            $mdata['from_age'] = $from_age;
            $mdata['to_age'] = $to_age;
            $mdata['binding_type'] = $binding_type;
            $mdata['color'] = $color;
            $mdata['status'] = $status;
            $mdata['user_id'] = 47;
            $mdata['meta_title'] = $title;
            $mdata['parent_cid'] = $parent_cid;

            $this->db->insert('product_master', $mdata);
            $master_id = $this->db->insert_id();

            if($is_bookset=='No'){
                $is_bookset=0;
            }
            else{
                $is_bookset=1;
            }

            if($is_individual=='No'){
                $is_individual=0;
            }
            else{
                $is_individual=1;
            }

            $data['user_id'] = 47;
            $data['master_id'] = $master_id;
            $data['model_number'] = $model_number;
            $data['min_quantity'] = $min_quantity;
            $data['base_price'] = $base_price;
            $data['discount_price'] = $discount_price;
            $data['day_exchange'] = $day_exchange;
            $data['is_bookset'] = $is_bookset;
            $data['is_individually'] = $is_individual;
            $data['delivery_type'] = 'standard';
            $data['quantity'] = '1';
            $data['visibility'] = '1';
            $data['approve_by'] = '1';
            $data['status'] = $status;
            $data['parent_cid'] = $parent_cid;
            $this->db->insert('products', $data);
            $product_id = $this->db->insert_id();

            $catdata['product_id'] = $master_id;
            $catdata['category_id'] = $type;
            $this->db->insert('products_category', $catdata);

            $wdata['product_id'] = $product_id;
            $wdata['warehouse_id'] = 39;
            $wdata['quantity'] = $stock;
            $this->db->insert('products_warehouse_qty', $wdata);

			$this->db->where('id', $import_id)->update('import_table', array(
				'is_check' => 1
			));
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }

    public function web_token($token,$user_id)
    {
        $this->db->where('id', $user_id)->update('users', array(
            'web_token' => $token
        ));
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }

    public function token_update($token,$user_id,$agent)
    {
        $this->db->where('id', $user_id)->update('users', array(
            'fcm_token' => $token,
            'agent' => $agent
        ));
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }

    public function update_fcm_token($user_id,$fcm_token,$agent)
    {
        $this->db->where('id', $user_id)->update('users', array(
            'fcm_token' => $fcm_token,
            'agent' => $agent
        ));
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }


    public function auth()
    {
        date_default_timezone_set('Asia/Kolkata');
        $users_id = $this->input->get_request_header('User-ID', TRUE);

        $token = $this->input->get_request_header('Authorizations', TRUE);
        $q     = $this->db->select('expired_at')->from('api_users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return json_output(401, array(
                    'status' => 401,
                    'message' => 'Your session has been expired.'
                ));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = '2030-11-12 08:57:58';
                $this->db->where('users_id', $users_id)->where('token', $token)->update('api_users_authentication', array(
                    'expired_at' => $expired_at,
                    'updated_at' => $updated_at
                ));
                return array(
                    'status' => 200,
                    'message' => 'Authorized.'
                );
            }
        }
    }


    //get user by id
    public function get_user($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('users');
        return $query->row();
    }

    //get user by email
    public function get_user_by_email($email)
    {
        $this->db->where('email', $email);
        $where = '(role="vendor" or role = "staff")';
        $this->db->where($where);
        $query = $this->db->get('users');
        return $query->row();
    }

    //get user by mobile
    public function get_user_by_mobile($phone_number)
    {
        $this->db->where('phone_number', $phone_number);
        $where = '(role="vendor" or role = "staff")';
        $this->db->where($where);
        $query = $this->db->get('users');
        return $query->row();
    }

    //check if email is unique
    public function is_unique_email($email, $user_id = 0)
    {
        $user_id = $user_id;
        $user    = $this->get_user_by_email($email);

        //if id doesnt exists
        if ($user_id == 0) {
            if (empty($user)) {
                return true;
            } else {
                return false;
            }
        }

        if ($user_id != 0) {
            if (!empty($user) && $user->id != $user_id) {
                //email taken
                return false;
            } else {
                return true;
            }
        }
    }


    //check if email is unique
    public function is_unique_mobile($phone_number, $user_id = 0)
    {
        $user_id = $user_id;
        $user    = $this->get_user_by_mobile($phone_number);

        //if id doesnt exists
        if ($user_id == 0) {
            if (empty($user)) {
                return true;
            } else {
                return false;
            }
        }

        if ($user_id != 0) {
            if (!empty($user) && $user->id != $user_id) {
                //email taken
                return false;
            } else {
                return true;
            }
        }
    }


    public function login($email, $password)
    {

        $this->load->library('bcrypt');
        $user  = $this->get_user_by_email($email);
        $user2 = $this->get_user_by_mobile($email);

        if (!empty($user) || !empty($user2)) {

            if (!empty($user2)) {
                $user = $user2;
            }

            //check password
            if ($this->bcrypt->check_password($password, $user->password)==false) {
                $this->session->set_flashdata('error', trans("login_error"));
                $data       = array();
                $resultpost = array(
                    'status' => 400,
                    'message' => 'Invalid Username or Password',
                    'data' => $data
                );
            }
            else{
                if ($user->banned == 1) {
                    $data       = array();
                    $resultpost = array(
                        'status' => 400,
                        'message' => 'Account is temporarily In Active',
                        'data' => $data
                    );
                }
                else{
                    if($user->role == 'staff'){
                        $user_id = $user->vendor_id ;
                        $staff_id = $user->id ;
                        $vendor  = $this->get_user($user->vendor_id);
                        $firm_name = $vendor->firm_name;
                    }else{
                        $user_id = $user->id ;
                        $staff_id = 0 ;
                        $firm_name = $user->firm_name;
                    }

                    $firm_name = str_replace(' ', '-', $firm_name);
					$firm_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $firm_name);
					$firm_name = str_replace('-', ' ', $firm_name);


                    $data[] = array(
                        "auth_token" => $token,
                        "user_id" => $user_id,
                        "staff_id" => $staff_id,
                        "user_name" => ucfirst($user->username),
                        "email" => $user->email,
                        "phone" => $user->phone_number,
                        "firm_name" => $this->common_model->shorter($firm_name,'20'),
                        "logo" => 'https://api.kirtibook.in/vendor/v1/uploads/logo/' . $user->logo
                    );

                    $resultpost = array(
                        'status' => 200,
                        'message' => 'success',
                        'data' => $data
                    );
                }
            }
        } else {
            $data       = array();
            $resultpost = array(
                'status' => 400,
                'message' => 'Account not exist!',
                'data' => $data
            );
        }

        return $resultpost;
    }

    public function app_login($email, $password,$fcmToken,$agent)
    {

        $this->load->library('bcrypt');
        $user  = $this->get_user_by_email($email);
        $user2 = $this->get_user_by_mobile($email);


        if (!empty($user) || !empty($user2)) {

            if (!empty($user2)) {
                $user = $user2;
            }

            //check password
            if ($this->bcrypt->check_password($password, $user->password)==false) {
                $this->session->set_flashdata('error', trans("login_error"));
                $data       = array();
                $resultpost = array(
                    'status' => 400,
                    'message' => 'Invalid Username or Password',
                    'data' => $data
                );
            }
            else{
                if ($user->banned == 1) {
                    $data       = array();
                    $resultpost = array(
                        'status' => 400,
                        'message' => 'Account is temporarily In Active',
                        'data' => $data
                    );
                }
                else{
                    if($user->role == 'staff'){
                        $user_id = $user->vendor_id ;
                        $staff_id = $user->id ;
                        $vendor  = $this->get_user($user->vendor_id);
                        $firm_name = $vendor->firm_name;
                    }else{
                        $user_id = $user->id ;
                        $staff_id = 0 ;
                        $firm_name = $user->firm_name;
                    }

                    $firm_name = str_replace(' ', '-', $firm_name);
					$firm_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $firm_name);
					$firm_name = str_replace('-', ' ', $firm_name);

					if($user->auth_token == '' || $user->auth_token==null){
					    $token = md5(uniqid(rand(), true));
					}
					else{
					    $token=$user->auth_token;
					}

				    $user_details= array(
                        'auth_token' => $token,
                        'fcm_token' => $fcmToken,
                        'agent' => $agent
                    );
                    $this->db->where('id',$user_id);
                    $this->db->update('users', $user_details);


                    $data[] = array(
                        "auth_token" => $token,
                        "user_id" => $user_id,
                        "staff_id" => $staff_id,
                        "user_name" => ucfirst($user->username),
                        "email" => $user->email,
                        "phone" => $user->phone_number,
                        "firm_name" => $this->common_model->shorter($firm_name,'20'),
                        "logo" => 'https://api.kirtibook.in/vendor/v1/uploads/logo/' . $user->logo
                    );

                    $resultpost = array(
                        'status' => 200,
                        'message' => 'success',
                        'data' => $data
                    );
                }
            }
        } else {
            $data       = array();
            $resultpost = array(
                'status' => 400,
                'message' => 'Account not exist!',
                'data' => $data
            );
        }

        return $resultpost;
    }




    public function token_login($token)
    {
        $query = $this->db->query("SELECT id,vendor_id,firm_name,username,email,banned,phone_number,logo FROM `users` WHERE auth_token='$token' limit 1");
        $count = $query->num_rows();
        if ($count > 0) {
            $user=$query->row();
            if($user->role == 'staff'){
                $user_id = $user->vendor_id ;
                $staff_id = $user->id ;
                $vendor  = $this->get_user($user->vendor_id);
                $firm_name = $vendor->firm_name;
            }else{
                $user_id = $user->id;
                $staff_id = 0 ;
                $firm_name = $user->firm_name;
            }

            $firm_name = str_replace(' ', '-', $firm_name);
			$firm_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $firm_name);
			$firm_name = str_replace('-', ' ', $firm_name);

            $data[] = array(
                "auth_token" => $token,
                "user_id" => $user_id,
                "staff_id" => $staff_id,
                "user_name" => ucfirst($user->username),
                "email" => $user->email,
                "phone" => $user->phone_number,
                "firm_name" => $this->common_model->shorter($firm_name,'20'),
                "logo" => 'https://api.kirtibook.in/vendor/v1/uploads/logo/' . $user->logo
            );

            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data
            );

        } else {
            $data       = array();
            $resultpost = array(
                'status' => 400,
                'message' => 'Account not exist!',
                'data' => $data
            );
        }
        return $resultpost;
    }


    public function register_vendor($name, $email, $phone, $password, $firm_name)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->library('bcrypt');
        $data['username']     = html_escape($name);
        $data['email']        = html_escape($email);
        $data['firm_name']    = html_escape($firm_name);
        $data['phone_number'] = html_escape($phone);
        $data['password']     = $this->bcrypt->hash_password($password);
        $data['user_type']    = "registered";
        $data["slug"]         = $this->auth_model->generate_uniqe_slug($name);
        $data['banned']       = 0;
        $data['created_at']   = date('Y-m-d H:i:s');
        $data['token']        = generate_token();
        $data['email_status'] = 0;
        $otp = $this->auth_model->generatePIN();
        //$otp                  = '1155';
        $data['otp']          = $otp;
        $data['role']         = 'vendor';
        if ($this->db->insert('temp_users', $data)) {
            $last_id      = $this->db->insert_id();
            $message_user = 'Your OTP for Kirtibook.in is '.$otp.' KIRTIZ';
            $this->auth_model->send_sms($message_user, $data['phone_number']);

            $data_[] = array(
                "user_id" => $last_id
            );

            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data_
            );

        } else {
            $data       = array();
            $resultpost = array(
                'status' => 400,
                'message' => 'Error while registration!',
                'data' => $data
            );
        }
        return $resultpost;
    }



    public function register_otp_verify($otp, $ref_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $query = $this->db->get_where('temp_users', array(
            'id' => $ref_id,
            'otp!=' => '0',
            'otp' => $otp
        ));
        $count = $query->num_rows();

        if ($count > 0) {
            $info                 = $query->row_array();
            $data['username']     = $info['username'];
            $data['email']        = $info['email'];
            $data['phone_number'] = $info['phone_number'];
            $data['password']     = $info['password'];
            $data['firm_name']    = $info['firm_name'];
            $data['user_type']    = "registered";
            $data["slug"]         = $this->auth_model->generate_uniqe_slug($data["username"]);
            $data['banned']       = 0;
            $data['created_at']   = date('Y-m-d H:i:s');
            $data['token']        = generate_token();
            $data['email_status'] = 0;
            $data['otp']          = $info['otp'];
            $data['role'] = 'vendor';

            $this->db->insert('users', $data);
            $user_id = $this->db->insert_id();

            //delete in temp
            $this->db->where('id', $ref_id);
            $this->db->delete('temp_users');

            $message_user = 'Thank you for registering with Kirti Book. To activate your account please go to https://vendor.kirtibook.in/settings/update-profile ‘My profile’ and fill in all the details.';
            // $this->auth_model->send_sms($message_user,$data['phone_number']);

            $username=$info['firm_name'];
            $mail_message = '<body style="background-color: #fbf8ee; margin: 0; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;">
<table border="0" cellpadding="0" cellspacing="0" class="nl-container" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #fbf8ee;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-1" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="25%">
<div class="spacer_block" style="height:70px;line-height:5px;font-size:1px;"> </div>
</td>
<td class="column column-2" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="50%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
<div align="center" style="line-height:10px"><img src="https://kirtibook.in/images/mailer/kirtibook8.gif" style="display: block; height: auto; border: 0; width: 300px; max-width: 100%;" width="300"/></div>
</td>
</tr>
</table>
</td>
<td class="column column-3" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="25%">
<div class="spacer_block" style="height:70px;line-height:5px;font-size:1px;"> </div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-2" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="heading_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;text-align:center;">
<h3 style="margin: 0; color: #000000; font-size: 16px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: center; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;">Download App Now!</h3>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-3" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="50%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
<div align="right" style="line-height:10px"><a href="https://play.google.com/store/apps/details?id=com.kirtibook.app" target="_blank"><img src="https://kirtibook.in/images/mailer/google-play.png" style="display: block; height: auto; border: 0; width: 120px; max-width: 100%;" width="120"/></a></div>
</td>
</tr>
</table>
</td>
<td class="column column-2" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="50%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
<div style="line-height:10px"><a href="https://apps.apple.com/ae/app/kirtibook/id1560166551" target="_blank"><img src="https://kirtibook.in/images/mailer/app-store.png" style="display: block; height: auto; border: 0; width: 120px; max-width: 100%;" width="120"/></a></div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-4" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;">
<div align="center" style="line-height:10px"><a href="https://kirtibook.in/" style="outline:none" tabindex="-1" target="_blank"><img class="big" src="https://kirtibook.in/images/mailer/vendor-account-registered-successfully.jpg" style="display: block; height: auto; border: 0; width: 600px; max-width: 100%;" width="600"/></a></div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-5" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 0px; padding-bottom: 25px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="text_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;" width="100%">
<tr>
<td style="padding-bottom:10px;padding-left:25px;padding-right:25px;padding-top:20px;">
<div style="font-family: sans-serif">
<div style="font-size: 12px; mso-line-height-alt: 18px; color: #636363; line-height: 1.5; font-family: Arial, Helvetica Neue, Helvetica, sans-serif;">
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Dear '.$username.', </strong></span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">Welcome to kirtibook.in</span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">Congratulations for successfully registering on India’s 1st fully integrated Edu-commerce platform.</span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">To activate your account please visit ‘My profile’ section on www.kirtibook.in and fill in all the details and ensure that the profile is 100% complete. </span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Note:</strong> Your account will be activated only after ‘My Profile’ information is 100% complete.</span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">Once your account is activated, you will be informed via email / SMS.</span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Thanks & Regards,</strong></span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Team Kirti Book</strong></span></p>
</div>
</div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-6" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f68529; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 10px; padding-bottom: 10px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="heading_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;text-align:center;">
<h2 style="margin: 0; color: #ffffff; font-size: 18px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: center; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;">Connect with us</h2>
</td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" class="divider_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="padding-bottom:20px;padding-top:15px;">
<div align="center">
<table border="0" cellpadding="0" cellspacing="0" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="50%">
<tr>
<td class="divider_inner" style="font-size: 1px; line-height: 1px; border-top: 2px solid #FFFFFF;"><span> </span></td>
</tr>
</table>
</div>
</td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" class="social_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="padding-left:10px;padding-right:10px;text-align:center;">
    <table align="center" border="0" cellpadding="0" cellspacing="0" class="social-table" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="144px">
    <tr>
    <td style="padding:0 2px 0 2px;"><a href="https://www.facebook.com/kirtibook" target="_blank"><img alt="Facebook" height="32" src="https://kirtibook.in/images/mailer/facebook2x.png" style="display: block; height: auto; border: 0;" title="Facebook" width="32"/></a></td>
    <td style="padding:0 2px 0 2px;"><a href="https://twitter.com/kirtibook" target="_blank"><img alt="Twitter" height="32" src="https://kirtibook.in/images/mailer/twitter2x.png" style="display: block; height: auto; border: 0;" title="Twitter" width="32"/></a></td>
    <td style="padding:0 2px 0 2px;"><a href="https://www.instagram.com/kirtibook" target="_blank"><img alt="Instagram" height="32" src="https://kirtibook.in/images/mailer/instagram2x.png" style="display: block; height: auto; border: 0;" title="Instagram" width="32"/></a></td>
    <td style="padding:0 2px 0 2px;"><a href="https://kirtibook.in/" target="_blank"><img alt="Web Site" height="32" src="https://kirtibook.in/images/mailer/website2x.png" style="display: block; height: auto; border: 0;" title="Web Site" width="32"/></a></td>
    </tr>
    </table>
</td>
</tr>
</table>
<table border="0" cellpadding="10" cellspacing="0" class="text_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;" width="100%">
<tr>
<td>
<div style="font-family: serif">
<div style="font-size: 12px; mso-line-height-alt: 14.399999999999999px; color: #ffffff; line-height: 1.2; font-family:  Arial, Helvetica Neue, Helvetica, sans-serif;">
<p style="margin: 0; font-size: 12px; text-align: center;"><span id="f5c76119-6591-4a54-bb42-858e19560972" style="font-size:14px;">@2021 Kirti Book. All Rights Reserved.</span></p>
</div>
</div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-7" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="icons_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="vertical-align: middle; color: #9d9d9d; font-family: inherit; font-size: 15px; padding-bottom: 5px; padding-top: 5px; text-align: center;">
<table cellpadding="0" cellspacing="0" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="vertical-align: middle; text-align: center;">

<table cellpadding="0" cellspacing="0" class="icons-inner" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; display: inline-block; margin-right: -4px; padding-left: 0px; padding-right: 0px;">

<tr>

</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body>';
        $mail_subject = 'Account Registered Successfully';
        $this->auth_model->sent_simple_mail($mail_message,$data['email'],$mail_subject);



            $user_data[] = array(
                "user_id" => $last_id,
                "user_name" => ucfirst($info['username']),
                "email" => $info['email'],
                "phone" => $info['phone_number'],
                "firm_name" => $info['firm_name']
            );

            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $user_data
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Invalid OTP'
            );
        }
        return $resultpost;
    }





    public function register_resend_otp($ref_id)
    {
        $info         = $this->db->get_where('temp_users', array(
            'id' => $ref_id
        ))->row_array();
        $otp          = $info['otp'];
        $mobile       = $info['phone_number'];
        $message_user = 'Use OTP ' . $otp . ' to confirm Vendor.';
        $res          = $this->auth_model->send_sms($message_user, $mobile);
        $resultpost   = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;
    }



    public function module_list($user_id, $school_id, $profile)
    {
        $query       = $this->db->query("SELECT id,module FROM module_list order by id asc");
        $count       = $query->num_rows();
        $module_arr  = array();
        $checked_arr = array();
        foreach ($query->result_array() as $row) {
            $module_id      = $row['id'];
            $module         = $row['module'];
            $no_id          = 0;
            $sub_module_arr = array();
            $sub_query      = $this->db->query("SELECT id,module FROM sub_module_list where module_id='$module_id' order by id asc");
            foreach ($sub_query->result_array() as $sub_row) {
                $sub_module_id = $sub_row['id'];
                $sub_module    = $sub_row['module'];

                $sub_child_module_arr = array();
                $sub_child_query      = $this->db->query("SELECT id,module FROM sub_child_module_list where module_id='$module_id' and sub_module_id='$sub_module_id' order by id asc");
                foreach ($sub_child_query->result_array() as $sub_child_row) {
                    $sub_child_module_id = $sub_child_row['id'];
                    $sub_child_module    = $sub_child_row['module'];

                    $sub_child_last_module_arr = array();
                    $sub_child_last_query      = $this->db->query("SELECT id,module FROM sub_child_last_module_list where module_id='$module_id' and sub_module_id='$sub_module_id' and sub_child_module_id='$sub_child_module_id' order by id asc");
                    foreach ($sub_child_last_query->result_array() as $sub_child_last_row) {
                        $sub_child_last_module_id = $sub_child_last_row['id'];
                        $sub_child_last_module    = $sub_child_last_row['module'];

                        $sub_child_last_value = $module_id . '_' . $sub_module_id . '_' . $sub_child_module_id . '_' . $sub_child_last_module_id;
                        $query_count          = $this->db->query("SELECT id FROM module_access_list WHERE value='$sub_child_last_value' and profile='$profile' and school_id='$school_id' limit 1");
                        if ($query_count->num_rows() > 0) {
                            $checked_arr[] = array(
                                $sub_child_last_value
                            );
                        }
                        $sub_child_last_module_arr[] = array(
                            "value" => $sub_child_last_value,
                            "label" => $sub_child_last_module
                        );
                    }

                    $sub_child_value = $module_id . '_' . $sub_module_id . '_' . $sub_child_module_id . '_' . $no_id;
                    $query_count     = $this->db->query("SELECT id FROM module_access_list WHERE value='$sub_child_value' and profile='$profile' and school_id='$school_id' limit 1");
                    if ($query_count->num_rows() > 0) {
                        $checked_arr[] = array(
                            $sub_child_value
                        );
                    }
                    if (count($sub_child_last_module_arr) > 0) {
                        $sub_child_module_arr[] = array(
                            "value" => $sub_child_value,
                            "label" => $sub_child_module,
                            "children" => $sub_child_last_module_arr
                        );
                    } else {
                        $sub_child_module_arr[] = array(
                            "value" => $sub_child_value,
                            "label" => $sub_child_module
                        );
                    }
                }
                $sub_value   = $module_id . '_' . $sub_module_id . '_' . $no_id . '_' . $no_id;
                $query_count = $this->db->query("SELECT id FROM module_access_list WHERE value='$sub_value' and profile='$profile' and school_id='$school_id' limit 1");
                if ($query_count->num_rows() > 0) {
                    $checked_arr[] = array(
                        $sub_value
                    );
                }
                if (count($sub_child_module_arr) > 0) {
                    $sub_module_arr[] = array(
                        "value" => $sub_value,
                        "label" => $sub_module,
                        "children" => $sub_child_module_arr
                    );
                } else {
                    $sub_module_arr[] = array(
                        "value" => $sub_value,
                        "label" => $sub_module
                    );
                }
            }
            $value       = $module_id . '_' . $no_id . '_' . $no_id . '_' . $no_id;
            $query_count = $this->db->query("SELECT id FROM module_access_list WHERE value='$value' and profile='$profile' and school_id='$school_id' limit 1");
            if ($query_count->num_rows() > 0) {
                $checked_arr[] = array(
                    $value
                );
            }
            if (count($sub_module_arr) > 0) {
                $module_arr[] = array(
                    "value" => $value,
                    "label" => $module,
                    "children" => $sub_module_arr
                );
            } else {
                $module_arr[] = array(
                    "value" => $value,
                    "label" => $module
                );
            }
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'checked' => $checked_arr,
            'data' => $module_arr
        );
        return $resultpost;
    }




    public function validate_admin($token,$type)
    {
        if($type == '1'){
            $token = remove_special_characters($token);
            $this->db->where('token', $token);
            $this->db->where('id', $type);
            $query = $this->db->get('users');
            $user  = $query->row();
            $name = ucfirst($user->username);
            $phone_number = ucfirst($user->phone_number);
            $back_url = 'https://admin2.kirtibook.in/admin/';
        }else{
            $token = remove_special_characters($token);
            $this->db->where('token', $token);
            $this->db->where('id', $type);
            $query = $this->db->get('staff');
            if($query->num_rows()>0){
                $user  = $query->row();
                $name = ucfirst($user->name);
                $phone_number = ucfirst($user->mobile);
            }
            else{
                $name='';
            }

            $back_url = 'https://staffsandbox.kirtibook.in/admin/';
        }
            if($name != ''){
                $data[] = array(
                    "user_id" => $user->id,
                    "user_name" => $name,
                    "email" => $user->email,
                    "phone" => $phone_number,
                    "back_url" => $back_url,
                );

            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data
            );
        } else {
            $data       = array();
            $resultpost = array(
                'status' => 400,
                'message' => 'failure',
                'data' => $data
            );
        }


        return $resultpost;
    }


     public function forgot_password($phone)
    {

		$query = $this->db->query("SELECT id,username,email,phone_number FROM users WHERE (phone_number='$phone') AND role='vendor'");

		if ($query->num_rows() > 0) {
            $info=$query->row_array();
            $user_id=$info['id'];
            $phone_number =$info['phone_number'];
            $username =$info['username'];
            $email =$info['email'];

            $otp = $this->auth_model->generatePIN();
            $data_otp['otp'] = $otp;
            $this->db->where('id', $user_id);
            $update=$this->db->update('users', $data_otp);
			if($update){
                $message_user = 'Your OTP for Kirtibook.in is '.$otp.' KIRTIZ';
                $this->auth_model->send_sms($message_user,$phone_number);


 $mail_message = '<body style="background-color: #fbf8ee; margin: 0; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;">
<table border="0" cellpadding="0" cellspacing="0" class="nl-container" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #fbf8ee;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-1" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="25%">
<div class="spacer_block" style="height:70px;line-height:5px;font-size:1px;"> </div>
</td>
<td class="column column-2" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="50%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
<div align="center" style="line-height:10px"><img src="https://kirtibook.in/images/mailer/kirtibook8.gif" style="display: block; height: auto; border: 0; width: 300px; max-width: 100%;" width="300"/></div>
</td>
</tr>
</table>
</td>
<td class="column column-3" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="25%">
<div class="spacer_block" style="height:70px;line-height:5px;font-size:1px;"> </div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-2" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="heading_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;text-align:center;">
<h3 style="margin: 0; color: #000000; font-size: 16px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: center; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;">Download App Now!</h3>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-3" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="50%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
<div align="right" style="line-height:10px"><a href="https://play.google.com/store/apps/details?id=com.kirtibook.app" target="_blank"><img src="https://kirtibook.in/images/mailer/google-play.png" style="display: block; height: auto; border: 0; width: 120px; max-width: 100%;" width="120"/></a></div>
</td>
</tr>
</table>
</td>
<td class="column column-2" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="50%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
<div style="line-height:10px"><a href="https://apps.apple.com/ae/app/kirtibook/id1560166551" target="_blank"><img src="https://kirtibook.in/images/mailer/app-store.png" style="display: block; height: auto; border: 0; width: 120px; max-width: 100%;" width="120"/></a></div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-4" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="image_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;padding-right:0px;padding-left:0px;">
<div align="center" style="line-height:10px"><a href="https://kirtibook.in/" style="outline:none" tabindex="-1" target="_blank"><img class="big" src="https://kirtibook.in/images/mailer/seller-forgot-password.jpg" style="display: block; height: auto; border: 0; width: 600px; max-width: 100%;" width="600"/></a></div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-5" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>

<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 0px; padding-bottom: 25px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="text_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;" width="100%">
<tr>
<td style="padding-bottom:10px;padding-left:25px;padding-right:25px;padding-top:20px;">
<div style="font-family: sans-serif">
<div style="font-size: 12px; mso-line-height-alt: 18px; color: #636363; line-height: 1.5; font-family: Arial, Helvetica Neue, Helvetica, sans-serif;">
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Dear '.$username.', </strong></span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">Welcome to kirtibook.in</span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">You are receiving this email because you requested a password reset for your account at www.kirtibook.in.</span></p>

<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;">If you did not request this change, you can disregard this email - we have not yet reset your password.	</span></p>

<p style="margin: 0; font-size: 16px; mso-line-height-alt: 18px;"> </p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Thanks & Regards,</strong></span></p>
<p style="margin: 0; font-size: 16px; mso-line-height-alt: 24px;"><span style="font-size:16px;"><strong>Team Kirti Book</strong></span></p>
</div>
</div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>


</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-6" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #ffffff;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f68529; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 10px; padding-bottom: 10px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="heading_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="width:100%;text-align:center;">
<h2 style="margin: 0; color: #ffffff; font-size: 18px; font-family: Arial, Helvetica Neue, Helvetica, sans-serif; line-height: 120%; text-align: center; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;">Connect with us</h2>
</td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" class="divider_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="padding-bottom:20px;padding-top:15px;">
<div align="center">
<table border="0" cellpadding="0" cellspacing="0" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="50%">
<tr>
<td class="divider_inner" style="font-size: 1px; line-height: 1px; border-top: 2px solid #FFFFFF;"><span> </span></td>
</tr>
</table>
</div>
</td>
</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" class="social_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="padding-left:10px;padding-right:10px;text-align:center;">
    <table align="center" border="0" cellpadding="0" cellspacing="0" class="social-table" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="144px">
    <tr>
    <td style="padding:0 2px 0 2px;"><a href="https://www.facebook.com/kirtibook" target="_blank"><img alt="Facebook" height="32" src="https://kirtibook.in/images/mailer/facebook2x.png" style="display: block; height: auto; border: 0;" title="Facebook" width="32"/></a></td>
    <td style="padding:0 2px 0 2px;"><a href="https://twitter.com/kirtibook" target="_blank"><img alt="Twitter" height="32" src="https://kirtibook.in/images/mailer/twitter2x.png" style="display: block; height: auto; border: 0;" title="Twitter" width="32"/></a></td>
    <td style="padding:0 2px 0 2px;"><a href="https://www.instagram.com/kirtibook" target="_blank"><img alt="Instagram" height="32" src="https://kirtibook.in/images/mailer/instagram2x.png" style="display: block; height: auto; border: 0;" title="Instagram" width="32"/></a></td>
    <td style="padding:0 2px 0 2px;"><a href="https://kirtibook.in/" target="_blank"><img alt="Web Site" height="32" src="https://kirtibook.in/images/mailer/website2x.png" style="display: block; height: auto; border: 0;" title="Web Site" width="32"/></a></td>
    </tr>
    </table>
</td>
</tr>
</table>
<table border="0" cellpadding="10" cellspacing="0" class="text_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;" width="100%">
<tr>
<td>
<div style="font-family: serif">
<div style="font-size: 12px; mso-line-height-alt: 14.399999999999999px; color: #ffffff; line-height: 1.2; font-family:  Arial, Helvetica Neue, Helvetica, sans-serif;">
<p style="margin: 0; font-size: 12px; text-align: center;"><span id="f5c76119-6591-4a54-bb42-858e19560972" style="font-size:14px;">@2021 Kirti Book. All Rights Reserved.</span></p>
</div>
</div>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-7" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tbody>
<tr>
<td>
<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content stack" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; width: 600px;" width="600">
<tbody>
<tr>
<td class="column column-1" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;" width="100%">
<table border="0" cellpadding="0" cellspacing="0" class="icons_block" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="vertical-align: middle; color: #9d9d9d; font-family: inherit; font-size: 15px; padding-bottom: 5px; padding-top: 5px; text-align: center;">
<table cellpadding="0" cellspacing="0" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
<tr>
<td style="vertical-align: middle; text-align: center;">

<table cellpadding="0" cellspacing="0" class="icons-inner" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; display: inline-block; margin-right: -4px; padding-left: 0px; padding-right: 0px;">

<tr>

</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body>';
        $mail_subject = 'Forgot Password';
        $this->auth_model->sent_simple_mail($mail_message,$email,$mail_subject);



				$resultpost = array(
					'status' => 200,
					'message' => 'OTP send successfully !!',
					'phone' => $phone
				);
			}
			else{
				$resultpost = array(
						'status' => 400,
						'message' => 'Something Went Wrong',
				);
			}
		}
		else {
			$resultpost = array(
					'status' => 400,
					'message' => 'Enter Correct Registered Mobile No.',
			);
		}

	   return $resultpost;
    }


    public function resend_otp($phone)
    {

		$query = $this->db->query("SELECT id,otp FROM users WHERE (phone_number='$phone') AND role='vendor'");
		if ($query->num_rows() > 0) {
            $info=$query->row_array();
            $otp =$info['otp'];

            $message_user = 'Your OTP for Kirtibook.in is '.$otp.' KIRTIZ';
			$this->auth_model->send_sms($message_user,$phone);
			$resultpost = array(
				'status' => 200,
				'message' => 'OTP re-send successfully !!',
				'phone' => $phone
			);

		}
		else {
			$resultpost = array(
					'status' => 400,
					'message' => 'Enter Correct Registered Mobile No.',
			);
		}

	   return $resultpost;
    }

     public function forgot_password_varify($phone,$otp,$password)
    {
		$this->load->library('bcrypt');
		$query = $this->db->query("SELECT id,phone_number FROM users WHERE (phone_number='$phone') AND role='vendor' AND otp='$otp'");

		if ($query->num_rows() > 0) {
            $info=$query->row_array();
            $user_id=$info['id'];
            $phone_number =$info['phone_number'];

            $data_otp['password'] = $this->bcrypt->hash_password($password);
            $this->db->where('id', $user_id);
            $update=$this->db->update('users', $data_otp);

			if($update){

				$resultpost = array(
					'status' => 200,
					'message' => 'Password Changed successfully !!',
				);
			}
			else{
				$resultpost = array(
						'status' => 400,
						'message' => 'Something Went Wrong',
				);
			}
		}
		else {
			$resultpost = array(
					'status' => 400,
					'message' => 'Enter Correct OTP',
			);
		}

	   return $resultpost;
    }

}
?>
