<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Complaint_model extends CI_Model
{

public function complaint_list($user_id, $per_page, $offset, $filter)   {
	  $school_filter="";
	  $category_filter="";
	  $keyword_filter="";
	  $ticket_status_filter="";
      $academic_year_filter   = "";

			$per_page='50';

       if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            //$academic_year_filter    = " AND (DATE(t.added_date) BETWEEN '$from' AND '$to')";
        endif;


      if(!empty($filter['school']) && $filter['school']!="") :
    	  $school_id=implode(",",$filter['school']);
          $school_filter =" AND  FIND_IN_SET(o.school_id, '$school_id')";
    endif;

	if(!empty($filter['complaint_category']) && $filter['complaint_category']!="") :
    	  $complaint_category=implode(",",$filter['complaint_category']);
          $category_filter =" AND  FIND_IN_SET(t.cat_id, '$complaint_category')";
    endif;

    if(isset($filter['keyword']) && $filter['keyword']!="") :
      $keyword=trim($filter['keyword']);
      $keyword_filter =" AND (t.id like '%".$keyword."%'
      or CONCAT(t.ctype,t.id) like '%".$keyword."%'
      or t.username like '%".$keyword."%'
      or t.email like '%".$keyword."%'
      or o.order_number like '%".$keyword."%'
      or t.phone_number like '%".$keyword."%'
      or t.cat_name like '%".$keyword."%'
      or t.subcat_name like '%".$keyword."%'
      or t.source like '%".$keyword."%'
      or t.dept_name like '%".$keyword."%')";
    endif;

    if(isset($filter['ticket_status']) && !empty($filter['ticket_status']) &&  $filter['ticket_status']!="") :
      $ticket_status=$filter['ticket_status'];
      $ticket_status_filter = " AND (t.ticket_status='$ticket_status')";
     endif;



        $catrgory = "1,2,3,4";
        $query = $this->db->query("SELECT CONCAT(t.ctype,t.id) AS ticket_no,t.ctype,t.id,t.product_id,t.ticket_status,t.order_type,t.user_id,t.username,t.order_id,t.cat_name,t.ticket_desc,t.added_date,o.order_number,o.product_name,o.school_name FROM oc_tickets as t LEFT JOIN orders as o ON t.order_id=o.id WHERE t.id<>'' $school_filter $category_filter  $keyword_filter $ticket_status_filter order by t.id desc  LIMIT $offset,$per_page");

		$rows = $this->db->query("SELECT t.id FROM oc_tickets as t LEFT JOIN orders as o ON t.order_id=o.id WHERE t.id<>'' $school_filter $category_filter  $keyword_filter   $ticket_status_filter  order by id desc");

        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $ticket_id=$row['id'];
            $id   = $row['id'];
            $product_id = $row['product_id'];
            $ticket_status = $row['ticket_status'];
            $order_type = $row['order_type'];
            $user_id = $row['user_id'];
            $username = $row['username'];
            $order_id = $row['order_id'];
            $cat_name = $row['cat_name'];
            $ticket_desc = $row['ticket_desc'];
            $added_date = $row['added_date'];

            if ($order_type == 'individual') {
               $product_name = $row['product_name'];
            } else {
              $product_name = $row['school_name'];
            }

            $date = date("Y-m-d H:i:s", strtotime($row['added_date']));
            $pending_since = get_time_difference($date);


            $rticket=$this->get_last_reply_ticket($ticket_id);

            $data[] = array(
                "id" => $id,
                "ticket_code" => '#'.$row['ctype'].sprintf('%04d',$id),
                "product_id" => $product_id,
                "ticket_status" => $ticket_status,
                "order_type" => ucfirst($order_type),
                "user_id" => $user_id,
                "username" => $username,
                "order_id" => $order_id,
                "order_number" => ($row['order_number']!='' ? $row['order_number']:'-'),
                "school_name" => ($row['school_name']!='' ? $row['school_name']:'-'),
                "product_name" => $product_name,
                "cat_name" => $cat_name,
                "ticket_desc" => $ticket_desc,
                "added_date" => date("d M Y h:i a", strtotime($added_date)),
                "pending_since" => $pending_since,
                "reply_type" => $rticket['reply_type'],
                "reply_name" => $rticket['reply_name'],
                "reply_date" => $rticket['reply_date'],
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count,
        );
        return $resultpost;
    }


    public function get_last_reply_ticket($ticket_id){
     $resultdata = array();
     $query = $this->db->query("SELECT reply_name, reply_id, reply_date FROM oc_tickets_reply WHERE ticket_id='$ticket_id' ORDER BY id DESC LIMIT 1");

     if(!empty($query)){
		foreach($query->result_array() as $item){
		    $vendor_id = $item['reply_id'];
		    $vendor_name = '';
            if($vendor_id > 0){
                if($item['reply_name'] == 'reply_name'){
                     $vendor_name =  'Replied';
                }

            }else{
                  $vendor_name =  'Admin Replied';
            }

            $resultdata = array(
                "reply_type" => $item['reply_name'],
                "reply_name" => $vendor_name,
                "reply_date" =>  date("F j, Y, g:i a",strtotime($item['reply_date'])),
            );
        }
      }
	return  $resultdata;

    }




    public function complaint_details($user_id,$id){
        $catrgory = "1,2,3,4";
        $query = $this->db->query("SELECT * FROM oc_tickets where id='$id' order by id desc");
        $rows  = $this->db->query("SELECT id FROM oc_tickets where id='$id' order by id desc");

        $count = $rows->num_rows();
        $data  = array();

        if(!empty($query)){
         foreach ($query->result_array() as $row) {
            $id             = $row['id'];
            $product_id     = explode(',',$row['product_id']);
            $ticket_status  = $row['ticket_status'];
            $order_type     = $row['order_type'];
            $user_id        = $row['user_id'];
            $username       = $row['username'];
            $order_id       = $row['order_id'];
            $cat_name       = $row['cat_name'];
            $ticket_desc    = $row['ticket_desc'];
            $added_date     = $row['added_date'];
            $vendor_id      = $row['vendor_id'];
            $cat_id         = $row['cat_id'];

            $order_number = $this->db->query("SELECT order_number,product_name,school_name,board_name,grade_name FROM orders where id='$order_id' limit 1")->row_array();


            $product = array();
            foreach($product_id as $product_ids){
                if($order_type=='bookset'){
                    $order_image = $this->db->query("SELECT image,product_unit_price,product_name,product_quantity FROM order_products where order_id='$order_id' and id='$product_ids'")->row_array();
                }
                else{
                    $order_image = $this->db->query("SELECT image,product_unit_price,product_name,product_quantity FROM order_products where order_id='$order_id' and product_id='$product_ids'")->row_array();
                 }

                $product[] = array(
                    "product_id" => $product_ids,
                    "product_image" => $order_image['image'],
                    "product_name" => $order_image['product_name'],
                    "product_price" => $order_image['product_unit_price'],
                    "product_quantity" => $order_image['product_quantity'],
                );

            }

            $gallery = array();
            $comaplint_gallery = $this->db->query("SELECT * FROM oc_tickets_gallery where complaint_id='$id'");
            foreach ($comaplint_gallery->result_array() as $row_gallery) {

                if($row_gallery['type'] == 'image'){
                    $main_url = main_api_url().'uploads/complaint/image/';
                }else{
                    $main_url =  main_api_url().'uploads/complaint/video/';
                }
                $gallery[] = array(
                    "type" => $row_gallery['type'],
                    "url" => $main_url.$row_gallery['url'],
                );

            }

						$vendor_id='47';

            $date = date("Y-m-d H:i:s", strtotime($row['added_date']));
            $pending_since = get_time_difference($date);
            $is_reply_sql = $this->db->query("SELECT id,reply_desc FROM oc_tickets_reply where ticket_id='$id'  and reply_id = '$vendor_id' limit 1");
            $is_reply = $is_reply_sql->num_rows();


            $vendor_reply = '';
            if($is_reply > 0){
                $reply =$is_reply_sql->row_array();
                $vendor_reply = $reply['reply_desc'];

            }

            $data[] = array(
                "id" => $id,
                "ticket_code" => '#'.$row['ctype'].sprintf('%04d',$id),
                "ticket_status" => $ticket_status,
                "order_type" => ucfirst($order_type),
                "user_id" => $user_id,
                "username" => $username,
                "order_id" => $order_id,
                "school_name" => ($order_number['school_name']!='' ? $order_number['school_name'].'-'.$order_number['board_name']:'-'),
                "board_name" => $order_number['board_name'],
                "grade_name" => ($order_number['grade_name']!=''?$order_number['grade_name']:'-'),
                "order_number" => $order_number['order_number'],
                "cat_name" => $cat_name,
                "ticket_desc" => $ticket_desc,
                "added_date" => date("d M Y h:i a", strtotime($added_date)),
                "pending_since" => $pending_since,
                "product" => $product,
                "gallery" => $gallery,
                "is_reply" => $is_reply,
                "reply" => $vendor_reply,
                "cat_id" => $cat_id,
                "vendor_action" => get_phrase($row['vendor_action']),

            );
         }
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count,
        );
        return $resultpost;
    }


    public function complaint_reply($user_id,$id,$reply,$action_status)   {
        $data['reply_id'] = $user_id;
        $data['ticket_id'] = $id;
        $data['reply_desc'] = $reply;
        $data['reply_name'] = 'vendor';
        $data['reply_date'] =  date("Y-m-d H:i:s");
        if($this->db->insert('oc_tickets_reply', $data)){
          $check_sql = $this->db->query("SELECT id,cat_id,order_id FROM oc_tickets WHERE id='$id' AND order_id IS NOT NULL AND vendor_action IS NULL LIMIT 1");
          if($check_sql->num_rows()>0){
            $item=$check_sql->row();
            $order_id=$item->order_id;
            $cat_id=$item->cat_id;
            $data2['vendor_action'] = $action_status;
            $data2['action_date']   = date("Y-m-d H:i:s");
            $this->db->where('id', $id);
            $this->db->update('oc_tickets', $data2);

            //update order
            $return_status=NULL;

            if($cat_id=='1' || $cat_id=='2' || $cat_id=='3'){

             if($cat_id=='2' || $cat_id=='3'){
                $complaint_status='complaint_return';
             }
             else{
                $complaint_status=NULL;
              }

             if($action_status=='accept'){
               $data3['complaint_id']     = $id;
               $data3['complaint_status'] = 'pending';
               $data3['return_status']    = $complaint_status;
               $data3['complaint_date']   = date("Y-m-d H:i:s");
               $this->db->where('id', $order_id);
               $this->db->update('orders', $data3);
             }
            }


           }
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
            );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'error',
            );
        }

        return $resultpost;
    }
    
    public function complaint_closed($user_id,$ticket_id){
        
        
        $data_2 = array(
            'ticket_status' => 3,
            'reply_last_updated' => date('Y-m-d H:i:s'),
            'ticket_closed_date' => date('Y-m-d H:i:s'),
        );
		$this->db->where('id', $ticket_id);
        $this->db->update('oc_tickets', $data_2);
                        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }

}
