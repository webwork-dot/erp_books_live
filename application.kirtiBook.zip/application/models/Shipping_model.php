<?php defined('BASEPATH') OR exit('No direct script access allowed');

 class Shipping_model extends CI_Model{
   private $url = 'https://api.bigship.in/api/';
  
   function __construct(){
        parent::__construct();
        /*cache control*/
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
		date_default_timezone_set('Asia/Kolkata');
    }

   public function bigship_token() {
    date_default_timezone_set('Asia/Kolkata');
    $curr_date = date('Y-m-d H:i:s');
    $update_date = date('Y-m-d H:i:s');
        
    $token=$this->db->get_where('ship_auth_token', array('id' => '1'))->row_array();
    $token_expiry = date('Y-m-d H:i:s',strtotime($token['token_expiry']));
	 
    if($token_expiry < $curr_date){
        $url = $this->url ."login/user";
        $ip_addr=$this->input->ip_address();
		$data = array(
          "user_name"=> $token['email'],
          "password"=> $token['password'],
          "access_key"=> $token['access_key'],
        );
		
        $payload = json_encode($data);        
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "$url",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 60,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS =>$payload,
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: application/json",
          ),
        ));
        
        $result = curl_exec($curl);
        $api_data = json_decode($result, TRUE);
		//echo json_encode($api_data);exit();  
        if(!empty($api_data)){
			$token_expiry = date('Y-m-d H:i:s', strtotime('+8 hours', strtotime($curr_date)));
            $data_update=array();
            $data_update['token'] 		 = $api_data['data']['token'];
            $data_update['token_expiry'] = $token_expiry;
            $data_update['created_at'] 	 = $api_data['created_at'];
            $data_update['last_updated'] = $update_date;
            $this->db->where('id', '1');
            $this->db->update('ship_auth_token', $data_update);  
        }
      }
    }

   public function bigship_get_courier_rates($system_order_id) {
		date_default_timezone_set('Asia/Kolkata');
		$curr_date = date('Y-m-d H:i:s');
		$curl = curl_init();
		$token = $this->common_model->getNameByVar('ship_auth_token','token',array('id'=>1));
        $url = $this->url ."order/shipping/rates?shipment_category=B2C&system_order_id=".$system_order_id;
		curl_setopt_array($curl, array(
		  CURLOPT_URL =>  $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_POSTFIELDS =>json_encode($consignments),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
            'Authorization: Bearer ' . trim($token)
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);		
        $api_data = json_decode($response);
		
		if($api_data->responseCode==200 && $api_data->success==true){		
			  usort($api_data->data, function ($a, $b) {
				$isDelhiveryA = strpos($a->courier_name, 'Delhivery') !== false;
				$isDelhiveryB = strpos($b->courier_name, 'Delhivery') !== false;

				// Prioritize Delhivery couriers
				if ($isDelhiveryA && !$isDelhiveryB) {
					return -1;
				} elseif (!$isDelhiveryA && $isDelhiveryB) {
					return 1;
				} else {
					// If both are Delhivery or neither, sort by shipping charges
					return $a->total_shipping_charges <=> $b->total_shipping_charges;
				}
			});
			
			$resultpost = array(
				'status' => 200,
				'data' => !empty($api_data->data) ? $api_data->data[0] : null,
				'message' => 'success'
			);
        }
		else{
			 $resultpost = array(
				'status' => 400,
				'message' => 'One or more validation errors occurred!',
			);
		} 
		return $resultpost;		
	}

  
    public function bigship_get_balance() {
		date_default_timezone_set('Asia/Kolkata');
		$curr_date = date('Y-m-d H:i:s');
		$curl = curl_init();
		$token = $this->common_model->getNameByVar('ship_auth_token','token',array('id'=>1));

        $url = $this->url ."Wallet/balance/get";
		curl_setopt_array($curl, array(
		  CURLOPT_URL =>  $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_POSTFIELDS =>json_encode($consignments),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
            'Authorization: Bearer ' . trim($token)
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);		
        $api_data = json_decode($response);
		
		if($api_data->responseCode==200 && $api_data->success==true){		
			$resultpost = array(
				'status' => 200,
				'balance' => $api_data->data,
				'message' => 'success'
			);
        }
		else{
			 $resultpost = array(
				'status' => 400,
				'balance' => 0,
				'message' => 'No balance in wallet!',
			);
		} 
		return $resultpost;		
	}
			
	
    public function bigship_manifest_order($params) {
		date_default_timezone_set('Asia/Kolkata');
		$curr_date = date('Y-m-d H:i:s');
		$curl = curl_init();
		$token = $this->common_model->getNameByVar('ship_auth_token','token',array('id'=>1));

        $url = $this->url ."order/manifest/single";
		curl_setopt_array($curl, array(
		  CURLOPT_URL =>  $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>json_encode($params),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
            'Authorization: Bearer ' . trim($token)
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);		
        $api_data = json_decode($response);
		
		if($api_data->responseCode==200 && $api_data->success==true){		
			$resultpost = array(
				'status' => 200,
				'message' => 'success'
			);
        }
		else{
			 $resultpost = array(
				'status' => 400,
				'message' => $api_data->message,
			);
		} 
		return $resultpost;		
	}	
		
		
	
    public function bigship_get_awb($system_order_id) {
		date_default_timezone_set('Asia/Kolkata');
		$curr_date = date('Y-m-d H:i:s');
		$curl = curl_init();
		$token = $this->common_model->getNameByVar('ship_auth_token','token',array('id'=>1));

        $url = $this->url ."shipment/data?shipment_data_id=1&system_order_id=".$system_order_id;
		curl_setopt_array($curl, array(
		  CURLOPT_URL =>  $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => json_encode($params),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
            'Authorization: Bearer ' . trim($token)
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);		
        $api_data = json_decode($response);
		
		if($api_data->responseCode==200 && $api_data->success==true){	
			$master_awb = isset($api_data->data->master_awb) ? $api_data->data->master_awb : null;
	
			$resultpost = array(
				'status' => 200,
				'data' => $api_data->data,
				'master_awb' => $master_awb,
				'message' => 'success'
			);
        }
		else{
			 $resultpost = array(
				'status' => 400,
				'message' => $api_data->message,
			);
		} 
		return $resultpost;		
	}		
		
		
    public function bigship_assign_courier(){
		$curr_date = date('Y-m-d H:i:s');   
		$date = date('Y-m-d');      	
   	    $cron_orders =  $this->db->query("SELECT o.id,o.order_slot,vsl.id as vid, o.process_slot, o.system_order_id FROM orders o INNER JOIN vendor_shipping_label vsl ON o.system_order_id = vsl.system_order_id WHERE  o.courier_name IS NULL AND o.awb_number IS NULL AND o.system_order_id IS NOT NULL AND o.shipment_provider = 'bigship' AND (o.order_status = 'processing' OR o.order_status = 'exchange_pending')  GROUP BY o.order_slot ORDER BY o.id ASC LIMIT 5");
		//echo $this->db->last_query();exit();  
					
        if($cron_orders->num_rows()>0) {
    	  foreach ($cron_orders->result_array() as $item) {
			   $courier_res=array();
    	       $order_id        = $item['id'];   
    	       $vid     		= $item['vid'];   
    	       $order_slot      = $item['order_slot'];   
        	   $system_order_id = $item['system_order_id'];	   			

			   $courier_res=$this->bigship_get_courier_rates($system_order_id);
			   $courier=$courier_res['data'];
			   $courier_id=$courier->courier_id;
			   $courier_name=$courier->courier_name;
			   $total_shipping_charges=$courier->total_shipping_charges;			   			   
			   $res_walllet=$this->bigship_get_balance();			   
			   $wallet_balance = $res_walllet['balance'];
			   
			   if($courier_res['status']==200){
			   
			   if($wallet_balance>$total_shipping_charges){ 
				   	$params = array(
						'system_order_id'=> $system_order_id,
						'courier_id'	 => $courier_id,
					);
				  $response=$this->bigship_manifest_order($params);			
				  if($response['status']==200){	
					 $awb_res=$this->bigship_get_awb($system_order_id);
			
					  $master_awb=NULL;
					  if($awb_res['status']==200){
						 $master_awb=$awb_res['master_awb'];
					  }
					  
				
						$data_status=array();
						$data_status['courier_name']  = $courier_name;
						$data_status['awb_number']    = $master_awb;
						$this->db->where('order_slot', $order_slot);
						$this->db->update('orders', $data_status);   
						
						
						$data_status=array();
						$data_status['courier'] 	  = $courier_name;
						$data_status['courier_charge']= $total_shipping_charges;
						$data_status['awb_number']    = $master_awb;
						$data_status['courier_assign_date'] = $curr_date;
						$this->db->where('slot_no', $order_slot);
						$this->db->update('vendor_shipping_label', $data_status);   
											
						$function_name='manifest_order';
						$json_request=json_encode($item);
						$json_data=json_encode([]);		
						$remark='1';		
						$track_data = array(
							'json_courier'	=> json_encode($courier_res),
							'wallet'		=> $wallet_balance,
							'json_request'	=> $json_request,
							'json_data'		=> $json_data,
							'master_awb'	=> $master_awb,
							'remark'	 	=> $remark
						);				
						$this->add_cronjob_track($order_slot,$function_name,$track_data);   
					}
					else{
						$function_name='manifest_order';
						$json_request=json_encode($item);
						$json_data=json_encode($response);		
						$remark='2';		
						$track_data = array(
							'json_courier'	=> json_encode($courier_res),
							'wallet'		=> $wallet_balance,
							'json_request'	=> $json_request,
							'json_data'		=> $json_data,
							'master_awb'	=> NULL,
							'remark'	 	=> $remark
						);				
						$this->add_cronjob_track($order_slot,$function_name,$track_data); 						
					}					
			   }
			   else{
				//wallet_reminder				  
				$function_name='manifest_order';
				$json_request=json_encode($item);
				$json_data=json_encode([]);		
				$remark='3';		
				$track_data = array(
					'json_courier'	=> json_encode($courier_res),
					'wallet'		=> $wallet_balance,
					'json_request'	=> $json_request,
					'json_data'		=> $json_data,
					'master_awb'	=> NULL,
					'remark'	 	=> $remark
				);				
				$this->add_cronjob_track($order_slot,$function_name,$track_data); 
			  } 
			}
			else{
				$function_name='manifest_order';
				$json_request=json_encode($item);
				$json_data=json_encode([]);		
				$remark='4';		
				$track_data = array(
					'json_courier'	=> json_encode($courier_res),
					'wallet'		=> $wallet_balance,
					'json_request'	=> $json_request,
					'json_data'		=> $json_data,
					'master_awb'	=> NULL,
					'remark'	 	=> $remark
				);				
				$this->add_cronjob_track($order_slot,$function_name,$track_data); 
			}
    	   }
        }
    }
 
 
 	
    public function bigship_update_failed_awb_courier(){
		$curr_date = date('Y-m-d H:i:s');   
		$date = date('Y-m-d');      	
   	    $cron_orders =  $this->db->query("SELECT o.id,o.order_slot,vsl.id as vid, o.process_slot, o.system_order_id FROM orders o INNER JOIN vendor_shipping_label vsl ON o.system_order_id = vsl.system_order_id WHERE o.courier_name IS NOT NULL AND o.awb_number IS NULL AND o.system_order_id IS NOT NULL AND o.shipment_provider = 'bigship' AND (o.order_status = 'processing' OR o.order_status = 'exchange_pending') GROUP BY o.order_slot ORDER BY o.id ASC LIMIT 5");
		//echo $this->db->last_query();exit();  
					
        if($cron_orders->num_rows()>0) {
    	  foreach ($cron_orders->result_array() as $item) {
			  $courier_res=array();
    	      $order_id        = $item['id'];   
    	      $vid     		   = $item['vid'];   
    	      $order_slot      = $item['order_slot'];   
        	  $system_order_id = $item['system_order_id'];	 	
			  $awb_res=$this->bigship_get_awb($system_order_id);		
			  if($awb_res['status']==200){
					$master_awb=$awb_res['master_awb'];	
					$data_status=array();
					$data_status['awb_number']    = $master_awb;
					$this->db->where('order_slot', $order_slot);
					$this->db->update('orders', $data_status);   
					
					
					$data_status=array();
					$data_status['awb_number']    = $master_awb;
					$this->db->where('slot_no', $order_slot);
					$this->db->update('vendor_shipping_label', $data_status);   
										
					$function_name='update_awb_number';
					$json_request=json_encode($item);
					$json_data=json_encode([]);		
					$remark='1';		
					$track_data = array(
						'json_courier'	=> json_encode($courier_res),
						'wallet'		=> 0,
						'json_request'	=> $json_request,
						'json_data'		=> $json_data,
						'master_awb'	=> $master_awb,
						'remark'	 	=> $remark
					);				
					$this->add_cronjob_track($order_slot,$function_name,$track_data);   
				}
				else{
					$function_name='update_awb_number';
					$json_request=json_encode($item);
					$json_data=json_encode($response);		
					$remark='2';		
					$track_data = array(
						'json_courier'	=> json_encode($courier_res),
						'wallet'		=> 0,
						'json_request'	=> $json_request,
						'json_data'		=> $json_data,
						'master_awb'	=> NULL,
						'remark'	 	=> $remark
					);				
					$this->add_cronjob_track($order_slot,$function_name,$track_data); 						
				}					
			} 
        }
    }
  
   
    public function add_cronjob_track($order_slot, $function_name,$params){ 
        $added_date =  date('Y-m-d H:i:s');
        $data['order_slot']      = $order_slot;
        $data['function_name']   = $function_name;
        $data['json_courier']    = $params['json_courier'];
        $data['wallet']    	 	 = $params['wallet'];
        $data['json_request']    = $params['json_request'];
        $data['json_data']   	 = $params['json_data'];
        $data['master_awb']   	 = $params['master_awb'];
        $data['remark']   		 = $params['remark'];
        $data['created_date']    = $added_date;
		$this->db->insert('shipping_track', $data);
    }
    
	
	
	  public function demo_bigship_get_courier_rates($system_order_id) {
		date_default_timezone_set('Asia/Kolkata');
		$curr_date = date('Y-m-d H:i:s');
		$curl = curl_init();
		$token = $this->common_model->getNameByVar('ship_auth_token','token',array('id'=>1));
        $url = $this->url ."order/shipping/rates?shipment_category=B2C&system_order_id=".$system_order_id;
		curl_setopt_array($curl, array(
		  CURLOPT_URL =>  $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_POSTFIELDS =>json_encode($consignments),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
            'Authorization: Bearer ' . trim($token)
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);		
        $api_data = json_decode($response);
		if($api_data->responseCode==200 && $api_data->success==true){		
		
		  usort($api_data->data, function ($a, $b) {
            $isDelhiveryA = strpos($a->courier_name, 'Delhivery') !== false;
            $isDelhiveryB = strpos($b->courier_name, 'Delhivery') !== false;

            // Prioritize Delhivery couriers
            if ($isDelhiveryA && !$isDelhiveryB) {
                return -1;
            } elseif (!$isDelhiveryA && $isDelhiveryB) {
                return 1;
            } else {
                // If both are Delhivery or neither, sort by shipping charges
                return $a->total_shipping_charges <=> $b->total_shipping_charges;
            }
        });
		//echo json_encode($api_data->data[0]);exit();
		
			$resultpost = array(
				'status' => 200,
				'data' => !empty($api_data->data) ? $api_data->data[0] : null,
				'message' => 'success'
			);
        }
		else{
			 $resultpost = array(
				'status' => 400,
				'message' => 'One or more validation errors occurred!',
			);
		} 
		return $resultpost;		
	}
	

	public function bigship_tracking() {
		$curr_date = date('Y-m-d H:i:s');   
		$date = date('Y-m-d');      	
		$cron_orders = $this->db->query("SELECT o.id, o.order_slot, vsl.id as vid, o.awb_number, o.system_order_id, o.last_checked 
										 FROM orders o 
										 INNER JOIN vendor_shipping_label vsl ON o.system_order_id = vsl.system_order_id 
										 WHERE o.courier_name IS NOT NULL 
										 AND o.awb_number IS NOT NULL 
										 AND o.system_order_id IS NOT NULL 
										 AND o.shipment_provider = 'bigship' 
										 AND (o.order_status = 'out_for_delivery') 
										 AND (o.last_checked IS NULL OR o.last_checked < DATE_SUB(NOW(), INTERVAL 2 HOUR)) 
										 GROUP BY o.order_slot 
										 ORDER BY o.id ASC 
										 LIMIT 10");

		if ($cron_orders->num_rows() > 0) {
			foreach ($cron_orders->result_array() as $item) {
				$order_id = $item['id'];   
				$vid = $item['vid'];   
				$order_slot = $item['order_slot'];   
				$tracking_id = $item['awb_number'];	 

				date_default_timezone_set('Asia/Kolkata');
				$curr_date = date('Y-m-d H:i:s');
				$curl = curl_init();
				$token = $this->common_model->getNameByVar('ship_auth_token', 'token', array('id' => 1));
				$url = $this->url . "tracking?tracking_type=awb&tracking_id=" . $tracking_id;
				curl_setopt_array($curl, array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'GET',
					CURLOPT_POSTFIELDS => json_encode($consignments),
					CURLOPT_HTTPHEADER => array(
						'content-type: application/json',
						'Authorization: Bearer ' . trim($token)
					),
				));
				$response = curl_exec($curl);
				curl_close($curl);		
				$api_data = json_decode($response, true);

				// Update last_checked time for the order
				$this->db->where('id', $order_id);
				$this->db->update('orders', array('last_checked' => $curr_date));

				// Log the API response and other details
				$function_name = ''; // Initialize function name
				$json_request = json_encode($item);
				$json_data = $response;		
				$remark = '2';		
				$track_data = array(
					'json_courier' => NULL,
					'wallet' => 0,
					'json_request' => $json_request,
					'json_data' => $json_data,
					'master_awb' => NULL,
					'remark' => $remark
				);

				// Handle API responses
				if (isset($api_data['success'])) {
					if ($api_data['success'] === true) {
						if (isset($api_data['data']['order_detail']['current_tracking_status'])) {
							$current_status = $api_data['data']['order_detail']['current_tracking_status'];
							$current_tracking_datetime = $api_data['data']['order_detail']['current_tracking_datetime'];
							$delivered_date=date('Y-m-d H:i:s',strtotime($current_tracking_datetime));
							if ($current_status == 'DELIVERED') {
								$update_data = array(
									'order_status' => 'delivered',
									'delivered_date' => $delivered_date
								);
								$this->db->where('id', $order_id);
								$this->db->update('orders', $update_data);

								$function_name = 'order_delivered';
							} else {
								$function_name = 'order_in_progress';
							}
						} else {
							$function_name = 'no_tracking_history';
						}
					} else {
						if ($api_data['responseCode'] == 404) {
							$function_name = 'tracking_id_not_found';
						}
						elseif ($api_data['responseCode'] == 202) {
							$function_name = 'invalid_tracking_type';
						}
						else {
							$function_name = 'api_error';
						}
					}
				} else {
					$function_name = 'invalid_api_response';
				}
				
				$this->add_cronjob_track($order_slot, $function_name, $track_data);

			   return true;
			}
		}
	}

}