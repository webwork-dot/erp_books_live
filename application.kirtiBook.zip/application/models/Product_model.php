<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
    
    public function check_product_sku($sku, $user_id, $product_id, $type)
    {
        if ($type == 'on_create') {
            $count = $this->db->get_where('products', array(
                'is_deleted' => 0,
                'model_number' => $sku,
                'user_id' => $user_id
            ))->num_rows();
            
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }
        
        if ($type == 'on_update') {
            $count = $this->db->get_where('products', array(
                'id!=' => $product_id,
                'is_deleted' => 0,
                'model_number' => $sku,
                'user_id' => $user_id
            ))->num_rows();
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }
    }
    
    public function get_product_by_id($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('products');
        return $query->row();
    }
    
    
    
    
    // Books -> School Text Book Starts    
    public function add_product_post($data, $warehouse, $quantity)
    {
        $data['parent_cid'] = '8';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    public function add_product_other_post($data, $warehouse, $quantity)
    {
        $data['parent_cid'] = '45';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function edit_product_post($data, $warehouse, $quantity,$product_id)
    {
        // $data['parent_cid'] = '8';
        $product_id = $product_id;
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            // $data_qty['product_id']   = $product_id;
            // $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->where('product_id', $product_id);
            $this->db->where('warehouse_id', $warehouse_id);
            $this->db->update('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_post($data, $category, $warehouse, $quantity, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Books -> School Text Book Ends      
    
    public function get_publisher_by_id($id)
    {
        return $this->db->get_where('publisher', array(
            'id' => $id
        ));
    }
    public function get_publisher_by_name($name)
    {
        return $this->db->get_where('publisher', array(
            'name' => $name
        ));
    }
    
    public function get_grades_by_id($id)
    {
        return $this->db->get_where('grade_list', array(
            'id' => $id
        ));
    }
    
    public function get_grades_by_name($name)
    {
        return $this->db->get_where('grade_list', array(
            'name' => $name
        ));
    }
    
    public function get_stationery_by_id($id)
    {
        return $this->db->get_where('stationery_type', array(
            'id' => $id
        ));
    }
    
    public function get_stationery_by_name($name)
    {
        return $this->db->get_where('stationery_type', array(
            'name' => $name
        ));
    }
    
    public function get_subject_by_id($id)
    {
        return $this->db->get_where('subject', array(
            'id' => $id
        ));
    }
    
    public function get_subject_by_name($name)
    {
        return $this->db->get_where('subject', array(
            'name' => $name
        ));
    }
    
    public function get_brand_by_id($id)
    {
        return $this->db->get_where('brand', array(
            'id' => $id
        ));
    }
    
    public function get_brand_by_name($name)
    {
        return $this->db->get_where('brand', array(
            'name' => $name
        ));
    }
    
    public function get_board_by_id($id)
    {
        return $this->db->get_where('board', array(
            'id' => $id
        ));
    }
    
    
    public function get_board_by_name($name)
    {
        return $this->db->get_where('board', array(
            'name' => $name
        ));
    }
    
    
    
    public function get_binding_type_by_name($name)
    {
        return $this->db->get_where('binding_type', array(
            'name' => $name
        ));
    }
    
    public function get_binding_type_by_id($id)
    {
        return $this->db->get_where('binding_type', array(
            'id' => $id
        ));
    }
    
    
    public function get_color_by_name($name)
    {
        return $this->db->get_where('product_color', array(
            'name' => $name
        ));
    }
    
    public function get_color_by_id($id)
    {
        return $this->db->get_where('product_color', array(
            'id' => $id
        ));
    }
    
    
    public function get_school_by_name($name)
    {
        return $this->db->get_where('school', array(
            'name' => $name
        ));
    }
    
    public function get_school_by_id($id)
    {
        return $this->db->get_where('school', array(
            'id' => $id
        ));
    }
    
    
    public function get_category_by_name($name)
    {
        return $this->db->get_where('categories', array(
            'name' => $name
        ));
    }
    
    public function get_category_by_id($id)
    {
        return $this->db->get_where('categories', array(
            'id' => $id
        ));
    }
    
    public function get_size_by_id($id)
    {
        return $this->db->get_where('size', array(
            'id' => $id
        ));
    }
    
    
    
    public function get_main_cat_by_id($id)
    {
        $products = $this->db->get_where('products_category', array(
            'product_id' => $id
        ))->row_array();
        $cat_id   = $this->db->get_where('categories', array(
            'id' => $products['category_id']
        ))->row()->parent_id;
        $cat_name = $this->db->get_where('categories', array(
            'id' => $cat_id
        ))->row()->name;
        return $cat_name;
    }
    
    function get_warehouse_name($id)
    {
      return $this->db->get_where('vendor_shipping_details', array('id' => $id ))->row()->name;
    }
    
    
    function get_board_list($board_array)
    {
        $boards = explode(",", $board_array);
        $arr    = array();
        for ($i = 0; $i < sizeof($boards); $i++) {
            $prod = $this->db->get_where('board', array('id' => $boards[$i]));
            if($prod->num_rows()>0){
                $arr[] = $prod ->row()->name; 
            }
        }
        return implode(",", $arr);
    }
    
    function get_grade_list($grade_array)
    {
        $grades = explode(",", $grade_array);
        $arr    = array();
       
            for ($i = 0; $i < sizeof($grades); $i++) {
               $prod = $this->db->get_where('grade_list', array('id' => $grades[$i]));
               if($prod->num_rows()>0){
                $arr[] = $prod ->row()->name; 
               }
            }
            return implode(",", $arr);
       
    }
    
    
    function get_category_type_list($id)
    {
        $arr = array();
        
        $products = $this->db->get_where('products_category', array(
            'product_id' => $id
        ))->result_array();
        foreach ($products as $prod) {
            $arr[] = $this->db->get_where('categories', array(
                'id' => $prod['category_id']
            ))->row()->name;
        }
        return implode(",", $arr);
    }
    
    
    function get_size_list($board_array)
    {
        $boards = explode(",", $board_array);
        $arr    = array();
        for ($i = 0; $i < sizeof($boards); $i++) {
            $product = $this->db->get_where('size', array('id' => $boards[$i]));
            // echo $this->db->last_query();
            
            if($product->num_rows() > 0){
                $product = $product->row();
                $arr[] = $product->name;
            }
        }
        return implode(",", $arr);
    }
    
    
    
    
    
    public function get_user_products_count($user_id, $category)
    {
        $this->db->select('p.id,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold');
        $this->db->join('products_category', 'p.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $this->db->group_by('categories.parent_id');
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        return $query->num_rows();
    }
    
    public function get_uniform_product_count($user_id, $category,$filter)
    {
        $product_search = '';
        $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(p.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);
        } else {
            $product_search = '';
        }
        
         if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('vsd.address,vsd.id as warehouse_id,s.name as size_name,p.id,p.title,p.gender,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold');
        $this->db->join('products_category', 'p.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        return $query->num_rows();
    }
    
    public function get_uniform_product_list_count($user_id, $category,$filter)
    {
        $product_search = '';
        $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(p.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('p.id');
        
        $this->db->join('categories', 'categories.id=p.uniform_cat');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        return $query->num_rows();
    }
    
    public function get_uniform_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
         $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(p.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);  
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
             $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('categories.name as cat_name,vsd.address,vsd.id as warehouse_id,pwq.quantity,pwq.kirtibook_price,s.name as size_name,p.id,p.uniform_cat,p.title,p.gender,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,status,p.is_sold');
        
        $this->db->join('categories', 'categories.id=p.uniform_cat');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
    //   echo $this->db->last_query();
    //     exit();
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            if($row['cat_name'] != ''){
                $uniform_cat = $row['cat_name'];  
            }else{
                $uniform_cat = '---';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $this->common_model->shorter($row['title'],'35'),
                "model_number" => $this->common_model->shorter($row['model_number'],'11'),
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "status" => $row['status'],
                "is_sold" => $row['is_sold'],
                "size_name" => $row['size_name'],
                "gender" => $row['gender'],
                "quantity" => $row['quantity'],
                "kirtibook_price" => $row['kirtibook_price'],
                "uniform_cat" => $this->common_model->shorter($uniform_cat,'18'),
            );
        }
        
        $total_data =  $this->get_uniform_product_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_delete_uniform_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(p.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where); 
            
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('categories.name as cat_name,vsd.address,vsd.id as warehouse_id,pwq.quantity,pwq.kirtibook_price,s.name as size_name,p.id,p.uniform_cat,p.title,p.gender,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,status,p.is_sold');
        
        $this->db->join('categories', 'categories.id=p.uniform_cat');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 1);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $this->db->group_by('p.id');
        
        $query = $this->db->get('products as p');
    //   echo $this->db->last_query();
    //     exit();
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            if($row['cat_name'] != ''){
                $uniform_cat = $row['cat_name'];  
            }else{
                $uniform_cat = '---';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $this->common_model->shorter($row['title'],'35'),
                "model_number" => $this->common_model->shorter($row['model_number'],'11'),
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "status" => $row['status'],
                "is_sold" => $row['is_sold'],
                "size_name" => $row['size_name'],
                "gender" => $row['gender'],
                "quantity" => $row['quantity'],
                "kirtibook_price" => $row['kirtibook_price'],
                "uniform_cat" => $this->common_model->shorter($uniform_cat,'18'),
            );
        }
        
        $total_data =  $this->get_uniform_product_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        $this->db->select('p.id,p.title,p.gender,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold');
        $this->db->join('products_category', 'p.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
       
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "model_number" => $row['model_number'],
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold'],
                "gender" => $row['gender']
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_all_product_list_count($user_id,$filter){
        $product_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(pm.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);
            
        } else {
            $product_search = '';
        }
        $status_filter='';
        if (isset($filter['status']) && $filter['status'] != ""):
            $status = $filter['status'];
            if($status=='active'){
                $status_filter = $this->db->where("p.status='1'");
            }
            else if($status=='inactive'){
                $status_filter = $this->db->where("p.status='0'");
            }
            else if($status=='outofstock'){
                $status_filter = $this->db->where("pwq.quantity<=0");
            }
        endif;

        $this->db->select('p.id');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id');
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $product_search;
        $status_filter;
        //$this->db->group_by('pwq.warehouse_id');
        $query = $this->db->get('products as p');
        return $count = $query->num_rows();
    }
    
    public function get_all_product_list($user_id,$per_page,$offset,$filter)
    {
        $keyword = '';
        $product_search = '';
        $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(pm.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);
        } else {
            $product_search = '';
        }
        
        $status_filter='';
        if (isset($filter['status']) && $filter['status'] != ""):
            $status = $filter['status'];
            if($status=='active'){
                $status_filter = $this->db->where("p.status='1'");
            }
            else if($status=='inactive'){
                $status_filter = $this->db->where("p.status='0'");
            }
            else if($status=='outofstock'){
                $status_filter = $this->db->where("pwq.quantity<=0");
            }
        endif;
        
        $this->db->select('pwq.warehouse_id,pm.parent_cid,p.id,p.created_at,pm.title,p.gender,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,p.discount_price,pm.gst,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id');
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $product_search;
        $status_filter;
        //$this->db->group_by('pwq.warehouse_id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc'); 
        $query = $this->db->get('products as p');
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            $product_id = $row['id'];
            $warehouse_id= $row['warehouse_id'];
            $parent_cid = $row['parent_cid'];
            
            $cquery = $this->db->query("SELECT sum(quantity) as quantity FROM products_warehouse_qty WHERE product_id='$product_id' and warehouse_id='$warehouse_id'");
            if ($cquery->num_rows() > 0) {
                $crow     = $cquery->row_array();
                $quantity = $crow['quantity'];
            } else {
                $quantity = 0;
            }
            
            $cquery = $this->db->query("SELECT name FROM vendor_shipping_details WHERE id='$warehouse_id' limit 1");
            if ($cquery->num_rows() > 0) {
                $crow     = $cquery->row_array();
                $warehouse_name = $crow['name'];
            } else {
                $warehouse_name = '';
            }
            
            $cquery = $this->db->query("SELECT name FROM categories WHERE id='$parent_cid' limit 1");
            if ($cquery->num_rows() > 0) {
                $crow     = $cquery->row_array();
                $cat_name = $crow['name'];
            } else {
                $cat_name = '';
            }
            
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            $created_at=date("d M Y h:i A", strtotime($row['created_at']));
            
            $data[] = array(
                "id" => $row['id'],
                "parent_cid" => $parent_cid,
                "cat_name" => $cat_name,
                "warehouse_name" => $warehouse_name,
                "title" => $this->common_model->shorter($row['title'],'40'),
                "model_number" => $this->common_model->shorter($row['model_number'],'30'),
                "publisher" => $this->common_model->shorter($publisher,'11'),
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold'],
                "discount_price" => $row['discount_price'],
                "quantity" => $quantity,
                "created_at" => $created_at,
                "gender" => ''
            );
        }
        
        $total_data = $this->get_all_product_list_count($user_id,$filter);
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'data' => $data
        );
        return $resultpost;
    }
    
     public function get_product_list_count($user_id, $category,$filter){
        $product_search = '';
        $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(pm.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);
            
        } else {
            $product_search = '';
        }
        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        $this->db->select('pwq.quantity,p.id,pm.title,p.gender,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,p.discount_price,pm.gst,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        return $count = $query->num_rows();
    }
    
    public function get_product_list_($user_id, $category, $per_page, $offset, $filter)
    {
        $keyword = '';
        $product_search = '';
        $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $where  = "(pm.title  LIKE '%$keyword%' OR p.model_number LIKE '%$keyword%')";
            $product_search = $this->db->where($where);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('pwq.quantity,p.id,p.created_at,pm.title,p.gender,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,p.discount_price,pm.gst,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc'); 
        $query = $this->db->get('products as p');
        
        $count = $query->num_rows();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            $created_at=date("d M Y h:i A", strtotime($row['created_at']));
            
            $data[] = array(
                "id" => $row['id'],
                "created_at" => $created_at,
                "title" => $this->common_model->shorter($row['title'],'39'),
                "model_number" => $this->common_model->shorter($row['model_number'],'17'),
                "publisher" => $this->common_model->shorter($publisher,'11'),
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold'],
                "discount_price" => $row['discount_price'],
                "quantity" => $row['quantity'],
                "gender" => $row['gender']
            );
        }
        
        $total_data = $this->get_product_list_count($user_id, $category,$filter);
		//echo $this->db->last_query();exit();
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_shoes_product_list_count($user_id, $category,$filter)
    {
        $product_search = '';
         $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
             $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('p.id');
        
        
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
         $warehouse_search;
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        
        // echo $this->db->last_query();
        
        $count = $query->num_rows();
        
        return $count;
    }
    
    public function get_shoes_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
         $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
             $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('categories.name as cat_name,vsd.name as warehouse_name,vsd.id as warehouse_id,pwq.quantity,pwq.kirtibook_price,s.type as size_type,s.indian as size_indian,s.usa as size_usa,s.uk as size_uk,p.id,pm.title,pm.gender,pm.age_type,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,pm.gst,p.status,p.is_sold');
        
        
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
         $warehouse_search;
        // $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        
        // echo $this->db->last_query();
        
        $count = $query->num_rows();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $this->common_model->shorter($row['title'],'39'),
                "model_number" => $this->common_model->shorter($row['model_number'],'17'),
                "size_type" => $row['size_type'],
                "size" => ' Indian : '.$row['size_indian'].' ,USA : '.$row['size_usa'].' ,UK : '.$row['size_uk'],
                "status" => $row['status'],
                "warehouse_name" => $row['warehouse_name'],
                "cat_name" => $row['cat_name'],
                "discount_price" => $row['kirtibook_price'],
                "quantity" => $row['quantity'],
                "gender" => $row['gender'],
                "age_type" => $row['age_type'],
            );
        }
        
        $total_data = $this->get_shoes_product_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_shoes_deleted_product_list_count($user_id, $category,$filter)
    {
        $product_search = '';
         $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
             $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('categories.name as cat_name,vsd.name as warehouse_name,vsd.id as warehouse_id,pwq.quantity,pwq.kirtibook_price,s.type as size_type,s.indian as size_indian,s.usa as size_usa,s.uk as size_uk,p.id,pm.title,pm.gender,pm.age_type,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,pm.gst,p.status,p.is_sold');
        
        
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 1);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
         $warehouse_search;
        $this->db->group_by('p.id'); 
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        
        // echo $this->db->last_query();
        
        $count = $query->num_rows();
        
        return $count;
    }
    
    public function get_shoes_deleted_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
         $warehouse_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
             $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('categories.name as cat_name,vsd.name as warehouse_name,vsd.id as warehouse_id,pwq.quantity,pwq.kirtibook_price,s.type as size_type,s.indian as size_indian,s.usa as size_usa,s.uk as size_uk,p.id,pm.title,pm.gender,pm.age_type,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,pm.gst,p.status,p.is_sold');
        
        
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 1);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
         $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        
        // echo $this->db->last_query();
        
        $count = $query->num_rows();
        $data  = array();
        
        foreach ($query->result_array() as $row) {
            
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $this->common_model->shorter($row['title'],'39'),
                "model_number" => $this->common_model->shorter($row['model_number'],'17'),
                "size_type" => $row['size_type'],
                "size" => ' Indian : '.$row['size_indian'].' ,USA : '.$row['size_usa'].' ,UK : '.$row['size_uk'],
                "status" => $row['status'],
                "warehouse_name" => $row['warehouse_name'],
                "cat_name" => $row['cat_name'],
                "discount_price" => $row['kirtibook_price'],
                "quantity" => $row['quantity'],
                "gender" => $row['gender'],
                "age_type" => $row['age_type'],
            );
        }
        
        $total_data = $this->get_shoes_deleted_product_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    public function get_product_list_delete($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
       
        
        
        $this->db->select('p.id,pm.title,p.gender,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,pm.gst,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->where('p.is_deleted', 1);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "model_number" => $row['model_number'],
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold'],
                "gender" => $row['gender']
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_products_category_by_product($id)
    {
        return $this->db->get_where('products_category', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_warehouse_qty_by_product($id)
    {
        return $this->db->get_where('products_warehouse_qty', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_warehouse_qty_by_product_def($id)
    {
        $this->db->group_by('warehouse_id');
        return $this->db->get_where('products_warehouse_qty', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_warehouse_by_search($product_id, $warehouse_id)
    {
        return $this->db->get_where('products_warehouse_qty', array(
            'product_id' => $product_id,
            'warehouse_id' => $warehouse_id
        ));
    }
    
    public function get_products_images($id)
    {
        return $this->db->get_where('product_images', array(
            'product_id' => $id
        ));
    }
    
    public function get_uniform_products_images($id)
    {
        return $this->db->get_where('product_images', array(
            'product_id' => $id,'type' => 'product'
        ));
    }
    
    public function get_vendor_shipping($id)
    {
        return $this->db->get_where('vendor_shipping_details', array(
            'id' => $id
        ));
    }
    
    
    public function get_product_details($user_id, $id)
    {
        $this->db->where('id', $id);
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('products');
        $count = $query->num_rows();
        $data  = array();
        $row   = $query->row_array();
        if ($count > 0) {
            $categories    = $this->get_products_category_by_product($row['id']);
            $category_data = array();
            foreach ($categories->result_array() as $category) {
                $category_data[] = $category['category_id'];
            }
            
            $warehouse     = $this->get_products_warehouse_qty_by_product($row['id']);
            $warehouse_def = $this->get_products_warehouse_qty_by_product_def($row['id']);
            
            $warehouse_data_default = array();
            $warehouse_data_default2 = array();
            $warehouse_list         = array();
            
            
            
            $warehouse_data_group = array();
            $sizeName_list        = array();
            
            $vendor_shipping_name = '';
            $comma = '';
            foreach ($warehouse_def->result_array() as $ware_def) {
                $warehouse_data_default[] = array(
                    "key" => $ware_def['warehouse_id']
                ); 
             
                array_push($warehouse_data_default2,$ware_def['warehouse_id']);
                $warehouse_data[]     = $ware_def['warehouse_id'];
                $vendor_shipping = $this->get_vendor_shipping($ware_def['warehouse_id'])->row();
                $vendor_shipping_name .= $comma.$vendor_shipping->name;
                
                $warehouse_data_group[] = $ware_def['warehouse_id'];
                
                $warehouse_list[] = array(
                    "warehouse_id" => $ware_def['warehouse_id'],
                    "address" => $this->common_model->get_warehouse_address_add_by_id($ware_def['warehouse_id'])
                );
                
                 $comma = '';
            }
            
            
            
            $warehouse_data     = array();
            $warehouse_data_qty = array();
            $stock_data         = array();
            $products_images    = array();
            $sizeName_list      = array();
            
            foreach ($warehouse->result_array() as $ware) {
                
                $warehouse_data_qty[] = array(
                    "warehouse_id" => $ware['warehouse_id'],
                    "quantity" => $ware['quantity'],
                    "address" => $this->common_model->get_warehouse_address_add_by_id($ware['warehouse_id'])
                );
                
                $stock_data[] = array(
                    "product_id" => $ware['product_id'],
                    "warehouse_id" => $ware['warehouse_id'],
                    "size_id" => $ware['size_id'],
                    "quantity" => $ware['quantity']
                );
                
                $size_by = $this->get_size_by_id($ware['size_id'])->row();
                
                 $sizeName_list[] = array(
                    "warehouse_id" => $ware['warehouse_id'],
                    "id" => $ware['size_id'],
                    "name" => $size_by->name,
                    "quantity" => $ware['quantity'],
                    "price" => $ware['price'],
                    "kirtibook_price" => $ware['kirtibook_price'],
                );
                
            }
            
             $sizeDefault = array();
            
            
            $size_array = explode(',', $row['size']);
            foreach ($size_array as $size_id)
                $sizeDefault[] = array(
                    "key" => $size_id
                );     
            

            
            $vendor_shipping_name = explode(',',$vendor_shipping_name);   
            
            $products_images = array();
            $get_images      = $this->get_uniform_products_images($row['id']);
            if ($get_images->num_rows() > 0) {
                foreach ($get_images->result_array() as $images) {
                    $products_images[] = array(
                        "id" => $images['id'],
                        "image" => $images['image'],
                        "image_url" => vendor_url()."uploads/products/" . $images['image']
                    );
                }
            }
            
             $board_name       = $this->auth_model->get_board_name($row['board_id']);
            $data[] = array(
                "id" => $row['id'],
                "sku" => $row['model_number'],
                "title" => $row['title'],
                "description" => $row['description'],
                "publisher" => $row['publisher_id'],
                "category_id" => $row['category_id'],
                "category_name" => $this->common_model->get_category_name($row['category_id']),  
                "category_label" => array(
                    "key" => $row['category_id']
                ),
                "board" => explode(',', $row['board_id']),
                "grades" => explode(',', $row['grade_id']),
                "board_id" => $row['board_id'],
                "brand_id" => $row['brand_id'],
                "board_name" => $board_name,
                "stationery_id" => $row['stationery_id'],
                "subject" => $row['subject_id'],
                "pages" => $row['no_of_pages'],
                "base_price" => $row['base_price'],
                "price" => $row['discount_price'],
                "gst" => (int)$row['gst'],
                "hsn" => $row['hsn'],
                "lenght" => $row['lenght'],
                "width" => $row['width'],
                "height" => $row['height'],
                "weight" => $row['weight'],
                "meta_title" => $row['meta_title'],
                "meta_keyword" => $row['meta_keyword'],
                "meta_description" => $row['meta_description'],
                "min_quantity" => $row['min_quantity'],
                "product_description" => $row['product_description'],
                "age_grade" => $row['age_grade'],
                "to_age" => $row['to_age'],
                "from_age" => $row['from_age'],
                "is_bookset" => $row['is_bookset'],
                "is_individually" => $row['is_individually'],
                "is_exchange" => $row['is_exchange'],
                "day_exchange" => $row['day_exchange'],
                "highlights" => json_decode($row['highlights']),
                "category_data" => $category_data,
                "warehouse_data" => $warehouse_data,
                "warehouse_data_default" => $warehouse_data_default,
                "warehouse_data_default2" => $warehouse_data_default2,
                "warehouse_data_qty" => $warehouse_data_qty,
                "stock_data" => $stock_data,
                "products_images" => $products_images,
                "size" => explode(',', $row['size']),
                "size_name" => $this->common_model->get_size_name($row['size']),
                "school" => $row['school'], 
                "school_name" => $this->common_model->get_school_name($row['school']), 
                "school_label" => array(
                    "key" => $row['school']
                ),
                "product_origin" => $row['product_origin'],
                "gender" => $row['gender'],
                "color_id" => $row['color_id'], 
                "color_name" => $this->common_model->get_color_name($row['color_id']), 
                "color_label" => array(
                    "key" => $row['color_id']
                ),
                "uniform_cat" => $row['uniform_cat'],
                "uniform_cat_name" => array(
                    "key" => $this->common_model->get_category_name($row['uniform_cat'])
                ),
                "sizeName_list" => $sizeName_list,
                "sizeDefault" => $sizeDefault,
                "warehouse_list" => $warehouse_list,
                "warehouse_data_group" => $warehouse_data_group
                
            );
            
            
            $total_data = count($data);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $total_data
            );
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    
    public function get_product_details_($user_id, $id,$parent_id)
    {
        $query_master = $this->db->query("SELECT p.is_individually,p.category_id,p.discount_price,p.base_price,p.model_number,p.day_exchange,p.is_bookset,p.min_quantity,p.size as prod_size,p.id,pm.id as master_id,pm.subcate,pm.title,pm.publisher_id,pm.isbn,pm.board_id,pm.grade_id,pm.brand_id,pm.subject_id,
            pm.no_of_pages,pm.gst,pm.hsn,pm.lenght,pm.width,pm.height,pm.weight,pm.meta_title,pm.meta_keyword,pm.meta_description,
            pm.product_description,pm.age_grade,pm.from_age,pm.to_age,pm.highlights,pm.size,pm.school,pm.video,pm.binding_type,pm.color,pm.product_origin
         	FROM  products as p
        	INNER JOIN product_master as pm ON pm.id = p.master_id 
            LEFT JOIN products_category ON p.id=products_category.product_id 
            LEFT JOIN categories ON categories.id=products_category.category_id
            WHERE (p.id='$id')");	
	   //     echo $this->db->last_query();
		  //  exit();
            $data  = array();
            foreach ($query_master->result_array() as $row_master) {
                
             $publisher='-'; 
             $subject='-';
             $grade='N/A'; 
             $board='-'; 
             $brand='-'; 
             $size='-'; 
             $school='-'; 
             $binding_type='-'; 
             $color='-'; 
             $subcate='-'; 
             
            if($row_master['publisher_id']!='') {
              $get_publisher = $this->product_model->get_publisher_by_id($row_master['publisher_id']);
              if($get_publisher->num_rows() > 0){
                 $publisher_data=$get_publisher->row();
                 $publisher= $publisher_data->name;
              }
            }
    
           
            if($row_master['grade_id']!='') {   
              $get_grade = $this->product_model->get_grade_list($row_master['grade_id']);
               if($get_grade!=''){
                  $grade= $get_grade;
              }
             }
              
            
            if($row_master['board_id']!='') {    
              $get_board = $this->product_model->get_board_list($row_master['board_id']);
              if($get_board!=''){
                  $board= $get_board;
              }
             }  
             
             
            if($row_master['brand_id']!='') {    
              $get_brand = $this->product_model->get_brand_by_id($row_master['brand_id']);
               if($get_brand->num_rows() > 0){
                 $brand_data=$get_brand->row();
                 $brand= $brand_data->name;
              }
             }
            
            if($row_master['subject_id']!='') {    
              $get_subject = $this->product_model->get_subject_by_id($row_master['brand_id']);
               if($get_subject->num_rows() > 0){
                 $subject_data=$get_subject->row();
                 $subject= $subject_data->name;
              }
             }
              
              
            if($row_master['size']!='') {    
              $get_size = $this->product_model->get_size_list($row_master['size']);
              if($get_size!=''){
                  $size= $get_size;
              }
             }  
             
                 
            if($row_master['school']!='') {    
              $get_school = $this->product_model->get_school_by_id($row_master['school']);
               if($get_school->num_rows() > 0){
                 $school_data=$get_school->row();
                 $school= $school_data->name;
              }
             }  
             
            if($row_master['binding_type']!='') {    
              $get_binding_type = $this->product_model->get_binding_type_by_id($row_master['binding_type']);
               if($get_binding_type->num_rows() > 0){
                 $binding_type_data=$get_binding_type->row();
                 $binding_type= $binding_type_data->name;
              }
             }  
             
            if($row_master['color']!='') {    
              $get_color = $this->product_model->get_color_by_id($row_master['color']);
               if($get_color->num_rows() > 0){
                 $color_data=$get_color->row();
                 $color= $color_data->name;
              }
             }   
             
             if($row_master['subcate']!='') {    
              $get_subcate = $this->product_model->get_category_by_id($row_master['subcate']);
               if($get_subcate->num_rows() > 0){
                 $subcate_data=$get_subcate->row();
                 $subcate= $subcate_data->name;
              }
             }
         
         
         
              $get_type = $this->product_model->get_category_type_list($row_master['master_id']);
              if($get_type!=''){
                  $category= $get_type;
              }
              else{ $category='-'; }
              
          
            $get_images= $this->product_master_model->get_products_images_single($row_master['master_id'])->row_array();
             $image_url=$get_images['image_small'];
           
               if(file_exists('uploads/products/'.$image_url)){
                   $image_url=vendor_url().'uploads/products/'.$image_url;
                }
                else{
                     $image_url=vendor_url().'uploads/default_product.png';
                }
                
            $warehouse     = $this->get_products_warehouse_qty_by_product($row_master['id']);
            $warehouse_def = $this->get_products_warehouse_qty_by_product_def($row_master['id']);
            
            $warehouse_data_default = array();
            $warehouse_list         = array();
            
            
            $warehouse_data_group = array();
            $sizeName_list        = array();
            
            $vendor_shipping_name = '';
            $comma = '';
            foreach ($warehouse_def->result_array() as $ware_def) {
                $warehouse_data_default[] = array(
                    "key" => $ware_def['warehouse_id']
                );
                
                $vendor_shipping = $this->get_vendor_shipping($ware_def['warehouse_id'])->row();
                $vendor_shipping_name .= $comma.$vendor_shipping->name;
                
                $warehouse_data_group[] = $ware_def['warehouse_id'];
                
                $warehouse_list[] = array(
                    "warehouse_id" => $ware_def['warehouse_id'],
                    "address" => $this->common_model->get_warehouse_address_add_by_id($ware_def['warehouse_id'])
                );
                
                $comma = '';
            }
            
            
            $warehouse_data     = array();
            $warehouse_data_qty = array();
            $stock_data         = array();
            $sizeName_list      = array();
            if($parent_id != '38'){
                foreach ($warehouse->result_array() as $ware) {
                    $warehouse_data[]     = $ware['warehouse_id'];
                    $warehouse_data_qty[] = array(
                        "warehouse_id" => $ware['warehouse_id'],
                        "quantity" => $ware['quantity'],
                        "address" => $this->common_model->get_warehouse_address_add_by_id($ware['warehouse_id'])
                    );
                    
                    $stock_data[] = array(
                        "product_id" => $ware['product_id'],
                        "warehouse_id" => $ware['warehouse_id'],
                        "size_id" => $ware['size_id'],
                        "quantity" => $ware['quantity']
                    );
                    
                    $size_by = $this->get_size_by_id($ware['size_id'])->row();
                    
                    $sizeName_list[] = array(
                        "warehouse_id" => $ware['warehouse_id'],
                        "id" => $ware['size_id'],
                        "name" => $size_by['name'],
                        "quantity" => $ware['quantity']
                    );
                    
                }  
            }
            
            $sizeDefault = array();
            
            
            $size_array = explode(',', $row_master['prod_size']);
            foreach ($size_array as $size_id)
                $sizeDefault[] = array(
                    "key" => $size_id
                );
            
            $vendor_shipping_name = explode(',',$vendor_shipping_name);    
           
            $data[] = array(
                "id" =>  $row_master['master_id'],
                "title" =>  $row_master['title'],
                "isbn" =>  $row_master['isbn'],
                "sku" =>  $row_master['model_number'],
                "min_quantity" =>  $row_master['min_quantity'],
                "day_exchange" =>  $row_master['day_exchange'],
                "is_bookset" =>  $row_master['is_bookset'],
                "is_individually" =>  $row_master['is_individually'],
                "base_price" =>  $row_master['base_price'],
                "discount_price" =>  $row_master['discount_price'],
                "category_id" =>  $row_master['category_id'],
                "publisher" => $publisher,
                "board" =>   $board,
                "brand" =>   $brand,
                "subject" =>  $subject,
                "grade" =>  $grade,
                "category" =>  $category,
                "image_url" => $image_url,
                "no_of_pages" =>  ($row_master['no_of_pages']!=0 ? $row_master['no_of_pages']:'-'),
                "isbn" =>  $row_master['isbn'],
                "gst" =>  $row_master['gst'],
                "hsn" =>  ($row_master['hsn'] ? $row_master['hsn']:'-'),
                "lenght" =>  ($row_master['lenght'] ? $row_master['lenght']:'-'),
                "width" =>  ($row_master['width'] ? $row_master['width']:'-'),
                "height" =>  ($row_master['height'] ? $row_master['height']:'-'),
                "weight" =>   ($row_master['weight'] ? $row_master['weight']:'-'),
                "meta_title" =>   ($row_master['meta_title'] ? $row_master['meta_title']:'-'),
                "meta_keyword" =>   ($row_master['meta_keyword'] ? $row_master['meta_keyword']:'-'),
                "meta_description" =>  ($row_master['meta_description'] ? $row_master['meta_description']:'-'),
                "product_description" =>  $row_master['product_description'],
                "age_grade" =>  $row_master['age_grade'],
                "from_age" =>  $row_master['from_age'],
                "to_age" =>  $row_master['to_age'],
                "isbn" =>  $row_master['isbn'],    
                "highlights" =>  json_decode($row_master['highlights']),
                "product_origin" =>  ($row_master['product_origin'] ? $row_master['product_origin']:'-'),
                "size" =>  $size,
                "school" =>  $school,
                "binding_type" =>  $binding_type,
                "color" =>  $color,
                "subcate" =>  $subcate,
                "warehouse_data" => $warehouse_data,
                "warehouse_data_default" => $warehouse_data_default,
                "warehouse_data_qty" => $warehouse_data_qty,
                "stock_data" => $stock_data,
                "size" => explode(',', $row_master['prod_size']),
                "sizeName_list" => $sizeName_list,
                "sizeDefault" => $sizeDefault,
                "warehouse_list" => $warehouse_list,
                "warehouse_data_group" => $warehouse_data_group,
                "vendor_shipping_name" => $vendor_shipping_name,
            );
        }
            
           
            
            $total_data = count($data);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $total_data
            );
        
        return $resultpost;
    }
    
    
    
    public function set_product_as_sold($user_id, $product_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        
        $product = $this->get_product_by_id($product_id);
        if (!empty($product)) {
            if ($user_id == $product->user_id) {
                if ($product->is_sold == 1) {
                    $data = array(
                        'is_sold' => 0
                    );
                    $msg  = 'Product set as Unsold!';
                } else {
                    $data = array(
                        'is_sold' => 1
                    );
                    $msg  = 'Product set as Sold!';
                }
                $this->db->where('id', $product_id);
                $this->db->update('products', $data);
            }
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }
    
    public function set_product_as_delete($user_id,$product_id)
    {
        foreach($product_id as $ids){
                $data = array(
                        'is_deleted' => 1
                    );
                $this->db->where('id', $ids);
                $this->db->update('products', $data);
            
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function set_product_as_restore($user_id,$product_id)
    {
        
                $data = array(
                        'is_deleted' => 0
                    );
                $this->db->where('id', $product_id);
                $this->db->update('products', $data);
            
       
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    public function set_service_product_as_restore($user_id,$product_id)
    {
        $data = array(
            'is_deleted' => 0
        );
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
     public function assign_school($user_id,$id,$school)
    {
        
                $data = array(
                        'school' => $school
                    );
                $this->db->where('id', $id);
                $this->db->update('products', $data);
            
       
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
        );
        return $resultpost;
    }
    
    
    
    // Books -> School Text Book Starts    
    public function add_product_other_book_post($data, $category, $warehouse, $quantity)
    {
        $data['parent_cid'] = '45';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_other_book_post($data, $category, $warehouse, $quantity, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Books -> School Text Book Ends        
    
    
    
    // Books -> School Note Book Starts    
    public function add_product_note_book_post($data, $warehouse, $quantity)
    {
        $data['parent_cid'] = '10';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_note_book_post($data, $category, $warehouse, $quantity, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Books -> School Note Book Ends        
    
    
    
    
    // Uniform  
    public function add_product_uniform_post($data, $category_id, $stock_data)
    {
        $data['parent_cid'] = '22';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        
        //single
        // $data_cat['product_id']  = $product_id;
        // $data_cat['category_id'] = $category_id;
        // $this->db->insert('products_category', $data_cat);
        
        
        $i = 0;
        foreach ($stock_data as $item) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $item['warehouse_id'];
            $data_qty['size_id']      = $item['size_id'];
            $data_qty['kirtibook_price'] = $item['kirtibook_price'];
            $data_qty['price']        = $item['price'];
            $data_qty['quantity']     = ($item['quantity'] == '' ? '0' : $item['quantity']);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        
        
        
        
        return $resultpost;
    }
    
    public function add_educational_services_post($data,$category,$type_list,$user_id)
    {
        $data['parent_cid'] = '261';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        if($product_id>0){
            foreach ($type_list as $type) {
                
                if(count($type['sub_item'])>0){
                    $category_id=$type['cat_id'];
                
                    $cquery = $this->db->query("SELECT name FROM categories WHERE id='$category_id' limit 1");
                    if ($cquery->num_rows() > 0) {
                        $crow          = $cquery->row_array();
                        $category_name = $crow['name'];
                    } else {
                        $category_name = '';
                    }
                    
                    $product_services['product_id']  = $product_id;
                    $product_services['user_id']  = $user_id;
                    $product_services['service_id']  = $type['cat_id'];
                    $product_services['service_name']  = $category_name;
                    $this->db->insert('product_services', $product_services);
                    $product_service_id = $this->db->insert_id();
                    
                    foreach ($type['sub_item'] as $sub_item) {
                        $item_id=$sub_item['item_id'];
                        
                        $cquery = $this->db->query("SELECT name FROM categories WHERE id='$item_id' limit 1");
                        if ($cquery->num_rows() > 0) {
                            $crow          = $cquery->row_array();
                            $item_name = $crow['name'];
                        } else {
                            $item_name = '';
                        }
                    
                        $product_services_type['product_id']  = $product_id;
                        $product_services_type['user_id']  = $user_id;
                        $product_services_type['service_id']  = $type['cat_id'];
                        $product_services_type['product_service_id']  = $product_service_id;
                        $product_services_type['item_id']  = $sub_item['item_id'];
                        $product_services_type['item_name']  = $item_name;
                        $product_services_type['item_base_price']  = $sub_item['item_base_price'];
                        $product_services_type['item_price']  = $sub_item['item_price'];
                        $product_services_type['item_discount']  = $sub_item['item_discount'];
                        $product_services_type['item_gst']  = $sub_item['item_gst'];
                        $product_services_type['item_description']  = $sub_item['item_description'];
                        $this->db->insert('product_services_type', $product_services_type);
                    }
                }
            }
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    public function add_educational_product_post($data,$category,$stock_data)
    {
        $data['parent_cid'] = '262';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        $i = 0;
        foreach ($stock_data as $item) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $item['warehouse_id'];
            $data_qty['quantity']     = ($item['quantity'] == '' ? '0' : $item['quantity']);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    public function add_product_shoes_post($data,$stock_data)
    {
        $data['parent_cid'] = '38';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        $i = 0;
        foreach ($stock_data as $item) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $item['warehouse_id'];
            $data_qty['size_id']      = $item['size_id'];
            $data_qty['kirtibook_price'] = $item['kirtibook_price'];
            $data_qty['price']        = $item['price'];
            $data_qty['quantity']     = ($item['quantity'] == '' ? '0' : $item['quantity']);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        
        
        
        
        return $resultpost;
    }
    
    public function update_product_shoes_post($data,$product_id)
    {
        
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        
        
        
        
        return $resultpost;
    }
    
    
    
    public function update_product_uniform_post($data, $category,$stock_data,$product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        $i = 0;
/*        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($stock_data as $item) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $item['warehouse_id'];
            $data_qty['size_id']      = $item['size_id'];
            $data_qty['kirtibook_price'] = $item['kirtibook_price'];
            $data_qty['price']        = $item['price'];
            $data_qty['quantity']     = ($item['quantity'] == '' ? '0' : $item['quantity']);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        */
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Books -> School Note Book Ends        
    
    
    
    public function get_stationery_product_list_count($user_id,$category,$filter)
    {
        
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('pwq.quantity,p.discount_price,p.id,pm.title,pm.isbn,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,pm.gst,p.status,p.is_sold,pm.stationery_id,pm.brand_id,pm.description');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id','left');
        $this->db->join('categories', 'categories.id=products_category.category_id','left');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('pm.parent_cid', $category);
        $product_search;
        $this->db->group_by('p.id');
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        return $count = $query->num_rows(); 
    }
    
    
    
    // Books -> Stationery Starts  
    
    public function get_stationery_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('pwq.quantity,p.master_id,p.discount_price,p.id,pm.title,pm.isbn,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,pm.gst,p.status,p.is_sold,pm.stationery_id,pm.brand_id,pm.description');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id','left');
        $this->db->join('categories', 'categories.id=products_category.category_id','left');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('pm.parent_cid', $category);
        $product_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
		
	
		
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            
            $get_stationery = $this->product_model->get_stationery_by_id($row['stationery_id']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            $data[] = array(
                "id" => $row['id'],
                "master_id" => $row['master_id'],
                "description" => $row['title'],
                "model_number" => $row['isbn'],
                "brand" => $brand,
                "stationery" => $stationery,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "discount_price" => $row['discount_price'],
                "quantity" => $row['quantity'],
                "is_sold" => $row['is_sold']
            );
        }
        
        $total_data = $this->get_stationery_product_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'total_data' => $total_data,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }
    
    public function get_stationery_product_delete_list($user_id, $category, $per_page, $offset, $filter)
    {
        
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('pwq.quantity,p.discount_price,p.id,pm.title,pm.isbn,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,pm.gst,p.status,p.is_sold,pm.stationery_id,pm.brand_id,pm.description');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 1);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('p.parent_cid', $category);
        $product_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        /*    echo $this->db->last_query();
        exit();*/
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            
            $get_stationery = $this->product_model->get_stationery_by_id($row['stationery_id']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            $data[] = array(
                "id" => $row['id'],
                "description" => $row['title'],
                "model_number" => $row['isbn'],
                "brand" => $brand,
                "stationery" => $stationery,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "discount_price" => $row['discount_price'],
                "quantity" => $row['quantity'],
                "is_sold" => $row['is_sold']
            );
        }
        
        $total_data = $this->get_user_products_count($user_id, $category);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }
    
    
    
    
    public function add_product_stationery_post($data, $warehouse, $quantity)
    {
        $data['parent_cid'] = '6';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_stationery_post($data, $category, $warehouse, $quantity, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Books -> School Text Book Ends      
    
    
    
    public function upload_images($product_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');
        
        $upload_path = './uploads/products/';
        
        
        $total_count = count($_FILES['images']['name']);
        // Loop through every file
        for ($i = 0; $i < $total_count; $i++) {
            
            $tmpFilePath = $_FILES['images']['tmp_name'][$i];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['images']['name'][$i];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $data = array(
                            'product_id' => $product_id,
                            'image' => $this->upload_model->product_default_image_upload($temp_path, "products"),
                            'image_small' => $this->upload_model->product_small_image_upload($temp_path, "products")
                        );
                        $this->upload_model->delete_temp_image($temp_path);
                        $this->db->insert('product_images', $data);
                    }
                }
            }
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }
    
    
    
    public function get_product_image_by_id($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('product_images');
        return $query->row();
    }
    
    public function product_image_delete($id)
    {
        $this->load->model('upload_model');
        date_default_timezone_set('Asia/Kolkata');
        $upload_path = './uploads/products/';
        
        $product = $this->get_product_image_by_id($id);
        if (!empty($product)) {
            $temp_path  = $upload_path . $product->image;
            $temp_path2 = $upload_path . $product->image_small;
            
            $this->upload_model->delete_temp_image($temp_path);
            $this->upload_model->delete_temp_image($temp_path2);
            $this->db->where('id', $id);
            $this->db->delete('product_images');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }
    
    
    
    
    
    // Toys Starts  
    
    public function get_toys_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        $this->db->select('p.id,p.title,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold,p.stationery_id,p.brand_id,p.description');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('p.parent_cid', $category);
        $product_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        /*    echo $this->db->last_query();
        exit();*/
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            
            $get_stationery = $this->product_model->get_stationery_by_id($row['stationery_id']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            $data[] = array(
                "id" => $row['id'],
                "description" => $row['description'],
                "model_number" => $row['model_number'],
                "brand" => $brand,
                "stationery" => $stationery,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold']
            );
        }
        
        $total_data = $this->get_user_products_count($user_id, $category);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    public function add_product_toys_post($data, $category, $warehouse, $quantity)
    {
        $data['parent_cid'] = '155';
        $this->db->insert('products', $data);
        $product_id = $this->db->insert_id();
        
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_toys_post($data, $category, $warehouse, $quantity, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Toys Ends        
    
    
    public function get_educational_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        $delete_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title or p.model_number', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
       
        $delete_search = $this->db->where('p.is_deleted', $filter['is_delete']);
         
        // echo $product_search ;
        // print_r($product_search);
        // exit();
        $this->db->select('categories.name as cat_name,vsd.address,vsd.id as warehouse_id,pwq.quantity,p.id,p.title,p.model_number,p.status,p.is_sold,p.discount_price');
        
        $this->db->join('categories', 'categories.id=p.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $delete_search;
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
    
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
        // echo $this->db->last_query();    
        // exit();    
            $data[] = array(
                "id" => $row['id'],
                "title" => $this->common_model->shorter($row['title'],'35'),
                "model_number" => $this->common_model->shorter($row['model_number'],'11'),
                "status" => $row['status'],
                "is_sold" => $row['is_sold'],
                "quantity" => $row['quantity'],
                "kirtibook_price" => $row['discount_price'],
                "type" => $row['cat_name'],
            );
        }
        
        $total_data =  $this->get_educational_product_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
	
	public function get_educational_product_list_count($user_id, $category,$filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title or p.model_number', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('p.id');
        
        $this->db->join('categories', 'categories.id=p.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        return $query->num_rows();
    }
    
    public function get_educational_service_product_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        $delete_search = '';
        
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title or p.model_number', $filter['keyword']);
        } else {
            $product_search = '';
        }
        if ($filter['is_delete'] != '') {
            $delete_search = $this->db->where('p.is_deleted', $filter['is_delete']);
        } else {
            $delete_search = '';
        }
        
        $this->db->select('categories.name as cat_name,p.id,p.title,p.description,p.status,p.is_sold,p.discount_price');
        
        $this->db->join('categories', 'categories.id=p.category_id');
        $this->db->where('p.user_id', $user_id);
        $this->db->where('p.category_id', $category);
        $product_search;
        $delete_search;
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        
        //echo $this->db->last_query();    
        //exit(); 
    
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {   
            $data[] = array(
                "id" => $row['id'],
                "title" => $this->common_model->shorter($row['title'],'35'),
                "description" => $this->common_model->shorter($row['description'],'100'),
                "status" => $row['status'],
                "is_sold" => $row['is_sold'],
                "quantity" => $row['quantity'],
                "kirtibook_price" => $row['discount_price']
            );
        }
        
        $total_data =  $this->get_educational_service_product_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
	
	public function get_educational_service_product_list_count($user_id, $category,$filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title or p.model_number', $filter['keyword']);
        } else {
            $product_search = '';
        }
        
        if ($filter['is_delete'] != '') {
            $delete_search = $this->db->where('p.is_deleted', $filter['is_delete']);
        } else {
            $delete_search = '';
        }
        
        $this->db->select('p.id');
        
        $this->db->join('categories', 'categories.id=p.category_id');
        $this->db->where('p.user_id', $user_id);
        $this->db->where('p.category_id', $category);
        $product_search;
        $delete_search;
        $this->db->order_by('p.id', 'desc'); 
        $query = $this->db->get('products as p');   
        return $query->num_rows();
    }
    
    public function update_educational_product_post($data, $category,$stock_data,$product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($stock_data as $item) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $item['warehouse_id'];
            $data_qty['quantity']     = ($item['quantity'] == '' ? '0' : $item['quantity']);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    public function get_educational_product_details($user_id, $id)
    {
        $this->db->where('id', $id);
        $this->db->where('user_id', $user_id);
        $this->db->where('parent_cid', '262');
        $query = $this->db->get('products');
        $count = $query->num_rows();
        $data  = array();
        $row   = $query->row_array();
        if ($count > 0) {
           
                
            $warehouse     = $this->get_products_warehouse_qty_by_product($row['id']);
            $warehouse_def = $this->get_products_warehouse_qty_by_product_def($row['id']);
            
            $warehouse_data_default = array();
            $warehouse_list         = array();
            
            
            $warehouse_data_group = array();
            $sizeName_list        = array();
            
            $vendor_shipping_name = '';
            $comma = '';
            foreach ($warehouse_def->result_array() as $ware_def) {
                $warehouse_data_default[] = array(
                    "key" => $ware_def['warehouse_id']
                );
                
                $vendor_shipping = $this->get_vendor_shipping($ware_def['warehouse_id'])->row();
                $vendor_shipping_name .= $comma.$vendor_shipping->name;
                
                $warehouse_data_group[] = $ware_def['warehouse_id'];
                
                $warehouse_list[] = array(
                    "warehouse_id" => $ware_def['warehouse_id'],
                    "address" => $this->common_model->get_warehouse_address_add_by_id($ware_def['warehouse_id'])
                );
                
                $comma = '';
            }
            
            
            $warehouse_data     = array();
            $warehouse_data_qty = array();
            $stock_data         = array();
            $sizeName_list      = array();
           
                foreach ($warehouse->result_array() as $ware) {
                    $warehouse_data[]     = $ware['warehouse_id'];
                    $warehouse_data_qty[] = array(
                        "warehouse_id" => $ware['warehouse_id'],
                        "quantity" => $ware['quantity'],
                        "address" => $this->common_model->get_warehouse_address_add_by_id($ware['warehouse_id'])
                    );
                    
                    $stock_data[] = array(
                        "product_id" => $ware['product_id'],
                        "warehouse_id" => $ware['warehouse_id'],
                        "size_id" => $ware['size_id'],
                        "quantity" => $ware['quantity']
                    );
                    
                    $size_by = $this->get_size_by_id($ware['size_id'])->row();
                    
                    $sizeName_list[] = array(
                        "warehouse_id" => $ware['warehouse_id'],
                        "id" => $ware['size_id'],
                        "name" => $size_by['name'],
                        "quantity" => $ware['quantity']
                    );
                    
                }  
            
            
          
            
            $vendor_shipping_name = explode(',',$vendor_shipping_name);   
            
            $products_images = array();
            $get_images      = $this->get_uniform_products_images($row['id']);
            if ($get_images->num_rows() > 0) {
                foreach ($get_images->result_array() as $images) {
                    $products_images[] = array(
                        "id" => $images['id'],
                        "image" => $images['image'],
                        "image_url" => vendor_url()."uploads/products/" . $images['image']
                    );
                }
            }
			
			if($row['category_id']!='') {    
              $get_subcate = $this->product_model->get_category_by_id($row['category_id']);
               if($get_subcate->num_rows() > 0){
                 $subcate_data=$get_subcate->row();
                 $category_name = $subcate_data->name;
              }
             }
            
            
            $data[] = array(
                "id" => $row['id'],
                "sku" => $row['model_number'],
                "title" => $row['title'],
                "category" => $row['category_id'],
                "category_name" => $category_name,  
                "category_label" => array(
                    "key" => $row['category_id']
                ),
                "base_price" => $row['base_price'],
                "discount_price" => $row['discount_price'],
                "gst" => (int)$row['gst'],
                "hsn" => $row['hsn'],
                "lenght" => $row['lenght'],
                "width" => $row['width'],
                "height" => $row['height'],
                "weight" => $row['weight'],
                "meta_title" => $row['meta_title'],
                "meta_keyword" => $row['meta_keyword'],
                "meta_description" => $row['meta_description'],
                "min_quantity" => $row['min_quantity'],
                "product_description" => $row['product_description'],
                "age_group" => $row['age_grade'],
                "is_exchange" => $row['is_exchange'],
                "day_exchange" => $row['day_exchange'],
                "highlights" => json_decode($row['highlights']),
                "warehouse_data" => $warehouse_data,
                "warehouse_data_default" => $warehouse_data_default,
                "warehouse_data_qty" => $warehouse_data_qty,
                "stock_data" => $stock_data,
                "products_images" => $products_images,
                "product_origin" => $row['product_origin'],
                "warehouse_list" => $warehouse_list,
                "warehouse_data_group" => $warehouse_data_group,
                "vendor_shipping_name" => $vendor_shipping_name,
                
            );
            
            
            $total_data = count($data);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $total_data
            );
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    
    
}