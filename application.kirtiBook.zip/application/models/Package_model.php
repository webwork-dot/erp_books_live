<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Package_model extends CI_Model
{
    
   public function get_product_by_category($category_id,$user_id)
    {
        //accessories and staionery no subcate
        if($category_id=='6'){
          $sql = $this->db->query("SELECT GROUP_CONCAT(`id`) AS ids FROM `categories` WHERE  parent_id='$category_id'");   
          if($sql->num_rows()>0){
              $irow=$sql->row_array();
              $parent_cid=$irow['ids'];
          }
          else{
              $parent_cid='0';
          }
        }
        
       
        //uniform
        if($category_id=='22'){
    		$this->db->select('p.id,p.title,p.model_number');
    	    $this->db->join('products_category','p.id=products_category.product_id'); 
            $this->db->join('categories','categories.id=products_category.category_id'); 
    		$this->db->where('p.visibility', 1);
    		$this->db->where('p.is_deleted', 0);
    		$this->db->where('p.user_id', $user_id);
            $this->db->where_in('categories.parent_id', $parent_cid);
    		$this->db->group_by('p.id');
    		$this->db->order_by('p.id', 'desc');
    		$query = $this->db->get('products as p');
        }
        else{
            $this->db->select('p.id,pm.title,p.model_number');
        	$this->db->join('product_master as pm','p.master_id=pm.id'); 
    	    $this->db->join('products_category','pm.id=products_category.product_id'); 
            $this->db->join('categories','categories.id=products_category.category_id'); 
    		$this->db->where('p.visibility', 1);
    		$this->db->where('p.is_deleted', 0);
    		$this->db->where('p.user_id', $user_id);
            $this->db->where_in('categories.parent_id', $category_id);
    		$this->db->group_by('p.id');	
    		$this->db->order_by('p.id', 'desc');
    		$query = $this->db->get('products as p');   
        }
        
        
        // echo $this->db->last_query();
       // exit();
        $count = $query->num_rows();
        
        
        $data = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = array(
                    "id" => $row['id'],
                    "title" => $row['title'],
                    "model_number" => $row['model_number']
                );
            }
        }
        
        $total_data = count($data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
   public function get_product_by_bookset_category($category_id,$user_id,$grade_id,$board_id)
    {
     
        // staionery no subcate
        
        if($category_id=='6'){
            $sql = $this->db->query("SELECT `id` FROM `categories` WHERE  parent_id='$category_id'")->result_array();  
            $parent_ids = array(); 
            if (sizeof($sql) > 0) {
                foreach ($sql as $row) {
                    if (!in_array($row['id'], $parent_ids)) {
                        array_push($parent_ids, $row['id']);
                    }
                }
            }
        }
        else{ $parent_ids='0';}
        // echo $this->db->last_query();
        // echo $parent_ids;
        // exit();
        
        if($category_id=='6'){
            $this->db->select('p.id,pm.title,p.model_number');
        	$this->db->join('product_master as pm','p.master_id=pm.id'); 
    	    $this->db->join('products_category','pm.id=products_category.product_id'); 
            $this->db->join('categories','categories.id=products_category.category_id'); 
    		$this->db->where('p.visibility', 1);
    		$this->db->where('p.status', 1);
    		$this->db->where('p.is_deleted', 0);
    		$this->db->where('p.user_id', $user_id);
            $this->db->where_in('categories.parent_id', $parent_ids);
    		$this->db->group_by('p.id');	
    		$this->db->order_by('p.id', 'desc');
    		$query = $this->db->get('products as p');  
    		
        }elseif($category_id=='8'){
            
            $where = "FIND_IN_SET('".$grade_id."', pm.grade_id)";
            $where2 = "FIND_IN_SET('".$board_id."', pm.board_id)";
            $this->db->select('p.id,pm.title,p.model_number');
        	$this->db->join('product_master as pm','p.master_id=pm.id'); 
    	    $this->db->join('products_category','pm.id=products_category.product_id'); 
            $this->db->join('categories','categories.id=products_category.category_id'); 
            $this->db->where( $where );
            $this->db->where( $where2 );
    		$this->db->where('p.visibility', 1);
    		$this->db->where('p.status', 1);
    		$this->db->where('p.is_deleted', 0);
    		$this->db->where('p.user_id', $user_id);
            // $this->db->where_in('categories.parent_id', $parent_ids);
    		$this->db->group_by('p.id');	
    		$this->db->order_by('p.id', 'desc');
    		$query = $this->db->get('products as p');  
            	
            
        }elseif($category_id=='45'){
            $where = "FIND_IN_SET('".$grade_id."', pm.grade_id)";
            $where2 = "FIND_IN_SET('".$board_id."', pm.board_id)";
            $this->db->select('p.id,pm.title,p.model_number');
        	$this->db->join('product_master as pm','p.master_id=pm.id'); 
    	    $this->db->join('products_category','pm.id=products_category.product_id'); 
            $this->db->join('categories','categories.id=products_category.category_id'); 
            $this->db->where( $where ); 
            $this->db->where( $where2 );
    		$this->db->where('p.visibility', 1);
    		$this->db->where('p.is_deleted', 0);
    		$this->db->where('p.status', 1);
    		$this->db->where('p.user_id', $user_id);
            // $this->db->where_in('categories.parent_id', $parent_ids);
    		$this->db->group_by('p.id');	
    		$this->db->order_by('p.id', 'desc');
    		$query = $this->db->get('products as p');  
    	
        }
        else{
            $this->db->select('p.id,pm.title,p.model_number');
        	$this->db->join('product_master as pm','p.master_id=pm.id'); 
    	    $this->db->join('products_category','pm.id=products_category.product_id'); 
            $this->db->join('categories','categories.id=products_category.category_id'); 
    		$this->db->where('p.visibility', 1);
    		$this->db->where('p.is_deleted', 0);
    		$this->db->where('p.status', 1);
    		$this->db->where('p.user_id', $user_id);
            $this->db->where('categories.parent_id', $category_id);
            //$this->db->where('find_in_set("'.$grade_id.'", pm.grade_id) <> 0');
    		$this->db->group_by('p.id');	
    		$this->db->order_by('p.id', 'desc');
    		$query = $this->db->get('products as p');   
        }
        
        
        // echo $this->db->last_query();
        // exit();
        
        $count = $query->num_rows();
        
         
        $data = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = array(
                    "id" => $row['id'],
                    "title" => $row['title'],
                    "model_number" => $row['model_number']
                );
            }
        }
        
        $total_data = count($data);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_package_name($category_id,$grade_id)
    {
        $sql1 = $this->db->query("SELECT name FROM `categories` WHERE id='$category_id' limit 1");   
        if($sql1->num_rows()>0){
            $irow1 = $sql1->row_array();
            $cat_name = $irow1['name'];
        }
        else{
            $cat_name='';
        }
        
        $sql2 = $this->db->query("SELECT name FROM `grade_list` WHERE id='$grade_id' limit 1");   
        if($sql2->num_rows()>0){
            $irow2 = $sql2->row_array();
            $grade_name = $irow2['name'];
        }
        else{
            $grade_name='';
        }
        
        return array(
            'status' => 200,
            'message' => 'true',
            'package_name' => $cat_name
        );
    }
    
    
     public function get_product_dprice($product_id,$user_id,$category_id)
    {
        $this->db->where('id', $product_id);
        $this->db->where('user_id', $user_id);
        $row = $this->db->get('products')->row_array();
        
        $this->db->where('id', $row['master_id']);
        $row2 = $this->db->get('product_master')->row_array();
        
        $master_id=$row['master_id'];
		$sql1 = $this->db->query("SELECT title FROM `product_master` WHERE id='$master_id' limit 1");   
		if($sql1->num_rows()>0){
			$irow1 = $sql1->row_array();
			$display_name = $irow1['title'];
		}
		else{
			$display_name='';
		}
        $wieght = $row2['weight'];
        if($wieght == '' || $wieght == 'null'){
            $wieght = '200';
        }
        
        return array(
            'status' => 200,
            'message' => 'true',
            'weight' => $wieght,
            'discount_price' => $row['discount_price'],
            'base_price' => $row['base_price'],
            'display_name' => $display_name
        );
    }
    
    public function get_service_categories()
    {
        $query = $this->db->query("SELECT id,name FROM categories WHERE visibility='1' AND parent_id='261' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        return array(
            'status' => 200,
            'message' => 'true',
            'data' => $data,
        );
    }
    
 
     public function get_categories()
    {
        $query = $this->db->query("SELECT id,name FROM categories WHERE visibility='1' AND is_bookset='1' order by name asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $name = $row['name'];
            
            $data[] = array(
                "id" => $id,
                "name" => $name
            );
        }
        
        return array(
            'status' => 200,
            'message' => 'true',
            'data' => $data,
        );
    }
    
}
