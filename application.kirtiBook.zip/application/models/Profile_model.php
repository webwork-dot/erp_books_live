<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_model extends CI_Model
{

	public function get_national_courier($user_id,$courier_type,$product_type)
    {
		if($product_type=='1'){
			$product_type = 'bookset';
		}
		else{
			$product_type = 'individual';
		}
        $this->db->select('id,min_kms,max_kms,min_kg,max_kg,charges,charges_0_500,charges_500_1000,charges_1000,last_modified');
		$this->db->order_by('id', 'asc');   
		$this->db->where('product_id', '0');
		$this->db->where('delivery_type', 'standard');
		$this->db->where('courier_type', $courier_type);
		$this->db->where('product_type', $product_type);
        $query = $this->db->get('courier_delivery_charges');
        $count = $query->num_rows(); 
        $data  = array();
		$sr_no = 1;
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = array(
					"sr_no" => $sr_no,
                    "id" => $row['id'],
                    "min_kms" => $row['min_kms'],
                    "max_kms" => $row['max_kms'],
                    "min_kg" => $row['min_kg'],
                    "max_kg" => $row['max_kg'],
                    "charges" => $row['charges'],
                    "charges_0_500" => $row['charges_0_500'],
                    "charges_500_1000" => $row['charges_500_1000'],
                    "charges_1000" => $row['charges_1000'],
                    "last_modified" => $row['last_modified']
                );
				$sr_no++;
            }
        } else {
            $data[] = array();
        }
        $total_data = count($data);
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
	
	public function update_courier_charges($user_id,$id,$charges)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date("Y-m-d H:m:s");
        $msg = '';        
        $pdata = array(
            'charges' => $charges,
			'last_modified' => $date
        ); 
        $this->db->where('id', $id);
        $this->db->update('courier_delivery_charges', $pdata);
           
        $msg = 'Success, Price Updated';
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    } 
	
    public function get_communication_details_by_id($user_id)
    {
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_communication_details');
        $count = $query->num_rows();
        $data  = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = array(
                    "id" => $row['id'],
                    "company_name" => $row['company_name'],
                    "person_name" => $row['person_name'],
                    "address" => $row['address'],
                    "state_id" => $row['state_id'],
                    "city_id" => $row['city_id'],
                    "city" => get_city_name($row['city_id']),
                    "state" => get_state_name($row['state_id']),
                    "pincode" => $row['pincode'],
                    "contact_number" => $row['contact_number'],
                    "location" => $row['location'],
                    "lattitude" => $row['lattitude'],
                    "longitude" => $row['longitude']
                );
            }
        } else {
            $data[] = array(
                "id" => '',
                "company_name" => '',
                "person_name" => '',
                "address" => '',
                "state_id" => '',
                "city_id" => '',
                "city" => '',
                "state" => '',
                "pincode" => '',
                "contact_number" => '',
                "location" => '',
                "lattitude" => '',
                "longitude" => ''
            );

        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }




    public function update_communication_details($user_id, $data)
    {
        date_default_timezone_set('Asia/Kolkata');
        $count = $this->db->get_where('vendor_communication_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count > 0) {
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->where('vendor_id', $user_id);
            $this->db->update('vendor_communication_details', $data);

            $data2['firm_name'] = $data['company_name'];
            $this->db->where('id', $user_id);
            $this->db->update('users', $data2);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $data['vendor_id']     = $user_id;
            $data['added_date']    = date('Y-m-d H:i:s');
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->insert('vendor_communication_details', $data);

            $data2['firm_name'] = $data['company_name'];
            $this->db->where('id', $user_id);
            $this->db->update('users', $data2);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        }
        return $resultpost;

    }


    public function get_billing_details_by_id($user_id)
    {
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_billing_details');
        $count = $query->num_rows();
        $data  = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = array(
                    "id" => $row['id'],
                    "address" => $row['address'],
                    "state_id" => $row['state_id'],
                    "city_id" => $row['city_id'],
                    "city" => get_city_name($row['city_id']),
                    "state" => get_state_name($row['state_id']),
                    "pincode" => $row['pincode'],
                    "contact_number" => $row['contact_number'],
                    "pan" => $row['pan'],
                    "gst" => $row['gst'],
                    "location" => $row['location'],
                    "lattitude" => $row['lattitude'],
                    "longitude" => $row['longitude']
                );
            }
        } else {
            $data[] = array(
                "id" => '',
                "address" => '',
                "state_id" => '',
                "city_id" => '',
                "city" => '',
                "state" => '',
                "pincode" => '',
                "contact_number" => '',
                "pan" => '',
                "gst" => '',
                "location" => '',
                "lattitude" => '',
                "longitude" => ''
            );

        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }



    public function update_billing_details($user_id, $data, $data2)
    {
        date_default_timezone_set('Asia/Kolkata');
        $count = $this->db->get_where('vendor_billing_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count > 0) {
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->where('vendor_id', $user_id);
            $this->db->update('vendor_billing_details', $data);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $data['pan']           = $data2['pan'];
            $data['gst']           = $data2['gst'];
            $data['vendor_id']     = $user_id;
            $data['added_date']    = date('Y-m-d H:i:s');
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->insert('vendor_billing_details', $data);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        }
        return $resultpost;

    }



    public function get_bank_details_by_id($user_id)
    {
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_bank_details');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "bank_id" => $row['bank_id'],
                "bank" => get_bank_name($row['bank_id']),
                "branch" => $row['branch'],
                "ifsc_code" => $row['ifsc_code'],
                "account_no" => $row['account_no']
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }





    public function update_bank_details($user_id, $data)
    {
        date_default_timezone_set('Asia/Kolkata');
        $count = $this->db->get_where('vendor_bank_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count > 0) {
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->where('vendor_id', $user_id);
            $this->db->update('vendor_bank_details', $data);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        } else {
            $data['vendor_id']     = $user_id;
            $data['added_date']    = date('Y-m-d H:i:s');
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->insert('vendor_bank_details', $data);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        }
        return $resultpost;

    }



    public function get_shipping_list($user_id)
    {
        $this->db->where('is_deleted', 0);
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_shipping_details');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            if($row['name'] != ''){
                $name =  $row['name'];
            }else{
                $name =  '-';
            }

            $data[] = array(
                "id" => $row['id'],
                "address" => $row['address'],
                "landmark" => $row['landmark'],
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id']),
                "pincode" => $row['pincode'],
                "contact_number" => $row['contact_number'],
                "location" => $row['location'],
                "lattitude" => $row['lattitude'],
                "longitude" => $row['longitude'],
                "name" => $row['name'],
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }





    public function get_shipping_details_by_id($user_id, $id)
    {
        $this->db->where('is_deleted', 0);
        $this->db->where('id', $id);
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_shipping_details');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "address" => $row['address'],
                "landmark" => $row['landmark'],
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id']),
                "pincode" => $row['pincode'],
                "contact_number" => $row['contact_number'],
                "location" => $row['location'],
                "lattitude" => $row['lattitude'],
                "longitude" => $row['longitude'],
                "name" => $row['name'],
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }


    public function add_shipping_details($user_id, $data)
    {
        date_default_timezone_set('Asia/Kolkata');
        $data['vendor_id']     = $user_id;
        $data['added_date']    = date('Y-m-d H:i:s');
        $data['last_modified'] = date('Y-m-d H:i:s');
        $this->db->insert('vendor_shipping_details', $data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;
    }


    public function update_shipping_details($user_id, $data, $id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $data['last_modified'] = date('Y-m-d H:i:s');
        $this->db->where('vendor_id', $user_id);
        $this->db->where('id', $id);
        $this->db->update('vendor_shipping_details', $data);
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;
    }

    public function shipping_delete($user_id, $id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $data['is_deleted']    = 1;
        $data['last_modified'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        $result = $this->db->update('vendor_shipping_details', $data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }




    public function get_vendors_by_id($user_id)
    {
        $result = $this->get_vendor_progress($user_id);

        $this->db->where('role', 'vendor');
        $this->db->where('id', $user_id);
        $query = $this->db->get('users');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {

            $logo_ = $row['logo'];
            if ($logo_ != '') {
                $logo = vendor_url() . $row['logo'];
            } else {
                $logo = '';
            }

            $data[] = array(
                "id" => $row['id'],
                "username" => $row['username'],
                "email" => $row['email'],
                "phone" => $row['phone_number'],
                "firm_name" => $row['firm_name'],
                "vendor_aproval" => $row['vendor_aproval'],
                "progress" => $result['data']['0']['progress'],
                "logo" => $logo
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data,
            "vendor_aproval" => $data[0]['vendor_aproval']
        );
        return $resultpost;
    }

    public function get_vendor_details($user_id,$staff_id)
    {
        $result = $this->get_vendor_progress($user_id);

        $this->db->where('role', 'vendor');
        $this->db->where('id', $user_id);
        $query = $this->db->get('users');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {

            $logo_ = $row['logo'];
            if ($logo_ != '') {
                $logo = vendor_url() . $row['logo'];
            } else {
                $logo = '';
            }

            if($staff_id > 0){
                $this->db->where('role', 'staff');
                $this->db->where('id', $staff_id);
                $query_staff = $this->db->get('users');
                $row_staff = $query_staff->row_array();

                $access_manager = explode(',',$row_staff['access_manager']);
            }else{
                $access_manager = array();
            }


            $data[] = array(
                "id" => $row['id'],
                "username" => $row['username'],
                "email" => $row['email'],
                "phone" => $row['phone_number'],
                "firm_name" => $row['firm_name'],
                "vendor_aproval" => $row['vendor_aproval'],
                "progress" => $result['data']['0']['progress'],
                "logo" => $logo,
                "access_manager" => $access_manager,
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data,
            "vendor_aproval" => $data[0]['vendor_aproval']
        );
        return $resultpost;
    }




    public function update_profile($user_id, $data)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->db->where('id', $user_id);
        $this->db->update('users', $data);

         $where = '(role="vendor" or role = "staff")';
        $this->db->where($where);
        $this->db->where('id', $user_id);
        $user = $this->db->get('users')->row();

        if($user->role == 'staff'){
            $user_id = $user->vendor_id ;
            $staff_id = $user->id ;
            $vendor  = $this->LoginModel->get_user($user->vendor_id);
            $firm_name = $vendor->firm_name;
        }else{
            $user_id = $user->id ;
            $staff_id = 0 ;
            $firm_name = $user->firm_name;
        }


        $data2[] = array(
            "user_id" => $user_id,
            "staff_id" => $staff_id,
            "user_name" => ucfirst($user->username),
            "email" => $user->email,
            "phone" => $user->phone_number,
            "firm_name" => $firm_name,
            "logo" => 'https://api.kirtibook.in/vendor/v1/uploads/logo/' . $user->logo
            );

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data2
        );

        return $resultpost;
    }

    public function profile_details($user_id)
    {

        $this->db->where('role', 'vendor');
        $this->db->where('id', $user_id);
        $user = $this->db->get('users')->row();

        $query = $this->db->get_where('users', array(
            'id' => $user_id,
            'role' => 'vendor'
        ));
        $info  = $query->row_array();

        if ($info['logo'] != '') {
            $logo[] = array(
                "file_url" => vendor_url() . $info['logo']
            );
        } else {
            $logo = array();
        }

        $data2[] = array(
            "user_id" => $info['id'],
            "user_name" => $info['username'],
            "email" => $info['email'],
            "phone" => $info['phone_number'],
            "firm_name" => $info['firm_name'],
            "logo" => $logo
        );

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data2
        );

        return $resultpost;
    }



    //change password
    public function change_password($user_id, $data)
    {
        $this->load->library('bcrypt');
        $where = '(role="vendor" or role="staff")';
        $this->db->where($where);
        $this->db->where('id', $user_id);
        $user = $this->db->get('users')->row();


        //password does not match stored password.
        if (!$this->bcrypt->check_password($data['old_password'], $user->password)) {
            $resultpost = array(
                'status' => 400,
                'message' => 'Wrong old password!'
            );
        } else {
            $data2 = array(
                'password' => $this->bcrypt->hash_password($data['password'])
            );

            $this->db->where('id', $user_id);
            $this->db->update('users', $data2);

            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        }

        return $resultpost;

    }


    public function get_vendor_progress_for_dashboard($user_id)
    {

        $communication_details = $shipping_details = 0;

        $this->db->select('id');
        $count2 = $this->db->get_where('vendor_communication_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count2 > 0) {
            $communication_details = 1;
        }

        $this->db->select('id');
        $count4 = $this->db->get_where('vendor_shipping_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count4 > 0) {
            $shipping_details = 1;
        }


        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            "communication_details" => $communication_details,
            "shipping_details" => $shipping_details,
        );
        return $resultpost;
    }


    public function get_vendor_progress($user_id)
    {


        $step1 = 10;
        $step2 = 0;
        $step3 = 0;
        $step4 = 0;
        $step5 = 0;
        $step6 = 0;
        $step7 = 0;
        $total = 0;
        $progress_array=array();
        $communication_details = $billing_details = $shipping_details = $bank_details = $vendor_documents = $vendor_commission = 0;

        $user = $this->common_model->get_user_by_id($user_id);

        $this->db->select('id');
        $count7 = $this->db->get_where('vendor_commission', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count7 > 0) {
            $step7             = 15;
            $vendor_commission = 1;
        }

        $progress_array[]=array(
            'step' => 'Manage Category',
            'value' => $vendor_commission,
            'link' => '/settings/category-select',
        );

        $this->db->select('id');
        $count2 = $this->db->get_where('vendor_communication_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count2 > 0) {
            $step2                 = 15;
            $communication_details = 1;
        }

        $progress_array[]=array(
            'step' => 'Communication Details',
            'value' => $communication_details,
            'link' => '/settings/communication-details-update',
        );


        $this->db->select('id');
        $count3 = $this->db->get_where('vendor_billing_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count3 > 0) {
            $step3           = 15;
            $billing_details = 1;
        }

        $progress_array[]=array(
            'step' => 'Billing Details',
            'value' => $billing_details,
            'link' => '/settings/billing-details-update',
        );

        $this->db->select('id');
        $count4 = $this->db->get_where('vendor_shipping_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        $link = '/settings/add-shipping';

        if ($count4 > 0) {
            $step4            = 15;
            $shipping_details = 1;
            $link = '/settings/shipping';
        }


        $progress_array[]=array(
            'step' => 'Warehouse Details',
            'value' => $shipping_details,
            'link' => $link,
        );

        $this->db->select('id');
        $count5 = $this->db->get_where('vendor_bank_details', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count5 > 0) {
            $step5        = 15;
            $bank_details = 1;
        }

        $progress_array[]=array(
            'step' => 'Bank Details',
            'value' => $bank_details,
            'link' => '/settings/bank-details-update',
        );

        $this->db->select('id');
        $count6 = $this->db->get_where('vendor_documents', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count6 > 0) {
            $step6            = 15;
            $vendor_documents = 1;
        }

        $progress_array[]=array(
            'step' => 'Upload Documents',
            'value' => $vendor_documents,
            'link' => '/settings/upload-document-update',
        );





        $total = $step1 + $step2 + $step3 + $step4 + $step5 + $step6 + $step7;


        $data[] = array(
            "progress" => $total
        );
        $logo_  = $user->logo;
        if ($logo_ != '') {
            $logo = vendor_url() . $logo_;
        } else {
            $logo = '';
        }

        usort($progress_array, function($a, $b) {
            $timeStamp1 = $a['value'];
            $timeStamp2 = $b['value'];
            return  $timeStamp2-$timeStamp1;
        });
        $vendor_aproval  = $user->vendor_aproval;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'progress_array' => $progress_array,
            'data' => $data,
            "logo" => $logo,
            "communication_details" => $communication_details,
            "billing_details" => $billing_details,
            "shipping_details" => $shipping_details,
            "bank_details" => $bank_details,
            "vendor_documents" => $vendor_documents,
            "vendor_commission" => $vendor_commission,
            "vendor_aproval" => $vendor_aproval
        );
        return $resultpost;
    }





    public function get_category_details_by_id($user_id)
    {
        $this->db->where('is_display', '1');
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_commission');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $cat_id = $row['category_id'];
            $query2 = $this->db->query("SELECT slug FROM `categories` where id='$cat_id' limit 1");
            $count2 = $query2->num_rows();
            $slug='';

            $query3 = $this->db->query("SELECT is_sort FROM `vendor_commission_category` where category_id='$cat_id'  limit 1");
            $row3   = $query3->row_array();
            $is_sort   = $row3['is_sort'];
            if($count2>0){
                $row_cat = $query2->row_array();
                $slug    = $row_cat['slug'];
            }
            $data[] = array(
                "id" => $row['id'],
                "slug" => $slug,
                "is_sort" => $is_sort,
                "category_id" => $row['category_id'],
                "category_name" => $row['category_name']
            );
        }

        $total_data = count($data);

        usort($data, function($a, $b) {
            $timeStamp1 = $a['is_sort'];
            $timeStamp2 = $b['is_sort'];
            return  $timeStamp1-$timeStamp2;
        });

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_school_category($user_id)
    {
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_commission');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $cat_id = $row['category_id'];
            $query2 = $this->db->query("SELECT slug FROM `categories` where id='$cat_id' limit 1");
            $count2 = $query2->num_rows();
            $slug='';

            $query3 = $this->db->query("SELECT is_sort FROM `vendor_commission_category` where category_id='$cat_id' limit 1");
            $row3   = $query3->row_array();
            $is_sort   = $row3['is_sort'];
            if($count2>0){
                $row_cat = $query2->row_array();
                $slug    = $row_cat['slug'];
            }
            if($row['category_id'] == '7' || $row['category_id'] == '22' ){
                 if($row['category_id'] == '7'){
                     $category_name = 'School For Bookset';
                 }
                 if($row['category_id'] == '22'){
                     $category_name = 'School For Uniform';
                 }

                $data[] = array(
                    "id" => $row['id'],
                    "slug" => $slug,
                    "is_sort" => $is_sort,
                    "category_id" => $row['category_id'],
                    "category_name" => $category_name
                );
            }
        }

        $total_data = count($data);

        usort($data, function($a, $b) {
            $timeStamp1 = $a['is_sort'];
            $timeStamp2 = $b['is_sort'];
            return  $timeStamp1-$timeStamp2;
        });

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }


    public function get_vendor_commission_category($user_id = "")
    {
        $query = $this->db->query("SELECT * FROM vendor_commission_category WHERE is_display='1' order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $category_id = $row['category_id'];
            $name        = $row['name'];

            $data[] = array(
                "category_id" => $category_id,
                "name" => $name
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }




    public function check_vendor_commission($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $count = $this->db->get_where('vendor_commission', array(
            'vendor_id' => $user_id
        ))->num_rows();
        if ($count > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function update_category_details($user_id, $categories)
    {
        date_default_timezone_set('Asia/Kolkata');

        foreach ($categories as $category_id) {
            $data['vendor_id']     = $user_id;
            $data['category_id']   = $category_id;
            $data['category_name'] = get_category_name($category_id);
            $data['added_date']    = date('Y-m-d H:i:s');
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->insert('vendor_commission', $data);
            if($category_id=='7'){
                $data_1['vendor_id']     = $user_id;
                $data_1['category_id']   = '6';
                $data_1['category_name'] = get_category_name('6');
                $data_1['added_date']    = date('Y-m-d H:i:s');
                $data_1['last_modified'] = date('Y-m-d H:i:s');
                $this->db->insert('vendor_commission', $data_1);

                $data_3['vendor_id']     = $user_id;
                $data_3['category_id']   = '46';
                $data_3['category_name'] = get_category_name('46');
                $data_3['added_date']    = date('Y-m-d H:i:s');
                $data_3['last_modified'] = date('Y-m-d H:i:s');
                $data_3['is_display'] ='0';
                $this->db->insert('vendor_commission', $data_3);
            }

            if($category_id=='22'){
                $data_2['vendor_id']     = $user_id;
                $data_2['category_id']   = '382';
                $data_2['category_name'] = get_category_name('382');
                $data_2['added_date']    = date('Y-m-d H:i:s');
                $data_2['last_modified'] = date('Y-m-d H:i:s');
                $data_2['is_display'] ='0';
                $this->db->insert('vendor_commission', $data_2);
            }
        }

        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;

    }



    public function get_upload_document_details($user_id)
    {
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_documents');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $data[] = array(
                "id" => $row['id'],
                "gst_certificate" => $row['gst_certificate'],
                "pan" => $row['pan'],
                "cancel_cheque" => $row['cancel_cheque'],
                "signature" => $row['signature']
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }




    public function get_vendor_documents_by_id($user_id)
    {

        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_documents');
        $count = $query->num_rows();
        $data  = array();
        $row   = $query->row_array();
        if ($count > 0) {

            $gst_certificate = $row['gst_certificate'];
            $pan             = $row['pan'];
            $cancel_cheque   = $row['cancel_cheque'];
            $signature       = $row['signature'];


            if ($gst_certificate == 'null' || !$gst_certificate) {
                $gst_certificate = '';
            }
            if ($pan == 'null' || !$pan) {
                $pan = '';
            }
            if ($cancel_cheque == 'null' || !$cancel_cheque) {
                $cancel_cheque = '';
            }
            if ($signature == 'null' || !$signature) {
                $signature = '';
            }

        } else {
            $gst_certificate = '';
            $pan             = '';
            $cancel_cheque   = '';
            $signature       = '';
        }



        $data[] = array(
            "id" => $row['id'],
            "gst_certificate" => $gst_certificate,
            "pan" => $pan,
            "cancel_cheque" => $cancel_cheque,
            "signature" => $signature
        );


        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;

    }


    public function upload_document_details($user_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');

        $row         = $this->db->get_where('vendor_documents', array(
            'vendor_id' => $user_id
        ))->row();
        $count       = $this->db->get_where('vendor_documents', array(
            'vendor_id' => $user_id
        ))->num_rows();
        $upload_path = vendor_download_url().'/uploads/vendor/';

        if (isset($_FILES['file1']) && is_uploaded_file($_FILES['file1']['tmp_name'])) {
            $ext1                    = pathinfo($_FILES['file1']['name'], PATHINFO_EXTENSION);
            $data['gst_certificate'] = 'gst_' . generate_unique_id() . '.' . $ext1;
            move_uploaded_file($_FILES['file1']['tmp_name'], $upload_path . $data['gst_certificate']);
            if ($count > 0):
                $this->upload_model->delete_temp_image($upload_path . $row->gst_certificate);
            endif;
        }

        if (isset($_FILES['file2']) && is_uploaded_file($_FILES['file2']['tmp_name'])) {
            $ext2        = pathinfo($_FILES['file2']['name'], PATHINFO_EXTENSION);
            $data['pan'] = 'pan_' . generate_unique_id() . '.' . $ext2;
            move_uploaded_file($_FILES['file2']['tmp_name'], $upload_path . $data['pan']);
            if ($count > 0):
                $this->upload_model->delete_temp_image($upload_path . $row->pan);
            endif;
        }

        if (isset($_FILES['file3']) && is_uploaded_file($_FILES['file3']['tmp_name'])) {
            $ext3                  = pathinfo($_FILES['file3']['name'], PATHINFO_EXTENSION);
            $data['cancel_cheque'] = 'cheque_' . generate_unique_id() . '.' . $ext3;
            move_uploaded_file($_FILES['file3']['tmp_name'], $upload_path . $data['cancel_cheque']);
            if ($count > 0):
                $this->upload_model->delete_temp_image($upload_path . $row->cancel_cheque);
            endif;
        }


        if (isset($_FILES['file4']) && is_uploaded_file($_FILES['file4']['tmp_name'])) {
            $ext4              = pathinfo($_FILES['file4']['name'], PATHINFO_EXTENSION);
            $data['signature'] = 'signature_' . generate_unique_id() . '.' . $ext4;
            move_uploaded_file($_FILES['file4']['tmp_name'], $upload_path . $data['signature']);
            if ($count > 0):
                $this->upload_model->delete_temp_image($upload_path . $row->signature);
            endif;
        }



        if ($count > 0) {
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->where('vendor_id', $user_id);
            $this->db->update('vendor_documents', $data);
        } else {
            $data['vendor_id']     = $user_id;
            $data['added_date']    = date('Y-m-d H:i:s');
            $data['last_modified'] = date('Y-m-d H:i:s');
            $this->db->insert('vendor_documents', $data);
        }

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }



    public function add_school($data)
    {
        date_default_timezone_set('Asia/Kolkata');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $data['created_at'] = date('Y-m-d H:i:s');
        $this->db->insert('school', $data);
        $school_id  = $this->db->insert_id();
        
        $email = $data['school_email'];
        $vendor_id = $data['vendor_id'];
        $password = $data['password']; 
        
        // check for multi school login 
        $rows = $this->db->query("SELECT id,school_id FROM `school_login` WHERE email='$email' limit 1");
        if ($rows->num_rows() > 0) {
            $row_y = $rows->row_array();
            $curr_school_id = $row_y['school_id'];
            
            // Check if $id already exists in $curr_school_id
            if (strpos($curr_school_id, $school_id) !== false) {
                // $id exists in the list, update password
                $this->db->set('password', $password);
                $this->db->where('email', $email);
                $this->db->update('school_login');
            } else {
                // Append $id to $curr_school_id
                $updated_school_id = $curr_school_id . ',' . $school_id;
                // Update password and school_id
                $this->db->set('password', $password);
                $this->db->set('school_id', $updated_school_id);
                $this->db->where('email', $email);
                $this->db->update('school_login');
            }
        }
        else{
            $data_school = array(
                'vendor_id' => $vendor_id,
                'school_id' => $school_id,
                'email' => $email,
                'password' => $password,
                'is_active' => 1,
                'added_date' => date('Y-m-d H:i:s')
            );
            $this->db->insert('school_login', $data_school);
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $school_id
        );
        return $resultpost;
    }


    public function update_school($data, $id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        $this->db->update('school', $data);
        
        $email = $data['school_email'];
        $vendor_id = $data['vendor_id'];
        $password = $data['password'];
        
        // check for multi school login 
        $rows = $this->db->query("SELECT id,school_id FROM `school_login` WHERE email='$email' limit 1");
        if ($rows->num_rows() > 0) {
            $row_y = $rows->row_array();
            $curr_school_id = $row_y['school_id'];
            
            // Check if $id already exists in $curr_school_id
            if (strpos($curr_school_id, $id) !== false) {
                // $id exists in the list, update password
                $this->db->set('password', $password);
                $this->db->where('email', $email);
                $this->db->update('school_login');
            } else {
                // Append $id to $curr_school_id
                $updated_school_id = $curr_school_id . ',' . $id;
                // Update password and school_id
                $this->db->set('password', $password);
                $this->db->set('school_id', $updated_school_id);
                $this->db->where('email', $email);
                $this->db->update('school_login');
            }
        }
        else{
            $data_school = array(
                'vendor_id' => $vendor_id,
                'school_id' => $id,
                'email' => $email,
                'password' => $password,
                'is_active' => 1,
                'added_date' => date('Y-m-d H:i:s')
            );
            $this->db->insert('school_login', $data_school);
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $id
        );
        return $resultpost;
    }



    public function upload_school_images($user_id, $pid)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');

        $row         = $this->db->get_where('school', array(
            'id' => $pid
        ))->row();
        $count       = $this->db->get_where('school', array(
            'id' => $pid
        ))->num_rows();
        $upload_path = './uploads/school/';


        if (isset($_FILES['file1']) && is_uploaded_file($_FILES['file1']['tmp_name'])) {
            $temp_path = $this->upload_model->upload_temp_image('file1');
            if (!empty($temp_path)) {
                //delete old avatar
                $data["avatar"] = $this->upload_model->school_image_upload($temp_path);
                $this->upload_model->delete_temp_image($temp_path);
                if ($count > 0):
                    $this->upload_model->delete_temp_image($row->avatar);
                endif;

                $this->db->where('id', $pid);
                $this->db->update('school', $data);
            }
        }


        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }

    public function get_customer_list($filter, $per_page, $offset)
    {
        $keywords_filter = "";
        if (isset($filter['keyword']) && $filter['keyword'] != ""):
            $keyword         = $filter['keyword'];
            $keywords_filter = " AND (username like '%$keyword%' or phone_number like '%$keyword%' or email like '%$keyword%')";
        endif;

        $rows = $this->db->query("SELECT `id` FROM `users` WHERE role='member' $keywords_filter ORDER BY id DESC");
        $data  = array();
        $count = $rows->num_rows();
        if($count>0){
            $query = $this->db->query("SELECT id,username,email,phone_number,created_at FROM `users` WHERE role='member' $keywords_filter ORDER BY id DESC LIMIT $offset,$per_page");
            foreach ($query->result_array() as $row) {
                $created_at=$row['created_at'];
                $created_at=date('d M Y h:i A', strtotime($created_at));
                $data[] = array(
                    "id" => $row['id'],
                    "name" => $row['username'],
                    "email" => $row['email'],
                    "phone_number" => $row['phone_number'],
                    "created_at" => $created_at
                );
            }
        }



        $total_data = $count;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_student_list($filter, $per_page, $offset)
    {
        $keywords_filter = "";
        $grade_filter        = "";
        $grade_filter        = "";
        $academic_year_filter ="";
        $date_range="";

        if (isset($filter['user_id']) && $filter['user_id'] != ""):
            $user_id         = $filter['user_id'];
            $keywords_filter = " AND vendor_id = '$user_id'";
        endif;

        if (isset($filter['keyword']) && $filter['keyword'] != ""):
            $keyword         = $filter['keyword'];
            $keywords_filter = " AND f_name like '%$keyword%'";
        endif;

        if(isset($filter['keyword']) && $filter['keyword']!="") :
          $keyword=trim($filter['keyword']);
          $keyword_filter =" AND (f_name like '%".$keyword."%'
          or m_name like '%".$keyword."%'
          or s_name like '%".$keyword."%'
          or school_name like '%".$keyword."%')";
        endif;

         if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""){
            $date_range = $filter['academic_year'];
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        }
        else{
            $queryd = $this->db->query("SELECT year,date_range FROM oc_academic_year order by sort asc limit 1");
            $row_y = $queryd->row_array();
            $date_range = $row_y['date_range'];
            $academic_year        = explode(" - ", $date_range);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        }

        $rows = $this->db->query("SELECT id FROM `orders` WHERE order_type='bookset' and payment_status='payment_received' AND order_status != 'cancelled' $keywords_filter $grade_filter $school_filter $academic_year_filter ORDER BY id DESC");

        $query = $this->db->query("SELECT id,school_name,grade_name,board_name,f_name,m_name,s_name,dob,phone_number FROM `orders` WHERE order_type='bookset' and payment_status='payment_received' AND order_status != 'cancelled' $keywords_filter $grade_filter $school_filter $academic_year_filter ORDER BY id DESC LIMIT $offset,$per_page");

        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $dob=$row['dob'];
            $name=$row['f_name'];
            if($row['m_name']!=''){
                $name.=' '.$row['m_name'];
            }
            $name.=' '.$row['s_name'];

            $dob='';
            if($row['dob']!=''){
                $dob=date('d M Y', strtotime($row['dob']));
            }

            $data[] = array(
                "id" => $row['id'],
                "name" => $name,
                "dob" => $dob,
                "phone_number" => $row['phone_number'],
                "school_name" => $row['school_name'],
                "board_name" => $row['board_name'],
                "grade_name" => $row['grade_name']
            );
        }

        $total_data = $count;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'date_range' => $date_range,
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_school_list($filter, $per_page, $offset)
    {
        $keywords_filter = "";

        if (isset($filter['user_id']) && $filter['user_id'] != ""):
            $user_id         = $filter['user_id'];
            $keywords_filter = " AND vendor_id = '$user_id'";
        endif;
        if (isset($filter['keyword']) && $filter['keyword'] != ""):
            $keyword         = $filter['keyword'];
            $keywords_filter = " AND name like '%$keyword%'";
        endif;

        $status_filter='';
        if (isset($filter['status']) && $filter['status'] != ""):
            $status = $filter['status'];
            if($status=='active'){
                $status_filter = " AND status='1'";
            }
            else if($status=='inactive'){
                $status_filter = " AND status='0'";
            }
        endif;

        $rows = $this->db->query("SELECT `id` FROM `school` WHERE  id!='' $keywords_filter $status_filter ORDER BY id DESC");

        $query = $this->db->query("SELECT is_block_payment,is_national_block,`id`, `avatar`,`category`, `vendor_id`, `name`, `board`, `strength`,  `state_id`, `city_id`, `affiliation_no`, `school_person`, `school_email`, `school_phone`, `status`, `pending` FROM `school` WHERE  id!='' $keywords_filter $status_filter ORDER BY id DESC LIMIT $offset,$per_page");

        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {

            $get_board = $this->product_model->get_board_list($row['board']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = '-';
            }
            if($row['category'] != ''){
                $category = explode(',',$row['category']);
            }else{
                $category = '';
            }

            $comma = '';
            $category_name = '';
            if(!empty($category)){
                foreach($category as $category_id){
                    if($category_id == '7'){
                        $category_name_ = 'School For Bookset';
                    }
                    if($category_id == '22'){
                        $category_name_ = 'School For Uniform';
                    }
                    $category_name .= $comma.$category_name_;
                    $comma = ', ';
                }
            }

            $avatar = $row['avatar'];
            if (file_exists($avatar)) {
                $image_url = vendor_url() . $avatar;
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }

            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "board" => $board,
                "strength" => $row['strength'],
                "affiliation_no" => $row['affiliation_no'],
                "school_person" => $row['school_person'],
                "school_email" => $row['school_email'],
                "school_phone" => $row['school_phone'],
                "is_block_payment" => $row['is_block_payment'],
                "is_national_block" => $row['is_national_block'],
                "status" => $row['status'],
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "category_name" => $category_name,
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id'])
            );
        }

        $total_data = $count;
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'data' => $data
        );
        return $resultpost;
    }

    public function update_school_block($user_id,$master_id,$status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date("Y-m-d H:m:s");
        if($status==true){
            $status=1;
        }else{
            $status=0;
        }
        $pdata = array(
            'is_block_payment' => $status
        );
        $this->db->where('id', $master_id);
        $this->db->update('school', $pdata);

        if($status==1){
            $msg = 'Success!! Payment Is Block';
        }else{
            $msg = 'Success!! Payment Is Active';
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }



    public function update_national_block($user_id,$master_id,$status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date("Y-m-d H:m:s");
        if($status==true){
            $status=1;
        }else{
            $status=0;
        }
        $pdata = array(
            'is_national_block' => $status
        );
        $this->db->where('id', $master_id);
        $this->db->update('school', $pdata);

        if($status==1){
            $msg = 'Success!! National Delivery Is Block';
        }else{
            $msg = 'Success!! National Delivery Is Active';
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }



    public function update_school_status($user_id,$master_id,$status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date("Y-m-d H:m:s");
        if($status==true){
            $status=1;
        }else{
            $status=0;
        }
        $pdata = array(
            'status' => $status
        );
        $this->db->where('id', $master_id);
        $this->db->update('school', $pdata);

        if($status==1){
            $msg = 'Success! Status Is Active';
        }else{
            $msg = 'Success! Status Is In-Active';
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }

    public function get_school_details($id)
    {
        $query = $this->db->query("SELECT `id`, `address`,`principal_name`,`principal_email`,`principal_phone`, `category`, `location`,`lattitude`, `longitude`,`pincode`,`avatar`, `vendor_id`, `name`, `board`, `strength`,  `state_id`, `city_id`, `affiliation_no`,`description`, `school_person`, `school_email`, `school_phone`, `status`, `pending`,`password` FROM `school` WHERE  id='$id' LIMIT 1");

        $data = array();
        foreach ($query->result_array() as $row) {

            $get_board = $this->product_model->get_board_list($row['board']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = '-';
            }
            if($row['category'] != ''){
                $category = explode(',',$row['category']);
            }else{
                $category = '';
            }
            $category_name = '';
            $comma = '';
            foreach($category as $category_id){
                if($category_id == '7'){
                    $category_name_ = 'School For Bookset';
                }
                if($category_id == '22'){
                    $category_name_ = 'School For Uniform';
                }
                $category_name .= $comma.$category_name_;
                $comma = ', ';
            }


            $avatar = $row['avatar'];

            /*if (file_exists($avatar)) {
                $image_url = vendor_url(). $avatar;
            } else {
                $image_url = '';
            }*/

            if ($avatar!='') {
                $image_url = vendor_url(). $avatar;
            } else {
                $image_url = '';
            }



            if ($row['status'] == '0' && $row['pending'] == '0') {
                $status = 0;
            } elseif ($row['status'] == '0' && $row['pending'] == '1') {
                $status = 1;
            } else {
                $status = 2;
            }


            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "board" => explode(",", $row['board']),
                "category" => explode(",", $row['category']),
                "category_name" => $category_name,
                "board_name" => $board,
                "avatar" => $image_url,
                "strength" => $row['strength'],
                "affiliation_no" => $row['affiliation_no'],
                "description" => $row['description'],
                "school_person" => $row['school_person'],
                "school_email" => $row['school_email'],
                "school_phone" => $row['school_phone'],
                "status" => $status,
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "address" => $row['address'],
                "location" => $row['location'],
                "lattitude" => $row['lattitude'],
                "longitude" => $row['longitude'],
                "pincode" => $row['pincode'],
                "school_status" => $row['status'],
                "principal_name" => $row['principal_name'],
                "principal_email" => $row['principal_email'],
                "principal_phone" => $row['principal_phone'],
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id']),

            );
        }

        $total_data = 1;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function upload_vendor_logo($product_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');

        $row         = $this->db->get_where('users', array(
            'id' => $product_id
        ))->row();
        $count       = $this->db->get_where('users', array(
            'id' => $product_id
        ))->num_rows();

        if (isset($_FILES['images']) && is_uploaded_file($_FILES['images']['tmp_name'])) {
            $temp_path = $this->upload_model->upload_temp_image('images');
            if (!empty($temp_path)) {
                //delete old avatar
                $data["avatar"] = $this->upload_model->vendor_image_upload($temp_path);

                    $data = array(
                         'logo' => $this->upload_model->vendor_image_upload($temp_path)
                    );
                    $this->upload_model->delete_temp_image($temp_path);
                    $this->db->where('id', $product_id);
                    $this->db->update('users', $data);

                if ($count > 0):
                    $this->upload_model->delete_temp_image($row->logo);
                endif;

            }
        }




        //$resultpost = array(
        //    'status' => 200,
        //    'message' => 'success'
        //);
        //return $resultpost;
    }

    public function get_vendor_logo_by_id($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('users');
        return $query->row();
    }

    public function vendor_logo_delete($id)
    {
        $this->load->model('upload_model');
        date_default_timezone_set('Asia/Kolkata');
        $upload_path = './uploads/logo/';

        $product = $this->get_vendor_logo_by_id($id);

        $temp_path = $upload_path . $product->logo;
        $this->upload_model->delete_temp_image($temp_path);
        $data = array(
            'logo' => ''
        );
        $this->db->where('id', $id);
        $this->db->update('users', $data);


        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }




    public function get_product_by_category($user_id, $category_id)
    {
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_communication_details');

        $query = $this->db->query("SELECT `id`,`title`, `model_number` FROM `products` WHERE user_id='$user_id' AND `parent_cid`='$category_id'");
        $count = $query->num_rows();


        $data = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = array(
                    "id" => $row['id'],
                    "name" => $row['title']
                );
            }
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }




    public function get_product_dprice($product_id)
    {
        $this->db->where('id', $product_id);
        $row = $this->db->get('products')->row_array();

        return array(
            'status' => 200,
            'message' => 'true',
            'discount_price' => $row['discount_price'],
            'base_price' => $row['base_price']
        );
    }


    public function add_new_package_simple($data)
    {
        $user_id         = $data['user_id'];
        $board_id        = $data['board_id'];
        $school_id       = $data['school_id'];
        $grade_id        = $data['grade_id'];
        $shipping_id     = $data['shipping_id'];
        $category        = $data['category'];
        $package_name    = $data['package_name'];
        $package_price   = $data['package_price'];
        $package_offer_price   = $data['package_offer_price'];
        $package_gst     = $data['package_gst'];
        $package_hsn     = $data['package_hsn'];
        $is_it           = $data['is_it'];
        $weight          = $data['weight'];
        $note            = $data['note'];
        $product         = $data['product'];
        $minimum_package = $data['minimum_package'];
        $package_status = $data['package_status'];


        $data_package = array(
            'vendor_id' => $user_id,
            'school_id' => $school_id,
            'board' => $board_id,
            'grade_id' => $grade_id,
            'shipping_id' => $shipping_id,
            'minimum_package' => $minimum_package,
            'status' => $package_status,
            'pending' => $package_status,
            'is_simple' => 1,
            'is_sold' => 0,
            'added_date' => date('Y-m-d H:i:s'),
            'last_modified' => date('Y-m-d H:i:s')
        );
        $this->db->insert('packages', $data_package);
        $package_id = $this->db->insert_id();

        if ($package_id) {
            for ($i = 0; $i < count($category); $i++) {
                $data_category = array();
                $data_category = array(
                    'package_id' => $package_id,
                    'package_name' => $package_name[$i],
                    'package_price' => $package_price[$i],
                    'package_offer_price' => $package_offer_price[$i],
                    'category' => $category[$i],
                    'gst' => $package_gst[$i],
                    'hsn' => $package_hsn[$i],
                    'is_it' => $is_it[$i],
                    'weight' => $weight[$i],
                    'note' => $note[$i]
                );
                $this->db->insert('package_category', $data_category);
                $insert_id = $this->db->insert_id();
                if ($insert_id) {

                    foreach($product[$i] as $product_list){
                      $data_product = array();
                      if($product_list['product']!='' && $product_list['product']!='0'){
                        $count_pcheck=$this->check_duplicate_package_product($package_id,$product_list['product']);
                        if($count_pcheck==0){
                            $data_product = array(
                                'package_id' => $package_id,
                                'package_catid' => $insert_id,
                                'product_id' => $product_list['product'],
                                'quantity' => $product_list['qty'],
                                'display_name' => $product_list['display_name'],
                                'discount_price' => $product_list['discount_price']
                            );
                            $this->db->insert('package_products', $data_product);
                        }
                      }
                    }
                }
            }

            if ($insert_id) {
                $resultpost = array(
                    'status' => 200,
                    'message' => 'Package Add Successfully !!'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! Package not added !!'
            );
        }
        return $resultpost;
    }

    public function add_new_package($data)
    {
        $user_id         = $data['user_id'];
        $board_id        = $data['board_id'];
        $school_id       = $data['school_id'];
        $grade_id        = $data['grade_id'];
        $shipping_id     = $data['shipping_id'];
        $category        = $data['category'];
        $package_name    = $data['package_name'];
        $is_it           = $data['is_it'];
        $weight          = $data['weight'];
        $note            = $data['note'];
        $product         = $data['product'];
        $minimum_package = $data['minimum_package'];
        
        
        $data_package = array(
            'vendor_id' => $user_id,
            'school_id' => $school_id,
            'board' => $board_id,
            'grade_id' => $grade_id,
            'shipping_id' => $shipping_id,
            'minimum_package' => $minimum_package,
            'added_date' => date('Y-m-d H:i:s'),
            'status' => 1,
			'is_simple' => 0,
            'last_modified' => date('Y-m-d H:i:s')
        );
        
        $this->db->insert('packages', $data_package);
        $package_id = $this->db->insert_id();
        
        
        
        if ($package_id) {
            for ($i = 0; $i < count($category); $i++) { 
                $data_category = array();
                $data_category = array(
                    'package_id' => $package_id,
                    'package_name' => $package_name[$i],
                    'category' => $category[$i],
                    'is_it' => $is_it[$i],
                    'weight' => $weight[$i],
                    'note' => $note[$i]
                );
                $this->db->insert('package_category', $data_category);
                $insert_id = $this->db->insert_id();
                if ($insert_id) {
                   
                    foreach($product[$i] as $product_list){
                      $data_product = array();
                      if($product_list['product']!='' && $product_list['product']!='0'){
                        $count_pcheck=$this->check_duplicate_package_product($package_id,$product_list['product']);
                        if($count_pcheck==0){
                            $data_product = array(
                                'package_id' => $package_id,
                                'package_catid' => $insert_id,
                                'product_id' => $product_list['product'],
                                'quantity' => $product_list['qty'],
                                'display_name' => $product_list['display_name'],
                                'discount_price' => $product_list['discount_price']
                            );
                            $this->db->insert('package_products', $data_product);
                        }
                      }
                    }
                }
            }
            
            if ($insert_id) {
                $resultpost = array(
                    'status' => 200,
                    'message' => 'Package Add Successfully !!'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! Package not added !!'
            );
        }
        
        
        return $resultpost;
        
        
    }

  	public function check_duplicate_package_product($package_id,$product_id){
	  $query = $this->db->query("SELECT id  FROM package_products WHERE package_id='$package_id' AND product_id='$product_id' LIMIT 1");
	  return $query->num_rows();
	}

    public function delete_package_products($package_id)
	{
		$package_id = clean_number($package_id);
		$this->db->where('package_id', $package_id);
		return $this->db->delete('package_products');
	}
	
	public function update_package_simple($data){
        $package_id      = $data['package_id'];
        $user_id         = $data['user_id'];
        $board_id        = $data['board_id'];
        $school_id       = $data['school_id'];
        $grade_id        = $data['grade_id'];
        $shipping_id     = $data['shipping_id'];
        $category        = $data['category'];
        $package_name    = $data['package_name'];
        $package_price   = $data['package_price'];
        $package_offer_price   = $data['package_offer_price'];
        $package_gst     = $data['package_gst'];
        $package_hsn     = $data['package_hsn'];
        $is_it           = $data['is_it'];
        $weight          = $data['weight'];
        $note            = $data['note'];
        $product         = $data['product'];
        $minimum_package = $data['minimum_package'];
        $package_status = $data['package_status'];
        $pc_id = $data['package_category_id'];
		    $pinsert_id=0;

        $data_package = array(
      			'minimum_package'    => $minimum_package,
      			'shipping_id'    => $shipping_id,
            'last_modified'    => date('Y-m-d H:i:s'),
            'status' => $package_status,
			      'pending' => $package_status,
			      'is_sold' => 0
        );
        $this->db->where('id', $package_id);
        $update_package = $this->db->update('packages', $data_package);

        if ($update_package) {
		    //$this->profile_model->delete_package_products($package_id);

            for ($i = 0; $i < count($category); $i++) {
                $data_category = array();
                $data_category = array(
                    'package_id' => $package_id,
                    'package_name' => $package_name[$i],
                    'package_price' => $package_price[$i],
                    'package_offer_price' => $package_offer_price[$i],
                    'category' => $category[$i],
                    'gst' => $package_gst[$i],
                    'hsn' => $package_hsn[$i],
                    'is_it' => $is_it[$i],
                    'weight' => $weight[$i],
                    'note' => $note[$i]
                );
			    $package_category_id=$pc_id[$i];

    			if($package_category_id>0):
    				$this->db->where('id', $package_category_id);
    				$this->db->update('package_category', $data_category);
    				$insert_id=$package_category_id;
                else:
    				$this->db->insert('package_category', $data_category);
    				$insert_id = $this->db->insert_id();
                endif;

                if ($insert_id) {
                    if(!empty($product[$i])){
                        foreach($product[$i] as $product_list){
                            $data_product = array();
                            if($product_list['product']!='' && $product_list['product']!='0'){
                                $count_pcheck=$this->check_duplicate_package_product($package_id,$product_list['product']);
                                if($count_pcheck==0){
                                    $data_product = array(
                                        'package_id' => $package_id,
                                        'package_catid' => $insert_id,
                                        'product_id' => $product_list['product'],
                                        'quantity' => $product_list['qty'],
                                        'display_name' => $product_list['display_name'],
                                        'discount_price' => $product_list['discount_price']
                                    );
                                    //$this->db->insert('package_products', $data_product);
                                    //$pinsert_id = $this->db->insert_id();
                                }
                            }
                        }
                    }
                }
            }

            if ($insert_id>0) {
                $resultpost = array(
                    'status' => 200,
                    'message' => 'Package updated Successfully!!'
                );
            }
            else{
                $resultpost = array(
                    'status' => 400,
                    'message' => 'Error! Package not updated',
                    'package_category_id' => $package_category_id,
                    'insert_id' => $insert_id,
                    'pinsert_id' => $pinsert_id,
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! Package not updated !!'
            );
        }
        return $resultpost;
    }

    public function update_package($data){
        $package_id      = $data['package_id'];
        $user_id         = $data['user_id'];
        $board_id        = $data['board_id'];
        $school_id       = $data['school_id'];
        $grade_id        = $data['grade_id'];
        $shipping_id     = $data['shipping_id'];
        $category        = $data['category'];
        $package_name    = $data['package_name'];
        $package_price   = $data['package_price'];
        $package_offer_price   = $data['package_offer_price'];
        $package_gst     = $data['package_gst'];
        $package_hsn     = $data['package_hsn'];
        $is_it           = $data['is_it'];
        $weight          = $data['weight'];
        $note            = $data['note'];
        $product         = $data['product'];
        $minimum_package = $data['minimum_package'];
        $package_status = $data['package_status'];
        $pc_id = $data['package_category_id'];
		$pinsert_id=0;

        $data_package = array(
			'minimum_package'    => $minimum_package,
      		'shipping_id'    => $shipping_id,
            'last_modified'    => date('Y-m-d H:i:s'),
            'status' => $package_status,
			'pending' => $package_status,
			'is_sold' => 0
        );
        $this->db->where('id', $package_id);
        $update_package = $this->db->update('packages', $data_package);

        if ($update_package) {
		    $this->profile_model->delete_package_products($package_id);

            for ($i = 0; $i < count($category); $i++) {
                $data_category = array();
                $data_category = array(
                    'package_id' => $package_id,
                    'package_name' => $package_name[$i],
                    //'package_price' => $package_price[$i],
                    //'package_offer_price' => $package_offer_price[$i],
                    'category' => $category[$i],
                    //'gst' => $package_gst[$i],
                    //'hsn' => $package_hsn[$i],
                    'is_it' => $is_it[$i],
                    'weight' => $weight[$i],
                    'note' => $note[$i]
                );
				
			    $package_category_id=$pc_id[$i];

    			if($package_category_id>0):
    				$this->db->where('id', $package_category_id);
    				$this->db->update('package_category', $data_category);
    				$insert_id=$package_category_id;
                else:
    				$this->db->insert('package_category', $data_category);
    				$insert_id = $this->db->insert_id();
                endif;

                if ($insert_id) {
                    if(!empty($product[$i])){
                        foreach($product[$i] as $product_list){
                            $data_product = array();
                            if($product_list['product']!='' && $product_list['product']!='0'){
                                $count_pcheck=$this->check_duplicate_package_product($package_id,$product_list['product']);
                                if($count_pcheck==0){
                                    $data_product = array(
                                        'package_id' => $package_id,
                                        'package_catid' => $insert_id,
                                        'product_id' => $product_list['product'],
                                        'quantity' => $product_list['qty'],
                                        'display_name' => $product_list['display_name'],
                                        'discount_price' => $product_list['discount_price']
                                    );
                                    $this->db->insert('package_products', $data_product);
                                    $pinsert_id = $this->db->insert_id();
                                }
                            }
                        }
                    }
                }
            }

            if ($insert_id>0) {
                $resultpost = array(
                    'status' => 200,
                    'message' => 'Package updated Successfully!!'
                );
            }
            else{
                $resultpost = array(
                    'status' => 400,
                    'message' => 'Error! Package not updated',
                    'package_category_id' => $package_category_id,
                    'insert_id' => $insert_id,
                    'pinsert_id' => $pinsert_id,
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! Package not updated !!'
            );
        }
        return $resultpost;
    }

    public function get_package_category_by_id($id) {
        return $this->db->get_where('package_category',array('package_id' => $id));
    }
    
    public function get_package_list_simple($filter, $per_page, $offset)
    {
        $keywords_filter = "";

        if (isset($filter['user_id']) && $filter['user_id'] != ""):
            $user_id         = $filter['user_id'];
            $keywords_filter = " AND packages.vendor_id = '$user_id'";
        endif;

        if (isset($filter['keyword']) && $filter['keyword'] != ""):
            $keyword         = $filter['keyword'];
            $keywords_filter = " AND school.name like '%$keyword%'";
        endif;

        $status_filter='';
        if (isset($filter['status']) && $filter['status'] != ""):
            $status = $filter['status'];
            if($status=='active'){
                $status_filter = " AND packages.status='1'";
            }
            else if($status=='inactive'){
                $status_filter = " AND packages.status='0'";
            }
        endif;

        $rows = $this->db->query("SELECT packages.id FROM `school` INNER JOIN packages ON school.id = packages.school_id LEFT JOIN grade_list ON grade_list.id = packages.grade_id  WHERE packages.vendor_id='$user_id' AND packages.is_deleted='0' and packages.is_simple=1 $keywords_filter $status_filter GROUP BY packages.school_id,packages.board,packages.grade_id ORDER BY packages.id DESC");
        $query = $this->db->query("SELECT packages.board,packages.status,packages.id,packages.shipping_id,school.name,grade_list.name as grade_name FROM `school` INNER JOIN packages ON school.id = packages.school_id LEFT JOIN grade_list ON grade_list.id = packages.grade_id  WHERE packages.vendor_id='$user_id' AND packages.is_deleted='0' and packages.is_simple=1 $keywords_filter $status_filter GROUP BY packages.school_id,packages.board,packages.grade_id ORDER BY packages.id DESC LIMIT $offset,$per_page");

        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {

            $warehouse_name = $this->product_model->get_warehouse_name($row['shipping_id']);
            $get_board = $this->product_model->get_board_list($row['board']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = '-';
            }

            $package_count=$this->profile_model->get_package_category_by_id($row['id'])->num_rows();

            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "board" => $board,
                "warehouse_name" => $warehouse_name,
                "grade_name" => $row['grade_name'],
                "package_count" => $package_count,
                "status" => $row['status'],
            );
        }

        $total_data = $count;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_package_list($filter, $per_page, $offset)
    {
        $keywords_filter = "";

        if (isset($filter['user_id']) && $filter['user_id'] != ""):
            $user_id         = $filter['user_id'];
            $keywords_filter = " AND packages.vendor_id = '$user_id'";
        endif;

        if (isset($filter['keyword']) && $filter['keyword'] != ""):
            $keyword         = $filter['keyword'];
            $keywords_filter = " AND school.name like '%$keyword%'";
        endif;

        $status_filter='';
        if (isset($filter['status']) && $filter['status'] != ""):
            $status = $filter['status'];
            if($status=='active'){
                $status_filter = " AND packages.status='1'";
            }
            else if($status=='inactive'){
                $status_filter = " AND packages.status='0'";
            }
        endif;

        $rows = $this->db->query("SELECT packages.id FROM `school` INNER JOIN packages ON school.id = packages.school_id LEFT JOIN grade_list ON grade_list.id = packages.grade_id  WHERE packages.vendor_id='$user_id' AND packages.is_deleted='0' and packages.is_simple=0  $keywords_filter $status_filter GROUP BY packages.school_id,packages.board,packages.grade_id ORDER BY packages.id DESC");
        $query = $this->db->query("SELECT packages.board,packages.status,packages.id,packages.shipping_id,school.name,grade_list.name as grade_name FROM `school` INNER JOIN packages ON school.id = packages.school_id LEFT JOIN grade_list ON grade_list.id = packages.grade_id  WHERE packages.vendor_id='$user_id' AND packages.is_deleted='0' and packages.is_simple=0 $keywords_filter $status_filter GROUP BY packages.school_id,packages.board,packages.grade_id ORDER BY packages.id DESC LIMIT $offset,$per_page");

        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {

            $warehouse_name = $this->product_model->get_warehouse_name($row['shipping_id']);
            $get_board = $this->product_model->get_board_list($row['board']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = '-';
            }

            $package_count=$this->profile_model->get_package_category_by_id($row['id'])->num_rows();

            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "board" => $board,
                "warehouse_name" => $warehouse_name,
                "grade_name" => $row['grade_name'],
                "package_count" => $package_count,
                "status" => $row['status'],
            );
        }

        $total_data = $count;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_staff_list($user_id,$per_page,$offset)
    {
        $rows = $this->db->query("SELECT id,username,email,phone_number,banned,access_manager FROM users WHERE vendor_id='$user_id' and role='staff' order by id asc");
        $query = $this->db->query("SELECT id,username,email,phone_number,banned,access_manager FROM users WHERE vendor_id='$user_id' and role='staff' order by id asc LIMIT $offset,$per_page");
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id = $row['id'];
            $username = $row['username'];
            $email        = $row['email'];
            $phone_number        = $row['phone_number'];
            $banned        = $row['banned'];
            $access_manager        = explode(',',$row['access_manager']);

            $name = '';
            $comma = '';
            foreach($access_manager as $access){
                $access = str_replace("_", " ", $access);
                $name .= $comma .ucwords($access);
                $comma = ', ';
            }

            $data[] = array(
                "id" => $id,
                "username" => $username,
                "email" => $email,
                "phone_number" => $phone_number,
                "banned" => $banned,
                "access_manager" => $name,
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count,
        );
        return $resultpost;
    }

    public function get_staff_details($user_id,$id)
    {

        $query = $this->db->query("SELECT id,username,email,phone_number,banned,access_manager FROM users WHERE vendor_id='$user_id' and role='staff' and id='$id' order by id asc");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id = $row['id'];
            $username = $row['username'];
            $email        = $row['email'];
            $phone_number        = $row['phone_number'];
            $banned        = $row['banned'];
            $access_manager        = explode(',',$row['access_manager']);

            if($banned == 0){
                $status = 'Active';
            }else{
                 $status = 'In Active';
            }

            $data[] = array(
                "id" => $id,
                "username" => $username,
                "email" => $email,
                "phone_number" => $phone_number,
                "banned" => $banned,
                "access_manager" => $access_manager,
                "status" => $status,
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function add_staff($user_id,$data)
    {
        date_default_timezone_set('Asia/Kolkata');
        $data['vendor_id']     = $user_id;
        $data['created_at']    = date('Y-m-d H:i:s');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->insert('users', $data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;
    }

    public function update_staff($user_id,$data)
    {
        date_default_timezone_set('Asia/Kolkata');

        $data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id',$user_id);
        $this->db->update('users', $data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;
    }

    public function delete_staff($user_id,$id)
    {

        $this->db->where('id',$id);
        $this->db->where('vendor_id',$user_id);
        if($this->db->delete('users')){
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
             );
        }else{
            $resultpost = array(
                'status' => 400,
                'message' => 'error'
            );
        }



        return $resultpost;
    }

    public function get_active_package_list($filter, $per_page, $offset)
    {
        $keywords_filter = "";

        if (isset($filter['user_id']) && $filter['user_id'] != ""):
            $user_id         = $filter['user_id'];
            $keywords_filter = " AND packages.vendor_id = '$user_id'";
        endif;

        if (isset($filter['keyword']) && $filter['keyword'] != ""):
            $keyword         = $filter['keyword'];
            $keywords_filter = " AND (school.name like '%$keyword%' OR grade_list.name like '%$keyword%')";
        endif;

        $rows = $this->db->query("SELECT packages.id FROM `school` INNER JOIN packages ON school.id = packages.school_id INNER JOIN grade_list ON grade_list.id = packages.grade_id  WHERE packages.vendor_id='$user_id' AND packages.is_deleted='0' $keywords_filter GROUP BY packages.school_id,packages.board,packages.grade_id ORDER BY packages.id DESC");

        $query = $this->db->query("SELECT packages.board,packages.discount_type,packages.status,packages.id,packages.shipping_id,school.name,grade_list.name as grade_name FROM `school` INNER JOIN packages ON school.id = packages.school_id INNER JOIN grade_list ON grade_list.id = packages.grade_id  WHERE packages.vendor_id='$user_id' AND packages.is_deleted='0' $keywords_filter GROUP BY packages.school_id,packages.board,packages.grade_id ORDER BY packages.id DESC LIMIT $offset,$per_page");


        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {

            $warehouse_name = $this->product_model->get_warehouse_name($row['shipping_id']);
            $get_board = $this->product_model->get_board_list($row['board']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = '-';
            }

             $package_count=$this->profile_model->get_package_category_by_id($row['id'])->num_rows();

            $discount_type = $row['discount_type'];
            if($discount_type == '' || $discount_type == 'NULL'){
                $discount_type = '-';
            }

            $data[] = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "board" => $board,
                "warehouse_name" => $warehouse_name,
                "grade_name" => $row['grade_name'],
                "package_count" => $package_count,
                "status" => $row['status'],
                "discount_type" => $discount_type,
            );
        }

        $total_data = $count;

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_discount_list($orderform_id,$user_id)
    {

        $query = $this->db->query("SELECT id,discount_type,discount_cat,discount FROM packages WHERE id='$orderform_id' and vendor_id='$user_id'");
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id = $row['id'];
            $discount_type = $row['discount_type'];
            $discount_cat       = $row['discount_cat'];
            $discount        = $row['discount'];


            $package_array = array();
            $packages_ids ='';
            $comma = '';
            $query_package = $this->db->query("SELECT id,package_name,discount FROM package_category WHERE package_id='$orderform_id' and is_it != '2'");
            foreach ($query_package->result_array() as $row_package) {
                $package_id        = $row_package['id'];
                $package_name        = $row_package['package_name'];
                $package_discount        = $row_package['discount'];

                $package_array[] = array(
                    "package_id" => $package_id,
                    "package_name" => $package_name,
                    "package_discount" => $package_discount,
                );

                $packages_ids .= $comma.$package_id;
                $comma = ',';
            }

            $packages_ids = explode(',',$packages_ids);

            $data[] = array(
                "id" => $id,
                "discount_type" => $discount_type,
                "discount_cat" => $discount_cat,
                "discount" => $discount,
                "package" => $package_array,
                "packages_ids" => $packages_ids,
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function update_discount_orderform($user_id,$discount_amt,$discount,$discount_type,$discount_cat,$orderform_id,$packages_ids)
    {

        if($discount_type == 'orderform'){
            $data['discount'] = $discount;
            $data['discount_type'] = $discount_type;
            $data['discount_cat'] = $discount_cat;

            $this->db->where('id',$orderform_id);
            $this->db->update('packages', $data);

        }elseif($discount_type == 'package'){
            $data['discount'] = '';
            $data['discount_type'] = $discount_type;
            $data['discount_cat'] = '';

            $this->db->where('id',$orderform_id);
            $this->db->update('packages', $data);

            $count = count($packages_ids);
            for($i = 0; $i < $count; $i++) {
                $data_1['discount'] = $discount_amt[$i];

                $this->db->where('id',$packages_ids[$i]);
                $this->db->update('package_category', $data_1);
                // echo $this->db->last_query();
    		 }
        }elseif($discount_type == 'none'){
            $data['discount'] = '';
            $data['discount_type'] = $discount_type;
            $data['discount_cat'] = '';

            $this->db->where('id',$orderform_id);
            $this->db->update('packages', $data);
        }

        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );

        return $resultpost;
    }




    public function package_category_delete_ajax($user_id,$package_id,$package_category_id)
    {
        $this->db->select('id');
        $this->db->where('vendor_id', $user_id);
        $this->db->where('id', $package_id);
        $check = $this->db->get('packages')->num_rows();

        if($check>0){
            $this->db->where('id', $package_category_id);
	    	$result = $this->db->delete('package_category');

            return array(
                'status' => 200,
                'message' => 'true',
            );

        }
        else{
            return array(
            'status' => 400,
            'message' => 'Error, You do not have access!',
            );

        }
    }


    public function get_shipping_count_list($user_id,$filter){
        $order_status=$filter['order_status'];

        $this->db->where('is_deleted', 0);
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_shipping_details');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            if($row['name'] != ''){
                $name =  $row['name'];
            }else{
                $name =  '-';
            }

            $warehouse_id=$row['id'];
			
	
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

       if($order_status=='processing'){
        $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id')   AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) $academic_year_filter and warehouse_id = '$warehouse_id' AND (process_slot != '') ORDER BY id ASC")->num_rows();
       }

       elseif($order_status=='shipment'){
          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) $academic_year_filter and warehouse_id = '$warehouse_id' AND (order_slot!='') ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='out_for_delivery'){

          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) $academic_year_filter and warehouse_id = '$warehouse_id' AND (order_slot!='') ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='delivered'){
          
         $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) $academic_year_filter AND warehouse_id = '$warehouse_id' AND (order_slot!='') ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='cancelled'){
          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND (order_status = '$order_status') $academic_year_filter and warehouse_id = '$warehouse_id' AND (order_slot!='') ORDER BY id ASC")->num_rows();
       }
       else{
         $orders_count=0;
       }

            $data[] = array(
                "id" => $row['id'],
                "address" => $row['address'],
                "landmark" => $row['landmark'],
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id']),
                "pincode" => $row['pincode'],
                "contact_number" => $row['contact_number'],
                "location" => $row['location'],
                "lattitude" => $row['lattitude'],
                "longitude" => $row['longitude'],
                "name" => $row['name'],
                "orders_count" => $orders_count,
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_handed_dtdc_count_list($user_id,$filter){
        $order_status='shipment';

        $this->db->where('is_deleted', 0);
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_shipping_details');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            if($row['name'] != ''){
                $name =  $row['name'];
            }else{
                $name =  '-';
            }

            $warehouse_id=$row['id'];

       $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') and is_picked_dtdc='1' AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' AND (order_slot!='') group by order_slot ORDER BY id ASC")->num_rows();

            $data[] = array(
                "id" => $row['id'],
                "address" => $row['address'],
                "landmark" => $row['landmark'],
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id']),
                "pincode" => $row['pincode'],
                "contact_number" => $row['contact_number'],
                "location" => $row['location'],
                "lattitude" => $row['lattitude'],
                "longitude" => $row['longitude'],
                "name" => $row['name'],
                "orders_count" => $orders_count,
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function get_dtdc_count_list($user_id,$filter){
        $order_status='picked_dtdc';

        $this->db->where('is_deleted', 0);
        $this->db->where('vendor_id', $user_id);
        $query = $this->db->get('vendor_shipping_details');
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            if($row['name'] != ''){
                $name =  $row['name'];
            }else{
                $name =  '-';
            }

            $warehouse_id=$row['id'];

       if($order_status=='processing'){
        $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id')   AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' AND (process_slot != '') group by process_slot ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='shipment'){
          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' AND (order_slot!='') group by order_slot ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='picked_dtdc'){
          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' AND (order_slot!='') group by order_slot ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='out_for_delivery'){

          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' AND (order_slot!='') group by order_slot ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='delivered'){
          $academic_year_filter='';
         if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            //$academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
         $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') $academic_year_filter AND warehouse_id = '$warehouse_id' AND (order_slot!='') group by order_slot ORDER BY id ASC")->num_rows();
       }
       elseif($order_status=='cancelled'){
          $orders_count   = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$user_id') AND (payment_status='payment_received') AND (order_status = '$order_status') and warehouse_id = '$warehouse_id' AND (order_slot!='') ORDER BY id ASC")->num_rows();
       }
       else{
         $orders_count=0;
       }

            $data[] = array(
                "id" => $row['id'],
                "address" => $row['address'],
                "landmark" => $row['landmark'],
                "state_id" => $row['state_id'],
                "city_id" => $row['city_id'],
                "city" => get_city_name($row['city_id']),
                "state" => get_state_name($row['state_id']),
                "pincode" => $row['pincode'],
                "contact_number" => $row['contact_number'],
                "location" => $row['location'],
                "lattitude" => $row['lattitude'],
                "longitude" => $row['longitude'],
                "name" => $row['name'],
                "orders_count" => $orders_count,
            );
        }

        $total_data = count($data);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }



}
