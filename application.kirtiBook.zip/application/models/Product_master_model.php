<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_master_model extends CI_Model
{
    
    public function check_product_isbn($isbn, $user_id, $product_id, $type)
    {
        if ($type == 'on_create') {
            $count = $this->db->get_where('product_master', array(
                'isbn' => $isbn,
                'is_deleted' => 0
            ))->num_rows();
            
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }
        
        if ($type == 'on_update') {
            $count = $this->db->get_where('product_master', array(
                'id!=' => $product_id,
                'isbn' => $isbn,
                'is_deleted' => 0
            ))->num_rows();
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }
    }
    
    
    public function check_update_product_isbn($isbn, $user_id, $product_id, $type)
    {
		
        return false;
       /* $query_prodct = $this->db->query("SELECT master_id FROM products where id='$product_id' limit 1");
        $row_data     = $query_prodct->row_array();
        $master_id    = $row_data['master_id'];
        
        if ($type == 'on_update') {
            $count = $this->db->get_where('product_master', array(
                'id!=' => $master_id,
                'isbn' => $isbn,
                'is_deleted' => 0
            ))->num_rows();
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        }*/
    }
    
    public function get_product_by_id($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('product_master');
        return $query->row();
    }
    
    
    
    
    // Books -> School Text Book Starts    
    public function add_product_post($data,$pdata,$category,$warehouse,$quantity)
    {
        $data['parent_cid'] = '8';
        $this->db->insert('product_master', $data);
        $master_id = $this->db->insert_id();
        
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $pdata['master_id']       = $master_id;
        $pdata['parent_cid'] = '8';
        $pdata['approve_by']  = 1;
        $pdata['status']  = 1;
        $this->db->insert('products', $pdata);
        $product_id = $this->db->insert_id();
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_post($data,$pdata,$category,$product_id,$warehouse,$quantity)
    {
        $query_prodct = $this->db->query("SELECT master_id FROM products where id='$product_id' limit 1");
        $row_data     = $query_prodct->row_array();
        $master_id    = $row_data['master_id'];
        
        $this->db->where('id', $master_id);
        $this->db->update('product_master', $data);
        
        $this->db->where('product_id', $master_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $this->db->where('id', $product_id);
        $this->db->update('products', $pdata);
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $check_warehouse = $this->db->query("SELECT id FROM products_warehouse_qty where product_id='$product_id' and warehouse_id='$warehouse_id' limit 1")->num_rows();
            if($check_warehouse>0){
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->where('product_id', $product_id);
                $this->db->where('warehouse_id', $warehouse_id);
                $this->db->update('products_warehouse_qty', $data_qty);
            }
            else{
                $data_qty['product_id']   = $product_id;
                $data_qty['warehouse_id'] = $warehouse_id;
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->insert('products_warehouse_qty', $data_qty);
            }
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    // Books -> School Text Book Ends      
    
    public function get_publisher_by_id($id)
    {
        return $this->db->get_where('publisher', array(
            'id' => $id
        ));
    }
    public function get_publisher_by_name($name)
    {
        return $this->db->get_where('publisher', array(
            'name' => $name
        ));
    }
    
    public function get_grades_by_id($id)
    {
        return $this->db->get_where('grade_list', array(
            'id' => $id
        ));
    }
    
    public function get_grades_by_name($name)
    {
        return $this->db->get_where('grade_list', array(
            'name' => $name
        ));
    }
    
    public function get_stationery_by_id($id)
    {
        return $this->db->get_where('stationery_type', array(
            'id' => $id
        ));
    }
    
    public function get_stationery_by_name($name)
    {
        return $this->db->get_where('stationery_type', array(
            'name' => $name
        ));
    }
    
    public function get_subject_by_id($id)
    {
        return $this->db->get_where('subject', array(
            'id' => $id
        ));
    }
    
    public function get_subject_by_name($name)
    {
        return $this->db->get_where('subject', array(
            'name' => $name
        ));
    }
    
    public function get_brand_by_id($id)
    {
        return $this->db->get_where('brand', array(
            'id' => $id
        ));
    }
    
    public function get_brand_by_name($name)
    {
        return $this->db->get_where('brand', array(
            'name' => $name
        ));
    }
    
    public function get_board_by_id($id)
    {
        return $this->db->get_where('board', array(
            'id' => $id
        ));
    }
    public function get_board_by_name($name)
    {
        return $this->db->get_where('board', array(
            'name' => $name
        ));
    }
    
    
    public function get_user_products_count($user_id, $category)
    {
        $this->db->select('p.id,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold');
        $this->db->join('products_category', 'p.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $this->db->group_by('categories.parent_id');
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        return $query->num_rows();
    }
    
    public function get_product_list($user_id, $category, $per_page, $offset)
    {
        
        $this->db->select('p.id,p.title,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold,p.gender,p.age_type');
        $this->db->join('products_category', 'p.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        /*    echo $this->db->last_query();
        exit();*/
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "model_number" => $row['model_number'],
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold']
            );
        }
        
        $total_data = $this->get_user_products_count($user_id, $category);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function get_products_category_by_product($id)
    {
        return $this->db->get_where('products_category', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_images($id)
    {
        return $this->db->get_where('product_images', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_images_single($id)
    {
        $this->db->limit(1);
        return $this->db->get_where('product_images', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_warehouse_qty_by_product($id)
    {
        return $this->db->get_where('products_warehouse_qty', array(
            'product_id' => $id
        ));
    }
    
    public function get_products_warehouse_qty_by_product_def($id)
    {
        $this->db->group_by('warehouse_id');
        return $this->db->get_where('products_warehouse_qty', array(
            'product_id' => $id
        ));
    }
    
    public function get_vendor_shipping($id)
    {
        return $this->db->get_where('vendor_shipping_details', array(
            'id' => $id
        ));
    }
    
    public function get_size_by_id($id)
    {
        return $this->db->get_where('size', array(
            'id' => $id
        ));
    }
    
    public function get_product_details($user_id, $id)
    {
        $query_prodct = $this->db->query("SELECT parent_cid,master_id,model_number,min_quantity,day_exchange,is_bookset,is_individually,base_price,discount_price FROM products where id='$id' limit 1");
        $row_data     = $query_prodct->row_array();
        $master_id    = $row_data['master_id'];
        $parent_cid    = $row_data['parent_cid'];
        
        
        $this->db->where('id', $master_id);
        $query = $this->db->get('product_master');
        $count = $query->num_rows();
        $data  = array();
        $row   = $query->row_array();
        if ($count > 0) {
            $publisher='-'; 
            $subject='-';
            $grade='N/A'; 
            $board='-'; 
            $brand='-'; 
            $size='-'; 
            $school='-'; 
            $binding_type='-'; 
            $color='-'; 

			$subcate=$row['subcate'];
            $categories     = $this->get_products_category_by_product($row['id']);
            $category_data  = array();
            $category_name  = array();
            $category_label = array();
            foreach ($categories->result_array() as $category) {
                if ($row['parent_cid'] != '38') {
                    $category_data[]  = $category['category_id'];
                    $category_name[]  = $this->common_model->get_category_name($category['category_id']);
                    $category_label[] = array(
                        "key" => $category['category_id']
                    );
                } else {
                    $category_data    = $category['category_id'];
                    $category_name[]  = $this->common_model->get_category_name($category['category_id']);
                    $category_label[] = array(
                        "key" => $category['category_id']
                    );
                }
				if ($row['parent_cid']== '6') {
					if($category['category_id']!=''){
						$category_id_arr=$category['category_id'];
						$category_id_arr = explode(',', $category_id_arr);						
						$subcate=$category_id_arr;
					}
					
				}	
            }
            
            $board_array = explode(',', $row['board_id']);
            $board_data  = array();
            $board_name  = array();
            $board_label = array();
            foreach ($board_array as $board_id) {
                $board_data[]  = $board_id;
                $board_name[]  = $this->common_model->get_board_name($board_id);
                $board_label[] = array(
                    "key" => $board_id
                );
            }
            
            $products_images = array();
            $get_images      = $this->get_products_images($row['id']);
            if ($get_images->num_rows() > 0) {
                foreach ($get_images->result_array() as $images) {
                    $products_images[] = array(
                        "id" => $images['id'],
                        "image" => $images['image'],
                        "image_url" => "http://liveapi.kirtibook.in/vendor/v1/uploads/products/" . $images['image']
                    );
                }
            }
            
            $warehouse     = $this->get_products_warehouse_qty_by_product($id);
            $warehouse_def = $this->get_products_warehouse_qty_by_product_def($id);
            
            $warehouse_data_default = array();
            $warehouse_list         = array();
            $warehouse_data_group = array();
            $sizeName_list        = array();
            
            $vendor_shipping_name = '';
            $comma = '';
            foreach ($warehouse_def->result_array() as $ware_def) {
                $warehouse_data_default[] = array(
                    "key" => $ware_def['warehouse_id']
                );
                
                $vendor_shipping = $this->get_vendor_shipping($ware_def['warehouse_id'])->row();
                $vendor_shipping_name .= $comma.$vendor_shipping->name;
                
                $warehouse_data_group[] = $ware_def['warehouse_id'];
                $warehouse_list[] = array(
                    "warehouse_id" => $ware_def['warehouse_id'],
                    "address" => $this->common_model->get_warehouse_address_add_by_id($ware_def['warehouse_id'])
                );
                $comma = '';
            }
            
            $warehouse_data     = array();
            $warehouse_data_qty = array();
            $stock_data         = array();
            $sizeName_list      = array();
            
            foreach ($warehouse->result_array() as $ware) {
                $warehouse_data[]     = $ware['warehouse_id'];
                $warehouse_data_qty[] = array(
                    "warehouse_id" => $ware['warehouse_id'],
                    "quantity" => $ware['quantity'],
                    "address" => $this->common_model->get_warehouse_address_add_by_id($ware['warehouse_id'])
                );
                
                $stock_data[] = array(
                    "product_id" => $ware['product_id'],
                    "warehouse_id" => $ware['warehouse_id'],
                    "size_id" => $ware['size_id'],
                    "quantity" => $ware['quantity']
                );
                
                $size_by = $this->get_size_by_id($ware['size_id'])->row();
                
                $sizeName_list[] = array(
                    "warehouse_id" => $ware['warehouse_id'],
                    "id" => $ware['size_id'],
                    "name" => $size_by['name'],
                    "quantity" => $ware['quantity']
                );
                
            } 
 
            $data[] = array(
                "id" => $row['id'],
                "category_data" => $category_data,
                "category_name" => $category_name,
                "category_label" => $category_label,
                "isbn" => $row['isbn'],
                "title" => $row['title'],
                "sku" =>  $row_data['model_number'],
                "min_quantity" =>  $row_data['min_quantity'],
                "day_exchange" =>  $row_data['day_exchange'],
                "is_bookset" =>  $row_data['is_bookset'],
                "is_individually" =>  $row_data['is_individually'],
                "base_price" =>  $row_data['base_price'],
                "discount_price" =>  $row_data['discount_price'],
                "warehouse_data" => $warehouse_data,
                "warehouse_data_default" => $warehouse_data_default,
                "warehouse_data_qty" => $warehouse_data_qty,
                "description" => $row['description'],
                "publisher" => $row['publisher_id'],
                "publisher_name" => $this->common_model->get_publisher_name($row['publisher_id']),
                "publisher_label" => array(
                    "key" => $row['publisher_id']
                ),
                "board" => $board_data,
                "board_name" => $board_name,
                "board_label" => $board_label,
                "grades" => explode(',', $row['grade_id']),
                "brand_id" => $row['brand_id'],
                "brand_name" => $this->common_model->get_brand_name($row['brand_id']),
                "brand_label" => array(
                    "key" => $row['brand_id']
                ),
                "stationery_id" => $row['stationery_id'],
                "subject" => $row['subject_id'],
                "subject_name" => $this->common_model->get_subject_name($row['subject_id']),
                "subject_label" => array(
                    "key" => $row['subject_id']
                ),
                "pages" => $row['no_of_pages'],
                "gst" => $row['gst'],
                "hsn" => $row['hsn'],
                "lenght" => $row['lenght'],
                "width" => $row['width'],
                "height" => $row['height'],
                "weight" => $row['weight'],
                "meta_title" => $row['meta_title'],
                "meta_keyword" => $row['meta_keyword'],
                "meta_description" => $row['meta_description'],
                "product_description" => $row['product_description'],
                "age_grade" => $row['age_grade'],
                "to_age" => $row['to_age'],
                "from_age" => $row['from_age'],
                "highlights" => json_decode($row['highlights']),
                "products_images" => $products_images,
                "size" => explode(',', $row['size']),
                "school" => $row['school'],
                "video" => $row['video'],
                "size" => $row['size'],
                "binding_type" => $row['binding_type'],
                "subcate" => $subcate,
                "color" => $row['color'],
                "gender" => $row['gender'],
                "age_type" => $row['age_type'],
                "product_origin" => $row['product_origin']
            );
            
            
            $total_data = count($data);
            
            $resultpost = array(
                'status' => 200,
                'message' => 'success',
                'data' => $data,
                'total_data' => $total_data
            );
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    
    
    
    public function set_product_as_sold($user_id, $product_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        
        $product = $this->get_product_by_id($product_id);
        if (!empty($product)) {
            if ($user_id == $product->user_id) {
                if ($product->is_sold == 1) {
                    $data = array(
                        'is_sold' => 0
                    );
                    $msg  = 'Product set as Unsold!';
                } else {
                    $data = array(
                        'is_sold' => 1
                    );
                    $msg  = 'Product set as Sold!';
                }
                $this->db->where('id', $product_id);
                $this->db->update('product_master', $data);
            }
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }
    
    
     
    // Books ->other Book Starts    
    public function add_product_other_book_post($data,$pdata,$category,$warehouse,$quantity)
    {
        $data['parent_cid'] = '45';
        $this->db->insert('product_master', $data);
        $master_id = $this->db->insert_id();
        
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $pdata['master_id']       = $master_id;
        $pdata['parent_cid'] = '45';
        $pdata['approve_by']  = 1;
        $pdata['status']  = 1;
        $this->db->insert('products', $pdata);
        $product_id = $this->db->insert_id();
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_other_book_post($data,$pdata,$category,$product_id,$warehouse,$quantity)
    {
        $query_prodct = $this->db->query("SELECT master_id FROM products where id='$product_id' limit 1");
        $row_data     = $query_prodct->row_array();
        $master_id    = $row_data['master_id'];
        
        $this->db->where('id', $master_id);
        $this->db->update('product_master', $data);
        
        $this->db->where('product_id', $master_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $this->db->where('id', $product_id);
        $this->db->update('products', $pdata);
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $check_warehouse = $this->db->query("SELECT id FROM products_warehouse_qty where product_id='$product_id' and warehouse_id='$warehouse_id' limit 1")->num_rows();
            if($check_warehouse>0){
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->where('product_id', $product_id);
                $this->db->where('warehouse_id', $warehouse_id);
                $this->db->update('products_warehouse_qty', $data_qty);
            }
            else{
                $data_qty['product_id']   = $product_id;
                $data_qty['warehouse_id'] = $warehouse_id;
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->insert('products_warehouse_qty', $data_qty);
            }
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    // Books -> Other Book Ends        
    
    
    
    // Books ->  Note Book Starts    
    public function add_product_note_book_post($data,$pdata,$category,$warehouse,$quantity)
    {
        $data['parent_cid'] = '10';
        $this->db->insert('product_master', $data);
        $master_id = $this->db->insert_id();
        
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $pdata['master_id']       = $master_id;
        $pdata['parent_cid'] = '10';
        $pdata['approve_by']  = 1;
        $pdata['status']  = 1;
        $this->db->insert('products', $pdata);
        $product_id = $this->db->insert_id();
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_note_book_post($data,$pdata,$category,$product_id,$warehouse,$quantity)
    {
        $query_prodct = $this->db->query("SELECT master_id FROM products where id='$product_id' limit 1");
        $row_data     = $query_prodct->row_array();
        $master_id    = $row_data['master_id'];
        
        $this->db->where('id', $master_id);
        $this->db->update('product_master', $data);
        
        $this->db->where('product_id', $master_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $this->db->where('id', $product_id);
        $this->db->update('products', $pdata);
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $check_warehouse = $this->db->query("SELECT id FROM products_warehouse_qty where product_id='$product_id' and warehouse_id='$warehouse_id' limit 1")->num_rows();
            if($check_warehouse>0){
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->where('product_id', $product_id);
                $this->db->where('warehouse_id', $warehouse_id);
                $this->db->update('products_warehouse_qty', $data_qty);
            }
            else{
                $data_qty['product_id']   = $product_id;
                $data_qty['warehouse_id'] = $warehouse_id;
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->insert('products_warehouse_qty', $data_qty);
            }
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    // Books -> School Note Book Ends        
    
    
    
    
    // Uniform  
    public function add_product_uniform_post($data, $category, $warehouse, $quantity)
    {
        $data['parent_cid'] = '38';
        $this->db->insert('product_master', $data);
        $product_id = $this->db->insert_id();
        
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_uniform_post($data, $category, $warehouse, $quantity, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('product_master', $data);
        
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        foreach ($category as $category_id) {
            $data_cat['product_id']  = $product_id;
            $data_cat['category_id'] = $category_id;
            $this->db->insert('products_category', $data_cat);
        }
        
        $i = 0;
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_warehouse_qty');
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // Books -> School Note Book Ends        
    
    
    
    
    
    
    
    // Books -> Stationery Starts  
    
    public function get_stationery_product_list($user_id, $category, $per_page, $offset)
    {
        
        $this->db->select('p.id,p.title,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold,p.stationery_id,p.brand_id,p.description');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('p.parent_cid', $category);
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        /*    echo $this->db->last_query();
        exit();*/
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            
            $get_stationery = $this->product_model->get_stationery_by_id($row['stationery_id']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            $data[] = array(
                "id" => $row['id'],
                "description" => $row['description'],
                "model_number" => $row['model_number'],
                "brand" => $brand,
                "stationery" => $stationery,
                "base_price" => $row['base_price'],
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold']
            );
        }
        
        $total_data = $this->get_user_products_count($user_id, $category);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    public function add_product_stationery_post($data,$pdata,$category,$warehouse,$quantity)
    {
        $data['parent_cid'] = '6';
        $this->db->insert('product_master', $data);
        $master_id = $this->db->insert_id();
        
        //foreach ($category as $category_id) {
            $data_cat['product_id']  = $master_id;
            $data_cat['category_id'] = $category;
            $this->db->insert('products_category', $data_cat);
        //}
        
     
        $pdata['staff_id']   = 0;
        $pdata['user_id']    = $data['user_id'];
        $pdata['master_id']  = $master_id;
        $pdata['approve_by']  = 1;
        $pdata['status']  = 1;
        
        if($data['staff_id'] == 0 ){
            $pdata['last_user_id']    =  $data['user_id'];
        }else{
            $pdata['last_user_id']    =  $params['staff_id'];
        }
        $pdata['last_modified']    =  date('Y-m-d H:i:s');	
        $pdata['created_at']    =  date('Y-m-d H:i:s');
            
        $pdata['parent_cid'] = '6';
        $this->db->insert('products', $pdata);
        $product_id = $this->db->insert_id();
      
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $data_qty['product_id']   = $product_id;
            $data_qty['warehouse_id'] = $warehouse_id;
            $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
            $this->db->insert('products_warehouse_qty', $data_qty);
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        return $resultpost;
    }
    
    public function update_product_stationery_post($data,$pdata,$category,$product_id,$warehouse,$quantity,$subcate)
    {
        $query_prodct = $this->db->query("SELECT master_id FROM products where id='$product_id' limit 1");
        $row_data     = $query_prodct->row_array();
        $master_id    = $row_data['master_id'];
        
        $this->db->where('id', $master_id);
        $this->db->update('product_master', $data);
        
        $this->db->where('product_id', $master_id);
        $this->db->delete('products_category');
		
		if (isset($category) && is_array($category) && count($category) > 0) {
			foreach ($category as $category_id) {
				$data_cat['product_id']  = $master_id;
				$data_cat['category_id'] = $category_id;
				$this->db->insert('products_category', $data_cat);
			}
		} else {
			$data_cat['product_id']  = $master_id;
			$data_cat['category_id'] = $subcate;
			$this->db->insert('products_category', $data_cat); 
		}

        $this->db->where('id', $product_id);
        $this->db->update('products', $pdata);
        
        $i = 0;
        foreach ($warehouse as $warehouse_id) {
            $check_warehouse = $this->db->query("SELECT id FROM products_warehouse_qty where product_id='$product_id' and warehouse_id='$warehouse_id' limit 1")->num_rows();
            if($check_warehouse>0){
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->where('product_id', $product_id);
                $this->db->where('warehouse_id', $warehouse_id);
                $this->db->update('products_warehouse_qty', $data_qty);
            }
            else{
                $data_qty['product_id']   = $product_id;
                $data_qty['warehouse_id'] = $warehouse_id;
                $data_qty['quantity']     = ($quantity[$i] == '' ? '0' : $quantity[$i]);
                $this->db->insert('products_warehouse_qty', $data_qty);
            }
            $i++;
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $master_id
        );
        
        return $resultpost;
    }
    // Books -> School Text Book Ends      
    
    
    
    public function upload_images($product_id, $type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('upload_model');
        
        $year        = date("Y");
        $month       = date("m");
        $day         = date("d");
        //The folder path for our file should be YYYY/MM/DD
        $upload_path = "uploads/products/" . "$year/$month/$day/";
        //If the directory doesn't already exists.
        if (!is_dir($upload_path)) {
            mkdir($upload_path, 0755, true);
        }
	
        $row = $this->db->get_where('product_master', array(
            'id' => $product_id
        ))->row();
        
        if ($type == '') {
            $type = 'master';
        }
        
        $total_count = count($_FILES['images']['name']);
        
        for ($i = 0; $i < $total_count; $i++) {
            
            $tmpFilePath = $_FILES['images']['tmp_name'][$i];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['images']['name'][$i];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                        $data         = array(
                            'type' => $type,
                            'product_id' => $product_id,
                            'image' => $product_name,
                            'image_small' => $product_name
                        );
                        $this->upload_model->delete_temp_image($temp_path);
                        $this->db->insert('product_images', $data);
                    }
                }
            }
        }
        
        
        /*        //video
        $upload_path2 = './uploads/products/videos/';
        if (isset($_FILES['video']) && is_uploaded_file($_FILES['video']['tmp_name'])) {
        $ext1=pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
        $data2['video']= 'video_'.generate_unique_id() .'.'.$ext1;
        move_uploaded_file($_FILES['video']['tmp_name'], $upload_path2.$data2['video']);
        if($count>0):
        $this->upload_model->delete_temp_image($upload_path.$row->video);
        $this->db->where('id', $product_id);
        $this->db->update('product_master', $data2); 
        endif;
        }
        */
        
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }
    
    
    public function upload_services_images($product_id, $type)
    {
        
        $this->load->model('upload_model');
        
        $year  = date("Y");
        $month = date("m");
        $day   = date("d");
        $type  = 'product';
        
        $product_images_count = count($_FILES['product_images']['name']);
        
        if ($product_images_count > 0) {
            $upload_path = "uploads/services/product/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            for ($i = 0; $i < $product_images_count; $i++) {
                $tmpFilePath = $_FILES['product_images']['tmp_name'][$i];
                if ($tmpFilePath != "") {
                    $temp_path = $upload_path . $_FILES['product_images']['name'][$i];
                    if (move_uploaded_file($tmpFilePath, $temp_path)) {
                        if (!empty($temp_path)) {
                            $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                            $data         = array(
                                'type' => $type,
                                'product_id' => $product_id,
                                'image' => $product_name,
                                'image_small' => $product_name
                            );
                            $this->upload_model->delete_temp_image($temp_path);
                            $this->db->insert('product_images', $data);
                        }
                    }
                }
            }
        }
        
        $slider_images_count = count($_FILES['slider_images']['name']);
        
        if ($slider_images_count > 0) {
            $upload_path = "uploads/services/slider/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            for ($i = 0; $i < $product_images_count; $i++) {
                $tmpFilePath = $_FILES['slider_images']['tmp_name'][$i];
                if ($tmpFilePath != "") {
                    $temp_path = $upload_path . $_FILES['slider_images']['name'][$i];
                    if (move_uploaded_file($tmpFilePath, $temp_path)) {
                        if (!empty($temp_path)) {
                            $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                            $data         = array(
                                'product_id' => $product_id,
                                'image' => $product_name
                            );
                            $this->upload_model->delete_temp_image($temp_path);
                            $this->db->insert('slider_images', $data);
                        }
                    }
                }
            }
        }
        
        $banner_image1_count = count($_FILES['banner_image1']['name']);
        
        if ($banner_image1_count > 0) {
            $upload_path = "uploads/services/banner/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            $cquery = $this->db->query("SELECT id FROM product_banners WHERE product_id='$product_id' limit 1");
            if ($cquery->num_rows() == 0) {
                $data               = array();
                $data['product_id'] = $product_id;
                $this->db->insert('product_banners', $data);
            }
            
            $tmpFilePath = $_FILES['banner_image1']['tmp_name'][0];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['banner_image1']['name'][0];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $data         = array();
                        $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                        $data         = array(
                            'banner_1' => $product_name
                        );
                        $this->db->where('product_id', $product_id);
                        $this->db->update('product_banners', $data);
                        $this->upload_model->delete_temp_image($temp_path);
                    }
                }
            }
        }
        
        $banner_image2_count = count($_FILES['banner_image2']['name']);
        
        if ($banner_image2_count > 0) {
            $upload_path = "uploads/services/banner/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            $cquery = $this->db->query("SELECT id FROM product_banners WHERE product_id='$product_id' limit 1");
            if ($cquery->num_rows() == 0) {
                $data               = array();
                $data['product_id'] = $product_id;
                $this->db->insert('product_banners', $data);
            }
            
            $tmpFilePath = $_FILES['banner_image2']['tmp_name'][0];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['banner_image2']['name'][0];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $data         = array();
                        $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                        $data         = array(
                            'banner_2' => $product_name
                        );
                        $this->db->where('product_id', $product_id);
                        $this->db->update('product_banners', $data);
                        $this->upload_model->delete_temp_image($temp_path);
                    }
                }
            }
        }
        
        $banner_image3_count = count($_FILES['banner_image3']['name']);
        
        if ($banner_image3_count > 0) {
            $upload_path = "uploads/services/banner/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            $cquery = $this->db->query("SELECT id FROM product_banners WHERE product_id='$product_id' limit 1");
            if ($cquery->num_rows() == 0) {
                $data               = array();
                $data['product_id'] = $product_id;
                $this->db->insert('product_banners', $data);
            }
            
            $tmpFilePath = $_FILES['banner_image3']['tmp_name'][0];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['banner_image3']['name'][0];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $data         = array();
                        $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                        $data         = array(
                            'banner_3' => $product_name
                        );
                        $this->db->where('product_id', $product_id);
                        $this->db->update('product_banners', $data);
                        $this->upload_model->delete_temp_image($temp_path);
                    }
                }
            }
        }
        
        $banner_image4_count = count($_FILES['banner_image4']['name']);
        
        if ($banner_image4_count > 0) {
            $upload_path = "uploads/services/banner/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            $cquery = $this->db->query("SELECT id FROM product_banners WHERE product_id='$product_id' limit 1");
            if ($cquery->num_rows() == 0) {
                $data               = array();
                $data['product_id'] = $product_id;
                $this->db->insert('product_banners', $data);
            }
            
            $tmpFilePath = $_FILES['banner_image4']['tmp_name'][0];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['banner_image4']['name'][0];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $data         = array();
                        $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                        $data         = array(
                            'banner_4' => $product_name
                        );
                        $this->db->where('product_id', $product_id);
                        $this->db->update('product_banners', $data);
                        $this->upload_model->delete_temp_image($temp_path);
                    }
                }
            }
        }
        
        $banner_image5_count = count($_FILES['banner_image5']['name']);
        
        if ($banner_image5_count > 0) {
            $upload_path = "uploads/services/banner/" . "$year/$month/$day/";
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true);
            }
            
            $cquery = $this->db->query("SELECT id FROM product_banners WHERE product_id='$product_id' limit 1");
            if ($cquery->num_rows() == 0) {
                $data               = array();
                $data['product_id'] = $product_id;
                $this->db->insert('product_banners', $data);
            }
            
            $tmpFilePath = $_FILES['banner_image5']['tmp_name'][0];
            if ($tmpFilePath != "") {
                $temp_path = $upload_path . $_FILES['banner_image5']['name'][0];
                if (move_uploaded_file($tmpFilePath, $temp_path)) {
                    if (!empty($temp_path)) {
                        $data         = array();
                        $product_name = $this->upload_model->product_default_image_upload($temp_path, $upload_path);
                        $data         = array(
                            'banner_5' => $product_name
                        );
                        $this->db->where('product_id', $product_id);
                        $this->db->update('product_banners', $data);
                        $this->upload_model->delete_temp_image($temp_path);
                    }
                }
            }
        }
        
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }
    
    
    public function get_product_image_by_id($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('product_images');
        return $query->row();
    }
    
    public function product_image_delete($id)
    {
        $this->load->model('upload_model');
        date_default_timezone_set('Asia/Kolkata');
        $upload_path = './uploads/products/';
        
        $product = $this->get_product_image_by_id($id);
        if (!empty($product)) {
            $temp_path  = $upload_path . $product->image;
            $temp_path2 = $upload_path . $product->image_small;
            
            $this->upload_model->delete_temp_image($temp_path);
            $this->upload_model->delete_temp_image($temp_path2);
            $this->db->where('id', $id);
            $this->db->delete('product_images');
        }
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success'
        );
        return $resultpost;
    }
    
    
    public function get_filter_school_text_book($filter, $per_page, $offset)
    {
        
        $publisher_filter = "";
        $subject_filter   = "";
        $board_filter     = "";
        $grades_filter    = "";
        $keywords_filter  = "";
        
        if (isset($filter['publisher']) && $filter['publisher'] != ""):
            $publisher        = $filter['publisher'];
            $publisher_filter = " AND p.publisher_id='$publisher'";
        endif;
        
        if (isset($filter['subject']) && $filter['subject'] != ""):
            $subject          = $filter['subject'];
            $publisher_filter = " AND p.subject_id='$subject'";
        endif;
        
        if (isset($filter['board']) && $filter['board'] != ""):
            $board        = $filter['board'];
            $board_filter = " AND  FIND_IN_SET(p.board_id    , '$board')";
        endif;
        
        if (isset($filter['grades']) && $filter['grades'] != ""):
            $grades        = $filter['grades'];
            $grades_filter = " AND  FIND_IN_SET(p.grade_id    , '$grades')";
        endif;
        
        if (isset($filter['keywords']) && $filter['keywords'] != ""):
            $keywords        = $filter['keywords'];
            $keywords_filter = " AND (p.title LIKE '%$keywords%'
          OR p.isbn LIKE '%$keywords%')";
        endif;
        
        
        
        
        $rows = $this->db->query("SELECT p.id,p.title,p.isbn
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='8') AND (p.is_deleted='0')
        $publisher_filter $subject_filter $board_filter $grades_filter $keywords_filter
          GROUP BY p.id ORDER BY p.id ASC");
        
        $query = $this->db->query("SELECT p.id,p.title,p.isbn,p.publisher_id,p.subject_id,p.grade_id,p.board_id
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='8') AND (p.is_deleted='0')
        $publisher_filter $subject_filter $board_filter $grades_filter $keywords_filter
        GROUP BY p.id ORDER BY p.id ASC LIMIT $offset,$per_page");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = 'N/A';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = 'N/A';
            }
            
            
            $get_grade = $this->product_model->get_grade_list($row['grade_id']);
            if ($get_grade != '') {
                $grade = $get_grade;
            } else {
                $grade = 'N/A';
            }
            
            
            $get_board = $this->product_model->get_board_list($row['board_id']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = 'N/A';
            }
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = 'N/A';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if ($image_url != '') {
                if (file_exists('uploads/products/' . $image_url)) {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
                } else {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
                }
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $id        = $row['id'];
            $user_id   = $filter['user_id'];
            $duplicate = $this->db->query("SELECT * FROM `products` WHERE master_id = '$id' AND user_id='$user_id'")->num_rows();
            
            $title = $row['title'];
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', ' ', $title);
            $title = strtolower(str_replace('-', ' ', $title));
            $title = ucfirst($title);
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $title,
                "isbn" => $row['isbn'],
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "category" => $category,
                "image_url" => $image_url,
                "duplicate" => $duplicate
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    public function get_product_master_details($user_id, $id, $parent_id)
    {
        $query = $this->db->query("SELECT p.id,p.subcate,p.title,p.publisher_id,p.isbn,p.board_id,p.grade_id,p.brand_id,p.subject_id,
        p.no_of_pages,p.gst,p.hsn,p.lenght,p.width,p.height,p.weight,p.meta_title,p.meta_keyword,p.meta_description,
        p.product_description,p.age_grade,p.from_age,p.to_age,p.highlights,p.size,p.school,p.video,p.binding_type,p.color,p.product_origin
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='$parent_id') AND (p.is_deleted='0')
        AND (p.id='$id')
        GROUP BY p.id ORDER BY p.id ASC");
        
        
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $data = array();
        foreach ($query->result_array() as $row) {
            
            $publisher    = 'N/A';
            $subject      = 'N/A';
            $grade        = 'N/A';
            $board        = 'N/A';
            $brand        = 'N/A';
            $size         = 'N/A';
            $school       = 'N/A';
            $binding_type = 'N/A';
            $color        = 'N/A';
            $subcate      = 'N/A';
            
            if ($row['publisher_id'] != '') {
                $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
                if ($get_publisher->num_rows() > 0) {
                    $publisher_data = $get_publisher->row();
                    $publisher      = $publisher_data->name;
                }
            }
            
            
            if ($row['grade_id'] != '') {
                $get_grade = $this->product_model->get_grade_list($row['grade_id']);
                if ($get_grade != '') {
                    $grade = $get_grade;
                }
            }
            
            
            if ($row['board_id'] != '') {
                $get_board = $this->product_model->get_board_list($row['board_id']);
                if ($get_board != '') {
                    $board = $get_board;
                }
            }
            
            
            if ($row['brand_id'] != '') {
                $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
                if ($get_brand->num_rows() > 0) {
                    $brand_data = $get_brand->row();
                    $brand      = $brand_data->name;
                }
            }
            
            if ($row['subject_id'] != '') {
                $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
                if ($get_subject->num_rows() > 0) {
                    $subject_data = $get_subject->row();
                    $subject      = $subject_data->name;
                }
            }
            
            
            if ($row['size'] != '') {
                $get_size = $this->product_model->get_size_list($row['size']);
                if ($get_size != '') {
                    $size = $get_size;
                }
            }
            
            
            if ($row['school'] != '') {
                $get_school = $this->product_model->get_school_by_id($row['school']);
                if ($get_school->num_rows() > 0) {
                    $school_data = $get_school->row();
                    $school      = $school_data->name;
                }
            }
            
            if ($row['binding_type'] != '') {
                $get_binding_type = $this->product_model->get_binding_type_by_id($row['binding_type']);
                if ($get_binding_type->num_rows() > 0) {
                    $binding_type_data = $get_binding_type->row();
                    $binding_type      = $binding_type_data->name;
                }
            }
            
            if ($row['color'] != '') {
                $get_color = $this->product_model->get_color_by_id($row['color']);
                if ($get_color->num_rows() > 0) {
                    $color_data = $get_color->row();
                    $color      = $color_data->name;
                }
            }
            
            if ($row['subcate'] != '') {
                $get_subcate = $this->product_model->get_category_by_id($row['subcate']);
                if ($get_subcate->num_rows() > 0) {
                    $subcate_data = $get_subcate->row();
                    $subcate      = $subcate_data->name;
                }
            }
            
            
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = '-';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if (file_exists('uploads/products/' . $image_url)) {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "isbn" => $row['isbn'],
                "publisher" => $publisher,
                "board" => $board,
                "brand" => $brand,
                "subject" => $subject,
                "grade" => $grade,
                "category" => $category,
                "image_url" => $image_url,
                "no_of_pages" => ($row['no_of_pages'] != 0 ? $row['no_of_pages'] : 'N/A'),
                "isbn" => $row['isbn'],
                "gst" => $row['gst'],
                "hsn" => ($row['hsn'] ? $row['hsn'] : 'N/A'),
                "lenght" => ($row['lenght'] ? $row['lenght'] : 'N/A'),
                "width" => ($row['width'] ? $row['width'] : 'N/A'),
                "height" => ($row['height'] ? $row['height'] : 'N/A'),
                "weight" => ($row['weight'] ? $row['weight'] : 'N/A'),
                "meta_title" => ($row['meta_title'] ? $row['meta_title'] : 'N/A'),
                "meta_keyword" => ($row['meta_keyword'] ? $row['meta_keyword'] : 'N/A'),
                "meta_description" => ($row['meta_description'] ? $row['meta_description'] : 'N/A'),
                "product_description" => $row['product_description'],
                "age_grade" => $row['age_grade'],
                "from_age" => $row['from_age'],
                "to_age" => $row['to_age'],
                "isbn" => $row['isbn'],
                "highlights" => json_decode($row['highlights']),
                "product_origin" => ($row['product_origin'] ? $row['product_origin'] : 'N/A'),
                "size" => $size,
                "school" => $school,
                "binding_type" => $binding_type,
                "color" => $color,
                "subcate" => $subcate
            );
        }
        
        $total_data = 1;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    
    public function get_product_stationary_master_details($user_id, $id, $parent_id)
    {
        $query = $this->db->query("SELECT p.id,p.subcate,p.title,p.publisher_id,p.isbn,p.board_id,p.grade_id,p.brand_id,p.subject_id,
        p.no_of_pages,p.gst,p.hsn,p.lenght,p.width,p.height,p.weight,p.meta_title,p.meta_keyword,p.meta_description,
        p.product_description,p.age_grade,p.from_age,p.to_age,p.highlights,p.size,p.school,p.video,p.binding_type,p.color,p.product_origin
         FROM  product_master as p
        WHERE  (p.parent_cid='$parent_id') AND (p.is_deleted='0')
        AND (p.id='$id')
        GROUP BY p.id ORDER BY p.id ASC");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $data = array();
        foreach ($query->result_array() as $row) {
            
            $publisher    = 'N/A';
            $subject      = 'N/A';
            $grade        = 'N/A';
            $board        = 'N/A';
            $brand        = 'N/A';
            $size         = 'N/A';
            $school       = 'N/A';
            $binding_type = 'N/A';
            $color        = 'N/A';
            $subcate      = 'N/A';
            
            
            if ($row['publisher_id'] != '') {
                $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
                if ($get_publisher->num_rows() > 0) {
                    $publisher_data = $get_publisher->row();
                    $publisher      = $publisher_data->name;
                }
            }
            
            
            if ($row['grade_id'] != '') {
                $get_grade = $this->product_model->get_grade_list($row['grade_id']);
                if ($get_grade != '') {
                    $grade = $get_grade;
                }
            }
            
            
            if ($row['board_id'] != '') {
                $get_board = $this->product_model->get_board_list($row['board_id']);
                if ($get_board != '') {
                    $board = $get_board;
                }
            }
            
            
            if ($row['brand_id'] != '') {
                $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
                if ($get_brand->num_rows() > 0) {
                    $brand_data = $get_brand->row();
                    $brand      = $brand_data->name;
                }
            }
            
            if ($row['subject_id'] != '') {
                $get_subject = $this->product_model->get_subject_by_id($row['brand_id']);
                if ($get_subject->num_rows() > 0) {
                    $subject_data = $get_subject->row();
                    $subject      = $subject_data->name;
                }
            }
            
            
            if ($row['size'] != '') {
                $get_size = $this->product_model->get_size_list($row['size']);
                if ($get_size != '') {
                    $size = $get_size;
                }
            }
            
            
            if ($row['school'] != '') {
                $get_school = $this->product_model->get_school_by_id($row['school']);
                if ($get_school->num_rows() > 0) {
                    $school_data = $get_school->row();
                    $school      = $school_data->name;
                }
            }
            
            if ($row['binding_type'] != '') {
                $get_binding_type = $this->product_model->get_binding_type_by_id($row['binding_type']);
                if ($get_binding_type->num_rows() > 0) {
                    $binding_type_data = $get_binding_type->row();
                    $binding_type      = $binding_type_data->name;
                }
            }
            
            if ($row['color'] != '') {
                $get_color = $this->product_model->get_color_by_id($row['color']);
                if ($get_color->num_rows() > 0) {
                    $color_data = $get_color->row();
                    $color      = $color_data->name;
                }
            }
            
            //  if($row['subcate']!='') {    
            //   $get_subcate = $this->product_model->get_category_by_id($row['subcate']);
            //   if($get_subcate->num_rows() > 0){
            //      $subcate_data=$get_subcate->row();
            //      $subcate= $subcate_data->name;
            //   }
            //  }
            $subcate               = '';
            $xtra_id_              = $row['id'];
            $query_prodct_cat      = $this->db->query("SELECT c2.name
            FROM categories as c1
            INNER JOIN products_category as pc ON pc.category_id = c1.id
            INNER JOIN categories as c2 ON c1.parent_id = c2.id 
            where pc.product_id = '$xtra_id_'");
            $query_prodct_cat_data = $query_prodct_cat->row_array();
            $subcate               = $query_prodct_cat_data['name'];
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = 'N/A';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if (file_exists('uploads/products/' . $image_url)) {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "isbn" => $row['isbn'],
                "publisher" => $publisher,
                "board" => $board,
                "brand" => $brand,
                "subject" => $subject,
                "grade" => $grade,
                "category" => $category,
                "image_url" => $image_url,
                "no_of_pages" => ($row['no_of_pages'] != 0 ? $row['no_of_pages'] : 'N/A'),
                "isbn" => $row['isbn'],
                "gst" => $row['gst'],
                "hsn" => ($row['hsn'] ? $row['hsn'] : 'N/A'),
                "lenght" => ($row['lenght'] ? $row['lenght'] : 'N/A'),
                "width" => ($row['width'] ? $row['width'] : 'N/A'),
                "height" => ($row['height'] ? $row['height'] : 'N/A'),
                "weight" => ($row['weight'] ? $row['weight'] : 'N/A'),
                "meta_title" => ($row['meta_title'] ? $row['meta_title'] : 'N/A'),
                "meta_keyword" => ($row['meta_keyword'] ? $row['meta_keyword'] : 'N/A'),
                "meta_description" => ($row['meta_description'] ? $row['meta_description'] : 'N/A'),
                "product_description" => $row['product_description'],
                "age_grade" => $row['age_grade'],
                "from_age" => $row['from_age'],
                "to_age" => $row['to_age'],
                "isbn" => $row['isbn'],
                "highlights" => json_decode($row['highlights']),
                "product_origin" => ($row['product_origin'] ? $row['product_origin'] : 'N/A'),
                "size" => $size,
                "school" => $school,
                "binding_type" => $binding_type,
                "color" => $color,
                "subcate" => $subcate
            );
        }
        
        $total_data = 1;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    
    public function get_product_toys_master_details($user_id, $id, $parent_id)
    {
        $query = $this->db->query("SELECT p.id,p.subcate,p.title,p.publisher_id,p.isbn,p.board_id,p.grade_id,p.brand_id,p.subject_id,
        p.no_of_pages,p.gst,p.hsn,p.lenght,p.width,p.height,p.weight,p.meta_title,p.meta_keyword,p.meta_description,
        p.product_description,p.age_grade,p.from_age,p.to_age,p.highlights,p.size,p.school,p.video,p.binding_type,p.color,p.product_origin
         FROM  product_master as p
        WHERE  (p.parent_cid='$parent_id') AND (p.is_deleted='0')
        AND (p.id='$id')
        GROUP BY p.id ORDER BY p.id ASC");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $data = array();
        foreach ($query->result_array() as $row) {
            
            $publisher    = 'N/A';
            $subject      = 'N/A';
            $grade        = 'N/A';
            $board        = 'N/A';
            $brand        = 'N/A';
            $size         = 'N/A';
            $school       = 'N/A';
            $binding_type = 'N/A';
            $color        = 'N/A';
            $subcate      = 'N/A';
            
            
            if ($row['publisher_id'] != '') {
                $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
                if ($get_publisher->num_rows() > 0) {
                    $publisher_data = $get_publisher->row();
                    $publisher      = $publisher_data->name;
                }
            }
            
            
            if ($row['grade_id'] != '') {
                $get_grade = $this->product_model->get_grade_list($row['grade_id']);
                if ($get_grade != '') {
                    $grade = $get_grade;
                }
            }
            
            
            if ($row['board_id'] != '') {
                $get_board = $this->product_model->get_board_list($row['board_id']);
                if ($get_board != '') {
                    $board = $get_board;
                }
            }
            
            
            if ($row['brand_id'] != '') {
                $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
                if ($get_brand->num_rows() > 0) {
                    $brand_data = $get_brand->row();
                    $brand      = $brand_data->name;
                }
            }
            
            if ($row['subject_id'] != '') {
                $get_subject = $this->product_model->get_subject_by_id($row['brand_id']);
                if ($get_subject->num_rows() > 0) {
                    $subject_data = $get_subject->row();
                    $subject      = $subject_data->name;
                }
            }
            
            
            if ($row['size'] != '') {
                $get_size = $this->product_model->get_size_list($row['size']);
                if ($get_size != '') {
                    $size = $get_size;
                }
            }
            
            
            if ($row['school'] != '') {
                $get_school = $this->product_model->get_school_by_id($row['school']);
                if ($get_school->num_rows() > 0) {
                    $school_data = $get_school->row();
                    $school      = $school_data->name;
                }
            }
            
            if ($row['binding_type'] != '') {
                $get_binding_type = $this->product_model->get_binding_type_by_id($row['binding_type']);
                if ($get_binding_type->num_rows() > 0) {
                    $binding_type_data = $get_binding_type->row();
                    $binding_type      = $binding_type_data->name;
                }
            }
            
            if ($row['color'] != '') {
                $get_color = $this->product_model->get_color_by_id($row['color']);
                if ($get_color->num_rows() > 0) {
                    $color_data = $get_color->row();
                    $color      = $color_data->name;
                }
            }
            
            if ($row['subcate'] != '') {
                $get_subcate = $this->product_model->get_category_by_id($row['subcate']);
                if ($get_subcate->num_rows() > 0) {
                    $subcate_data = $get_subcate->row();
                    $subcate      = $subcate_data->name;
                }
            }
            
            
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = '-';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if (file_exists('uploads/products/' . $image_url)) {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "isbn" => $row['isbn'],
                "publisher" => $publisher,
                "board" => $board,
                "brand" => $brand,
                "subject" => $subject,
                "grade" => $grade,
                "category" => $category,
                "image_url" => $image_url,
                "no_of_pages" => ($row['no_of_pages'] != 0 ? $row['no_of_pages'] : 'N/A'),
                "isbn" => $row['isbn'],
                "gst" => $row['gst'],
                "hsn" => ($row['hsn'] ? $row['hsn'] : 'N/A'),
                "lenght" => ($row['lenght'] ? $row['lenght'] : 'N/A'),
                "width" => ($row['width'] ? $row['width'] : 'N/A'),
                "height" => ($row['height'] ? $row['height'] : 'N/A'),
                "weight" => ($row['weight'] ? $row['weight'] : 'N/A'),
                "meta_title" => ($row['meta_title'] ? $row['meta_title'] : 'N/A'),
                "meta_keyword" => ($row['meta_keyword'] ? $row['meta_keyword'] : 'N/A'),
                "meta_description" => ($row['meta_description'] ? $row['meta_description'] : 'N/A'),
                "product_description" => $row['product_description'],
                "age_grade" => $row['age_grade'],
                "from_age" => $row['from_age'],
                "to_age" => $row['to_age'],
                "isbn" => $row['isbn'],
                "highlights" => json_decode($row['highlights']),
                "product_origin" => ($row['product_origin'] ? $row['product_origin'] : 'N/A'),
                "size" => $size,
                "school" => $school,
                "binding_type" => $binding_type,
                "color" => $color,
                "subcate" => $subcate
            );
        }
        
        $total_data = 1;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    public function get_filter_note_book($filter, $per_page, $offset)
    {
        
        $keywords_filter = "";
        
        if (isset($filter['keywords']) && $filter['keywords'] != ""):
            $keywords        = $filter['keywords'];
            $keywords_filter = " AND (p.title LIKE '%$keywords%'
          OR p.isbn LIKE '%$keywords%')";
        endif;
        
        if (isset($filter['brand']) && $filter['brand'] != ""):
            $brand           = $filter['brand'];
            $keywords_filter = " AND (p.brand_id='$brand')";
        endif;
        
        
        
        $rows = $this->db->query("SELECT p.id,p.title,p.isbn,p.brand_id
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='10') AND (p.is_deleted='0')  $keywords_filter
         GROUP BY p.id ORDER BY p.id ASC");
        
        $query = $this->db->query("SELECT p.id,p.title,p.isbn,p.brand_id
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='10') AND (p.is_deleted='0')  $keywords_filter
        GROUP BY p.id ORDER BY p.id ASC LIMIT $offset,$per_page");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = 'N/A';
            }
            
            if ($category == null) {
                $category = 'N/A';
            }
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if ($image_url != '') {
                if (file_exists('uploads/products/' . $image_url)) {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
                } else {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
                }
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $this->db->where('id', $row['brand_id']);
            $query_brand = $this->db->get('brand');
            $row_brand   = $query_brand->row_array();
            $id          = $row['id'];
            $user_id     = $filter['user_id'];
            $duplicate   = $this->db->query("SELECT * FROM `products` WHERE master_id = '$id' and user_id='$user_id'")->num_rows();
            
            if ($row_brand['name'] == '' || $row_brand['name'] == 'null') {
                $brand_name = 'N/A';
            } else {
                $brand_name = $row_brand['name'];
            }
            
            $title = $row['title'];
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', ' ', $title);
            $title = strtolower(str_replace('-', ' ', $title));
            $title = ucfirst($title);
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $title,
                "isbn" => $row['isbn'],
                "brand_id" => $row['brand_id'],
                "brand" => $brand_name,
                "category" => $category,
                "image_url" => $image_url,
                "duplicate" => $duplicate
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    public function get_filter_other_book($filter, $per_page, $offset)
    {
        
        $publisher_filter = "";
        $subject_filter   = "";
        $board_filter     = "";
        $grades_filter    = "";
        $keywords_filter  = "";
        
        if (isset($filter['publisher']) && $filter['publisher'] != ""):
            $publisher        = $filter['publisher'];
            $publisher_filter = " AND p.publisher_id='$publisher'";
        endif;
        
        if (isset($filter['subject']) && $filter['subject'] != ""):
            $subject          = $filter['subject'];
            $publisher_filter = " AND p.subject_id='$subject'";
        endif;
        
        if (isset($filter['board']) && $filter['board'] != ""):
            $board        = $filter['board'];
            $board_filter = " AND  FIND_IN_SET(p.board_id    , '$board')";
        endif;
        
        if (isset($filter['grades']) && $filter['grades'] != ""):
            $grades        = $filter['grades'];
            $grades_filter = " AND  FIND_IN_SET(p.grade_id    , '$grades')";
        endif;
        
        if (isset($filter['keywords']) && $filter['keywords'] != ""):
            $keywords        = $filter['keywords'];
            $keywords_filter = " AND (p.title LIKE '%$keywords%'
          OR p.isbn LIKE '%$keywords%')";
        endif;
        
        
        
        
        $rows = $this->db->query("SELECT p.id,p.title,p.isbn
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='45') AND (p.is_deleted='0')
        $publisher_filter $subject_filter $board_filter $grades_filter $keywords_filter
          GROUP BY p.id ORDER BY p.id ASC");
        
        $query = $this->db->query("SELECT p.id,p.title,p.isbn,p.publisher_id,p.subject_id,p.grade_id,p.board_id
         FROM  product_master as p
        INNER JOIN products_category ON p.id=products_category.product_id
         INNER JOIN categories ON categories.id=products_category.category_id
        WHERE  (categories.parent_id='45') AND (p.is_deleted='0')
        $publisher_filter $subject_filter $board_filter $grades_filter $keywords_filter
        GROUP BY p.id ORDER BY p.id ASC LIMIT $offset,$per_page");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = 'N/A';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = 'N/A';
            }
            
            
            $get_grade = $this->product_model->get_grade_list($row['grade_id']);
            if ($get_grade != '') {
                $grade = $get_grade;
            } else {
                $grade = 'N/A';
            }
            
            
            $get_board = $this->product_model->get_board_list($row['board_id']);
            if ($get_board != '') {
                $board = $get_board;
            } else {
                $board = 'N/A';
            }
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = 'N/A';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if ($image_url != '') {
                if (file_exists('uploads/products/' . $image_url)) {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
                } else {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
                }
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $id        = $row['id'];
            $user_id   = $filter['user_id'];
            $duplicate = $this->db->query("SELECT * FROM `products` WHERE master_id = '$id' and user_id='$user_id'")->num_rows();
            
            $title = $row['title'];
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', ' ', $title);
            $title = strtolower(str_replace('-', ' ', $title));
            $title = ucfirst($title);
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $title,
                "isbn" => $row['isbn'],
                "publisher" => $publisher,
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade,
                "category" => $category,
                "image_url" => $image_url,
                "duplicate" => $duplicate
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    public function get_filter_stationary($filter, $per_page, $offset)
    {
        
        $stationary_filter = "";
        $brand_filter      = "";
        $keywords_filter   = "";
        
        if (isset($filter['stationary_id']) && $filter['stationary_id'] != ""):
            $stationary_id     = $filter['stationary_id'];
            $stationary_filter = " AND pc.category_id ='$stationary_id'";
        endif;
        
        if (isset($filter['brand_id']) && $filter['brand_id'] != ""):
            $brand_id     = $filter['brand_id'];
            $brand_filter = " AND p.brand_id='$brand_id'";
        endif;
        
        if (isset($filter['keywords']) && $filter['keywords'] != ""):
            $keywords        = $filter['keywords'];
            $keywords_filter = " AND (p.description LIKE '%$keywords%'
          OR p.isbn LIKE '%$keywords%' or p.title LIKE '%$keywords%')";
        endif;
        
        
        
        
        $rows = $this->db->query("SELECT p.subcate,p.id, p.title,p.isbn,p.stationery_id,p.brand_id,p.description
         FROM  product_master as p
         INNER JOIN products_category as pc ON pc.product_id = p.id
        WHERE  (p.parent_cid='6')  AND (p.is_deleted='0')
        $stationary_filter $brand_filter $keywords_filter
          GROUP BY p.id ORDER BY p.id ASC");
        
        $query = $this->db->query("SELECT p.subcate,p.id, p.title,p.isbn,p.stationery_id,p.brand_id,p.description
         FROM  product_master as p
         INNER JOIN products_category as pc ON pc.product_id = p.id
        WHERE  (p.parent_cid='6') AND (p.is_deleted='0')
        $stationary_filter $brand_filter $keywords_filter
        GROUP BY p.id ORDER BY p.id ASC LIMIT $offset,$per_page");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_stationery = $this->product_model->get_stationery_by_id($row['subcate']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = 'N/A';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = 'N/A';
            }
            
            
            
            
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = 'N/A';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            if ($image_url != '') {
                if (file_exists('uploads/products/' . $image_url)) {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
                } else {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
                }
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            $id        = $row['id'];
            $user_id   = $filter['user_id'];
            $duplicate = $this->db->query("SELECT * FROM `products` WHERE master_id = '$id' and user_id='$user_id'")->num_rows();
            
            $title = $row['title'];
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', ' ', $title);
            $title = strtolower(str_replace('-', ' ', $title));
            $title = ucfirst($title);
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $title,
                "isbn" => $row['isbn'],
                "stationary" => $stationery,
                "brand" => $brand,
                "category" => $category,
                "image_url" => $image_url,
                "duplicate" => $duplicate
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    
    
    // shoes Starts 
    
    public function get_filter_shoes($filter, $per_page, $offset)
    {
        
        $stationary_filter = "";
        $brand_filter      = "";
        $keywords_filter   = "";
        $category_filter   = "";
        
        if (isset($filter['color']) && $filter['color'] != ""):
            $color             = $filter['color'];
            $stationary_filter = " AND p.color='$color'";
        endif;
        
        if (isset($filter['brand_id']) && $filter['brand_id'] != ""):
            $brand_id     = $filter['brand_id'];
            $brand_filter = " AND p.brand_id='$brand_id'";
        endif;
        
        if (isset($filter['keywords']) && $filter['keywords'] != ""):
            $keywords        = $filter['keywords'];
            $keywords_filter = " AND (p.title LIKE '%$keywords%'
          OR p.isbn LIKE '%$keywords%')";
        endif;
        
        if (isset($filter['color']) && $filter['color'] != ""):
            $color             = $filter['color'];
            $stationary_filter = " AND p.color='$color'";
        endif;
        
        if (isset($filter['category']) && $filter['category'] != ""):
            $category        = $filter['category'];
            $category_filter = " AND cat.id='$category'";
        endif;
        
        $rows = $this->db->query("SELECT cat.name as cat_name,p.id,p.isbn,p.color,p.brand_id,p.title
         FROM  product_master as p
         INNER JOIN products_category as pc ON p.id = pc.product_id
         INNER JOIN categories as cat ON cat.id = pc.category_id
        WHERE  (parent_cid='38')  AND (p.is_deleted='0')
        $stationary_filter $brand_filter $keywords_filter $category_filter
          GROUP BY p.id ORDER BY p.id ASC");
        
        $query = $this->db->query("SELECT p.id,p.isbn,p.color,p.brand_id,p.title
         FROM  product_master as p
         INNER JOIN products_category as pc ON p.id = pc.product_id
         INNER JOIN categories as cat ON cat.id = pc.category_id
        WHERE  (parent_cid='38') AND (p.is_deleted='0')
        $stationary_filter $brand_filter $keywords_filter $category_filter
        GROUP BY p.id ORDER BY p.id ASC LIMIT $offset,$per_page");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_stationery = $this->product_model->get_color_by_id($row['color']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $color           = $stationery_data->name;
            } else {
                $color = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            
            
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = '-';
            }
            
            $get_main_cat = $this->product_model->get_main_cat_by_id($row['id']);
            if ($get_main_cat != '') {
                $main_cat = $get_main_cat;
            } else {
                $main_cat = '-';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if ($image_url != '') {
                if (file_exists('uploads/products/' . $image_url)) {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
                } else {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
                }
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $id        = $row['id'];
            $user_id   = $filter['user_id'];
            $duplicate = $this->db->query("SELECT * FROM `products` WHERE master_id = '$id' and user_id='$user_id' AND is_deleted='0'")->num_rows();
            
            $title = $row['title'];
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', ' ', $title);
            $title = strtolower(str_replace('-', ' ', $title));
            $title = ucfirst($title);
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $title,
                "isbn" => $row['isbn'],
                "color" => $color,
                "brand" => $brand,
                "main_cat" => $main_cat,
                "category" => $category,
                "image_url" => $image_url,
                "duplicate" => $duplicate
            );
        }
        
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    
    
    public function get_filter_toys($filter, $per_page, $offset)
    {
        
        $stationary_filter = "";
        $brand_filter      = "";
        $keywords_filter   = "";
        
        if (isset($filter['stationary_id']) && $filter['stationary_id'] != ""):
            $stationary_id     = $filter['stationary_id'];
            $stationary_filter = " AND p.stationery_id='$stationary_id'";
        endif;
        
        if (isset($filter['brand_id']) && $filter['brand_id'] != ""):
            $brand_id     = $filter['brand_id'];
            $brand_filter = " AND p.brand_id='$brand_id'";
        endif;
        
        if (isset($filter['keywords']) && $filter['keywords'] != ""):
            $keywords        = $filter['keywords'];
            $keywords_filter = " AND (p.title LIKE '%$keywords%'
          OR p.isbn LIKE '%$keywords%')";
        endif;
        
        
        
        
        $rows = $this->db->query("SELECT p.id,p.isbn,p.stationery_id,p.brand_id,p.description
         FROM  product_master as p
        WHERE  (parent_cid='155')  AND (p.is_deleted='0')
        $stationary_filter $brand_filter $keywords_filter
          GROUP BY p.id ORDER BY p.id ASC");
        
        $query = $this->db->query("SELECT p.id,p.isbn,p.stationery_id,p.brand_id,p.description as title
         FROM  product_master as p
        WHERE  (parent_cid='155') AND (p.is_deleted='0')
        $stationary_filter $brand_filter $keywords_filter
        GROUP BY p.id ORDER BY p.id ASC LIMIT $offset,$per_page");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $count = $rows->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_stationery = $this->product_model->get_stationery_by_id($row['stationery_id']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            
            
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = '-';
            }
            
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if ($image_url != '') {
                if (file_exists('uploads/products/' . $image_url)) {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
                } else {
                    $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
                }
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $title = $row['title'];
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', ' ', $title);
            $title = strtolower(str_replace('-', ' ', $title));
            $title = ucfirst($title);
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $title,
                "isbn" => $row['isbn'],
                "stationary" => $stationery,
                "brand" => $brand,
                "category" => $category,
                "image_url" => $image_url
            );
        }
        
        $total_data = $count;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    public function get_shoes_product_list($user_id, $category, $per_page, $offset)
    {
        
        $this->db->select('p.id,p.title,p.model_number,p.publisher_id,p.subject_id,p.grade_id,p.board_id,p.base_price,p.gst,status,p.is_sold,p.stationery_id,p.brand_id,p.description');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('p.parent_cid', $category);
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc');
        $query = $this->db->get('products as p');
        /*    echo $this->db->last_query();
        exit();*/
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            
            $get_stationery = $this->product_model->get_stationery_by_id($row['stationery_id']);
            if ($get_stationery->num_rows() > 0) {
                $stationery_data = $get_stationery->row();
                $stationery      = $stationery_data->name;
            } else {
                $stationery = '-';
            }
            
            $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
            if ($get_brand->num_rows() > 0) {
                $brand_data = $get_brand->row();
                $brand      = $brand_data->name;
            } else {
                $brand = '-';
            }
            
            
            $data[] = array(
                "id" => $row['id'],
                "description" => $row['description'],
                "model_number" => $row['model_number'],
                "brand" => $brand,
                "status" => $row['status'],
                "gst" => $row['gst'],
                "is_sold" => $row['is_sold']
            );
        }
        
        $total_data = $this->get_user_products_count($user_id, $category);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
    public function add_product_shoes_post($data, $category)
    {
        $data['parent_cid'] = '38';
        $this->db->insert('product_master', $data);
        $product_id = $this->db->insert_id();
        
        
        $data_cat['product_id']  = $product_id;
        $data_cat['category_id'] = $category;
        $this->db->insert('products_category', $data_cat);
        
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    
    
    
    public function update_product_shoes_post($data, $category, $product_id)
    {
        $this->db->where('id', $product_id);
        $this->db->update('product_master', $data);
        
        $this->db->where('product_id', $product_id);
        $this->db->delete('products_category');
        
        $data_cat['product_id']  = $product_id;
        $data_cat['category_id'] = $category;
        $this->db->insert('products_category', $data_cat);
        
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'pid' => $product_id
        );
        
        return $resultpost;
    }
    // shoes Ends      
    
    
    
    
    public function get_product_shoes_master_details($user_id, $id, $parent_id)
    {
        $query = $this->db->query("SELECT p.id,p.subcate,p.title,p.publisher_id,p.isbn,p.board_id,p.grade_id,p.brand_id,p.subject_id,
        p.no_of_pages,p.gst,p.hsn,p.lenght,p.width,p.height,p.weight,p.meta_title,p.meta_keyword,p.meta_description,
        p.product_description,p.age_grade,p.from_age,p.to_age,p.highlights,p.size,p.school,p.video,p.binding_type,p.color,p.product_origin,p.gender,p.age_type
         FROM  product_master as p
        WHERE  (p.parent_cid='$parent_id') AND (p.is_deleted='0')
        AND (p.id='$id')
        GROUP BY p.id ORDER BY p.id ASC");
        
        
        /*    echo $this->db->last_query();
        exit();*/
        $data = array();
        foreach ($query->result_array() as $row) {
            $publisher    = 'N/A';
            $subject      = 'N/A';
            $grade        = 'N/A';
            $board        = 'N/A';
            $brand        = 'N/A';
            $size         = 'N/A';
            $school       = 'N/A';
            $binding_type = 'N/A';
            $color        = 'N/A';
            $subcate      = 'N/A';
            
            if ($row['publisher_id'] != '') {
                $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
                if ($get_publisher->num_rows() > 0) {
                    $publisher_data = $get_publisher->row();
                    $publisher      = $publisher_data->name;
                }
            }
            
            
            if ($row['grade_id'] != '') {
                $get_grade = $this->product_model->get_grade_list($row['grade_id']);
                if ($get_grade != '') {
                    $grade = $get_grade;
                }
            }
            
            
            if ($row['board_id'] != '') {
                $get_board = $this->product_model->get_board_list($row['board_id']);
                if ($get_board != '') {
                    $board = $get_board;
                }
            }
            
            if ($row['size'] != '') {
                $get_size = $this->product_model->get_size_list($row['size']);
                if ($get_size != '') {
                    $size = $get_size;
                }
            }
            
            
            if ($row['school'] != '') {
                $get_school = $this->product_model->get_school_by_id($row['school']);
                if ($get_school->num_rows() > 0) {
                    $school_data = $get_school->row();
                    $school      = $school_data->name;
                }
            }
            
            if ($row['binding_type'] != '') {
                $get_binding_type = $this->product_model->get_binding_type_by_id($row['binding_type']);
                if ($get_binding_type->num_rows() > 0) {
                    $binding_type_data = $get_binding_type->row();
                    $binding_type      = $binding_type_data->name;
                }
            }
            
            if ($row['color'] != '') {
                $get_stationery = $this->product_model->get_color_by_id($row['color']);
                if ($get_stationery->num_rows() > 0) {
                    $stationery_data = $get_stationery->row();
                    $color           = $stationery_data->name;
                }
            }
            
            if ($row['brand_id'] != '') {
                $get_brand = $this->product_model->get_brand_by_id($row['brand_id']);
                if ($get_brand->num_rows() > 0) {
                    $brand_data = $get_brand->row();
                    $brand      = $brand_data->name;
                }
            }
            
            if ($row['subcate'] != '') {
                $get_subcate = $this->product_model->get_category_by_id($row['subcate']);
                if ($get_subcate->num_rows() > 0) {
                    $subcate_data = $get_subcate->row();
                    $subcate      = $subcate_data->name;
                }
            }
            
            
            $get_type = $this->product_model->get_category_type_list($row['id']);
            if ($get_type != '') {
                $category = $get_type;
            } else {
                $category = '-';
            }
            
            
            $get_main_cat = $this->product_model->get_main_cat_by_id($row['id']);
            if ($get_main_cat != '') {
                $main_cat = $get_main_cat;
            } else {
                $main_cat = '-';
            }
            
            $get_images = $this->get_products_images_single($row['id'])->row_array();
            $image_url  = $get_images['image_small'];
            
            if (file_exists('uploads/products/' . $image_url)) {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/products/' . $image_url;
            } else {
                $image_url = 'https://api.kirtibook.in/vendor/v1/uploads/default_product.png';
            }
            
            $data[] = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "isbn" => $row['isbn'],
                "publisher" => $publisher,
                "board" => $board,
                "brand" => $brand,
                "subject" => $subject,
                "grade" => $grade,
                "category" => $category,
                "image_url" => $image_url,
                "no_of_pages" => ($row['no_of_pages'] != 0 ? $row['no_of_pages'] : 'N/A'),
                "isbn" => $row['isbn'],
                "gst" => $row['gst'],
                "hsn" => ($row['hsn'] ? $row['hsn'] : 'N/A'),
                "lenght" => ($row['lenght'] ? $row['lenght'] : 'N/A'),
                "width" => ($row['width'] ? $row['width'] : 'N/A'),
                "height" => ($row['height'] ? $row['height'] : 'N/A'),
                "weight" => ($row['weight'] ? $row['weight'] : 'N/A'),
                "meta_title" => ($row['meta_title'] ? $row['meta_title'] : 'N/A'),
                "meta_keyword" => ($row['meta_keyword'] ? $row['meta_keyword'] : 'N/A'),
                "meta_description" => ($row['meta_description'] ? $row['meta_description'] : 'N/A'),
                "product_description" => $row['product_description'],
                "age_grade" => $row['age_grade'],
                "from_age" => $row['from_age'],
                "to_age" => $row['to_age'],
                "isbn" => $row['isbn'],
                "gender" => $row['gender'],
                "age_type" => $row['age_type'],
                "highlights" => json_decode($row['highlights']),
                "product_origin" => ($row['product_origin'] ? $row['product_origin'] : 'N/A'),
                "size" => $size,
                "school" => $school,
                "binding_type" => $binding_type,
                "color" => $color,
                "subcate" => $subcate
            );
        }
        
        $total_data = 1;
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    
    
    
}