<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Excel_advanced extends CI_Model {
  
 public function consolidated_report_by_vendor_list($user_id){
		$resultpost = array(); 
/*		$query  = $this->db->query("SELECT id,id as order_id,price_shipping,order_status,tds_gst,tds,price_total,tcs_gst,tcs,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name,  product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE (payment_status='payment_received') AND vendor_id = '$user_id' AND id>37276 ORDER BY id ASC LIMIT 300");  */
		
        $query  = $this->db->query("SELECT id,id as order_id,price_shipping,order_status,tds_gst,tds,price_total,tcs_gst,tcs,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name,  product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE (payment_status='payment_received') AND (order_status='cancelled') AND vendor_id = '$user_id' AND (DATE(created_at) BETWEEN '2021-03-01' AND '2021-05-31') ORDER BY id ASC LIMIT 250");        		
        if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {	 
		  $data_slot = array();	
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone, added_date FROM consolidated_reports WHERE order_id='$order_id'");  
        
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$added_date = $item['added_date']; 		
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$invoice_no  	= $row['invoice_no'];
			$order_number   = $row['order_number']; 
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			
			$product_id   = $row['product_id'];
			$school_id    = $row['school_id'];				
			$category_id  = $row['product_parent_cid'];
			$size_id      = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name    = $this->common_model->get_size_name_by_id($size_id);
			$color_name   = $this->common_model->get_color_name_by_product($product_id);			
			$school_city  = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
             $details='';
			
            $package_details=array();		
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
	       
	     
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
            ); 
           $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		 
		  
		    $invoice_amount=price_format_decimal($row['price_total']-$row['price_shipping']);
		  
		  $order_products=$this->get_order_products($order_id);
		  
		 $iq=1;
		 foreach($order_products as $op) {
		   if($iq==1){   
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
                "order_status" => $row['order_status'],
                "tcs_gst" => $row['tcs_gst'],
                "tcs" => $row['tcs'],
                "invoice_amount" => $invoice_amount,
                "price_shipping" => $row['price_shipping'],
                "price_total" => $row['price_total'],
                "tds_gst" => $row['tds_gst'],
                "tds" => $row['tds'],
                "package_name"     => $op['package_name'],
                "total_products"   => $op['total_products'],
                "product_quantity" => $op['product_quantity'],
                "total_price"      => $op['total_price'],
            );
		   }
		   else{
		       
		      $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
                "order_status" => $row['order_status'],
                "tcs_gst" =>  '',
                "tcs" =>  '',
                "invoice_amount" => '',
                "price_shipping" =>  '',
                "price_total" => '',   
                "tds_gst" => '',   
                "tds" => '',   
                "package_name"     => $op['package_name'],
                "total_products"   => $op['total_products'],
                "product_quantity" => $op['product_quantity'],
                "total_price"      => $op['total_price'],
            );   
		   }
            
            
		$iq++; }
		 }
		}
	  return $resultpost;
  	}
  	
  	
  	
  	
  	
      
     public function get_order_products($order_id)   {
        $query = $this->db->query("SELECT package_name,count(product_id) as total_products, SUM(product_quantity) as product_quantity, SUM(product_total_price) as total_price FROM order_products WHERE order_id='$order_id' GROUP BY package_id");
        $count = $query->num_rows();
        $resultpost  = array();
        foreach ($query->result_array() as $row) {
            $resultpost[] = array(
                "package_name"     => $row['package_name'],
                "total_products"   => $row['total_products'],
                "product_quantity" => $row['product_quantity'],
                "total_price"      => $row['total_price'],
                );  
            }
            
        return $resultpost;
    }  
     	
  	
  	
  	
  	
  	
  	
  	
  	}	
  	
  	
  	