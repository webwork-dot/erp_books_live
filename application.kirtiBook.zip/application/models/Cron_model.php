<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cron_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        /*cache control*/
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
    }

    function generate_dtdc_label()
    {
        $query = $this->db->query("SELECT slot_no,awb_number FROM vendor_shipping_label WHERE`awb_number` IS NOT NULL AND `dtdc_label_url` IS NULL ORDER BY id desc limit 10");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
               $awb_number = $info['awb_number'];
                  $slot_no = $info['slot_no'];



                $curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_URL => 'https://dtdcapi.shipsy.io/api/customer/integration/consignment/label/multipiece',
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS => "{\"reference_number\":\"$awb_number\"}",
					CURLOPT_HTTPHEADER => array(
					  'content-type: application/json',
					  'api-key: 9820bacb9c50f0ae71b1a6ce43e5d0'
					),
				));
				$response = curl_exec($curl);
				curl_close($curl);

				$dtdc_arr = json_decode($response);

				if($dtdc_arr->status=='OK'){
					if($dtdc_arr->data){
					  if ($dtdc_arr->data[0]->label) {
							$source_url = $dtdc_arr->data[0]->label;


							date_default_timezone_set('Asia/Kolkata');
							$year        = date("Y");
							$month       = date("m");
							$day         = date("d");
							$upload_path = "./uploads/vendor_label_report/" . "$year/$month/$day/";
							if (!is_dir($upload_path)) {
							  mkdir($upload_path, 0755, true);
							}
							$destination_path = $upload_path.$awb_number.".pdf";
							//copy($source_url, $destination_path);
							$output = base64_decode($source_url);
							if (file_put_contents($destination_path, $output)) {
								$data_order = array(
								  'dtdc_label_url' => $destination_path,
								  'updated_at' => date('Y-m-d H:i:s')
								);
								$this->db->where('slot_no', $slot_no);
								$this->db->update('vendor_shipping_label', $data_order);

								$check_label = '1';
							}
						}
						$check_label = '1';
					}
				}
            }
            $resultdata = array(
                'status' => 200,
                'message' => 'success'
            );
            simple_json_output($resultdata);
        }
    }
    
    function generate_shipping_bill_new_3()
    {
        $query = $this->db->query("SELECT vendor_id,slot_no,courier,awb_number FROM vendor_shipping_label WHERE is_label='0' and label_url IS NULL ORDER BY id desc LIMIT 1 OFFSET 5");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {

                $courier    = $info['courier'];
                $awb_number = $info['awb_number'];
                $slot_no[]    = $info['slot_no'];


                if (!empty($slot_no)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');

                    foreach ($slot_no as $shipping_no):
                        $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
                        if ($shipping_label->num_rows() > 0) {
                            $row = $shipping_label->row();
                            if ($row->barcode_url == NULL) {
                                $this->pdf_model->get_barcode($row->slot_no, $row->id);
                            }
                        } else {
                            $label_id = $this->pdf_model->add_shipping_label($shipping_no);
                            $this->pdf_model->get_barcode($shipping_no, $label_id);
                        }

                        $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

                        if ($row->label_url == NULL) {

                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
                            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no);


                            $this->load->library('pdf');
                            $this->pdf->set_paper("A4", "portrait");
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
                            $output    = $this->pdf->output();
                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            $directory = "uploads/vendor_label_report/" . "$year/$month/$day/";
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;


                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_label_generated($shipping_no, $file_url);
                            }
                            unset($this->pdf);
                            $check_label = '1';
                        }
                    endforeach;
                }
            }
            $resultdata = array(
                'status' => 200,
                'message' => 'success'
            );
            simple_json_output($resultdata);
        }
    }
    
    function generate_shipping_bill_new_2()
    {
        $query = $this->db->query("SELECT vendor_id,slot_no,courier,awb_number FROM vendor_shipping_label WHERE is_label='0' and label_url IS NULL ORDER BY id desc limit 1");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {

                $courier    = $info['courier'];
                $awb_number = $info['awb_number'];
                $slot_no[]    = $info['slot_no'];


                if (!empty($slot_no)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');

                    foreach ($slot_no as $shipping_no):
                        $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
                        if ($shipping_label->num_rows() > 0) {
                            $row = $shipping_label->row();
                            if ($row->barcode_url == NULL) {
                                $this->pdf_model->get_barcode($row->slot_no, $row->id);
                            }
                        } else {
                            $label_id = $this->pdf_model->add_shipping_label($shipping_no);
                            $this->pdf_model->get_barcode($shipping_no, $label_id);
                        }

                        $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

                        if ($row->label_url == NULL) {

                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
                            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no);
							
                            $this->load->library('pdf');
                            $this->pdf->set_paper("A4", "portrait");
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
                            $output    = $this->pdf->output();
                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            $directory = "uploads/vendor_label_report/" . "$year/$month/$day/";
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;


                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_label_generated($shipping_no, $file_url);
                            }
                            unset($this->pdf);
                            $check_label = '1';
                        }
                    endforeach;
                }
            }
            $resultdata = array(
                'status' => 200,
                'message' => 'success'
            );
            simple_json_output($resultdata);
        }
    }

    function generate_shipping_bill_new()
    {
        $query = $this->db->query("SELECT vendor_id,slot_no,courier,awb_number FROM vendor_shipping_label WHERE is_label='0' and label_url IS NULL ORDER BY id asc limit 1");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {

                $courier    = $info['courier'];
                $awb_number = $info['awb_number'];
                $slot_no[]    = $info['slot_no'];


                if (!empty($slot_no)) {
                    $check_label = '0';
                    $this->load->library('pdf');
                    $this->load->library('zip');

                    foreach ($slot_no as $shipping_no):
                        $shipping_label = $this->pdf_model->get_shipping_label($shipping_no);
                        if ($shipping_label->num_rows() > 0) {
                            $row = $shipping_label->row();
                            if ($row->barcode_url == NULL) {
                                $this->pdf_model->get_barcode($row->slot_no, $row->id);
                            }
                        } else {
                            $label_id = $this->pdf_model->add_shipping_label($shipping_no);
                            $this->pdf_model->get_barcode($shipping_no, $label_id);
                        }

                        $row = $this->pdf_model->get_shipping_label($shipping_no)->row();

                        if ($row->label_url == NULL) {

                            $html_content = '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/bootstrap.min.css">';
                            $html_content .= '<link rel="stylesheet" href="' . base_url() . 'assets/pdf/cutsom-a5.css">';
                            $html_content .= $this->pdf_model->fetch_shipping_label($shipping_no);


                            $this->load->library('pdf');
                            $this->pdf->set_paper("A4", "portrait");
                            $this->pdf->set_option('isHtml5ParserEnabled', TRUE);
                            $this->pdf->load_html($html_content);
                            $this->pdf->render();
                            $pdfname   = 'sk-shipping-label-' . $shipping_no . '.pdf';
                            $output    = $this->pdf->output();
                            $year      = date("Y");
                            $month     = date("m");
                            $day       = date("d");
                            $directory = "uploads/vendor_label_report/" . "$year/$month/$day/";
                            if (!is_dir($directory)) {
                                mkdir($directory, 0755, true);
                            }

                            $file_url = $directory . $pdfname;


                            if (file_put_contents($file_url, $output)) {
                                $this->pdf_model->update_label_generated($shipping_no, $file_url);
                            }
                            unset($this->pdf);
                            $check_label = '1';
                        }
                    endforeach;
                }
            }
            $resultdata = array(
                'status' => 200,
                'message' => 'success'
            );
            simple_json_output($resultdata);
        }
    }

    function generate_shipping_bill()
    {
        $query = $this->db->query("SELECT vendor_id,slot_no,courier,awb_number FROM vendor_shipping_label WHERE is_label='0' and label_url IS NULL ORDER BY id asc limit 1");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {

                $courier    = $info['courier'];
                $awb_number = $info['awb_number'];
                $slot_no    = $info['slot_no'];

                if ($courier == 'DTDC') {
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                      CURLOPT_URL => 'https://dtdcapi.shipsy.io/api/customer/integration/consignment/label/multipiece',
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_FOLLOWLOCATION => true,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => 'POST',
                      CURLOPT_POSTFIELDS => "{\"reference_number\":\"$awb_number\"}",
                      CURLOPT_HTTPHEADER => array(
                        'content-type: application/json',
                        'api-key: 9820bacb9c50f0ae71b1a6ce43e5d0'
                      ),
                    ));
                    $response = curl_exec($curl);
                    curl_close($curl);
                    $dtdc_arr = json_decode($response);
                    if ($dtdc_arr->status == 'OK') {
                        if ($dtdc_arr->data) {
                            if ($dtdc_arr->data[0]->label) {
                                $source_url = $dtdc_arr->data[0]->label;
                                date_default_timezone_set('Asia/Kolkata');
                                $year        = date("Y");
                                $month       = date("m");
                                $day         = date("d");
                                $upload_path = "./uploads/vendor_label_report/" . "$year/$month/$day/";
                                if (!is_dir($upload_path)) {
                                    mkdir($upload_path, 0755, true);
                                }
                                $destination_path = $upload_path . $awb_number . ".pdf";
                                //copy($source_url, $destination_path);
                                $output = base64_decode($source_url);
                                if (file_put_contents($destination_path, $output)) {
                                    $data_order = array(
                                        'dtdc_label_url' => $destination_path,
                                        'updated_at' => date('Y-m-d H:i:s')
                                    );
                                    $this->db->where('slot_no', $slot_no);
                                    $this->db->update('vendor_shipping_label', $data_order);
                                    $curl    = curl_init();
                                    $url     = vendor_url() . "pdf_controller/generate_shipping_label";
                                    $user_id = $info['vendor_id'];
                                    $slot_no = $info['slot_no'];

                                    curl_setopt_array($curl, array(
                                        CURLOPT_URL => $url,
                                        CURLOPT_RETURNTRANSFER => true,
                                        CURLOPT_ENCODING => "",
                                        CURLOPT_MAXREDIRS => 10,
                                        CURLOPT_TIMEOUT => 50,
                                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                        CURLOPT_CUSTOMREQUEST => "POST",
                                        CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"slot_no\":[\"$slot_no\"]}",
                                        CURLOPT_HTTPHEADER => array(
                                            "auth-key: kirtibookapi",
                                            "cache-control: no-cache",
                                            "client-service: frontend-client",
                                            "content-type: application/json"
                                        )
                                    ));

                                    $response = curl_exec($curl);
                                    curl_close($curl);
                                    $result = json_decode($response, TRUE);
                                }


                            }
                        }
                    }
                } else {
                    $curl    = curl_init();
                    $url     = vendor_url() . "pdf_controller/generate_shipping_label";
                    $user_id = $info['vendor_id'];
                    $slot_no = $info['slot_no'];

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 50,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"slot_no\":[\"$slot_no\"]}",
                        CURLOPT_HTTPHEADER => array(
                            "auth-key: kirtibookapi",
                            "cache-control: no-cache",
                            "client-service: frontend-client",
                            "content-type: application/json"
                        )
                    ));

                    $response = curl_exec($curl);
                    curl_close($curl);
                    $result = json_decode($response, TRUE);
                }
                //print_r($response);
            }
        }
    }

    public function check_out_for_delivery()
    {
        $query = $this->db->query("SELECT id,complaint_id,order_slot,order_status,awb_number,complaint_status FROM orders WHERE payment_status='payment_received' AND (order_status='shipment' OR complaint_status='shipment' OR order_status='picked_dtdc' OR complaint_status='picked_dtdc') ORDER BY id asc limit 100");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $order_id = $info['id'];
                $awb_number  = $info['awb_number'];
                $complaint_id  = $info['complaint_id'];
                $complaint_status  = $info['complaint_status'];
                $order_slot  = $info['order_slot'];
                $order_status  = $info['order_status'];
                $complaint_status  = $info['complaint_status'];

                $response = $this->dtdc_track($awb_number);
                $res=json_decode($response);
                if($res->status=='SUCCESS'){
                    if($res->status=='SUCCESS'){
                        if($res->trackDetails){
                            foreach ($res->trackDetails as $key => $trackDetails) {
                                if($trackDetails->strCode=='BKD' && ($order_status!='picked_dtdc' OR $complaint_status!='picked_dtdc')){
                                    $strActionDate = $trackDetails->strActionDate;
                                    $strActionTime = $trackDetails->strActionTime;
                                    $day = substr($strActionDate,0,2);
                                    $month = substr($strActionDate,2,2);
                                    $year = substr($strActionDate,4,4);
                                    $min=substr($strActionTime,0,2);
                                    $hrs=substr($strActionTime,2,2);
                                    $new_date = $year.'-'.$month.'-'.$day;
                                    $new_time = $min.':'.$hrs.':00';
                                    $datetime= $new_date.' '.$new_time;
                                    $new_datetime = date('Y-m-d h:i:s', strtotime($datetime));

                                    if($complaint_status!=NULL){
                                          $data_order = array();
                                          $data_order['tmp_slot_no'] = NULL;
                                          $data_order['complaint_status'] = 'picked_dtdc';
                                          $data_order['updated_at']		= $new_datetime;
                                          $this->db->where('id', $order_id);
                                          $update = $this->db->update('orders', $data_order);

                                          $data_comp_order = array();
                                          $data_comp_order = array(
                                             'dispatched_date' => $new_datetime
                                          );
                                          $this->db->where('id',$complaint_id);
                                          $this->db->where('order_id',$order_id);
                                          $update = $this->db->update('oc_tickets', $data_comp_order);
                                    }
                                    else{
                                        $data_order = array();
                                        $data_order['tmp_slot_no'] = NULL;
                                        $data_order['order_status']     = 'picked_dtdc';
                                        $data_order['dispatched_date']  = $new_datetime;
                                        $data_order['updated_at']		= $new_datetime;

                                        $this->db->where('id', $order_id);
                                        $update = $this->db->update('orders', $data_order);
                                    }
                                    //$this->order_status_change_msg($order_slot,'out_for_delivery');
                                }
                                if($trackDetails->strCode=='OUTDLV'){
                                    $strActionDate = $trackDetails->strActionDate;
                                    $strActionTime = $trackDetails->strActionTime;
                                    $day = substr($strActionDate,0,2);
                                    $month = substr($strActionDate,2,2);
                                    $year = substr($strActionDate,4,4);
                                    $min=substr($strActionTime,0,2);
                                    $hrs=substr($strActionTime,2,2);
                                    $new_date = $year.'-'.$month.'-'.$day;
                                    $new_time = $min.':'.$hrs.':00';
                                    $datetime= $new_date.' '.$new_time;
                                    $new_datetime = date('Y-m-d h:i:s', strtotime($datetime));

                          			    if($complaint_status!=NULL){
                                          $data_order = array();
                                          $data_order['tmp_slot_no'] = NULL;
                                          $data_order['complaint_status'] = 'out_for_delivery';
                                          $data_order['updated_at']		= $new_datetime;
                                          $this->db->where('id', $order_id);
                                				  $update = $this->db->update('orders', $data_order);

                                          $data_comp_order = array();
                                          $data_comp_order = array(
                                             'dispatched_date' => $new_datetime
                                          );
                                          $this->db->where('id',$complaint_id);
                                          $this->db->where('order_id',$order_id);
                                          $update = $this->db->update('oc_tickets', $data_comp_order);
                                    }
                                    else{
                          		       	 	$data_order = array();
                                  			$data_order['tmp_slot_no'] = NULL;
                              					$data_order['order_status']     = 'out_for_delivery';
                              					$data_order['dispatched_date']  = $new_datetime;
                              					$data_order['updated_at']		= $new_datetime;
                                        $this->db->where('id', $order_id);
                              				  $update = $this->db->update('orders', $data_order);
                                    }
                                    //$this->order_status_change_msg($order_slot,'out_for_delivery');
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public function check_delivered()
    {
        $query = $this->db->query("SELECT id,complaint_id,order_slot,order_status,awb_number,complaint_status FROM orders WHERE payment_status='payment_received' AND (order_status='out_for_delivery' OR complaint_status='out_for_delivery') ORDER BY id asc limit 100");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $order_id = $info['id'];
                $awb_number  = $info['awb_number'];
                $complaint_id  = $info['complaint_id'];
                $complaint_status  = $info['complaint_status'];
                $order_slot  = $info['order_slot'];

                $response = $this->dtdc_track($awb_number);
                $res=json_decode($response);
                if($res->status=='SUCCESS'){
                    if($res->status=='SUCCESS'){
                        if($res->trackDetails){
                            foreach ($res->trackDetails as $key => $trackDetails) {
                                if($trackDetails->strCode=='DLV'){
                                    $strActionDate = $trackDetails->strActionDate;
                                    $strActionTime = $trackDetails->strActionTime;
                                    $day = substr($strActionDate,0,2);
                                    $month = substr($strActionDate,2,2);
                                    $year = substr($strActionDate,4,4);
                                    $min=substr($strActionTime,0,2);
                                    $hrs=substr($strActionTime,2,2);
                                    $new_date = $year.'-'.$month.'-'.$day;
                                    $new_time = $min.':'.$hrs.':00';
                                    $datetime= $new_date.' '.$new_time;
                                    $new_datetime = date('Y-m-d h:i:s', strtotime($datetime));

                                    if ($this->check_order_complaints($order_id) > 0) {
                                          $data_order = array();

                                          $data_order['complaint_status'] = 'delivered';
                                          $data_order['updated_at']		= $new_datetime;
                                          $this->db->where('id', $order_id);
                                          $this->db->update('orders', $data_order);

                                          $data_comp_order = array();
                                          $data_comp_order = array(
                                             'delivered_date' => $new_datetime
                                          );
                                          $this->db->where('id',  $complaint_id);
                                          $this->db->where('order_id',  $order_id);
                                          $update = $this->db->update('oc_tickets', $data_comp_order);

                                          $this->close_all_complaints_on_delivered($order_id);
                                    }
                                    else{
                                          $data_order = array();
                                          $data_order['order_status']   = 'delivered';
                                          $data_order['delivered_date'] = $new_datetime;
                                          $this->db->where('id', $order_id);
                                          $this->db->update('orders', $data_order);
                                          $this->close_all_complaints_on_delivered($order_id);
                                    }
                                    //$this->order_status_change_msg($order_slot,'delivered');
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public function check_order_complaints($order_id){
	     $keyword_filter='';
       $query = $this->db->query("SELECT id FROM orders WHERE id='$order_id' AND complaint_status IS NOT NULL");
       return $query->num_rows();
    }

    public function close_all_complaints_on_delivered($order_id){
        $sql = $this->db->query("SELECT id,order_id FROM `oc_tickets` WHERE order_id='$order_id' AND ticket_status!='3'");
        if(!empty($sql)){
      		foreach($sql->result_array() as $row){
                 $order_id=$row['order_id'];
                 $ticket_id=$row['id'];

        		     $data_ = array();
        		     $data_ = array(
                    'ticket_id' => $ticket_id,
                    'reply_id' => 0,
                    'reply_name' => 'admin',
                    'reply_email' => '',
                    'reply_desc' => 'Dear Customer, The current status of your order is ""Delivered"". We hope you had a great experience buying books from kirtibook. We appreciate your support and patience. Be Healthy - Be Safe Regards, Team kirtibook.',
                    'reply_type' => '',
                    'reply_date' => date('Y-m-d H:i:s'),
                );
        	      if($this->db->insert('oc_tickets_reply', $data_)){
            		    $data_2 = array();
            		    $data_2 = array(
                            'ticket_status' => 3,
                            'reply_last_updated' => date('Y-m-d H:i:s'),
                            'ticket_closed_date' => date('Y-m-d H:i:s'),
                    );
        			     $this->db->where('id', $ticket_id);
        	         $this->db->update('oc_tickets', $data_2);
        	    }
      	   }
        }
    }



    public function dtdc_track($awb_number){
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://blktracksvc.dtdc.com/dtdc-api/rest/JSONCnTrk/getTrackDetails',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
              "TrkType": "cnno",
              "strcnno": "'.$awb_number.'",
              "addtnlDtl": "Y"
          }',
          CURLOPT_HTTPHEADER => array(
              'content-type: application/json',
              'x-access-token: PL2694_trk:627a618d139313ead098d3f65d5409e2'
            ),
          ));
          $response = curl_exec($curl);
          curl_close($curl);
          return $response;
    }



    function generate_product_invoice()
    {
        $query = $this->db->query("SELECT id,buyer_id FROM orders WHERE payment_status='payment_received' AND is_invoice='0' AND invoice_url IS NULL ORDER BY id asc limit 10");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_product_invoice";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                print_r($response);

            }
        }
    }


    function generate_shipping_invoice()
    {
        $query = $this->db->query("SELECT id,buyer_id FROM orders WHERE payment_status='payment_received' AND order_status='delivered' AND user_invoice IS NULL AND user_invoice_url IS NULL ORDER BY id asc limit 10");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_shipping_invoice";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                print_r($response);

            }
        }
    }



    function generate_shipping_invoice_credit_note()
    {
        $query = $this->db->query("SELECT id,buyer_id FROM orders WHERE payment_status='payment_received' AND order_status='cancelled' AND (user_invoice_cn IS NULL AND user_invoice_cn_url IS NULL) AND (user_invoice IS NOT NULL AND user_invoice_url IS NOT NULL) ORDER BY id asc limit 10");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_shipping_invoice_credit_note";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                //print_r($response);

            }
        }
    }



    function generate_product_invoice_credit_note()
    {
        $query = $this->db->query("SELECT id,buyer_id FROM orders WHERE payment_status='payment_received' AND (order_status='cancelled' OR order_status='applied_for_exchange') AND invoice_cn IS NULL AND invoice_cn_url IS NULL ORDER BY id asc limit 10");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_product_invoice_credit_note";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                //print_r($response);
            }
        }
    }



    function generate_shipping_invoice_CI()
    {
        $query = $this->db->query("SELECT id,buyer_id FROM orders WHERE payment_status='payment_received' AND order_status='cancelled' AND (user_invoice_ci IS NULL AND user_invoice_ci_url IS NULL) AND  (refunded_id IS NOT NULL) AND (price_total>=refund_amount) ORDER BY id asc limit 10");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_shipping_invoice_CI";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                //print_r($response);

            }
        }
    }




    function generate_shipping_invoice_refresh()
    {
        $query = $this->db->query("SELECT o.id,o.user_invoice_url,os.state_name,os.state as user_state,vsd.state_id as vendor_state FROM orders as o INNER JOIN order_shipping as os ON o.id=os.order_id INNER JOIN vendor_billing_details as vsd ON o.vendor_id=vsd.vendor_id WHERE o.payment_status='payment_received' AND o.order_status='delivered' AND o.user_invoice IS NOT NULL AND o.is_refresh='0' AND os.state=vsd.state_id AND os.state_name!='Maharashtra' ORDER BY o.id asc limit 5");
        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_shipping_invoice_refresh";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                //print_r($response);

            }
        }
    }



    function generate_product_invoice_refresh()
    {
        $query = $this->db->query("SELECT id,buyer_id FROM orders WHERE payment_status='payment_received' AND is_refresh='0' AND vendor_id = 42867 ORDER BY id asc limit 20");

        if ($query->num_rows() > 0) {
            $result_data = $query->result_array();
            foreach ($result_data as $info) {
                $data     = array();
                $curl     = curl_init();
                $url      = vendor_url() . "pdf_controller/generate_product_invoice_refresh";
                $user_id  = $info['buyer_id'];
                $order_id = $info['id'];

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 50,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"order_id\":\"$order_id\"}",
                    CURLOPT_HTTPHEADER => array(
                        "auth-key: kirtibookapi",
                        "cache-control: no-cache",
                        "client-service: frontend-client",
                        "content-type: application/json"
                    )
                ));

                $response = curl_exec($curl);
                curl_close($curl);
                $result = json_decode($response, TRUE);
                //print_r($response);

            }
        }
    }
    
    public function update_cron_gst_report()
    {
        $added_date = date('Y-m-d H:i:s');
        $db2        = $this->load->database('crondb', TRUE);
        
        $cron_orders = $db2->query("SELECT order_id FROM `oc_cron_orders` WHERE is_gst_report='0' order by id asc LIMIT 500");
        if ($cron_orders->num_rows() > 0) {
            foreach ($cron_orders->result() as $info) {
                
                $order_id = $info->order_id;
                $orders   = $db2->query("SELECT id,username,school_id,vendor_id,invoice_no,price_shipping,price_total,created_at,order_number FROM `orders` WHERE id='$order_id'");
                if ($orders->num_rows() > 0) {
                    $order = $orders->row();
                    
                    $price_shipping = $order->price_shipping;
                    $price_total    = $order->price_total - $price_shipping;
                    $gst_excl       = $total_price_excl = $gst_0_excl = $gst_0_amt = $gst_5_excl = $gst_5_amt = $gst_12_excl = $gst_12_amt = $gst_18_excl = $gst_18_amt = $gst_28_excl = $gst_28_amt = 0;
                    $order_id       = $order->id;
                    
                    
                    $order_products = $this->db->query("SELECT product_total_price,product_gst FROM order_products WHERE order_id = '$order_id' order by id ASC");
                    foreach ($order_products->result_array() as $product) {
                        $product_total_price = $product['product_total_price'];
                        $gst                 = $product['product_gst'];
                        $gst_excl            = ($gst + 100) / 100;
                        $total_price_excl    = $product_total_price / $gst_excl;
                        
                        if ($gst == 0) {
                            $gst_0_excl += $total_price_excl;
                            $gst_0_amt += $product_total_price - $total_price_excl;
                        }
                        
                        if ($gst == 5) {
                            $gst_5_excl += $total_price_excl;
                            $gst_5_amt += $product_total_price - $total_price_excl;
                        }
                        
                        if ($gst == 12) {
                            $gst_12_excl += $total_price_excl;
                            $gst_12_amt += $product_total_price - $total_price_excl;
                        }
                        
                        if ($gst == 18) {
                            $gst_18_excl += $total_price_excl;
                            $gst_18_amt += $product_total_price - $total_price_excl;
                        }
                        
                        if ($gst == 28) {
                            $gst_28_excl += $total_price_excl;
                            $gst_28_amt += $product_total_price - $total_price_excl;
                        }
                    }
                    
                    
                    //0,5,12,18,28        
                    $check_gst = $db2->query("SELECT id FROM `oc_gst_report` WHERE order_id='$order_id' limit 1")->num_rows();
                    
                    $data = array(
                        "order_id" => $order->id,
                        "vendor_id" => $order->vendor_id,
                        "school_id" => $order->school_id,
                        "customer" => $order->username,
                        "invoice_no" => $order->invoice_no,
                        "created_at" => $order->created_at,
                        "order_number" => $order->order_number,
                        "invoice_amt" => $price_total,
                        "gst_0_excl" => price_format_decimal($gst_0_excl),
                        "gst_0_amt" => price_format_decimal($gst_0_amt),
                        "gst_5_excl" => price_format_decimal($gst_5_excl),
                        "gst_5_amt" => price_format_decimal($gst_5_amt),
                        "gst_12_excl" => price_format_decimal($gst_12_excl),
                        "gst_12_amt" => price_format_decimal($gst_12_amt),
                        "gst_18_excl" => price_format_decimal($gst_18_excl),
                        "gst_18_amt" => price_format_decimal($gst_18_amt),
                        "gst_28_excl" => price_format_decimal($gst_28_excl),
                        "gst_28_amt" => price_format_decimal($gst_28_amt),
                        "added_date" => date('Y-m-d H:i:s')
                    );
                    
                    if ($check_gst == 0) {
                        $this->db->insert('oc_gst_report', $data);
                    } else {
                        $this->db->where('order_id', $order_id);
                        $this->db->update('oc_gst_report', $data);
                    }
                    
                    $update_ = $db2->query("UPDATE oc_cron_orders SET is_gst_report='1',gst_report_date='$added_date' WHERE order_id='$order_id'");
                    $this->add_cronjob_track($order_id, 'gst_report_cron', 'gst_report updated', json_encode($data));
                    //return TRUE;
                }
            }
        }
    }


}
