<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_model extends CI_Model
{
    public function orderform_details($user_id, $pid)
    {
        $sql = $this->db->query("SELECT status,id,vendor_id, school_id, board, grade_id, shipping_id, status, pending, added_date,minimum_package, approve_by, last_modified FROM packages WHERE id='$pid' and vendor_id='$user_id' limit 1");

        $order_data = array();
        $vendor     = array();
        $data       = array();
        if ($sql->num_rows() > 0) {
            $package          = $sql->row_array();
            $pid              = $package['id'];
            $vendor_name      = $this->auth_model->get_vendor_name($package['vendor_id']);
            $school_name      = $this->auth_model->get_school_name($package['school_id']);
            $board_name       = $this->auth_model->get_board_name($package['board']);
            $grade_name       = $this->auth_model->get_grade_name($package['grade_id']);
            $shipping_details = $this->auth_model->get_warehouse_details_by_id($package['shipping_id']);
            $minimum_package  = $package['minimum_package'];

            $school_id                = $package['school_id'];
            $board_id                 = $package['board'];
            $grade_id                 = $package['grade_id'];
            $shipping_id              = $package['shipping_id'];
            $mandatory_optional_count = 0;
            $query_pc                 = $this->db->query("SELECT id, package_id, package_name,package_price,package_offer_price,category, is_it, weight, note, sort, discount,gst,hsn FROM package_category WHERE package_id='$pid' order by id asc");
            $package_category         = array();
            foreach ($query_pc->result_array() as $row_cate) {
                $package_catid        = $row_cate['id'];
                $category_id          = $row_cate['category'];
                $package_product_list = array();

                $products = $this->package_model->get_product_by_bookset_category($category_id, $user_id, $grade_id, $board_id);

                foreach ($products['data'] as $row_prod) {
                    $package_product_list[] = array(
                        "product_id" => $row_prod['id'],
                        "title" => $row_prod['title'],
                        "model_number" => $row_prod['model_number']
                    );
                }


                $query_prod       = $this->db->query("SELECT id, package_id, package_catid, product_id, quantity, discount_price, display_name FROM package_products WHERE package_id='$pid' AND package_catid='$package_catid'");
                $package_products = array();
                foreach ($query_prod->result_array() as $row_prod) {
                    $package_products[] = array(
                        "product_id" => $row_prod['product_id'],
                        "product_name" => $this->auth_model->get_product_name($row_prod['product_id']),
                        "product_weight" => $this->auth_model->get_product_weight($row_prod['product_id']),
                        "display_name" => $row_prod['display_name'],
                        "quantity" => $row_prod['quantity'],
                        "discount_price" => $row_prod['discount_price']
                    );
                }

                if ($row_cate['is_it'] == 2) {
                    $mandatory_optional_count = $mandatory_optional_count + 1;
                }

                $cquery = $this->db->query("SELECT name FROM categories WHERE id='$category_id' limit 1");
                if ($cquery->num_rows() > 0) {
                    $crow          = $cquery->row_array();
                    $category_name = $crow['name'];
                } else {
                    $category_name = '';
                }

                $package_category[] = array(
                    "package_category_id" => $row_cate['id'],
                    "package_id" => $row_cate['package_id'],
                    "package_name" => $row_cate['package_name'],
                    "package_price" => $row_cate['package_price'],
                    "package_offer_price" => $row_cate['package_offer_price'],
                    "category" => $category_name,
                    "category_id" => $row_cate['category'],
                    "weight" => $row_cate['weight'],
                    "note" => $row_cate['note'],
                    "gst" => $row_cate['gst'],
                    "hsn" => $row_cate['hsn'],
                    "is_it" => $row_cate['is_it'],
                    "sort" => $row_cate['sort'],
                    "discount" => ($row_cate['discount'] != NULL ? $row_cate['discount'] : '0'),
                    "package_products" => $package_products,
                    "package_product_list" => $package_product_list
                );
            }

            $data[] = array(
                "id" => $package['id'],
                "status" => $package['status'],
                "minimum_package" => $minimum_package,
                "mandatory_optional_count" => $mandatory_optional_count,
                "school_id" => $school_id,
                "board" => $board_id,
                "grade_id" => $grade_id,
                "shipping_id" => $shipping_id,
                "vendor_name" => $vendor_name,
                "school_name" => $school_name,
                "board_name" => $board_name,
                "grade_name" => $grade_name,
                "shipping_details" => $shipping_details,
                "package_category" => $package_category
            );
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data
        );
        return $resultpost;
    }

    public function all_order($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter = '';
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= "and (product_name like '%$keyword%' or school_name like '%$keyword%' or order_number like '%$keyword%' or invoice_no like '%$keyword%') ";
        }

        $rows = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status!='cancelled' AND complaint_status IS NULL)    ORDER BY id ASC");

        $query = $this->db->query("SELECT id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders
        WHERE (vendor_id = '$vendor_id')
        AND (payment_status='payment_received')
        AND (order_status!='cancelled' AND complaint_status IS NULL) $order_filter ORDER BY id desc LIMIT $offset,$per_page");
        $count = $query->num_rows();
        $data  = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $shipping = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                $data[]   = array(
                    "id" => $row['id'],
                    "order_type" => $row['order_type'],
                    "order_number" => $row['order_number'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['slot_no'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "city_name" => $shipping->city_name,
                    "pincode" => $shipping->pincode,
                    "order_status" => $row['order_status'],
                    "created_at" => date("d M Y h:i A", strtotime($row['created_at'])),
                    "product_name" => $row['product_name']
                );
            }
        }

        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $count
        );
        return $resultpost;
    }

    public function get_invoice_order_details($order_id)
    {
        $this->db->select('orders.id,orders.order_number,orders.grade_name,orders.invoice_no,orders.price_discount,orders.shipping_date,orders.barcode_url,orders.awb_number,orders.price_shipping,orders.price_total,orders.vendor_id,orders.invoice_no,orders.total_weight,orders.slot_no,orders.order_number,orders.created_at,orders.school_name,orders.grade_name,orders.board_name,cities.name as school_city');
        $this->db->join('school', 'orders.school_id = school.id');
        $this->db->join('cities', 'school.city_id = cities.id');
        $this->db->join('users', 'orders.vendor_id = users.id');
        $this->db->where('orders.id', $order_id);
        $query = $this->db->get('orders');
        return $query->row();
    }

    public function get_vendor_billing_details($vendor_id)
    {
        $this->db->select('vendor_billing_details.pan,vendor_billing_details.gst,states.name as state');
        $this->db->join('states', 'states.id = vendor_billing_details.state_id');
        $this->db->where('vendor_id', $vendor_id);
        $query = $this->db->get('vendor_billing_details');
        return $query->row_array();
    }


    public function get_vendor_details($vendor_id)
    {
        $this->db->select('vendor_documents.signature,users.email,v.company_name,v.address,states.name as state,states.code as state_code,cities.name as city,v.pincode,v.contact_number as phone');
        $this->db->join('vendor_communication_details as v', 'users.id = v.vendor_id');
        $this->db->join('vendor_documents', 'users.id = vendor_documents.vendor_id');
        $this->db->join('states', 'states.id = v.state_id');
        $this->db->join('cities', 'cities.id = v.city_id');
        $this->db->where('users.id', $vendor_id);
        $query = $this->db->get('users');
        return $query->row_array();
    }

    public function get_order_shipping($order_id)
    {
        $order_id = clean_number($order_id);
        $this->db->where('order_id', $order_id);
        $query = $this->db->get('order_shipping');
        return $query->row_array();
    }

    public function get_order($id)
    {
        $id = clean_number($id);
        $this->db->where('id', $id);
        $query = $this->db->get('orders');
        return $query->row();
    }

    public function get_vendor_shipping_by_id($warehouse_id)
    {
        $query = $this->db->query("SELECT vsd.id,vsd.name,vsd.pincode, cities.name as city_name FROM vendor_shipping_details as vsd INNER JOIN cities ON vsd.city_id = cities.id WHERE vsd.id = '$warehouse_id'");
        return $query->row();
    }

    public function process_order($user_id, $order_array, $warehouse_id)
    {
        if (count($order_array) > 0) {
            $flag        = 1;
            $address_arr = array();
            $order_arr   = array();
            foreach ($order_array as $order_list) {
                $address_arr[] = $order_list['address_id'];
                $order_arr[]   = $order_list['order_id'];
            }
            $address_uni = array_unique($address_arr);

            $msg = '<table class="table"><tr style="background: #f1f1f1;"><th>Order Type</th><th>Order Number</th><th>Invoice Number</th><th>School/Product Name</th><th>Date & Time</th></tr>';

            foreach ($address_uni as $add_id) {
                $query      = $this->db->query("SELECT count(id) as count,GROUP_CONCAT(id) as order_list FROM orders WHERE address_id='$add_id' and vendor_id='$user_id' and payment_status='payment_received' and order_status='pending' and warehouse_id = '$warehouse_id'");
                $counts     = array_count_values($address_arr);
                $order_list = array();
                $order_uni  = array();
                $row_prod   = $query->row_array();
                $count      = $row_prod['count'];
                $order_list = explode(',', $row_prod['order_list']);
                if ($counts[$add_id] != $count) {
                    $flag = 0;
                    foreach ($order_list as $id) {
                        if (in_array($id, $order_arr) == false) {
                            $query2 = $this->db->query("SELECT order_type,order_number,invoice_no,created_at,school_name,product_name FROM orders WHERE id='$id' limit 1");
                            $count2 = $query2->num_rows();
                            if ($count2 > 0) {
                                $ord_row      = $query2->row_array();
                                $order_type   = $ord_row['order_type'];
                                $order_number = $ord_row['order_number'];
                                $invoice_no   = $ord_row['invoice_no'];
                                $product_name = $ord_row['product_name'];
                                if ($order_type == 'bookset') {
                                    $product_name = $ord_row['school_name'];
                                }
                                $created_at = date("d M Y h:i a", strtotime($ord_row['created_at']));
                            }
                            $msg .= '<tr><td>' . $order_type . '</td><td>' . $order_number . '</td><td>' . $invoice_no . '</td><td>' . $product_name . '</td><td>' . $created_at . '</td></tr>';
                        }
                    }
                }
            }
            if ($flag > 0) {
                foreach ($order_array as $order_list) {
                    $order_id   = $order_list['order_id'];
                    $data_order = array(
                        'order_status' => 'processing'
                    );
                    $this->db->where('id', $order_id);
                    $update = $this->db->update('orders', $data_order);
                    if ($update) {
                        $query1       = $this->db->query("SELECT location,pincode,lattitude,longitude FROM order_shipping WHERE order_id='$order_id' limit 1");
                        $row1         = $query1->row_array();
                        $to_location  = $row1['location'];
                        $to_pincode   = $row1['pincode'];
                        $to_lattitude = $row1['lattitude'];
                        $to_longitude = $row1['longitude'];

                        $query2         = $this->db->query("SELECT school.location,school.pincode,school.lattitude,school.longitude FROM school INNER JOIN orders on orders.school_id=school.id where orders.id='$order_id' limit 1");
                        $row2           = $query2->row_array();
                        $from_location  = $row2['location'];
                        $from_pincode   = $row2['pincode'];
                        $from_lattitude = $row2['lattitude'];
                        $from_longitude = $row2['longitude'];

                        $data_slot  = array(
                            'order_id' => $order_id,
                            'from_location' => $from_location,
                            'from_pincode' => $from_pincode,
                            'from_lat' => $from_lattitude,
                            'from_lng' => $from_longitude,
                            'to_location' => $to_location,
                            'to_pincode' => $to_pincode,
                            'to_lat' => $to_lattitude,
                            'to_lng' => $to_longitude
                        );
                        $insert     = $this->db->insert('order_slot', $data_slot);
                        $slot_id    = $this->db->insert_id();
                        $data_order = array(
                            'slot_no' => $slot_id
                        );
                        $this->db->where('id', $order_id);
                        $update = $this->db->update('orders', $data_order);
                    }
                }
                $resultpost = array(
                    'status' => 200,
                    'message' => 'success'
                );
            } else {
                $msg .= '</table>';
                $resultpost = array(
                    'status' => 201,
                    'message' => "$msg"
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'failure'
            );
        }
        return $resultpost;
    }

    public function get_order_by_id($id)
    {
        $id = clean_number($id);
        $this->db->select('id,address_id,warehouse_id');
        $this->db->where('id', $id);
        $query = $this->db->get('orders');
        return $query->row();
    }

    public function check_shipping_label_dtdc($slot_no)
    {
        $this->db->select('id,dtdc_label_url');
        $this->db->where('dtdc_label_url!=', NULL);
        $this->db->where('slot_no', $slot_no);
        $query          = $this->db->get('vendor_shipping_label');
        $shipping_label = $query->row();

        if ($query->num_rows() > 0) {
            //check in folder
            if (!file_exists(FCPATH . $shipping_label->dtdc_label_url)) {
                //$this->pdf_model->get_blank_vendor_shipping_dtdc($slot_no, $shipping_label->dtdc_label_url);
                $pass = 0;
            } else {
                $pass = 1;
            }
        } else {
            $pass = 0;
        }

        return $pass;
    }
    public function check_shipping_label_app($slot_no) {		
		$ord=$this->common_model->getRowById('vendor_shipping_label','shipment_provider',array('slot_no'=>$slot_no));	
		if($ord['shipment_provider']=='self'){  
			$this->db->select('id,label_url');
			$this->db->where('label_url!=', NULL);
		}
		elseif($ord['shipment_provider']=='bigship'){
			$this->db->select('id,bigship_label_url as label_url');
			$this->db->where('bigship_label_url!=', NULL);			
		}
		else{			
			$this->db->select('id,label_url');
			$this->db->where('label_url!=', NULL);
		}
		
        $this->db->where('slot_no', $slot_no);
        $query          = $this->db->get('vendor_shipping_label');
        $shipping_label = $query->row();
        if ($query->num_rows() > 0) {
            if (!file_exists(FCPATH . $shipping_label->label_url)) {	
				if($ord['shipment_provider']=='self'){  
					$this->pdf_model->get_blank_vendor_shipping($slot_no, $shipping_label->label_url);
				}
				elseif($ord['shipment_provider']=='bigship'){
					$this->pdf_model->get_blank_vendor_shipping_bigship($slot_no, $shipping_label->label_url);
				}
				else{			
					$this->pdf_model->get_blank_vendor_shipping($slot_no, $shipping_label->label_url);
				}
				
                $pass = 0;
            } else {
                $pass = 1;
            }
        } else {
            $pass = 0;
        }
        return $pass;
    }



    public function check_shipping_label($slot_no)
    {
        $this->db->select('id,label_url');
        $this->db->where('label_url!=', NULL);
        $this->db->where('slot_no', $slot_no);
        $query          = $this->db->get('vendor_shipping_label');
        $shipping_label = $query->row();

        if ($query->num_rows() > 0) {
            //check in folder
            if (!file_exists(FCPATH . $shipping_label->label_url)) {
                $this->pdf_model->get_blank_vendor_shipping($slot_no, $shipping_label->label_url);
                $pass = 0;
            } else {
                $pass = 1;
            }
        } else {
            $pass = 0;
        }

        return $pass;
    }   

	public function check_shipping_label_bigship($slot_no) {
        $this->db->select('id,bigship_label_url');
        $this->db->where('bigship_label_url!=', NULL);
        $this->db->where('slot_no', $slot_no);
        $query          = $this->db->get('vendor_shipping_label');
        $shipping_label = $query->row();

        if ($query->num_rows() > 0) {
            //check in folder
            if (!file_exists(FCPATH . $shipping_label->bigship_label_url)) {
                $this->pdf_model->get_blank_vendor_shipping_bigship($slot_no, $shipping_label->bigship_label_url);
                $pass = 0;
            } else {
                $pass = 1;
            }
        } else {
            $pass = 0;
        }

        return $pass;
    }

    public function mark_delivered($user_id,$order_array)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND (((order_status = 'out_for_delivery' AND complaint_status IS NULL) OR complaint_status = 'out_for_delivery') OR ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment')) AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            $flag   = 0;
            $labels = array();

            foreach ($order_array as $order_list1) {
                $order_slot = $order_list1;

                $sql = $this->db->query("SELECT id FROM `orders` WHERE order_slot='$order_slot' AND (((order_status = 'out_for_delivery' AND complaint_status IS NULL) OR complaint_status = 'out_for_delivery') OR ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment'))");
                if(!empty($sql)){
                		foreach($sql->result_array() as $row){
                        $order_id = $row['id'];
                        $odata['order_status'] = 'delivered';
                        $odata['delivered_date'] = date("Y-m-d H:i:s");
                        $this->db->where('id', $order_id);
                        $this->db->update('orders', $odata);

                        $data2['order_status']   = 'delivered';
                        $data2['delivered_date'] = date("Y-m-d H:i:s");
                        $this->db->where('order_id', $order_id);
                        $this->db->update('oc_delivery_routes', $data2);

                        $this->close_all_complaints_on_delivered($order_id);
                    }
                }
            }
            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );
        }
        else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Out For Delivery Status'
            );
        }
        return $resultpost;
    }

    public function close_all_complaints_on_delivered($order_id){
        $sql = $this->db->query("SELECT id,order_id FROM `oc_tickets` WHERE order_id='$order_id' AND ticket_status!='3'");
        if(!empty($sql)){
        		foreach($sql->result_array() as $row){
                $order_id=$row['order_id'];
                $ticket_id=$row['id'];

          		   $data_ = array();
          	   	 $data_ = array(
                      'ticket_id' => $ticket_id,
                      'reply_id' => 0,
                      'reply_name' => 'admin',
                      'reply_email' => '',
                      'reply_desc' => 'Dear Customer, The current status of your order is ""Delivered"". We hope you had a great experience buying books from kirtibook. We appreciate your support and patience. Be Healthy - Be Safe Regards, Team kirtibook.',
                      'reply_type' => '',
                      'reply_date' => date('Y-m-d H:i:s'),
                  );
            	    if($this->db->insert('oc_tickets_reply', $data_)){
            		     $data_2 = array();
            		     $data_2 = array(
                            'ticket_status' => 3,
                            'reply_last_updated' => date('Y-m-d H:i:s'),
                            'ticket_closed_date' => date('Y-m-d H:i:s'),
                      );
            			    $this->db->where('id', $ticket_id);
            	        $this->db->update('oc_tickets', $data_2);
            	    }
        	   }
         }
    }

    public function process_order_scan_dtdc($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            $flag   = 0;
            $labels = array();

            foreach ($order_array as $order_list1) {
                $order_slot = $order_list1;
                $labels     = array();
               //$order      = $this->order_model->check_shipping_label($order_slot); 
                $order=1;
                if ($order > 0) {
                    //
                } else {
                    $flag     = 1;
                    $labels[] = $order_slot;
                }
            }

            if ($flag == 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id,complaint_id,buyer_id,order_number FROM orders WHERE vendor_id='$user_id'  AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$or_id' ");
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = array(
                            "id" => $row['id'],
                            "complaint_id" => $row['complaint_id'],
                            "buyer_id" => $row['buyer_id'],
                            "order_number" => $row['order_number']
                        );
                    }
                }

                $dtdc_flag=0;
                $awb_number='';

                foreach ($order_array as $slot_no) {
                  $consignments = array();
                  $check_slot_no = $this->db->query("SELECT order_slot,invoice_no,id,total_weight,warehouse_id,product_name,order_number,price_total,buyer_id FROM orders WHERE ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$slot_no'");
                  if ($check_slot_no->num_rows()>0) {
                      $pieces_detail = array();
                      $declared_value=0;
                      $total_weight=0;

                      foreach ($check_slot_no->result_array() as $slot_row) {
                          $product_name = $slot_row['product_name'];
                          $order_number = $slot_row['order_number'];
                          $price_total = $slot_row['price_total'];
                          $buyer_id = $slot_row['buyer_id'];
                          $order_id = $slot_row['id'];
                          $warehouse_id = $slot_row['warehouse_id'];
                          $invoice_no = $slot_row['invoice_no'];
                          $declared_value=(float)$declared_value+(float)$price_total;

                          $total_weight = (float)$total_weight+(float)$slot_row['total_weight'];

                          $weight = (float)$slot_row['total_weight']/1000;
                          if($weight==0){
                            $weight=1;
                            $weight = (float)$weight/1000;
                          }
                          $pieces_detail[] = array(
                            "description" => $product_name,
                            "declared_value" => $order_number,
                            "weight" => $weight,
                            "height" => "1",
                            "length" => "1",
                            "width" => "1"
                          );
                      }

                      $new_slot_query = $this->db->query("SELECT order_slot FROM orders WHERE ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$slot_no' limit 1");
                      $new_row      = $new_slot_query->row_array();
                      $new_slot_no = $new_row['order_slot'];

                      $add_query       = $this->db->query("SELECT name,phone,alternate_phone,flat_house_no,building_name,address,city_name,state_name,pincode,landmark FROM order_shipping WHERE order_id = '$order_id' LIMIT 1");
                      $address      = $add_query->row_array();

                      $name = $address['name'];
                      $phone = $address['phone'];
                      $alternate_phone = $address['alternate_phone'];
                      $flat_house_no = $address['flat_house_no'];
                      $building_name = $address['building_name'];
                      $caddress = $address['address'];
                      $city_name = $address['city_name'];
                      $state_name = $address['state_name'];
                      $pincode = $address['pincode'];
                      $landmark = $address['landmark'];
                      $address_line_1 = $flat_house_no.','.$building_name.','.$caddress.',landmark - '.$landmark;

                      $ware_row       = $this->db->query("SELECT state_id,city_id,address,pincode,landmark,contact_number FROM vendor_shipping_details WHERE id = '$warehouse_id' LIMIT 1")->row_array();

                      $ware_address = $ware_row['address'];
                      $ware_pincode = $ware_row['pincode'];
                      $ware_landmark = $ware_row['landmark'];
                      $ware_phone = $ware_row['contact_number'];
                      $state_id = $ware_row['state_id'];
                      $city_id = $ware_row['city_id'];

                      $state_row = $this->db->query("SELECT name FROM states WHERE id='$state_id' limit 1")->row_array();
                      $ware_state_name = $state_row['name'];

                      $city_row = $this->db->query("SELECT name FROM cities WHERE id='$city_id' limit 1")->row_array();
                      $ware_city_name = $city_row['name'];

                      $total_weight = $total_weight/1000;

                      if($total_weight==0){
                        $total_weight=1;
                        $total_weight = $total_weight/1000;
                      }

                      $consignments[] = array(
                        "customer_code" => "PL2694",
                        "service_type_id" => "GROUND EXPRESS",
                        "load_type" => "NON-DOCUMENT",
                        "description" => "",
                        "consignment_type" => "Forward",
                        "dimension_unit" => "",
                        "length" => "",
                        "width" => "",
                        "height" => "",
                        "weight_unit" => "kg",
                        "weight" => $total_weight,
                        "declared_value" => $declared_value,
                        "customer_reference_number" => $slot_no,
                        "commodity_id" => $slot_no,
                        "origin_details" => array(
                            "name" => "KIRTI BOOK AGENCY",
                            "phone" => $ware_phone,
                            "address_line_1" => $ware_address,
                            "pincode" => $ware_pincode,
                            "city" => $ware_city_name,
                            "state" => $ware_state_name
                        ),
                        "destination_details" => array(
                            "name" => $name,
                            "phone" => $phone,
                            "alternate_phone" => $alternate_phone,
                            "address_line_1" => $address_line_1,
                            "pincode" => $pincode,
                            "city" => $city_name,
                            "state" => $state_name
                        ),
                        "pieces_detail" => $pieces_detail
                      );
                      //echo json_encode($consignments);
                      //exit();

                      $dtdc=$this->create_dtdc_order($consignments);
                      $dtdc_arr = json_decode($dtdc);
                      if($dtdc_arr->status=='OK'){
                          foreach($dtdc_arr->data as $sdata){
                              if($sdata->success){
                                  $awb_number=$sdata->reference_number;

                                  $data_reforder = array(
                                    'awb_number' => $awb_number,
                                    'courier_name' => 'DTDC'
                                  );
                                  $this->db->where('order_slot', $new_slot_no);
                                  $update = $this->db->update('orders', $data_reforder);

                                  $data_slot = array(
                                    'awb_number' => $awb_number,
                                    'courier' => 'DTDC',
                                    'is_label' => '0'
                                  );
                                  $this->db->where('slot_no', $new_slot_no);
                                  $update = $this->db->update('vendor_shipping_label', $data_slot);
                              }
                          }
                      }
                    }
                }

                foreach ($order_arr as $item) {
                    if ($this->auth_model->check_order_complaints($item['id']) > 0) {
                        $data_order = array(
                            'complaint_status' => 'shipment',
                            'updated_at' => $updated_date
                        );

                        $data_comp_order = array();
                        $data_comp_order = array(
                            'shipping_date' => $updated_date
                        );
                        $this->db->where('id', $row['complaint_id']);
                        $this->db->where('order_id', $row['id']);
                        $update = $this->db->update('oc_tickets', $data_comp_order);

                    } else {
                        $data_order = array(
                            'order_status' => 'shipment',
                            'shipping_date' => $updated_date,
                            'updated_at' => $updated_date
                        );
                    }
                    $this->db->where('id', $item['id']);
                    $update = $this->db->update('orders', $data_order);

                    //notification starts
                    $buyer_id     = $item['buyer_id'];
                    $order_number = $item['order_number'];
                    $user         = $this->auth_model->get_user_notify($buyer_id);

                    $web_token2 = $user->web_token;
                    $fcm_token2 = $user->fcm_token;
                    $img_url2   = "https://kirtibook.in/images/mailer/ready-for-dispatch.png";

                    $notification_title2 = 'Ready For Dispatch';
                    $notification_msg2   = 'Dear customer Your order no. ' . $order_number . '  is Ready for Dispatch.Team Kirti Book';
                    $this->auth_model->send_notification_to_user($web_token2, $fcm_token2, 'web', $notification_title2, $notification_msg2, $img_url2);
                    //notification ends
                }


                foreach ($order_array as $order_slot) {
                    if ($this->auth_model->check_order_complaints_by_order_slot($order_slot) > 0) {
                        //start logs
                        $order_status_log = array();
                        $order_status_log = array(
                            'order_status' => 'complaint_ready_for_shipment',
                            'order_slot' => $order_slot,
                            'slot_no' => '',
                            'vehicle_name' => '',
                            'driver_name' => '',
                            'remark' => '',
                            'added_date' => date("Y-m-d H:i:s")
                        );
                        $this->db->insert('oc_delivery_order_status_logs', $order_status_log);
                        //end logs
                    }
                }


                $resultpost = array(
                    'status' => 200,
                    'message' => 'Ready For Shipment Successfully'
                );
            } else {
                $all_labels = implode(",", $labels);
                return $resultpost = array(
                    'status' => 400,
                    'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
                );
                exit();
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Processing Status'
            );
        }

        return $resultpost;
    }

    public function process_order_scan($user_id, $order_array, $order_status)
    {
        //single process
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id,order_slot FROM orders WHERE vendor_id='$user_id' AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND (FIND_IN_SET(order_slot, '$order_slot_comma') OR FIND_IN_SET(awb_number, '$order_slot_comma')) GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            $flag   = 0;
            $labels = array();

            /*foreach ($order_array as $order_list1) {
                $order_slot = $order_list1;
                $labels     = array();
                $order      = $this->order_model->check_shipping_label_app($order_slot);
                if ($order > 0) {
                    //
                } else {
                    $flag     = 1;
                    $labels[] = $order_slot;
                    //break;
                }
            }*/
			
			foreach ($check_ws->result_array() as $item) {
                $order_slot = $item['order_slot'];
                $labels     = array();
                //$order      = $this->order_model->check_shipping_label_app($order_slot); 
                $order=1;
                if ($order > 0) {
                    //
                } else {
                    $flag     = 1;
                    $labels[] = $order_slot;
                    //break;
                }
            }



            if ($flag == 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id,complaint_id,buyer_id,order_number,order_slot FROM orders WHERE vendor_id='$user_id'  AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND (order_slot = '$or_id' OR awb_number='$or_id') ");
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = array(
                            "id" => $row['id'],
                            "order_slot" => $row['order_slot'],
                            "complaint_id" => $row['complaint_id'],
                            "buyer_id" => $row['buyer_id'],
                            "order_number" => $row['order_number']
                        );
                    }
                }


                foreach ($order_arr as $item) {
                    if ($this->auth_model->check_order_complaints($item['id']) > 0) {
                        $data_order = array(
                            'complaint_status' => 'shipment',
                            'updated_at' => $updated_date
                        );

                        $data_comp_order = array();
                        $data_comp_order = array(
                            'shipping_date' => $updated_date
                        );
                        $this->db->where('id', $row['complaint_id']);
                        $this->db->where('order_id', $row['id']);
                        $update = $this->db->update('oc_tickets', $data_comp_order);

                    } else {
                        $data_order = array(
                            'order_status' => 'shipment',
                            'shipping_date' => $updated_date,
                            'updated_at' => $updated_date
                        );
                    }
                    $this->db->where('id', $item['id']);
                    $update = $this->db->update('orders', $data_order);

                    //notification starts
                    $buyer_id     = $item['buyer_id'];
                    $order_number = $item['order_number'];
                    $user         = $this->auth_model->get_user_notify($buyer_id);

                    $web_token2 = $user->web_token;
                    $fcm_token2 = $user->fcm_token;
                    $img_url2   = "https://kirtibook.in/images/mailer/ready-for-dispatch.png";

                    $notification_title2 = 'Ready For Dispatch';
                    $notification_msg2   = 'Dear customer Your order no. ' . $order_number . '  is Ready for Dispatch.Team Kirti Book';
                    $this->auth_model->send_notification_to_user($web_token2, $fcm_token2, 'web', $notification_title2, $notification_msg2, $img_url2);
                    //notification ends
                }


                foreach ($order_arr as $item) {
					$order_slot=$item['order_slot'];
                    if ($this->auth_model->check_order_complaints_by_order_slot($order_slot) > 0) {
                        //start logs
                        $order_status_log = array();
                        $order_status_log = array(
                            'order_status' => 'complaint_ready_for_shipment',
                            'order_slot' => $order_slot,
                            'slot_no' => '',
                            'vehicle_name' => '',
                            'driver_name' => '',
                            'remark' => '',
                            'added_date' => date("Y-m-d H:i:s")
                        );
                        $this->db->insert('oc_delivery_order_status_logs', $order_status_log);
                        //end logs
                    }
                }


                $resultpost = array(
                    'status' => 200,
                    'message' => 'Ready For Shipment Successfully'
                );
            } else {
                $all_labels = implode(",", $labels);
                return $resultpost = array(
                    'status' => 400,
                    'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
                );
                exit();
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Processing Status'
            );
        }

        return $resultpost;
    }

    public function process_ready_for_shipment($user_id, $order_array, $order_status)
    {
        //single process
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND (FIND_IN_SET(order_slot, '$order_slot_comma') OR FIND_IN_SET(awb_number, '$order_slot_comma')) GROUP BY order_slot");
       

        if ($check_ws->num_rows() == count($order_array)) {
            $flag   = 0;
            $labels = array();

            foreach ($order_array as $order_list1) {
                $order_slot = $order_list1;
                $labels     = array();
                //$order      = $this->order_model->check_shipping_label_app($order_slot);
                $order=1;
                if ($order > 0) {
                    //
                } else {
                    $flag     = 1;
                    $labels[] = $order_slot;
                    //break;
                }
            }
            
            //exit();

            if ($flag == 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id,complaint_id,buyer_id,order_number,order_slot FROM orders WHERE vendor_id='$user_id'  AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND (order_slot = '$or_id' OR awb_number='$or_id') ");
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = array(
                            "id" => $row['id'],
                            "complaint_id" => $row['complaint_id'],
                            "buyer_id" => $row['buyer_id'],
                            "order_number" => $row['order_number']
                        );
                    }
                }

                foreach ($order_arr as $item) {
                    if ($this->auth_model->check_order_complaints($item['id']) > 0) {
                        $data_order = array(
                            'complaint_status' => 'shipment',
                            'updated_at' => $updated_date
                        );

                        $data_comp_order = array();
                        $data_comp_order = array(
                            'shipping_date' => $updated_date
                        );
                        $this->db->where('id', $row['complaint_id']);
                        $this->db->where('order_id', $row['id']);
                        $update = $this->db->update('oc_tickets', $data_comp_order);

                    } else {
                        $data_order = array(
                            'order_status' => 'shipment',
                            'shipping_date' => $updated_date,
                            'updated_at' => $updated_date
                        );
                    }
                    $this->db->where('id', $item['id']);
                    $update = $this->db->update('orders', $data_order);

                    //notification starts
                    $buyer_id     = $item['buyer_id'];
                    $order_number = $item['order_number'];
                    $user         = $this->auth_model->get_user_notify($buyer_id);

                    $web_token2 = $user->web_token;
                    $fcm_token2 = $user->fcm_token;
                    $img_url2   = "https://kirtibook.in/images/mailer/ready-for-dispatch.png";

                    $notification_title2 = 'Ready For Dispatch';
                    $notification_msg2   = 'Dear customer Your order no. ' . $order_number . '  is Ready for Dispatch. Team Kirti Book';
                    //$this->auth_model->send_notification_to_user($web_token2, $fcm_token2, 'web', $notification_title2, $notification_msg2, $img_url2);
                    //notification ends
                }


                foreach ($order_array as $order_slot) {
                    if ($this->auth_model->check_order_complaints_by_order_slot($order_slot) > 0) {
                        //start logs
                        $order_status_log = array();
                        $order_status_log = array(
                            'order_status' => 'complaint_ready_for_shipment',
                            'order_slot' => $order_slot,
                            'slot_no' => '',
                            'vehicle_name' => '',
                            'driver_name' => '',
                            'remark' => '',
                            'added_date' => date("Y-m-d H:i:s")
                        );
                        $this->db->insert('oc_delivery_order_status_logs', $order_status_log);
                        //end logs
                    }
                }


                $resultpost = array(
                    'status' => 200,
                    'message' => 'Ready For Shipment Successfully'
                );
            } else {
                $all_labels = implode(",", $labels);
                return $resultpost = array(
                    'status' => 400,
                    'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
                );
                exit();
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Processing Status'
            );
        }

        return $resultpost;
    }

    public function picked_dtdc_app($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' and awb_number IS NOT NULL AND ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            $flag   = 0;
            $labels = array();

            foreach ($order_array as $order_list1) {
                $order_slot = $order_list1;
                $labels     = array();
                //$order      = $this->order_model->check_shipping_label($order_slot);  
                $order=1;
                if ($order > 0) {
                    //
                } else {
                    $flag     = 1;
                    $labels[] = $order_slot;
                }
            }

            if ($flag == 0) {
                foreach ($order_array as $slot_no) {
                  $consignments = array();
                  $check_slot_no = $this->db->query("SELECT id,complaint_id,buyer_id,order_number,order_slot FROM orders WHERE awb_number IS NOT NULL and ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') AND order_slot = '$slot_no'");
                    if ($check_slot_no->num_rows()>0) {
                          $data_reforder = array(
                            'is_picked_dtdc' => 1,
                            'is_picked_dtdc_date' => $updated_date
                          );
                          $this->db->where('order_slot', $slot_no);
                          $update = $this->db->update('orders', $data_reforder);
                    }
                }
                $resultpost = array(
                    'status' => 200,
                    'message' => 'Handed To DTDC'
                );
            } else {
                $all_labels = implode(",", $labels);
                return $resultpost = array(
                    'status' => 400,
                    'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
                );
                exit();
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Shipment Status'
            );
        }
        return $resultpost;
    }

    public function process_ready_for_shipment_dtdc($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            $flag   = 0;
            $labels = array();

            foreach ($order_array as $order_list1) {
                $order_slot = $order_list1;
                $labels     = array();
                //$order      = $this->order_model->check_shipping_label($order_slot);  
                $order=1;
                if ($order > 0) {
                    //
                } else {
                    $flag     = 1;
                    $labels[] = $order_slot;
                }
            }

            if ($flag == 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id,complaint_id,buyer_id,order_number,order_slot FROM orders WHERE vendor_id='$user_id'  AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$or_id' ");
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = array(
                            "id" => $row['id'],
                            "order_slot" => $row['order_slot'],
                            "complaint_id" => $row['complaint_id'],
                            "buyer_id" => $row['buyer_id'],
                            "order_number" => $row['order_number']
                        );
                    }
                }
                $dtdc_flag=0;
                $awb_number='';

                foreach ($order_array as $slot_no) {
                  $consignments = array();
                  $check_slot_no = $this->db->query("SELECT order_slot,invoice_no,id,total_weight,warehouse_id,product_name,order_number,price_total,buyer_id FROM orders WHERE ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$slot_no'");
                  if ($check_slot_no->num_rows()>0) {
                      $pieces_detail = array();
                      $declared_value=0;
                      $total_weight=0;

                      foreach ($check_slot_no->result_array() as $slot_row) {
                          $product_name = $slot_row['product_name'];
                          $order_number = $slot_row['order_number'];
                          $price_total = $slot_row['price_total'];
                          $buyer_id = $slot_row['buyer_id'];
                          $order_id = $slot_row['id'];
                          $warehouse_id = $slot_row['warehouse_id'];
                          $invoice_no = $slot_row['invoice_no'];
                          $declared_value=(float)$declared_value+(float)$price_total;

                          $total_weight = (float)$total_weight+(float)$slot_row['total_weight'];

                          $weight = (float)$slot_row['total_weight']/1000;
                          if($weight==0){
                            $weight=1;
                            $weight = (float)$weight/1000;
                          }
                          $pieces_detail[] = array(
                            "description" => $product_name,
                            "declared_value" => $order_number,
                            "weight" => $weight,
                            "height" => "1",
                            "length" => "1",
                            "width" => "1"
                          );
                      }

                      $new_slot_query = $this->db->query("SELECT order_slot FROM orders WHERE ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$slot_no' limit 1");
                      $new_row      = $new_slot_query->row_array();
                      $new_slot_no = $new_row['order_slot'];

                      $add_query       = $this->db->query("SELECT name,phone,alternate_phone,flat_house_no,building_name,address,city_name,state_name,pincode,landmark FROM order_shipping WHERE order_id = '$order_id' LIMIT 1");
                      $address      = $add_query->row_array();

                      $name = $address['name'];
                      $phone = $address['phone'];
                      $alternate_phone = $address['alternate_phone'];
                      $flat_house_no = $address['flat_house_no'];
                      $building_name = $address['building_name'];
                      $caddress = $address['address'];
                      $city_name = $address['city_name'];
                      $state_name = $address['state_name'];
                      $pincode = $address['pincode'];
                      $landmark = $address['landmark'];
                      $address_line_1 = $flat_house_no.','.$building_name.','.$caddress;

                      $ware_row       = $this->db->query("SELECT state_id,city_id,address,pincode,landmark,contact_number FROM vendor_shipping_details WHERE id = '$warehouse_id' LIMIT 1")->row_array();

                      $ware_address = $ware_row['address'];
                      $ware_pincode = $ware_row['pincode'];
                      $ware_landmark = $ware_row['landmark'];
                      $ware_phone = $ware_row['contact_number'];
                      $state_id = $ware_row['state_id'];
                      $city_id = $ware_row['city_id'];

                      $state_row = $this->db->query("SELECT name FROM states WHERE id='$state_id' limit 1")->row_array();
                      $ware_state_name = $state_row['name'];

                      $city_row = $this->db->query("SELECT name FROM cities WHERE id='$city_id' limit 1")->row_array();
                      $ware_city_name = $city_row['name'];

                      $total_weight = $total_weight/1000;

                      if($total_weight==0){
                        $total_weight=1;
                        $total_weight = $total_weight/1000;
                      }

                      $service_type_id='';
                      if($total_weight>2.5){
                          $service_type_id='GROUND EXPRESS';
                      }
                      else{
                          $service_type_id='STD EXP-A';
                      }

                      $consignments[] = array(
                        "customer_code" => "PL2694",
                        "service_type_id" => $service_type_id,
                        "load_type" => "NON-DOCUMENT",
                        "description" => "",
                        "consignment_type" => "Forward",
                        "dimension_unit" => "",
                        "length" => "",
                        "width" => "",
                        "height" => "",
                        "weight_unit" => "kg",
                        "weight" => $total_weight,
                        "declared_value" => $declared_value,
                        "customer_reference_number" => $slot_no,
                        "commodity_id" => $slot_no,
                        "origin_details" => array(
                            "name" => "KIRTI BOOK AGENCY",
                            "phone" => $ware_phone,
                            "address_line_1" => $ware_address,
                            "pincode" => $ware_pincode,
                            "city" => $ware_city_name,
                            "state" => $ware_state_name
                        ),
                        "destination_details" => array(
                            "name" => $name,
                            "phone" => $phone,
                            "alternate_phone" => $alternate_phone,
                            "address_line_1" => $address_line_1,
                            "pincode" => $pincode,
                            "city" => $city_name,
                            "state" => $state_name
                        ),
                        "pieces_detail" => $pieces_detail
                      );
                      //echo json_encode($consignments);
                      //exit();

                      $dtdc=$this->create_dtdc_order($consignments);
                      //echo $dtdc;
                      //exit();
                      $dtdc_arr = json_decode($dtdc);
                      if($dtdc_arr->status=='OK'){
                          foreach($dtdc_arr->data as $sdata){
                              if($sdata->success){
                                  $awb_number=$sdata->reference_number;

                                  $data_reforder = array(
                                    'awb_number' => $awb_number,
                                    'courier_name' => 'DTDC'
                                  );
                                  $this->db->where('order_slot', $new_slot_no);
                                  $update = $this->db->update('orders', $data_reforder);

                                  $data_slot = array(
                                    'awb_number' => $awb_number,
                                    'courier' => 'DTDC',
                                    'is_label' => '0'
                                  );
                                  $this->db->where('slot_no', $new_slot_no);
                                  $update = $this->db->update('vendor_shipping_label', $data_slot);
                              }
                          }
                      }
                    }
                }

                if($dtdc_flag==0){
                    foreach ($order_arr as $item) {
                        if ($this->auth_model->check_order_complaints($item['id']) > 0) {
                            $data_order = array(
                                'complaint_status' => 'shipment',
                                'updated_at' => $updated_date
                            );
                            $data_comp_order = array();
                            $data_comp_order = array(
                                'shipping_date' => $updated_date
                            );
                            $this->db->where('id', $row['complaint_id']);
                            $this->db->where('order_id', $row['id']);
                            $update = $this->db->update('oc_tickets', $data_comp_order);
                        } else {
                            $data_order = array(
                                'order_status' => 'shipment',
                                'shipping_date' => $updated_date,
                                'updated_at' => $updated_date
                            );
                        }
                        $this->db->where('id', $item['id']);
                        $update = $this->db->update('orders', $data_order);

                        $buyer_id     = $item['buyer_id'];
                        $order_number = $item['order_number'];
                        $user         = $this->auth_model->get_user_notify($buyer_id);

                        $web_token2 = $user->web_token;
                        $fcm_token2 = $user->fcm_token;
                        $img_url2   = "https://kirtibook.in/images/mailer/ready-for-dispatch.png";

                        $notification_title2 = 'Ready For Dispatch';
                        $notification_msg2   = 'Dear customer Your order no. ' . $order_number . '  is Ready for Dispatch. Team Kirti Book';
                    }
                }

                if($dtdc_flag==0){
                    foreach ($order_array as $order_slot) {
                        if ($this->auth_model->check_order_complaints_by_order_slot($order_slot) > 0) {
                            $order_status_log = array();
                            $order_status_log = array(
                                'order_status' => 'complaint_ready_for_shipment',
                                'order_slot' => $order_slot,
                                'slot_no' => '',
                                'vehicle_name' => '',
                                'driver_name' => '',
                                'remark' => '',
                                'added_date' => date("Y-m-d H:i:s")
                            );
                            $this->db->insert('oc_delivery_order_status_logs', $order_status_log);
                        }
                    }
                }

                if($dtdc_flag==0){
                    $resultpost = array(
                        'status' => 200,
                        'message' => 'Ready For Shipment Successfully'
                    );
                }
                else{
                    $resultpost = array(
                        'status' => 400,
                        'message' => 'DTDC Shipment Error'
                    );
                }
            } else {
                $all_labels = implode(",", $labels);
                return $resultpost = array(
                    'status' => 400,
                    'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
                );
                exit();
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Processing Status'
            );
        }
        return $resultpost;
    }


    public function process_order_($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        if (count($order_array) > 0) {
            $order_arr = array();
            foreach ($order_array as $order_list) {
                // $order_arr[]   = $order_list['order_id'];
                $or_id = $order_list;
                $query = $this->db->query("SELECT id FROM orders  WHERE vendor_id='$user_id' AND order_slot = '$or_id'");
                foreach ($query->result_array() as $row) {
                    $order_arr[] = $row['id'];
                }

            }


            /*   if ($order_status == 'shipment') {
            //check_shipping_label
            $flag   = 0;
            $labels = array();
            foreach ($order_array as $shipping_no) {
            $order = $this->order_model->check_shipping_label($shipping_no);
            if ($order > 0) {
            //
            } else {
            $flag     = 1;
            $labels[] = $shipping_no;
            //break;
            }
            }

            if ($flag == 0) {
            foreach ($order_arr as $order_id) {
            if ($this->auth_model->check_order_complaints($order_id) > 0) {
            $data_order = array(
            'complaint_status' => $order_status,
            'updated_at' => $updated_date,
            'shipping_date' => $updated_date
            );
            } else {
            $data_order = array(
            'order_status' => $order_status,
            'shipping_date' => $updated_date,
            'updated_at' => $updated_date
            );
            }

            $this->db->where('id', $order_id);
            $update = $this->db->update('orders', $data_order);
            }
            } else {
            $all_labels = implode(",", $labels);
            return $resultpost = array(
            'status' => 400,
            'message' => 'Following Shipping Invoice Not Generated Yet-' . $all_labels
            );
            exit();
            }

            }*/



            /*            if ($order_status == 'processing') {
            foreach ($order_arr as $order_id) {
            if ($this->auth_model->check_order_complaints($order_id) > 0) {
            $data_order = array(
            'complaint_status' => $order_status,
            'updated_at' => $updated_date
            );
            } else {
            $data_order = array(
            'order_status' => $order_status,
            'shipping_date' => $updated_date,
            'updated_at' => $updated_date
            );
            }

            $this->db->where('id', $order_id);
            $update = $this->db->update('orders', $data_order);
            }
            }*/



            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );

        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'error'
            );
        }
        return $resultpost;
    }

	public function pending_to_process_order_dtdc($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        $order_slot   = '';

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND (order_status='pending' OR order_status='exchange_pending') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            if (count($order_array) > 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id FROM orders WHERE order_slot = '$or_id'");
                    $i     = 0;
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = $row['id'];
                        if ($i == 0) {
                            $order_slot = $row['id'] . '_' . token_8_digit();
                        }
                        $i++;
                    }
                }

                //shipping label
                foreach ($order_array as $slot_no) {

					$consignments = array();
					$check_slot_no = $this->db->query("SELECT invoice_no,id,total_weight,warehouse_id,product_name,order_number,price_total,buyer_id FROM orders WHERE order_slot = '$slot_no'");
                    if ($check_slot_no->num_rows()>0) {

						$pieces_detail = array();
						$declared_value=0;
						$total_weight=0;
						foreach ($check_slot_no->result_array() as $slot_row) {
							$product_name = $slot_row['product_name'];
							$order_number = $slot_row['order_number'];
							$price_total = $slot_row['price_total'];
							$buyer_id = $slot_row['buyer_id'];
							$order_id = $slot_row['id'];
							$warehouse_id = $slot_row['warehouse_id'];
							$invoice_no = $slot_row['invoice_no'];
							$declared_value=(float)$declared_value+(float)$price_total;

							$total_weight = (float)$total_weight+(float)$slot_row['total_weight'];

							$weight = (float)$slot_row['total_weight']/1000;
							if($weight==0){
								$weight=1;
								$weight = (float)$weight/1000;
							}
							$pieces_detail[] = array(
								"description" => $product_name,
								"declared_value" => $order_number,
								"weight" => $weight,
								"height" => "1",
								"length" => "1",
								"width" => "1"
							);
						}

						$add_query       = $this->db->query("SELECT name,phone,alternate_phone,flat_house_no,building_name,address,city_name,state_name,pincode,landmark FROM order_shipping WHERE order_id = '$order_id' LIMIT 1");
                        $address      = $add_query->row_array();

						$name = $address['name'];
						$phone = $address['phone'];
						$alternate_phone = $address['alternate_phone'];
						$flat_house_no = $address['flat_house_no'];
						$building_name = $address['building_name'];
						$caddress = $address['address'];
						$city_name = $address['city_name'];
						$state_name = $address['state_name'];
						$pincode = $address['pincode'];
						$landmark = $address['landmark'];
						$address_line_1 = $flat_house_no.','.$building_name.','.$caddress.',landmark - '.$landmark;

						$ware_row       = $this->db->query("SELECT state_id,city_id,address,pincode,landmark,contact_number FROM vendor_shipping_details WHERE id = '$warehouse_id' LIMIT 1")->row_array();

						$ware_address = $ware_row['address'];
						$ware_pincode = $ware_row['pincode'];
						$ware_landmark = $ware_row['landmark'];
						$ware_phone = $ware_row['contact_number'];
						$state_id = $ware_row['state_id'];
						$city_id = $ware_row['city_id'];

						$state_row = $this->db->query("SELECT name FROM states WHERE id='$state_id' limit 1")->row_array();
						$ware_state_name = $state_row['name'];

						$city_row = $this->db->query("SELECT name FROM cities WHERE id='$city_id' limit 1")->row_array();
						$ware_city_name = $city_row['name'];

						$total_weight = $total_weight/1000;

						if($total_weight==0){
							$total_weight=1;
							$total_weight = $total_weight/1000;
						}

						$consignments[] = array(
							"customer_code" => "PL2694",
							"service_type_id" => "GROUND EXPRESS",
							"load_type" => "NON-DOCUMENT",
							"description" => "",
							"invoice_number" => "",
							"consignment_type" => "Forward",
							"dimension_unit" => "",
							"length" => "",
							"width" => "",
							"height" => "",
							"weight_unit" => "kg",
							"weight" => $total_weight,
							"declared_value" => $declared_value,
							"customer_reference_number" => $slot_no,
							"commodity_id" => $slot_no,
							"origin_details" => array(
								"name" => "KIRTI BOOK AGENCY",
								"phone" => $ware_phone,
								"address_line_1" => $ware_address,
								"pincode" => $ware_pincode,
								"city" => $ware_city_name,
								"state" => $ware_state_name
							),
							"destination_details" => array(
								"name" => $name,
								"phone" => $phone,
								"alternate_phone" => $alternate_phone,
								"address_line_1" => $address_line_1,
								"pincode" => $pincode,
								"city" => $city_name,
								"state" => $state_name
							),
							"pieces_detail" => $pieces_detail
						);
						//echo json_encode($consignments);

                        //exit();

						$dtdc=$this->create_dtdc_order($consignments);
						$dtdc_arr = json_decode($dtdc);
						if($dtdc_arr->status=='OK'){
							foreach($dtdc_arr->data as $sdata){
								if($sdata->success){
									$awb_number=$sdata->reference_number;
									$data_reforder = array(
										'awb_number' => $awb_number,
										'courier' => 'national',
										'courier_name' => 'DTDC',
										'process_slot' => $order_slot,
										'order_status' => 'processing',
										'processing_date' => $updated_date,
										'updated_at' => $updated_date
									);
									$this->db->where('order_slot', $slot_no);
									$update = $this->db->update('orders', $data_reforder);

									$check = $this->db->query("SELECT id FROM vendor_shipping_label  WHERE slot_no = '$slot_no' LIMIT 1")->num_rows();
									if ($check == 0) {
										$sql       = $this->db->query("SELECT vendor_id FROM orders  WHERE order_slot = '$slot_no' LIMIT 1");
										$item      = $sql->row_array();
										$data_slot = array(
											'vendor_id' => $item['vendor_id'],
											'process_slot' => $order_slot,
											'slot_no' => $slot_no,
											'ctype' => 'process',
											'courier' => 'DTDC',
											'awb_number' => $awb_number,
											'created_at' => $updated_date
										);
										$insert    = $this->db->insert('vendor_shipping_label', $data_slot);
									} else {
										$data_slot = array(
											'process_slot' => $order_slot,
											'awb_number' => $awb_number,
											'courier' => 'DTDC'
										);
										$this->db->where('slot_no', $slot_no);
										$update = $this->db->update('vendor_shipping_label', $data_slot);
									}
								}
							}
						}
						//exit();
					}
                }
                //shipping label

                $resultpost = array(
                    'status' => 200,
                    'message' => 'success'
                );

            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'error'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Pending Status'
            );
        }

        return $resultpost;
    }

	public function create_dtdc_order($consignments)
    {
		$curl = curl_init();

		$consignments_arr = array(
			'consignments' => $consignments
		);
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://dtdcapi.shipsy.io/api/customer/integration/consignment/softdata',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>json_encode($consignments_arr),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
			'api-key: 9820bacb9c50f0ae71b1a6ce43e5d0'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		return $response;
	}

    public function pending_to_process_order($user_id, $order_array, $order_status) {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        $order_slot   = '';

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND (order_status='pending' OR order_status='exchange_pending') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            if (count($order_array) > 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id FROM orders WHERE order_slot = '$or_id'");
                    $i     = 0;
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = $row['id'];
                        if ($i == 0) {
                            $order_slot = $row['id'] . '_' . token_8_digit();
                        }
                        $i++;
                    }
                }

                foreach ($order_arr as $order_id) {
                    $data_order = array(
						'shipment_provider' => 'self',
                        'process_slot' => $order_slot,
                        'order_status' => 'processing',
						'awb_number' 	=> NULL, 
						'courier_name' 	=> NULL,
                        'processing_date' => $updated_date,
                        'updated_at' => $updated_date
                    );
                    $this->db->where('id', $order_id);
                    $update = $this->db->update('orders', $data_order);
                }


                //shipping label
                foreach ($order_array as $slot_no) {
                    $check = $this->db->query("SELECT id FROM vendor_shipping_label  WHERE slot_no = '$slot_no' LIMIT 1")->num_rows();
                    if ($check == 0) {
                        $sql       = $this->db->query("SELECT vendor_id FROM orders  WHERE order_slot = '$slot_no' LIMIT 1");
                        $item      = $sql->row_array();
                        $data_slot = array(
							'shipment_provider' => 'self',
                            'vendor_id' => $item['vendor_id'],
                            'process_slot' => $order_slot,
                            'slot_no' => $slot_no,
                            'ctype' => 'process',
                            'created_at' => $updated_date
                        );
                        $insert    = $this->db->insert('vendor_shipping_label', $data_slot);
                    } else {
                        $data_slot = array(
							'shipment_provider' => 'self',
                            'process_slot' => $order_slot,
							'awb_number' => NULL,
							'courier' => NULL,
                        );
                        $this->db->where('slot_no', $slot_no);
                        $update = $this->db->update('vendor_shipping_label', $data_slot);
                    }
                }

                //shipping label

                $resultpost = array(
                    'status' => 200,
                    'message' => 'success'
                );

            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'error'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Pending Status'
            );
        }
        return $resultpost;
    }

    public function confirm_order($user_id,$order_id)
    {
        $query = $this->db->query("SELECT buyer_id,txn_id,payment_status FROM orders WHERE id='$order_id' limit 1");
        if ($query->num_rows() > 0) {
            $info = $query->row_array();
    		if($info['payment_status']!='payment_received'){
                $curl = curl_init();
                $url=main_api_url()."order/update_order";
                $user_id = $info['buyer_id'];
                $txn_id=$info['txn_id'];

        		curl_setopt_array($curl, array(
                  CURLOPT_URL => $url,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => "",
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 50,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => "POST",
                  CURLOPT_POSTFIELDS => "{\"user_id\":\"$user_id\",\"txn_id\":\"$txn_id\",\"payment_id\":\"$txn_id\",\"payment_status\":\"payment_received\",\"remark\":\"Direct_Admin\"}",
        		  CURLOPT_HTTPHEADER => array(
        			'Client-Service: frontend-client',
        			'Auth-Key: skoozofrontapi',
        			'Content-Type: application/json'
        		  ),
                ));

                $response = curl_exec($curl);
        		if (curl_errno($curl)) {
        			$error_msg = curl_error($curl);
        		}
                curl_close($curl);
                $result = json_decode($response, TRUE);

        		if (isset($error_msg)) {
        			return array('status' => 200, 'message' => 'false', 'remark' => 'Error! there is some issue while accepting order!');
        		}
        		else{
                    return array('status' => 200, 'message' => 'true','remark'=>'');
        		}
    		}
    		else{
    		    return array('status' => 200, 'message' => 'false', 'remark' => 'Error! Payment already received!');
    		}
        }
    }

    public function cancel_order($user_id, $order_id, $cancel_reason, $otp)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        $query        = $this->db->query("SELECT return_status,complaint_status,exchange_id,otp,price_total,email,order_status,order_number,order_type,price_total,product_name,school_name,board_name,grade_name,created_at FROM orders WHERE id = '$order_id' limit 1");
        $row          = $query->row_array();
        $old_otp      = $row['otp'];
        $price_total  = $row['price_total'];
        if ($old_otp == $otp) {
            $data_order = array(
                'cancel_type' => 'vendor',
                'cancel_amt' => $price_total,
                'cancel_per' => '0',
                'order_status' => 'cancelled',
                'cancel_status' => $row['order_status'],
                'cancelled_date' => $updated_date,
                'cancel_reason' => $cancel_reason
            );

            $this->db->where('id', $order_id);
            if ($this->db->update('orders', $data_order)) {
                $order_no    = $row['order_number'];
                $price_total = $row['price_total'];
                $order_date  = date('Y-m-d', strtotime($row['created_at']));

                if ($row['order_type'] == 'individual') {
                    $product_name = $row['product_name'];
                }

                if ($row['order_type'] == 'bookset') {
                    $product_name = $row['school_name'] . '-' . $row['board_name'] . '-' . $row['grade_name'];
                }

                if ($row['complaint_status'] != NULL) {
                    $product_name = $product_name . ' (Complaint)';
                }

                if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                    $product_name = $product_name . ' (Exchange)';
                }

                $mail_message = '<td align="left" bgcolor="#ffffff" style="padding: 15px;">
                <p>Your order has been successfully canceled.</p>
                <p>We\'re sorry this order didn\'t work out for you. </p>
                <p>But we hope we\'ll see you again..right?</p>
                <p>You can find all your order details below.</p>

                <p><b>Order Summary</b></p>
                <p>
                <b>Date:</b>' . $order_date . '<br/>
                <b>Order ID:</b>' . $order_no . '<br/>
                <b>Product Name:</b>' . $product_name . '<br/>
                <b>Price:</b>' . $price_total . '<br/>
                <b>Refund Amount:</b>' . $price_total . '<br/>
                </p>
                 <br/>
                 Regards,<br/>
                 <a href="https://kirtibook.in/">Team Kirti Book</a> <br/>
                </td>';
                $mail_subject = 'Cancellation Confirmation';
                $this->auth_model->sent_mail($mail_message, $row['email'], $mail_subject);

                $resultpost = array(
                    'status' => 200,
                    'message' => 'success'
                );
            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'error'
                );
            }
        } else {
            $resultpost = array(
                'status' => 300,
                'message' => 'Please Insert Correct OTP'
            );
        }

        return $resultpost;
    }

    public function cancel_order_list($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter = '';
        $warehouse_id = $filter['warehouse_id'];
        if ($filter['warehouse_id'] != '') {
            $warehouse_id = $filter['warehouse_id'];
            $order_filter .= "and warehouse_id = '$warehouse_id'";
        }
        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= "and courier_id = '$courier_id'";
        }

        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            $order_filter .= "and order_status = '$order_status'";
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }
		
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        $rows = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') AND (order_slot!='') AND (payment_status='payment_received') $academic_year_filter $order_filter  ORDER BY id ASC");

        $query        = $this->db->query("SELECT return_status,complaint_status,exchange_id,product_parent_cid,cancelled_date,returned_date,order_slot,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='') $academic_year_filter  $order_filter ORDER BY id desc LIMIT $offset,$per_page");
        $count        = $query->num_rows();
        $daily_report = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $shipping = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);

                if ($row['order_type'] == 'individual') {
                    if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                        $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                    } else {
                        $product_name = $row['product_name'];
                    }

                } else {
                    $product_name = $row['school_name'];
                }


                if ($row['complaint_status'] != NULL) {
                    $product_name = $product_name . ' (Complaint)';
                }


                if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                    $product_name = $product_name . ' (Exchange)';
                }


                $date_          = date("Y-m-d H:i:s", strtotime($row['cancelled_date']));
                $returned_date  = date("Y-m-d H:i:s", strtotime($row['returned_date']));
                $pending_since  = get_time_difference($date_);
                $returned_since = get_time_difference($returned_date);

                $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                $daily_report[] = array(
                    "id" => $row['id'],
                    "order_slot_no" => $row['order_slot'],
                    "address_id" => $row['address_id'],
                    "buyer_id" => $row['buyer_id'],
                    "order_type" => $row['order_type'],
                    "order_number" => $row['order_number'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['slot_no'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "city_name" => $shipping->city_name,
                    "pincode" => $shipping->pincode,
                    "order_status" => $row['order_status'],
                    "created_at" => $created_at,
                    "pending_since" => $pending_since,
                    "returned_since" => $returned_since,
                    "product_name" => $product_name
                );
            }
        }




        $order_status = $filter['order_status'];

        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset' $academic_year_filter    ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' $academic_year_filter    ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '1' AND (order_slot!='') $academic_year_filter  ORDER BY id  ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '2' AND (order_slot!='') $academic_year_filter  ORDER BY id ASC")->num_rows();

        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $daily_report,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function pending_order($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter         = '';
        $academic_year_filter = '';
        $warehouse_filter         = '';
        $warehouse_id         = $filter['warehouse_id'];
        if ($filter['warehouse_id'] != '') {
            $warehouse_id = $filter['warehouse_id'];
            $order_filter .= " and warehouse_id = '$warehouse_id'";
            $warehouse_filter = " and warehouse_id = '$warehouse_id'";
        }

        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= " and courier_id = '$courier_id'";
        }

        $group_by_dtdc='';
        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            if($order_status=='handed_dtdc'){
                $order_filter .= " AND is_picked_dtdc='1' and ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') ";
                $group_by_dtdc = ' GROUP BY slot_no';
            }
            else{
                //$order_filter .= " AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') ";
                $order_filter .= " AND ((order_status = '$order_status' AND complaint_status IS NULL)) ";
                $group_by_dtdc='';
            }
        }
        else{
          $group_by_dtdc='';
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or process_slot like '%" . $keyword . "%'
              or shipment_provider like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        $order_by = '';
        if ($filter['order_status'] == 'delivered') {
            $order_by = 'ORDER BY delivered_date DESC';
        } elseif ($filter['order_status'] == 'out_for_delivery') {
            $order_by = 'ORDER BY dispatched_date DESC';
        } else {
            $order_by = 'ORDER BY id desc';
        }

        if ($filter['order_status'] == 'shipment') {
            $order_by = 'ORDER BY process_slot asc';
        }

		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
		
		$group_by_dtdc='';

        $rows = $this->db->query("SELECT id FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='') $order_filter $group_by_dtdc $academic_year_filter");

        $query        = $this->db->query("SELECT process_slot,awb_number,courier_name,return_status,complaint_id,complaint_status,exchange_id,product_parent_cid,order_slot,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges,shipping_date, dispatched_date, delivered_date,shipment_provider FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='') $order_filter $academic_year_filter $order_by LIMIT $offset,$per_page");

        $count        = $rows->num_rows();
        $daily_report = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $shipping = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                $complaint_id = $row['complaint_id'];
                if ($complaint_id != NULL) {
                    $ticket    = $this->db->query("SELECT id,ctype,cat_name,ticket_desc FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                    $ticket_no = '#' . $ticket['ctype'] . sprintf('%04d', $ticket['id']);
                } else {
                    $ticket_no    = '-';
                    $complaint_id = '';
                }

                if ($row['order_type'] == 'individual') {
                    if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                        $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                    } else {
                        $product_name = $row['product_name'];
                    }
                } else {
                    $product_name = $row['school_name'];
                }

                if ($row['complaint_status'] != NULL) {
                    $product_name = $product_name . ' (Complaint)';
                }

                if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                    $product_name = $product_name . ' (Exchange)';
                }

                $date_         = date("Y-m-d H:i:s", strtotime($row['updated_at']));
                $pending_since = get_time_difference($date_);

                $dispatched_date = $row['dispatched_date'];
                if ($dispatched_date != NULL) {
                    $date_out_                = date("Y-m-d H:i:s", strtotime($row['dispatched_date']));
                    $pending_out_for_delivery = get_time_difference($date_out_);
                    $pending_since            = $pending_out_for_delivery;
                } else {
                    $pending_out_for_delivery = '';
                }

                $delivered_date = $row['delivered_date'];
                if ($delivered_date != NULL) {
                    $date_delivered_   = date("d M Y h:i a", strtotime($row['delivered_date']));
                    $pending_delivered = $date_delivered_;
                } else {
                    $pending_delivered = '';
                }

                $shipping_date = $row['shipping_date'];
                if ($shipping_date != NULL) {
                    $date_out_      = date("Y-m-d H:i:s", strtotime($row['shipping_date']));
                    $shipping_since = get_time_difference($date_out_);
                } else {
                    $shipping_since = '';
                }

                $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                $daily_report[] = array(
                    "id" => $row['id'],
                    "process_slot" => $row['process_slot'],
                    "awb_number" => $row['awb_number'],
                    "courier_name" => $row['courier_name'],
                    "order_slot_no" => $row['order_slot'],
                    "address_id" => $row['address_id'],
                    "buyer_id" => $row['buyer_id'],
                    "order_type" => $row['order_type'],
                    "order_number" => $row['order_number'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['slot_no'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "city_name" => $shipping->city_name,
                    "pincode" => $shipping->pincode,
                    "order_status" => $row['order_status'],
                    "created_at" => $created_at,
                    "pending_since" => $pending_since,
                    "shipping_since" => $shipping_since,
                    "pending_out" => $pending_out_for_delivery,
                    "pending_delivered" => $pending_delivered,
                    "product_name" => $product_name,
                    "ticket_no" => $ticket_no,
                    "complaint_id" => $complaint_id,
                    "shipment_provider" => $row['shipment_provider'],
                );
            }
        }


        $grouped_array = $this->group_array($daily_report, "order_slot_no", true);
        $report_data   = array();
        foreach ($grouped_array as $key => $value) {
            $list = array();
            $awb_number='';
            $courier_name='';
            $process_slot='';

            foreach ($value as $value2) {
                $awb_number=$value2['awb_number'];
                $courier_name=$value2['courier_name'];
                $process_slot=$value2['process_slot'];
                $list[] = array(
                    "id" => $value2['id'],
                    "process_slot" => $value2['process_slot'],
                    "awb_number" => $value2['awb_number'],
                    "courier_name" => $value2['courier_name'],
                    "address_id" => $value2['address_id'],
                    "order_slot_no" => $value2['order_slot_no'],
                    "buyer_id" => $value2['buyer_id'],
                    "order_type" => ucfirst($value2['order_type']),
                    "order_number" => $value2['order_number'],
                    "invoice_no" => $value2['invoice_no'],
                    "slot_no" => $value2['slot_no'],
                    "courier" => $value2['courier'],
                    "school_name" => $value2['school_name'],
                    "grade_name" => $value2['grade_name'],
                    "board_name" => $value2['board_name'],
                    "city_name" => $value2['city_name'],
                    "pincode" => $value2['pincode'],
                    "order_status" => $value2['order_status'],
                    "created_at" => $value2['created_at'],
                    "pending_since" => $value2['pending_since'],
                    "shipping_since" => $value2['shipping_since'],
                    "pending_out" => $value2['pending_out'],
                    "pending_delivered" => $value2['pending_delivered'],
                    "product_name" => $value2['product_name'],
                    "ticket_no" => $value2['ticket_no'],
                    "complaint_id" => $value2['complaint_id'],
                    "shipment_provider" => get_phrase($value2['shipment_provider']),
                );
            }

			$driver_contact='';
			if($courier_name=='LOCAL'){
				$dquery       = $this->db->query("SELECT driver_name,driver_id FROM oc_delivery_routes WHERE order_slot = '$key' limit 1");
				$drow         = $dquery->row_array();
				$awb_number   = '';
				$courier_name = $drow['driver_name'];
				$driver_id = $drow['driver_id'];

				$cdquery       = $this->db->query("SELECT driver_contact FROM oc_delivery_guy_details WHERE id = '$driver_id' limit 1");
				$cdrow         = $cdquery->row_array();
				$driver_contact = $cdrow['driver_contact'];
			}


            $report_data[] = array(
                "order_slot_no" => $key,
                "process_slot" => $process_slot,
                "awb_number" => $awb_number,
                "courier_name" => $courier_name,
                "driver_contact" => $driver_contact,
                "list" => $list
            );

        }

        $order_status = $filter['order_status'];
        
     
        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset' $academic_year_filter    ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' $academic_year_filter    ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and courier_id = '1' AND (order_slot!='') $warehouse_filter $academic_year_filter ORDER BY id  ASC")->num_rows();

        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and courier_id = '2' AND (order_slot!='') $warehouse_filter $academic_year_filter ORDER BY id ASC")->num_rows();

        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'data' => $report_data,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function proccess_order($id, $vendor_id, $per_page, $offset, $filter)
    {
        $order_filter = '';


        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            $order_filter .= " AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status')";
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";

        }

        $rows = $this->db->query("SELECT id FROM orders WHERE (awb_number IS NULL  OR awb_number IS NOT NULL OR complaint_status='processing') and (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (process_slot='$id') $order_filter  group by process_slot  ORDER BY id desc");

        $query = $this->db->query("SELECT process_slot,courier_name,shipment_provider FROM orders WHERE (awb_number IS NULL  OR awb_number IS NOT NULL OR complaint_status='processing') and (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (process_slot='$id') $order_filter group by process_slot ORDER BY id desc LIMIT $offset,$per_page"); 
		
		//echo $this->db->last_query();exit();

        $count        = $query->num_rows();
        $daily_report = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row1) {
                $process_slot = $row1['process_slot'];
                $shipment_provider = $row1['shipment_provider'];
                $main_courier_name = $row1['courier_name'];

				        $main_courier_name='';


                $query_order  = $this->db->query("SELECT return_status,complaint_id,complaint_status,courier_name,exchange_id,product_parent_cid,processing_date,shipping_date,order_slot,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges,shipment_provider FROM orders WHERE (awb_number IS NULL OR awb_number IS NOT NULL OR complaint_status='processing') and (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (process_slot='$process_slot') $order_filter ORDER BY id desc");
                $daily_report = array();
                foreach ($query_order->result_array() as $row) {

                    $shipping = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);

                    if ($row['order_type'] == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }

                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }

                    $complaint_id = $row['complaint_id'];
                    if ($complaint_id != NULL) {
                        $ticket    = $this->db->query("SELECT id,ctype,cat_name,ticket_desc FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                        $ticket_no = '#' . $ticket['ctype'] . sprintf('%04d', $ticket['id']);
                    } else {
                        $ticket_no    = '-';
                        $complaint_id = '';
                    }



                    $date_         = date("Y-m-d H:i:s", strtotime($row['processing_date']));
                    $pending_since = get_time_difference($date_);

                    $courier_name=$row['courier_name'];
					if($courier_name!='DTDC'){
						$courier_name='SELF';
					}

                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "courier_name" => $courier_name,
                        "process_slot" => $process_slot,
                        "shipment_provider" => $row['shipment_provider'],
                        "order_slot_no" => $row['order_slot'],
                        "address_id" => $row['address_id'],
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "order_status" => $row['order_status'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name,
                        "ticket_no" => $ticket_no,
                        "complaint_id" => $complaint_id
                    );
                }
            }
        }


        $grouped_array = $this->group_array($daily_report, "order_slot_no", true);
        $report_data   = array();
        foreach ($grouped_array as $key => $value) {
            $list = array();
            foreach ($value as $value2) {
                $list[] = array(
                    "id" => $value2['id'],
                    "courier_name" => $value2['courier_name'],
                    "address_id" => $value2['address_id'],
                    "process_slot" => $value2['process_slot'],
                    "order_slot_no" => $value2['order_slot_no'],
                    "buyer_id" => $value2['buyer_id'],
                    "order_type" => $value2['order_type'],
                    "order_number" => $value2['order_number'],
                    "invoice_no" => $value2['invoice_no'],
                    "slot_no" => $value2['slot_no'],
                    "courier" => $value2['courier'],
                    "school_name" => $value2['school_name'],
                    "grade_name" => $value2['grade_name'],
                    "board_name" => $value2['board_name'],
                    "city_name" => $value2['city_name'],
                    "pincode" => $value2['pincode'],
                    "order_status" => $value2['order_status'],
                    "created_at" => $value2['created_at'],
                    "pending_since" => $value2['pending_since'],
                    "product_name" => $value2['product_name'],
                    "ticket_no" => $value2['ticket_no'],
                    "complaint_id" => $value2['complaint_id']
                );
            }

            $report_data[] = array(
                "order_slot_no" => $key,
                "courier_name" => $main_courier_name,
                "shipment_provider" => $shipment_provider,
                "list" => $list
            );

        }



        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $report_data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function slot_proccess_order($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter = '';
        $warehouse_id = $filter['warehouse_id'];
        if ($filter['warehouse_id'] != '') {
            $warehouse_id = $filter['warehouse_id'];
            $order_filter .= "and warehouse_id = '$warehouse_id'";
        }
        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= "and courier_id = '$courier_id'";
        }

        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            $order_filter .= "and ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status')";
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= "and (product_name like '%$keyword%' or school_name like '%$keyword%' or order_number like '%$keyword%' or invoice_no like '%$keyword%') ";
        }
		
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;


        $query = $this->db->query("SELECT return_status,complaint_status,process_slot,processing_date,id,created_at,exchange_status,complaint_status,updated_at,shipment_provider FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (process_slot != '') $order_filter $academic_year_filter group by process_slot order by updated_at desc LIMIT  $offset,$per_page");


        $count        = $query->num_rows();
        $daily_report = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {

                $process_slot = $row['process_slot'];
                $shipment_provider = $row['shipment_provider'];
                $date_        = date("Y-m-d H:i:s", strtotime($row['updated_at']));

                $pending_since = get_time_difference($date_);
                $created_at    = date("d M Y h:i a", strtotime($row['updated_at']));

                if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                    $exchange_status = 'Exchange Pending';
                } else {
                    $exchange_status = '-';
                }

                if ($row['complaint_status'] != NULL) {
                    $complaint_status = 'Complaint';
                } else {
                    $complaint_status = '-';
                }

                $order_count = $this->db->query("SELECT id FROM orders WHERE (process_slot ='$process_slot') AND (payment_status='payment_received')  $order_filter group by order_slot")->num_rows();

                $daily_report[] = array(
                    "id" => $row['id'],
                    "process_slot" => $row['process_slot'],
                    "shipment_provider" => get_phrase($shipment_provider),
                    "order_count" => $order_count,
                    "pending_since" => $pending_since,
                    "created_at" => $created_at,
                    "exchange_status" => $exchange_status,
                    "complaint_status" => $complaint_status
                );
            }
        }

        $order_status = $filter['order_status'];

        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset' $academic_year_filter    ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' $academic_year_filter    ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '1' AND (process_slot != '') $academic_year_filter group by process_slot ORDER BY id  ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')   AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '2' AND (process_slot != '') $academic_year_filter group by process_slot ORDER BY id ASC")->num_rows();

        //$total_data = $rows->num_rows();
        $total_data = count($daily_report);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $daily_report,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function pending_slot_order($vendor_id,$per_page,$offset,$filter,$source)
    {
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";

        $warehouse_id = $filter['warehouse_id'];

        if ($source=='app') {
            $order_filter .= " and warehouse_id = '$warehouse_id'";
        }

        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= " and courier_id = '$courier_id'";
        }

        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            $order_filter .= " and (order_status = '$order_status')";
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
		
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        $query = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id desc");

        $count        = $query->num_rows();
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {

            foreach ($query->result_array() as $row_1) {

                $order_slot = $row_1['order_slot'];

                $query_1 = $this->db->query("SELECT return_status,complaint_status,exchange_id,product_parent_cid,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') $order_filter ORDER BY id desc");

                foreach ($query_1->result_array() as $row) {

                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }

                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }

                    $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
                    $pending_since = get_time_difference($date_);

                    $single_slot_no = $this->get_single_order_slot($order_id);
                    $slot_no        = $single_slot_no['order_slot'];

                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "warehouse_name" => $shipping->name,
                        "warehouse_id" => $shipping->id,
                        "order_status" => $row['order_status'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name
                    );

                }

                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );

            }
        }

        $order_status = $filter['order_status'];

        $q_filter='';
        if ($source=='app') {
            $q_filter = " and warehouse_id = '$warehouse_id'";
        }
        
        /*$bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset'    ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual'    ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and courier_id = '1' ORDER BY id ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and courier_id = '2' ORDER BY id ASC")->num_rows();
*/



        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset' $academic_year_filter    ORDER BY id ASC")->num_rows();
        
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' $academic_year_filter    ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and courier_id = '1'$academic_year_filter ORDER BY id ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL)) and courier_id = '2'$academic_year_filter ORDER BY id ASC")->num_rows();

        $total_data = count($daily_report);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'data' => $daily_report,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count
        );
        return $resultpost;
    }

    public function failed_order($vendor_id,$per_page,$offset,$filter,$source)
    {
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";

        $warehouse_id = $filter['warehouse_id'];

        if ($source=='app') {
            $order_filter .= " and warehouse_id = '$warehouse_id'";
        }

        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= " and courier_id = '$courier_id'";
        }

        $order_filter .= " and (payment_status = 'payment_pending' || payment_status = 'payment_failed')";

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
		
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        //$query = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') $order_filter $grade_filter $school_filter $date_filter group by order_slot  ORDER BY id desc");
        //echo "SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') $order_filter $grade_filter $school_filter $date_filter group by order_slot  ORDER BY id desc";
        //$count        = $query->num_rows();
        $daily_report = array();

        $query_1 = $this->db->query("SELECT txn_id,username,phone_number,return_status,complaint_status,exchange_id,product_parent_cid,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') $order_filter $academic_year_filter ORDER BY id desc"); 


        foreach ($query_1->result_array() as $row) {

            $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
            $order_type = $row['order_type'];
            $address_id = $row['address_id'];
            $order_id   = $row['id'];

            if ($order_type == 'individual') {
                if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                    $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                } else {
                    $product_name = $row['product_name'];
                }

            } else {
                $product_name = $row['school_name'];
            }

            if ($row['complaint_status'] != NULL) {
                $product_name = $product_name . ' (Complaint)';
            }

            if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                $product_name = $product_name . ' (Exchange)';
            }

            $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
            $pending_since = get_time_difference($date_);

            $single_slot_no = $this->get_single_order_slot($order_id);
            $slot_no        = $single_slot_no['order_slot'];

            $created_at     = date("d M Y h:i a", strtotime($row['created_at']));

            $txn_id=$row['txn_id'];
            $amount='';
            $query_prod  = $this->db->query("SELECT amount FROM order_payment WHERE payment_id='$txn_id' limit 1");
            if($query_prod->num_rows()>0){
                $row_prod     = $query_prod->row_array();
                $amount = $row_prod['amount'];
            }
            $daily_report[] = array(
                "id" => $row['id'],
                "address_id" => $address_id,
                "order_slot_no" => $slot_no,
                "amount" => $amount,
                "txn_id" => $row['txn_id'],
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "buyer_id" => $row['buyer_id'],
                "order_type" => ucfirst($row['order_type']),
                "order_number" => $row['order_number'],
                "invoice_no" => $row['invoice_no'],
                "slot_no" => $row['slot_no'],
                "courier" => $row['courier'],
                "school_name" => $row['school_name'],
                "grade_name" => $row['grade_name'],
                "board_name" => $row['board_name'],
                "city_name" => $shipping->city_name,
                "pincode" => $shipping->pincode,
                "warehouse_name" => $shipping->name,
                "warehouse_id" => $shipping->id,
                "order_status" => $row['order_status'],
                "created_at" => $created_at,
                "pending_since" => $pending_since,
                "product_name" => $product_name
            );

        }

        $order_status = $filter['order_status'];

        $q_filter='';
        if ($source=='app') {
            $q_filter = " and warehouse_id = '$warehouse_id'";
        }
        $sorder_filter = " (payment_status = 'payment_pending' || payment_status = 'payment_failed')";


        //$bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset'    ORDER BY id ASC")->num_rows();
        //$individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual'    ORDER BY id ASC")->num_rows();
        $bookset_count=0;
        $individual_count=0;

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND $sorder_filter and courier_id = '1' $academic_year_filter ORDER BY id ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') $q_filter AND $sorder_filter and courier_id = '2' $academic_year_filter ORDER BY id ASC")->num_rows(); 

        $total_data = count($daily_report);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'data' => $daily_report,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count
        );
        return $resultpost;
    }



    public function sortFunction($a, $b)
    {
        return strtotime($a["order_slot_no"]) - strtotime($b["order_slot_no"]);
    }

    public function get_single_order_slot($order_id)
    {
        return $this->db->query("SELECT order_slot FROM orders WHERE id='$order_id'")->row_array();
    }

    public function get_order_slot($address_id, $warehouse_id)
    {
        return $query = $this->db->query("SELECT order_slot FROM orders WHERE address_id='$address_id' and warehouse_id='$warehouse_id' and order_status = 'pending' and   (order_slot !='' or order_slot !='null') and payment_status = 'payment_received' group by order_slot limit 1")->row_array();
    }

    public function check_order_slot($address_id, $warehouse_id)
    {
        return $query = $this->db->query("SELECT id FROM orders WHERE address_id='$address_id' and warehouse_id='$warehouse_id' and order_status = 'pending' and  (order_slot !='' or order_slot !='null') and payment_status = 'payment_received'  LIMIT 1")->num_rows();
    }

    public function check_bookset_order_slot($address_id, $warehouse_id)
    {
        return $query = $this->db->query("SELECT id FROM orders WHERE address_id='$address_id' and warehouse_id='$warehouse_id' and order_status = 'pending' and  (order_slot !='' or order_slot !='null') and order_type ='bookset' and payment_status = 'payment_received'  LIMIT 1")->num_rows();
    }

    public function update_order_slot($order_id, $order_slot)
    {

        $check = $this->db->query("SELECT id FROM orders WHERE id='$order_id' and order_status = 'pending' and order_slot IS NULL")->num_rows();
        if ($check > 0) {
            $data_order = array(
                'order_slot' => $order_slot
            );
            $this->db->where('id', $order_id);
            $this->db->where('order_status', 'pending');
            $this->db->update('orders', $data_order);

            //remove from consolidated_reports
            $this->db->where('order_id', $order_id);
            $this->db->delete('consolidated_reports');

            return true;
        } else {
            return false;
        }


    }


    public function get_size_name($size_id)
    {
        $size  = '';
        $query = $this->db->query("SELECT * FROM size WHERE id='$size_id'");
        if ($query->num_rows() > 0) {
            $row = $query->row_array();
            if ($row['category_id'] == '38') {
                $size = 'Indian-' . $row['indian'] . ' USA-' . $row['usa'] . ' UK-' . $row['uk'];
            } else {
                $size = $row['name'];
            }
        } else {
            $size = '';
        }
        return $size;
    }

    public function order_details($user_id, $id)
    {
        $query_prod               = $this->db->query("SELECT * FROM orders WHERE vendor_id='$user_id' and order_slot='$id'");
        $order_data               = array();
        $vendor                   = array();
        $complaint_status_data    = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        foreach ($query_prod->result_array() as $row_prod) {
            $order_id         = $row_prod['id'];
            $order_slot       = $row_prod['order_slot'];
            $txn_id       = $row_prod['txn_id'];
            $created_at       = $row_prod['created_at'];
            $order_type       = $row_prod['order_type'];
            $order_number     = $row_prod['order_number'];
            $school_name      = $row_prod['school_name'];
            $grade_name       = $row_prod['grade_name'];
            $board_name       = $row_prod['board_name'];
            $price_subtotal   = $row_prod['price_subtotal'];
            $price_shipping   = $row_prod['price_shipping'];
            $price_total      = $row_prod['price_total'];
            $internet_charges = $row_prod['internet_charges'];
            $order_status     = $row_prod['order_status'];
            $warehouse_id     = $row_prod['warehouse_id'];
            $invoice_no       = $row_prod['invoice_no'];
            $total_weight     = $row_prod['total_weight'];
            $orderform_id     = $row_prod['orderform_id'];
            $size_name        = $this->get_size_name($row_prod['size_id']);
            $price_discount   = $row_prod['price_discount'];
            $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];

            $query_driver = $this->db->query("SELECT `driver_name`,`vehicle_name` FROM `oc_delivery_routes` WHERE order_slot='$order_slot' LIMIT 1");
            if ($query_driver->num_rows() > 0) {
                $driver = $query_driver->row_array();

                $driver_contact = $this->db->query("SELECT `driver_name`,`vehicle_name` FROM `oc_delivery_routes` WHERE order_slot='$order_slot' LIMIT 1");
                $driver_name    = $driver['driver_name'];
                $vehicle_name   = $driver['vehicle_name'];
            } else {
                $driver_name  = '';
                $vehicle_name = '';
            }

            $shipping_date   = ($row_prod['shipping_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['shipping_date'])) : '-');
            $dispatched_date = ($row_prod['dispatched_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['dispatched_date'])) : '-');
            $delivered_date  = ($row_prod['delivered_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['delivered_date'])) : '-');
            $processing_date = ($row_prod['processing_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['processing_date'])) : '-');
            $created_at = ($row_prod['created_at'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['created_at'])) : '-');

            $buyer_id = $row_prod['buyer_id'];

            $payment_method = $row_prod['payment_method'];
            $payment_id     = $row_prod['payment_id'];
            $created_at     = date("d M Y h:i a", strtotime($row_prod['created_at']));


            if ($row_prod['complaint_id'] != NULL) {
                $complaint_id         = $row_prod['complaint_id'];
                $ticket_rw            = $this->db->query("SELECT id,ctype,action_date, processing_date, shipping_date, dispatched_date, delivered_date, not_delivered_date FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                $ticket_no            = '#' . $ticket_rw['ctype'] . sprintf('%04d', $ticket_rw['id']);
                $created_at_comp      = date("d M Y h:i a", strtotime($row_prod['complaint_date']));
                $shipping_date_comp   = ($ticket_rw['shipping_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['shipping_date'])) : '-');
                $dispatched_date_comp = ($ticket_rw['dispatched_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['dispatched_date'])) : '-');
                $delivered_date_comp  = ($ticket_rw['delivered_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['delivered_date'])) : '-');
                $processing_date_comp = ($ticket_rw['processing_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['processing_date'])) : '-');
            } else {
                $ticket_no = $complaint_id = $created_at_comp = $shipping_date_comp = $dispatched_date_comp = $delivered_date_comp = $processing_date_comp = "";
            }

            if ($complaint_id != '' && $complaint_id != NULL) {
                $complaint_status_data[] = array(
                    "exchange_id" => '',
                    "ticket_no" => $ticket_no,
                    "complaint_id" => $complaint_id,
                    "created_at_comp" => $created_at_comp,
                    "shipping_date_comp" => $shipping_date_comp,
                    "dispatched_date_comp" => $dispatched_date_comp,
                    "delivered_date_comp" => $delivered_date_comp,
                    "processing_date_comp" => $processing_date_comp,
                    "complaint_status" => $row_prod['complaint_status']
                );
            }

            $get_shipping             = $this->db->query("SELECT * FROM `order_shipping` WHERE order_id='$order_id'")->row_array();
            $shipping_name            = $get_shipping['name'];
            $shipping_phone           = $get_shipping['phone'];
            $shipping_email           = $get_shipping['email'];
            $shipping_alternate_phone = $get_shipping['alternate_phone'];
            $shipping_flat_house_no   = $get_shipping['flat_house_no'];
            $shipping_building_name   = $get_shipping['building_name'];
            $shipping_location        = $get_shipping['location'];
            $shipping_address         = $get_shipping['address'];
            $shipping_state           = $get_shipping['state'];
            $shipping_city            = $get_shipping['city'];
            $shipping_pincode         = $get_shipping['pincode'];
            $shipping_landmark        = $get_shipping['landmark'];

            $get_state  = $this->db->query("SELECT name FROM states where id='$shipping_state'")->row_array();
            $state_name = $get_state['name'];

            $get_city  = $this->db->query("SELECT name FROM cities where id='$shipping_city'")->row_array();
            $city_name = $get_city['name'];

            $get_user   = $this->db->query("SELECT users.username,users.email,users.phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
            $username   = $get_user['username'];
            $user_email = $get_user['email'];
            $user_phone = $get_user['phone_number'];

            $get_vendor  = $this->db->query("SELECT users.firm_name FROM users where users.id='$user_id' limit 1")->row_array();
            $vendor_name = $get_vendor['firm_name'];

            $get_vendor_billing = $this->db->query("SELECT pan,gst FROM vendor_billing_details where vendor_id='$user_id' limit 1")->row_array();
            $vendor_pan_no      = $get_vendor_billing['pan'];
            $vendor_gst_no      = $get_vendor_billing['gst'];

            $get_vendor_billing = $this->db->query("SELECT vsd.address,vsd.pincode,c.name as city_name,s.name as state_name FROM vendor_shipping_details as vsd INNER JOIN cities as c ON vsd.city_id = c.id INNER JOIN states as s ON vsd.state_id = s.id where vsd.id='$warehouse_id'")->row_array();
            $vendor_address     = $get_vendor_billing['address'];
            $vendor_pincode     = $get_vendor_billing['pincode'];
            $vendor_city_name   = $get_vendor_billing['city_name'];
            $vendor_state_name  = $get_vendor_billing['state_name'];

            $total_amount = 0;

            $package_aaray = array();

            if ($order_type == 'individual') {
                $product = array();
                $query   = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id'");
                $count   = $query->num_rows();
                // $order_data = array();
                foreach ($query->result_array() as $row) {
                    $id                    = $row['id'];
                    $image                 = $row['image'];
                    $product_id            = $row['product_id'];
                    $product_name          = $row['product_name'];
                    $product_unit_price    = $row['product_unit_price'];
                    $product_quantity      = $row['product_quantity'];
                    $product_shipping_cost = $row['product_shipping_cost'];

                    /*$product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/

                    if ($row_prod['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    $total       = $product_unit_price * $product_quantity;
                    $grand_total = $total + $product_shipping_cost;
                    $total_amount .= $grand_total;

                    $product[] = array(
                        "product_name" => $product_name,
                        "size_name" => $size_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }
            } else {
                $image            = '';
                $package_discount = '';
                $package_aaray    = array();
                $query            = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id' group by package_id");
                foreach ($query->result_array() as $row) {

                    $package_id       = $row['package_id'];
                    $package_name     = $row['package_name'];
                    $package_discount = $row['package_discount'];

                    if ($package_discount == '' || $package_discount == 'null') {
                        $package_discount = 0;
                    }


                    $product     = array();
                    $query_proed = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id' and package_id = '$package_id'");
                    foreach ($query_proed->result_array() as $row_proed) {
                        // $id                    = $row['id'];
                        $image                 = $row_proed['image'];
                        $product_id            = $row_proed['product_id'];
                        $product_name          = $row_proed['product_name'];
                        $product_unit_price    = $row_proed['product_unit_price'];
                        $product_quantity      = $row_proed['product_quantity'];
                        $product_shipping_cost = $row_proed['product_shipping_cost'];

                        $total       = $product_unit_price * $product_quantity-$package_discount;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;
                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "package_discount" => $package_discount,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                    $package_aaray[] = array(
                        "package_id" => $package_id,
                        "package_name" => $package_name,
                        "product" => $product,
                        "discount" => $package_discount
                    );
                }
            }


            if ($i < 1) {
                $address[] = array(
                    "shipping_name" => $shipping_name,
                    "shipping_phone" => $shipping_phone,
                    "shipping_email" => $shipping_email,
                    "shipping_location" => $shipping_location,
                    "shipping_address" => $shipping_address,
                    "shipping_state" => $state_name,
                    "shipping_city" => $city_name,
                    "shipping_pincode" => $shipping_pincode,
                    "shipping_landmark" => $shipping_landmark,
                    "shipping_alternate_phone" => $shipping_alternate_phone,
                    "shipping_flat_house_no" => $shipping_flat_house_no,
                    "shipping_building_name" => $shipping_building_name,
                    "created_at" => $created_at,
                    "total_weight" => $total_weight,
                    "vendor_name" => $vendor_name,
                    "vendor_pan_no" => $vendor_pan_no,
                    "vendor_gst_no" => $vendor_gst_no,
                    "vendor_address" => $vendor_address,
                    "vendor_pincode" => $vendor_pincode,
                    "vendor_city_name" => $vendor_city_name,
                    "vendor_state_name" => $vendor_state_name,
                    "package_aaray" => $package_aaray,
                    "school_name" => $school_name . '-' . $grade_name
                );
            }

            if ($i < 1) {
                $vendor[] = array(
                    "vendor_name" => $vendor_name,
                    "vendor_pan_no" => $vendor_pan_no,
                    "vendor_gst_no" => $vendor_gst_no,
                    "vendor_address" => $vendor_address,
                    "vendor_pincode" => $vendor_pincode,
                    "vendor_city_name" => $vendor_city_name,
                    "vendor_state_name" => $vendor_state_name
                );
            }


            $product_total += intval($price_subtotal);
            $product_internet_charges += intval($internet_charges);
            $product_price_shipping += price_format_decimal($price_shipping);


            //exchange product
            $exchange_array   = array();
            $order_id_revised = $row_prod['order_id_revised'];
            if ($order_id_revised != NULL) {
                $exchange_array = $this->get_exchange_product_details($order_id_revised);
            }



            $order_data[] = array(
                "slot_id" => $order_slot,
                "image" => $image,
                "order_type" => $order_type,
                "created_at" => $created_at,
                "order_id" => $order_id,
                "product_id" => $product_id,
                "product_name" => $product_name,
                "size_name" => get_phrase($size_name),
                "product_unit_price" => $product_unit_price,
                "product_quantity" => $product_quantity,
                "product_shipping_cost" => $product_shipping_cost,
                "order_status" => $order_status,
                "total" => $total,
                "grand_total" => $grand_total,
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "created_at" => $created_at,
                "shipping_name" => $shipping_name,
                "shipping_phone" => $shipping_phone,
                "shipping_email" => $shipping_email,
                "shipping_location" => $shipping_location,
                "shipping_address" => $shipping_address,
                "shipping_state" => $state_name,
                "shipping_city" => $city_name,
                "shipping_pincode" => $shipping_pincode,
                "shipping_landmark" => $shipping_landmark,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "order_number" => $order_number,
                "price_subtotal" => $price_subtotal,
                "price_shipping" => $price_shipping,
                "price_total" => $price_total,
                "internet_charges" => $internet_charges,
                "student_name" => $student_name,
                "package_aaray" => $package_aaray,
                "username" => $username,
                "user_email" => $user_email,
                "user_phone" => $user_phone,
                "invoice_no" => $invoice_no,
                "vendor_name" => $vendor_name,
                "vendor_pan_no" => $vendor_pan_no,
                "vendor_gst_no" => $vendor_gst_no,
                "vendor_address" => $vendor_address,
                "vendor_pincode" => $vendor_pincode,
                "vendor_city_name" => $vendor_city_name,
                "vendor_state_name" => $vendor_state_name,
                "total_weight" => $total_weight,

                "created_at_comp" => $created_at_comp,
                "shipping_date_comp" => $shipping_date_comp,
                "dispatched_date_comp" => $dispatched_date_comp,
                "delivered_date_comp" => $delivered_date_comp,
                "processing_date_comp" => $processing_date_comp
            );
            $i++;


        }

        $final_amount = (float)$product_total+(float)$product_internet_charges+(float)$product_price_shipping;
        $details[]    = array(
            "created_at" => $created_at,
            "payment_id" => $payment_id,
            "payment_method" => $payment_method,
            "username" => $username,
            "user_email" => $user_email,
            "user_phone" => $user_phone,
            "product_total" => $product_total,
            "product_internet_charges" => $product_internet_charges,
            "product_price_shipping" => $product_price_shipping,
            "final_amount" => $final_amount,
            "driver_name" => $driver_name,
            "vehicle_name" => $vehicle_name
        );



        if ($row_prod['complaint_id'] != NULL) {
            //$this->load->model('complaint_model');
            //$cdata = $this->complaint_model->complaint_details($user_id,$row_prod['complaint_id']);
            $complaint_data = $cdata['data'];
        } else {
            $complaint_data = array();
        }


        $data[] = array(
            "txn_id" => $txn_id,
            "slot_no" => $order_slot,
            "created_at" => $created_at,
            "exchange_id" => $row_prod['exchange_id'],
            "complaint_id" => $row_prod['complaint_id'],
            "order_status" => $order_status,
            "shipping_date" => $shipping_date,
            "dispatched_date" => $dispatched_date,
            "delivered_date" => $delivered_date,
            "processing_date" => $processing_date,
            "details" => $details,
            "address" => $address,
            "data" => $order_data,
            "vendor" => $vendor,
            "exchange_array" => $exchange_array,
            "complaint_data" => $complaint_data,
            "created_at_comp" => $created_at_comp,
            "shipping_date_comp" => $shipping_date_comp,
            "dispatched_date_comp" => $dispatched_date_comp,
            "delivered_date_comp" => $delivered_date_comp,
            "processing_date_comp" => $processing_date_comp,
            "complaint_status" => $row_prod['complaint_status'],
            "complaint_status_data" => $complaint_status_data
        );

        return $data;
    }


    public function failed_order_details($user_id, $id)
    {
        $query_prod               = $this->db->query("SELECT * FROM orders WHERE vendor_id='$user_id' and id='$id' and order_status != 'cancelled'");
        // echo $this->db->last_query();
        // $row_prod         = $query_prod->row_array();
        $order_data               = array();
        $vendor                   = array();
        $complaint_status_data    = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        foreach ($query_prod->result_array() as $row_prod) {
            $order_id         = $row_prod['id'];
            $order_slot       = $row_prod['order_number'];
            $order_type       = $row_prod['order_type'];
            $order_number     = $row_prod['order_number'];
            $school_name      = $row_prod['school_name'];
            $grade_name       = $row_prod['grade_name'];
            $board_name       = $row_prod['board_name'];
            $price_subtotal   = $row_prod['price_subtotal'];
            $price_shipping   = $row_prod['price_shipping'];
            $price_total      = $row_prod['price_total'];
            $internet_charges = $row_prod['internet_charges'];
            $order_status     = $row_prod['order_status'];
            $warehouse_id     = $row_prod['warehouse_id'];
            $invoice_no       = $row_prod['invoice_no'];
            $total_weight     = $row_prod['total_weight'];
            $orderform_id     = $row_prod['orderform_id'];
            $size_name        = $this->get_size_name($row_prod['size_id']);
            $price_discount   = $row_prod['price_discount'];
            $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];

            $driver_name  = '';
            $vehicle_name = '';

            $shipping_date   = ($row_prod['shipping_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['shipping_date'])) : '-');
            $dispatched_date = ($row_prod['dispatched_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['dispatched_date'])) : '-');
            $delivered_date  = ($row_prod['delivered_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['delivered_date'])) : '-');
            $processing_date = ($row_prod['processing_date'] != NULL ? date("d M Y  h:i a", strtotime($row_prod['processing_date'])) : '-');

            $buyer_id = $row_prod['buyer_id'];

            $payment_method = $row_prod['payment_method'];
            $payment_id     = $row_prod['payment_id'];
            $created_at     = date("d M Y h:i a", strtotime($row_prod['created_at']));


            if ($row_prod['complaint_id'] != NULL) {
                $complaint_id         = $row_prod['complaint_id'];
                $ticket_rw            = $this->db->query("SELECT id,ctype,action_date, processing_date, shipping_date, dispatched_date, delivered_date, not_delivered_date FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                $ticket_no            = '#' . $ticket_rw['ctype'] . sprintf('%04d', $ticket_rw['id']);
                $created_at_comp      = date("d M Y h:i a", strtotime($row_prod['complaint_date']));
                $shipping_date_comp   = ($ticket_rw['shipping_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['shipping_date'])) : '-');
                $dispatched_date_comp = ($ticket_rw['dispatched_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['dispatched_date'])) : '-');
                $delivered_date_comp  = ($ticket_rw['delivered_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['delivered_date'])) : '-');
                $processing_date_comp = ($ticket_rw['processing_date'] != NULL ? date("d M Y  h:i a", strtotime($ticket_rw['processing_date'])) : '-');
            } else {
                $ticket_no = $complaint_id = $created_at_comp = $shipping_date_comp = $dispatched_date_comp = $delivered_date_comp = $processing_date_comp = "";
            }

            if ($complaint_id != '' && $complaint_id != NULL) {
                $complaint_status_data[] = array(
                    "exchange_id" => '',
                    "ticket_no" => $ticket_no,
                    "complaint_id" => $complaint_id,
                    "created_at_comp" => $created_at_comp,
                    "shipping_date_comp" => $shipping_date_comp,
                    "dispatched_date_comp" => $dispatched_date_comp,
                    "delivered_date_comp" => $delivered_date_comp,
                    "processing_date_comp" => $processing_date_comp,
                    "complaint_status" => $row_prod['complaint_status']
                );
            }

            $get_shipping             = $this->db->query("SELECT * FROM `order_shipping` WHERE order_id='$order_id' limit 1")->row_array();
            $shipping_name            = $get_shipping['name'];
            $shipping_phone           = $get_shipping['phone'];
            $shipping_email           = $get_shipping['email'];
            $shipping_alternate_phone = $get_shipping['alternate_phone'];
            $shipping_flat_house_no   = $get_shipping['flat_house_no'];
            $shipping_building_name   = $get_shipping['building_name'];
            $shipping_location        = $get_shipping['location'];
            $shipping_address         = $get_shipping['address'];
            $shipping_state           = $get_shipping['state'];
            $shipping_city            = $get_shipping['city'];
            $shipping_pincode         = $get_shipping['pincode'];
            $shipping_landmark        = $get_shipping['landmark'];

            $get_state  = $this->db->query("SELECT name FROM states where id='$shipping_state' limit 1")->row_array();
            $state_name = $get_state['name'];

            $get_city  = $this->db->query("SELECT name FROM cities where id='$shipping_city' limit 1")->row_array();
            $city_name = $get_city['name'];

            $get_user   = $this->db->query("SELECT users.username,users.email,users.phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
            $username   = $get_user['username'];
            $user_email = $get_user['email'];
            $user_phone = $get_user['phone_number'];

            $get_vendor  = $this->db->query("SELECT users.firm_name FROM users where users.id='$user_id' limit 1")->row_array();
            $vendor_name = $get_vendor['firm_name'];

            $get_vendor_billing = $this->db->query("SELECT pan,gst FROM vendor_billing_details where vendor_id='$user_id' limit 1")->row_array();
            $vendor_pan_no      = $get_vendor_billing['pan'];
            $vendor_gst_no      = $get_vendor_billing['gst'];

            $get_vendor_billing = $this->db->query("SELECT vsd.address,vsd.pincode,c.name as city_name,s.name as state_name FROM vendor_shipping_details as vsd INNER JOIN cities as c ON vsd.city_id = c.id INNER JOIN states as s ON vsd.state_id = s.id where vsd.id='$warehouse_id'")->row_array();
            $vendor_address     = $get_vendor_billing['address'];
            $vendor_pincode     = $get_vendor_billing['pincode'];
            $vendor_city_name   = $get_vendor_billing['city_name'];
            $vendor_state_name  = $get_vendor_billing['state_name'];

            $total_amount = 0;

            $package_aaray = array();

            if ($order_type == 'individual') {
                $product = array();
                $query   = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id'");
                $count   = $query->num_rows();
                // $order_data = array();
                foreach ($query->result_array() as $row) {
                    $id                    = $row['id'];
                    $image                 = $row['image'];
                    $product_id            = $row['product_id'];
                    $product_name          = $row['product_name'];
                    $product_unit_price    = $row['product_unit_price'];
                    $product_quantity      = $row['product_quantity'];
                    $product_shipping_cost = $row['product_shipping_cost'];

                    /*$product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/

                    if ($row_prod['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    $total       = $product_unit_price * $product_quantity;
                    $grand_total = $total + $product_shipping_cost;
                    $total_amount .= $grand_total;

                    $product[] = array(
                        "product_name" => $product_name,
                        "size_name" => $size_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }
            } else {
                $image            = '';
                $package_discount = '';
                $package_aaray    = array();
                $query            = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id' group by package_id");
                foreach ($query->result_array() as $row) {

                    $package_id       = $row['package_id'];
                    $package_name     = $row['package_name'];
                    $package_discount = $row['package_discount'];

                    if ($package_discount == '' || $package_discount == 'null') {
                        $package_discount = 0;
                    }

                    // $discount = 0;
                    // $dis = $this->get_single_discount_by_package_id($orderform_id,$package_id);
                    // if($dis['status'] == 200){
                    //     $discount = $dis['discount'];
                    // }

                    $product     = array();
                    $query_proed = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id' and package_id = '$package_id'");
                    foreach ($query_proed->result_array() as $row_proed) {
                        // $id                    = $row['id'];
                        $image                 = $row_proed['image'];
                        $product_id            = $row_proed['product_id'];
                        $product_name          = $row_proed['product_name'];
                        $product_unit_price    = $row_proed['product_unit_price'];
                        $product_quantity      = $row_proed['product_quantity'];
                        $product_shipping_cost = $row_proed['product_shipping_cost'];
                        // $order_status          = $row['order_status'];

                        /*$product_name = str_replace(' ', '-', $product_name);
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_name = strtolower(str_replace('-', ' ', $product_name));
                        $product_name = ucfirst($product_name);*/



                        $total       = $product_unit_price * $product_quantity;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;
                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                    $package_aaray[] = array(
                        "package_id" => $package_id,
                        "package_name" => $package_name,
                        "product" => $product,
                        "discount" => $package_discount
                    );
                }
            }


            if ($i < 1) {
                $address[] = array(
                    "shipping_name" => $shipping_name,
                    "shipping_phone" => $shipping_phone,
                    "shipping_email" => $shipping_email,
                    "shipping_location" => $shipping_location,
                    "shipping_address" => $shipping_address,
                    "shipping_state" => $state_name,
                    "shipping_city" => $city_name,
                    "shipping_pincode" => $shipping_pincode,
                    "shipping_landmark" => $shipping_landmark,
                    "shipping_alternate_phone" => $shipping_alternate_phone,
                    "shipping_flat_house_no" => $shipping_flat_house_no,
                    "shipping_building_name" => $shipping_building_name,
                    "created_at" => $created_at,
                    "total_weight" => $total_weight,
                    "vendor_name" => $vendor_name,
                    "vendor_pan_no" => $vendor_pan_no,
                    "vendor_gst_no" => $vendor_gst_no,
                    "vendor_address" => $vendor_address,
                    "vendor_pincode" => $vendor_pincode,
                    "vendor_city_name" => $vendor_city_name,
                    "vendor_state_name" => $vendor_state_name,
                    "package_aaray" => $package_aaray,
                    "school_name" => $school_name . '-' . $grade_name
                );
            }

            if ($i < 1) {
                $vendor[] = array(
                    "vendor_name" => $vendor_name,
                    "vendor_pan_no" => $vendor_pan_no,
                    "vendor_gst_no" => $vendor_gst_no,
                    "vendor_address" => $vendor_address,
                    "vendor_pincode" => $vendor_pincode,
                    "vendor_city_name" => $vendor_city_name,
                    "vendor_state_name" => $vendor_state_name
                );
            }


            $product_total += floatval($price_subtotal);
            $product_internet_charges += floatval($internet_charges);
            $product_price_shipping += price_format_decimal($price_shipping);


            //exchange product
            $exchange_array   = array();
            $order_id_revised = $row_prod['order_id_revised'];
            if ($order_id_revised != NULL) {
                $exchange_array = $this->get_exchange_product_details($order_id_revised);
            }



            $order_data[] = array(
                "slot_id" => $order_slot,
                "image" => $image,
                "order_type" => $order_type,
                "order_id" => $order_id,
                "product_id" => $product_id,
                "product_name" => $product_name,
                "size_name" => get_phrase($size_name),
                "product_unit_price" => $product_unit_price,
                "product_quantity" => $product_quantity,
                "product_shipping_cost" => $product_shipping_cost,
                "order_status" => $order_status,
                "total" => $total,
                "grand_total" => $grand_total,
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "created_at" => $created_at,
                "shipping_name" => $shipping_name,
                "shipping_phone" => $shipping_phone,
                "shipping_email" => $shipping_email,
                "shipping_location" => $shipping_location,
                "shipping_address" => $shipping_address,
                "shipping_state" => $state_name,
                "shipping_city" => $city_name,
                "shipping_pincode" => $shipping_pincode,
                "shipping_landmark" => $shipping_landmark,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "order_number" => $order_number,
                "price_subtotal" => $price_subtotal,
                "price_shipping" => $price_shipping,
                "price_total" => $price_total,
                "internet_charges" => $internet_charges,
                "student_name" => $student_name,
                "package_aaray" => $package_aaray,
                "username" => $username,
                "user_email" => $user_email,
                "user_phone" => $user_phone,
                "invoice_no" => $invoice_no,
                "vendor_name" => $vendor_name,
                "vendor_pan_no" => $vendor_pan_no,
                "vendor_gst_no" => $vendor_gst_no,
                "vendor_address" => $vendor_address,
                "vendor_pincode" => $vendor_pincode,
                "vendor_city_name" => $vendor_city_name,
                "vendor_state_name" => $vendor_state_name,
                "total_weight" => $total_weight,

                "created_at_comp" => $created_at_comp,
                "shipping_date_comp" => $shipping_date_comp,
                "dispatched_date_comp" => $dispatched_date_comp,
                "delivered_date_comp" => $delivered_date_comp,
                "processing_date_comp" => $processing_date_comp
            );
            $i++;


        }

        $final_amount = $product_total + $product_internet_charges + $product_price_shipping - $price_discount;
        $details[]    = array(
            "payment_id" => $payment_id,
            "payment_method" => $payment_method,
            "username" => $username,
            "user_email" => $user_email,
            "user_phone" => $user_phone,
            "product_total" => $product_total,
            "product_internet_charges" => $product_internet_charges,
            "product_price_shipping" => $product_price_shipping,
            "final_amount" => $product_total+$product_price_shipping,
            "driver_name" => $driver_name,
            "vehicle_name" => $vehicle_name
        );



        if ($row_prod['complaint_id'] != NULL) {
            //$this->load->model('complaint_model');
            //$cdata = $this->complaint_model->complaint_details($user_id,$row_prod['complaint_id']);
            $complaint_data = $cdata['data'];
        } else {
            $complaint_data = array();
        }


        $data[] = array(
            "slot_no" => $order_slot,
            "exchange_id" => $row_prod['exchange_id'],
            "complaint_id" => $row_prod['complaint_id'],
            "order_status" => $order_status,
            "shipping_date" => $shipping_date,
            "dispatched_date" => $dispatched_date,
            "delivered_date" => $delivered_date,
            "processing_date" => $processing_date,
            "details" => $details,
            "address" => $address,
            "data" => $order_data,
            "vendor" => $vendor,
            "exchange_array" => $exchange_array,
            "complaint_data" => $complaint_data,
            "created_at_comp" => $created_at_comp,
            "shipping_date_comp" => $shipping_date_comp,
            "dispatched_date_comp" => $dispatched_date_comp,
            "delivered_date_comp" => $delivered_date_comp,
            "processing_date_comp" => $processing_date_comp,
            "complaint_status" => $row_prod['complaint_status'],
            "complaint_status_data" => $complaint_status_data
        );

        return $data;
    }


    public function cancel_order_details($user_id, $id)
    {
        $query_prod               = $this->db->query("SELECT * FROM orders WHERE vendor_id='$user_id' and id='$id'");
        // echo $this->db->last_query();
        // $row_prod         = $query_prod->row_array();
        $order_data               = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        foreach ($query_prod->result_array() as $row_prod) {
            $order_id         = $row_prod['id'];
            $order_type       = $row_prod['order_type'];
            $order_number     = $row_prod['order_number'];
            $school_name      = $row_prod['school_name'];
            $grade_name       = $row_prod['grade_name'];
            $board_name       = $row_prod['board_name'];
            $price_subtotal   = $row_prod['price_subtotal'];
            $price_shipping   = $row_prod['price_shipping'];
            $price_total      = $row_prod['price_total'];
            $internet_charges = $row_prod['internet_charges'];
            $order_status     = $row_prod['order_status'];
            $warehouse_id     = $row_prod['warehouse_id'];
            $invoice_no       = $row_prod['invoice_no'];
            $total_weight     = $row_prod['total_weight'];
            $cancel_reason    = $row_prod['cancel_reason'];
            $returned_date    = $row_prod['returned_date'];
            $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];


            $buyer_id = $row_prod['buyer_id'];

            $payment_method = $row_prod['payment_method'];
            $payment_id     = $row_prod['payment_id'];
            $created_at     = date("d M Y h:i a", strtotime($row_prod['created_at']));

            $returned_since = get_time_difference($returned_date);


            $get_shipping             = $this->db->query("SELECT * FROM `order_shipping` WHERE order_id='$order_id'")->row_array();
            $shipping_name            = $get_shipping['name'];
            $shipping_phone           = $get_shipping['phone'];
            $shipping_email           = $get_shipping['email'];
            $shipping_location        = $get_shipping['location'];
            $shipping_address         = $get_shipping['address'];
            $shipping_state           = $get_shipping['state'];
            $shipping_city            = $get_shipping['city'];
            $shipping_pincode         = $get_shipping['pincode'];
            $shipping_landmark        = $get_shipping['landmark'];
            $shipping_alternate_phone = $get_shipping['alternate_phone'];
            $shipping_flat_house_no   = $get_shipping['flat_house_no'];
            $shipping_building_name   = $get_shipping['building_name'];

            $get_state  = $this->db->query("SELECT name FROM states where id='$shipping_state'")->row_array();
            $state_name = $get_state['name'];

            $get_city  = $this->db->query("SELECT name FROM cities where id='$shipping_city'")->row_array();
            $city_name = $get_city['name'];

            $get_user   = $this->db->query("SELECT users.username,users.email,users.phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
            $username   = $get_user['username'];
            $user_email = $get_user['email'];
            $user_phone = $get_user['phone_number'];

            $get_vendor  = $this->db->query("SELECT users.firm_name FROM users where users.id='$user_id' limit 1")->row_array();
            $vendor_name = $get_vendor['firm_name'];

            $get_vendor_billing = $this->db->query("SELECT pan,gst FROM vendor_billing_details where vendor_id='$user_id' limit 1")->row_array();
            $vendor_pan_no      = $get_vendor_billing['pan'];
            $vendor_gst_no      = $get_vendor_billing['gst'];

            $get_vendor_billing = $this->db->query("SELECT vsd.address,vsd.pincode,c.name as city_name,s.name as state_name FROM vendor_shipping_details as vsd INNER JOIN cities as c ON vsd.city_id = c.id INNER JOIN states as s ON vsd.state_id = s.id where vsd.id='$warehouse_id'")->row_array();
            $vendor_address     = $get_vendor_billing['address'];
            $vendor_pincode     = $get_vendor_billing['pincode'];
            $vendor_city_name   = $get_vendor_billing['city_name'];
            $vendor_state_name  = $get_vendor_billing['state_name'];

            $total_amount = 0;

            $package_aaray = array();

            if ($order_type == 'individual') {
                $product = array();
                $query   = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id'");
                $count   = $query->num_rows();
                // $order_data = array();
                foreach ($query->result_array() as $row) {
                    $id                    = $row['id'];
                    $image                 = $row['image'];
                    $product_id            = $row['product_id'];
                    $product_name          = $row['product_name'];
                    $product_unit_price    = $row['product_unit_price'];
                    $product_quantity      = $row['product_quantity'];
                    $product_shipping_cost = $row['product_shipping_cost'];

                    /*$product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);
                    */
                    $total       = $product_unit_price * $product_quantity;
                    $grand_total = $total + $product_shipping_cost;
                    $total_amount .= $grand_total;

                    $product[] = array(
                        "product_name" => $product_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }
            } else {
                $image         = '';
                $package_aaray = array();
                $query         = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id' group by package_id");
                foreach ($query->result_array() as $row) {

                    $package_id   = $row['package_id'];
                    $package_name = $row['package_name'];

                    $product     = array();
                    $query_proed = $this->db->query("SELECT * FROM order_products WHERE seller_id='$user_id' and order_id='$order_id' and package_id = '$package_id'");
                    foreach ($query_proed->result_array() as $row_proed) {
                        $id                    = $row_proed['id'];
                        $image                 = $row_proed['image'];
                        $product_id            = $row_proed['product_id'];
                        $product_name          = $row_proed['product_name'];
                        $product_unit_price    = $row_proed['product_unit_price'];
                        $product_quantity      = $row_proed['product_quantity'];
                        $product_shipping_cost = $row_proed['product_shipping_cost'];
                        // $order_status          = $row['order_status'];

                        $product_name = str_replace(' ', '-', $product_name);
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_name = strtolower(str_replace('-', ' ', $product_name));
                        $product_name = ucfirst($product_name);

                        $total       = $product_unit_price * $product_quantity;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;
                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                    $package_aaray[] = array(
                        "package_id" => $package_id,
                        "package_name" => $package_name,
                        "product" => $product
                    );
                }
            }


            $order_data[] = array(
                "slot_id" => $id,
                "image" => $image,
                "order_type" => $order_type,
                "order_id" => $order_id,
                "product_id" => $product_id,
                "product_name" => $product_name,
                "product_unit_price" => $product_unit_price,
                "product_quantity" => $product_quantity,
                "product_shipping_cost" => $product_shipping_cost,
                "order_status" => $order_status,
                "total" => $total,
                "grand_total" => $grand_total,
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "created_at" => $created_at,
                "shipping_alternate_phone" => $shipping_alternate_phone,
                "shipping_flat_house_no" => $shipping_flat_house_no,
                "shipping_building_name" => $shipping_building_name,
                "shipping_name" => $shipping_name,
                "shipping_phone" => $shipping_phone,
                "shipping_email" => $shipping_email,
                "shipping_location" => $shipping_location,
                "shipping_address" => $shipping_address,
                "shipping_state" => $state_name,
                "shipping_city" => $city_name,
                "shipping_pincode" => $shipping_pincode,
                "shipping_landmark" => $shipping_landmark,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "order_number" => $order_number,
                "price_subtotal" => $price_subtotal,
                "price_shipping" => $price_shipping,
                "price_total" => $price_total,
                "internet_charges" => $internet_charges,
                "student_name" => $student_name,
                "package_aaray" => $package_aaray,
                "username" => $username,
                "user_email" => $user_email,
                "user_phone" => $user_phone,
                "invoice_no" => $invoice_no,
                "vendor_name" => $vendor_name,
                "vendor_pan_no" => $vendor_pan_no,
                "vendor_gst_no" => $vendor_gst_no,
                "vendor_address" => $vendor_address,
                "vendor_pincode" => $vendor_pincode,
                "vendor_city_name" => $vendor_city_name,
                "vendor_state_name" => $vendor_state_name,
                "total_weight" => $total_weight,
                "cancel_reason" => $cancel_reason,
                "returned_since" => $returned_since
            );

        }





        return $order_data;
    }

    public function group_array($arr, $group, $preserveGroupKey = false, $preserveSubArrays = false)
    {
        $temp = array();
        foreach ($arr as $key => $value) {
            $groupValue = $value[$group];
            if (!$preserveGroupKey) {
                unset($arr[$key][$group]);
            }
            if (!array_key_exists($groupValue, $temp)) {
                $temp[$groupValue] = array();
            }

            if (!$preserveSubArrays) {
                $data = count($arr[$key]) == 1 ? array_pop($arr[$key]) : $arr[$key];
            } else {
                $data = $arr[$key];
            }
            $temp[$groupValue][] = $data;
        }
        return $temp;
    }


    public function get_order_type($order_id)
    {
        $query = $this->db->query("SELECT order_type,vendor_id FROM orders WHERE id = '$order_id'");
        return $query->row_array();
    }

    public function otp_send_by_order_id($user_id, $order_id)
    {
        //$otp = $this->auth_model->generatePIN();
        $otp = '1234';
        if ($otp) {
            $data['otp'] = $otp;
            $this->db->where('id', $order_id);
            $this->db->update('orders', $data);
            //$query          = $this->db->query("SELECT contact_number FROM vendor_communication_details WHERE vendor_id='$user_id'");
            //$row            = $query->row_array();
            //$contact_number = $row['contact_number'];
            //$message_user = 'OTP For Order Cancellation' . $otp;
            //$this->auth_model->send_sms($message_user, $contact_number);
            $resultpost = array(
                'status' => 200,
                'message' => 'Success'
            );
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'OTP Error'
            );
        }

        return $resultpost;

    }


    public function all_order_details_($user_id, $id)
    {
        $order_slot_ = $id;

        foreach ($order_slot_ as $order_slot) {
            $query_prod               = $this->db->query("SELECT id,order_slot,order_type,order_number,school_name,grade_name,board_name,price_subtotal,price_shipping,price_total,internet_charges,order_status,warehouse_id,invoice_no,total_weight,s_name,f_name,m_name,buyer_id,payment_method,payment_id,created_at,firm_name FROM orders WHERE vendor_id='$user_id'  AND (FIND_IN_SET(order_slot,'$order_slot')) AND order_status != 'cancelled'");
            // echo $this->db->last_query();
            // $row_prod         = $query_prod->row_array();
            $order_data               = array();
            $vendor                   = array();
            $i                        = 0;
            $product_total            = 0;
            $price_subtotal           = 0;
            $product_internet_charges = 0;
            $product_price_shipping   = 0;
            $final_amount             = 0;
            foreach ($query_prod->result_array() as $row_prod) {
                $order_id         = $row_prod['id'];
                $order_slot       = $row_prod['order_slot'];
                $order_type       = $row_prod['order_type'];
                $order_number     = $row_prod['order_number'];
                $school_name      = $row_prod['school_name'];
                $grade_name       = $row_prod['grade_name'];
                $board_name       = $row_prod['board_name'];
                $price_subtotal   = $row_prod['price_subtotal'];
                $price_shipping   = $row_prod['price_shipping'];
                $price_total      = $row_prod['price_total'];
                $internet_charges = $row_prod['internet_charges'];
                $order_status     = $row_prod['order_status'];
                $warehouse_id     = $row_prod['warehouse_id'];
                $invoice_no       = $row_prod['invoice_no'];
                $total_weight     = $row_prod['total_weight'];
                $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];
                $buyer_id         = $row_prod['buyer_id'];
                $payment_method   = $row_prod['payment_method'];
                $payment_id       = $row_prod['payment_id'];
                $created_at       = date("d M Y h:i a", strtotime($row_prod['created_at']));
                $vendor_name      = $row_prod['firm_name'];


                $get_shipping      = $this->db->query("SELECT name,phone,email,location,address,state,city,pincode,landmark FROM `order_shipping` WHERE order_id='$order_id'")->row_array();
                $shipping_name     = $get_shipping['name'];
                $shipping_phone    = $get_shipping['phone'];
                $shipping_email    = $get_shipping['email'];
                $shipping_location = $get_shipping['location'];
                $shipping_address  = $get_shipping['address'];
                $shipping_state    = $get_shipping['state'];
                $shipping_city     = $get_shipping['city'];
                $shipping_pincode  = $get_shipping['pincode'];
                $shipping_landmark = $get_shipping['landmark'];
                $state_name        = get_state_name($shipping_state);
                $city_name         = get_city_name($shipping_city);

                $get_user   = $this->db->query("SELECT username,email,phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
                $username   = $get_user['username'];
                $user_email = $get_user['email'];
                $user_phone = $get_user['phone_number'];

                $get_vendor_billing = $this->db->query("SELECT pan,gst FROM vendor_billing_details where vendor_id='$user_id' limit 1")->row_array();
                $vendor_pan_no      = $get_vendor_billing['pan'];
                $vendor_gst_no      = $get_vendor_billing['gst'];

                $get_vendor_shipping = $this->db->query("SELECT address,pincode,state_id,city_id FROM vendor_shipping_details where id='$warehouse_id'")->row_array();
                $vendor_address      = $get_vendor_shipping['address'];
                $vendor_pincode      = $get_vendor_shipping['pincode'];
                $vendor_city_name    = get_state_name($get_vendor_shipping['state_id']);
                $vendor_state_name   = get_city_name($get_vendor_shipping['city_id']);

                $total_amount = 0;


                $total_amount = 0;

                $package_aaray = array();

                if ($order_type == 'individual') {
                    $product = array();
                    $query   = $this->db->query("SELECT id,image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE seller_id='$user_id' and order_id='$order_id'");
                    $count   = $query->num_rows();
                    // $order_data = array();
                    foreach ($query->result_array() as $row) {
                        $id                    = $row['id'];
                        $image                 = $row['image'];
                        $product_id            = $row['product_id'];
                        $product_name          = $row['product_name'];
                        $product_unit_price    = $row['product_unit_price'];
                        $product_quantity      = $row['product_quantity'];
                        $product_shipping_cost = $row['product_shipping_cost'];

                        /*    $product_name = str_replace(' ', '-', $product_name);
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_name = strtolower(str_replace('-', ' ', $product_name));
                        $product_name = ucfirst($product_name);*/

                        $total       = $product_unit_price * $product_quantity;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;

                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                } else {
                    $image         = '';
                    $package_aaray = array();
                    $query         = $this->db->query("SELECT package_id,package_name FROM order_products WHERE order_id='$order_id' group by package_id");
                    foreach ($query->result_array() as $row) {

                        $package_id   = $row['package_id'];
                        $package_name = $row['package_name'];

                        $product     = array();
                        $query_proed = $this->db->query("SELECT image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE order_id='$order_id' and package_id = '$package_id'");
                        foreach ($query_proed->result_array() as $row_proed) {
                            $image                 = $row_proed['image'];
                            $product_id            = $row_proed['product_id'];
                            $product_name          = $row_proed['product_name'];
                            $product_unit_price    = $row_proed['product_unit_price'];
                            $product_quantity      = $row_proed['product_quantity'];
                            $product_shipping_cost = $row_proed['product_shipping_cost'];

                            $product_name = str_replace(' ', '-', $product_name);
                            $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                            $product_name = strtolower(str_replace('-', ' ', $product_name));
                            $product_name = ucfirst($product_name);

                            $total       = $product_unit_price * $product_quantity;
                            $grand_total = $total + $product_shipping_cost;
                            $total_amount .= $grand_total;
                            $product[] = array(
                                "product_name" => $product_name,
                                "product_unit_price" => $product_unit_price,
                                "product_quantity" => $product_quantity,
                                "product_total" => $total,
                                "grand_total" => $grand_total
                            );
                        }
                        $package_aaray[] = array(
                            "package_id" => $package_id,
                            "package_name" => $package_name,
                            "product" => $product
                        );
                    }
                }


                if ($i < 1) {
                    $address[] = array(
                        "shipping_name" => $shipping_name,
                        "shipping_phone" => $shipping_phone,
                        "shipping_email" => $shipping_email,
                        "shipping_location" => $shipping_location,
                        "shipping_address" => $shipping_address,
                        "shipping_state" => $state_name,
                        "shipping_city" => $city_name,
                        "shipping_pincode" => $shipping_pincode,
                        "shipping_landmark" => $shipping_landmark,
                        "created_at" => $created_at,
                        "total_weight" => $total_weight,
                        "vendor_name" => $vendor_name,
                        "vendor_pan_no" => $vendor_pan_no,
                        "vendor_gst_no" => $vendor_gst_no,
                        "vendor_address" => $vendor_address,
                        "vendor_pincode" => $vendor_pincode,
                        "vendor_city_name" => $vendor_city_name,
                        "vendor_state_name" => $vendor_state_name,
                        "package_aaray" => $package_aaray,
                        "school_name" => $school_name . '-' . $grade_name
                    );
                }

                if ($i < 1) {
                    $vendor[] = array(
                        "vendor_name" => $vendor_name,
                        "vendor_pan_no" => $vendor_pan_no,
                        "vendor_gst_no" => $vendor_gst_no,
                        "vendor_address" => $vendor_address,
                        "vendor_pincode" => $vendor_pincode,
                        "vendor_city_name" => $vendor_city_name,
                        "vendor_state_name" => $vendor_state_name
                    );
                }


                $product_total += intval($price_subtotal);
                $product_internet_charges += intval($internet_charges);
                $product_price_shipping += intval($price_shipping);

                $order_data[] = array(
                    "slot_id" => $order_slot,
                    "image" => $image,
                    "order_type" => $order_type,
                    "order_id" => $order_id,
                    "product_id" => $product_id,
                    "product_name" => $product_name,
                    "product_unit_price" => $product_unit_price,
                    "product_quantity" => $product_quantity,
                    "product_shipping_cost" => $product_shipping_cost,
                    "order_status" => $order_status,
                    "total" => $total,
                    "grand_total" => $grand_total,
                    "payment_id" => $payment_id,
                    "payment_method" => $payment_method,
                    "created_at" => $created_at,
                    "shipping_name" => $shipping_name,
                    "shipping_phone" => $shipping_phone,
                    "shipping_email" => $shipping_email,
                    "shipping_location" => $shipping_location,
                    "shipping_address" => $shipping_address,
                    "shipping_state" => $state_name,
                    "shipping_city" => $city_name,
                    "shipping_pincode" => $shipping_pincode,
                    "shipping_landmark" => $shipping_landmark,
                    "school_name" => $school_name,
                    "grade_name" => $grade_name,
                    "board_name" => $board_name,
                    "order_number" => $order_number,
                    "price_subtotal" => $price_subtotal,
                    "price_shipping" => $price_shipping,
                    "price_total" => $price_total,
                    "internet_charges" => $internet_charges,
                    "student_name" => $student_name,
                    "package_aaray" => $package_aaray,
                    "username" => $username,
                    "user_email" => $user_email,
                    "user_phone" => $user_phone,
                    "invoice_no" => $invoice_no,
                    "vendor_name" => $vendor_name,
                    "vendor_pan_no" => $vendor_pan_no,
                    "vendor_gst_no" => $vendor_gst_no,
                    "vendor_address" => $vendor_address,
                    "vendor_pincode" => $vendor_pincode,
                    "vendor_city_name" => $vendor_city_name,
                    "vendor_state_name" => $vendor_state_name,
                    "total_weight" => $total_weight
                );
                $i++;
            }

            $final_amount = $product_total + $product_internet_charges + $product_price_shipping;
            $details[]    = array(
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "username" => $username,
                "user_email" => $user_email,
                "user_phone" => $user_phone,
                "product_total" => $product_total,
                "product_internet_charges" => $product_internet_charges,
                "product_price_shipping" => $product_price_shipping,
                "final_amount" => $final_amount
            );

            $data[] = array(
                "slot_no" => $order_slot,
                "details" => $details,
                "address" => $address,
                "data" => $order_data,
                "vendor" => $vendor
            );

        }

        return $data;
    }







    public function all_order_details($user_id, $id)
    {
        $order_slot_ = $id;
        $data        = array();
        $resultdata  = array();

        foreach ($order_slot_ as $order_slot) {
            $query_prod               = $this->db->query("SELECT id,order_slot,order_type,order_number,school_name,grade_name,board_name,price_subtotal,price_shipping,price_total,internet_charges,order_status,warehouse_id,invoice_no,total_weight,s_name,f_name,m_name,buyer_id,payment_method,payment_id,created_at,firm_name FROM orders WHERE vendor_id='$user_id'  AND order_slot='$order_slot' AND order_status != 'cancelled'");
            // echo $this->db->last_query();
            // $row_prod         = $query_prod->row_array();
            $order_data               = array();
            $vendor                   = array();
            $i                        = 0;
            $product_total            = 0;
            $price_subtotal           = 0;
            $product_internet_charges = 0;
            $product_price_shipping   = 0;
            $final_amount             = 0;
            $final_total_weight       = 0;
            foreach ($query_prod->result_array() as $row_prod) {
                $order_id         = $row_prod['id'];
                $order_slot       = $row_prod['order_slot'];
                $order_type       = $row_prod['order_type'];
                $order_number     = $row_prod['order_number'];
                $school_name      = $row_prod['school_name'];
                $grade_name       = $row_prod['grade_name'];
                $board_name       = $row_prod['board_name'];
                $price_subtotal   = $row_prod['price_subtotal'];
                $price_shipping   = $row_prod['price_shipping'];
                $price_total      = $row_prod['price_total'];
                $internet_charges = $row_prod['internet_charges'];
                $order_status     = $row_prod['order_status'];
                $warehouse_id     = $row_prod['warehouse_id'];
                $invoice_no       = $row_prod['invoice_no'];
                $total_weight     = $row_prod['total_weight'];
                $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];
                $buyer_id         = $row_prod['buyer_id'];
                $payment_method   = $row_prod['payment_method'];
                $payment_id       = $row_prod['payment_id'];
                $created_at       = date("d M Y h:i a", strtotime($row_prod['created_at']));
                $vendor_name      = $row_prod['firm_name'];
                $total_amount     = 0;

                $total_amount  = 0;
                $package_aaray = array();

                $final_total_weight = $final_total_weight + $total_weight;


                if ($order_type == 'individual') {
                    $product = array();
                    $query   = $this->db->query("SELECT id,image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE seller_id='$user_id' and order_id='$order_id'");
                    $count   = $query->num_rows();
                    // $order_data = array();
                    foreach ($query->result_array() as $row) {
                        $id                    = $row['id'];
                        $image                 = $row['image'];
                        $product_id            = $row['product_id'];
                        $product_name          = $row['product_name'];
                        $product_unit_price    = $row['product_unit_price'];
                        $product_quantity      = $row['product_quantity'];
                        $product_shipping_cost = $row['product_shipping_cost'];

                        /*$product_name = str_replace(' ', '-', $product_name);
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_name = strtolower(str_replace('-', ' ', $product_name));
                        $product_name = ucfirst($product_name);*/

                        $total       = $product_unit_price * $product_quantity;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;

                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                } else {
                    $image         = '';
                    $package_aaray = array();
                    $query         = $this->db->query("SELECT package_id,package_name FROM order_products WHERE order_id='$order_id' group by package_id");
                    foreach ($query->result_array() as $row) {

                        $package_id   = $row['package_id'];
                        $package_name = $row['package_name'];

                        $product     = array();
                        $query_proed = $this->db->query("SELECT image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE order_id='$order_id' and package_id = '$package_id'");
                        foreach ($query_proed->result_array() as $row_proed) {
                            $image                 = $row_proed['image'];
                            $product_id            = $row_proed['product_id'];
                            $product_name          = $row_proed['product_name'];
                            $product_unit_price    = $row_proed['product_unit_price'];
                            $product_quantity      = $row_proed['product_quantity'];
                            $product_shipping_cost = $row_proed['product_shipping_cost'];

                            $product_name = str_replace(' ', '-', $product_name);
                            $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                            $product_name = strtolower(str_replace('-', ' ', $product_name));
                            $product_name = ucfirst($product_name);

                            $total       = $product_unit_price * $product_quantity;
                            $grand_total = $total + $product_shipping_cost;
                            $total_amount .= $grand_total;
                            $product[] = array(
                                "product_name" => $product_name,
                                "product_unit_price" => $product_unit_price,
                                "product_quantity" => $product_quantity,
                                "product_total" => $total,
                                "grand_total" => $grand_total
                            );
                        }
                        $package_aaray[] = array(
                            "package_id" => $package_id,
                            "package_name" => $package_name,
                            "product" => $product
                        );
                    }
                }

                $product_total += intval($price_subtotal);
                $product_internet_charges += intval($internet_charges);
                $product_price_shipping += intval($price_shipping);

                $order_data[] = array(
                    "slot_id" => $order_slot,
                    "image" => $image,
                    "order_type" => $order_type,
                    "order_id" => $order_id,
                    "product_id" => $product_id,
                    "product_name" => $product_name,
                    "product_unit_price" => $product_unit_price,
                    "product_quantity" => $product_quantity,
                    "product_shipping_cost" => $product_shipping_cost,
                    "order_status" => $order_status,
                    "total" => $total,
                    "grand_total" => $grand_total,
                    "payment_id" => $payment_id,
                    "payment_method" => $payment_method,
                    "created_at" => $created_at,
                    "grade_name" => $grade_name,
                    "board_name" => $board_name,
                    "order_number" => $order_number,
                    "price_subtotal" => $price_subtotal,
                    "price_shipping" => $price_shipping,
                    "price_total" => $price_total,
                    "internet_charges" => $internet_charges,
                    "student_name" => $student_name,
                    "package_aaray" => $package_aaray,
                    "invoice_no" => $invoice_no,
                    "total_weight" => $total_weight
                );
                $i++;
            }



            $data[] = array(
                "slot_no" => $order_slot,
                "data" => $order_data,
                "vendor" => $vendor
            );

        }


        $get_shipping      = $this->db->query("SELECT name,phone,email,location,address,state,city,pincode,landmark FROM `order_shipping` WHERE order_id='$order_id'")->row_array();
        $shipping_name     = $get_shipping['name'];
        $shipping_phone    = $get_shipping['phone'];
        $shipping_email    = $get_shipping['email'];
        $shipping_location = $get_shipping['location'];
        $shipping_address  = $get_shipping['address'];
        $shipping_state    = $get_shipping['state'];
        $shipping_city     = $get_shipping['city'];
        $shipping_pincode  = $get_shipping['pincode'];
        $shipping_landmark = $get_shipping['landmark'];
        $state_name        = get_state_name($shipping_state);
        $city_name         = get_city_name($shipping_city);

        $get_user   = $this->db->query("SELECT username,email,phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
        $username   = $get_user['username'];
        $user_email = $get_user['email'];
        $user_phone = $get_user['phone_number'];

        $get_vendor_billing = $this->db->query("SELECT pan,gst FROM vendor_billing_details where vendor_id='$user_id' limit 1")->row_array();
        $vendor_pan_no      = $get_vendor_billing['pan'];
        $vendor_gst_no      = $get_vendor_billing['gst'];

        $get_vendor_shipping = $this->db->query("SELECT address,pincode,state_id,city_id FROM vendor_shipping_details where id='$warehouse_id'")->row_array();
        $vendor_address      = $get_vendor_shipping['address'];
        $vendor_pincode      = $get_vendor_shipping['pincode'];
        $vendor_city_name    = get_state_name($get_vendor_shipping['state_id']);
        $vendor_state_name   = get_city_name($get_vendor_shipping['city_id']);


        $address[] = array(
            "shipping_name" => $shipping_name,
            "shipping_phone" => $shipping_phone,
            "shipping_email" => $shipping_email,
            "shipping_location" => $shipping_location,
            "shipping_address" => $shipping_address,
            "shipping_state" => $state_name,
            "shipping_city" => $city_name,
            "shipping_pincode" => $shipping_pincode,
            "shipping_landmark" => $shipping_landmark,
            "vendor_name" => $vendor_name,
            "vendor_pan_no" => $vendor_pan_no,
            "vendor_gst_no" => $vendor_gst_no,
            "vendor_address" => $vendor_address,
            "vendor_pincode" => $vendor_pincode,
            "vendor_city_name" => $vendor_city_name,
            "vendor_state_name" => $vendor_state_name,
            "total_weight" => $final_total_weight
        );


        $resultdata = array(
            'status' => 200,
            'message' => 'Success',
            "address" => $address,
            "data" => $data
        );


        return $resultdata;
    }
    
    public function order_details_by_order_slot_3($order_slot)
    {
        $order_slot_ = $order_slot;
        $data        = array();
        $resultdata  = array();
        $product     = array();
        $order_type_ = $this->auth_model->get_shipping_label_order_type_3($order_slot);

        $query_prod               = $this->db->query("SELECT id,order_slot,order_type,order_number,school_name,grade_name,board_name,price_subtotal,price_shipping,price_total,internet_charges,order_status,warehouse_id,invoice_no,total_weight,s_name,f_name,m_name,buyer_id,payment_method,payment_id,created_at,firm_name,vendor_id FROM orders WHERE order_slot='$order_slot' AND order_status != 'cancelled' AND (process_slot != '' or process_slot IS NOT NULL)");
        // echo $this->db->last_query();
        // $row_prod         = $query_prod->row_array();
        $order_data               = array();
        $vendor                   = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        $final_total_weight       = 0;
        $package_view             = '';
        foreach ($query_prod->result_array() as $row_prod) {
            $order_id         = $row_prod['id'];
            $order_slot       = $row_prod['order_slot'];
            $order_type       = $row_prod['order_type'];
            $order_number     = $row_prod['order_number'];
            $school_name      = $row_prod['school_name'];
            $grade_name       = $row_prod['grade_name'];
            $board_name       = $row_prod['board_name'];
            $price_subtotal   = $row_prod['price_subtotal'];
            $price_shipping   = $row_prod['price_shipping'];
            $price_total      = $row_prod['price_total'];
            $internet_charges = $row_prod['internet_charges'];
            $order_status     = $row_prod['order_status'];
            $warehouse_id     = $row_prod['warehouse_id'];
            $invoice_no       = $row_prod['invoice_no'];
            $total_weight     = $row_prod['total_weight'];
            $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];
            $buyer_id         = $row_prod['buyer_id'];
            $user_id          = $row_prod['buyer_id'];
            $vendor_id        = $row_prod['vendor_id'];
            $payment_method   = $row_prod['payment_method'];
            $payment_id       = $row_prod['payment_id'];
            $created_at       = date("d M Y h:i a", strtotime($row_prod['created_at']));
            $created_at_       = date("d M Y", strtotime($row_prod['created_at']));
            $vendor_name      = $row_prod['firm_name'];
            $total_amount     = 0;

            $total_amount  = 0;
            $package_aaray = array();

            $final_total_weight = $final_total_weight + $total_weight;

            if ($order_type == 'individual') {

                $query = $this->db->query("SELECT id,image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost,model_number FROM order_products WHERE order_id='$order_id'");
                $count = $query->num_rows();
                // $order_data = array();
                foreach ($query->result_array() as $row) {
                    $id                    = $row['id'];
                    $image                 = $row['image'];
                    $product_id            = $row['product_id'];
                    $product_name          = $row['product_name'];
                    $product_unit_price    = $row['product_unit_price'];
                    $product_quantity      = $row['product_quantity'];
                    $product_shipping_cost = $row['product_shipping_cost'];
                    $model_number          = $row['model_number'];

                    /* $product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/

                    $total       = $product_unit_price * $product_quantity;
                    $grand_total = $total + $product_shipping_cost;
                    $total_amount .= $grand_total;

                    $product[] = array(
                        "product_name" => $product_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }
            } else {
                $image         = '';
                $package_aaray = array();
                $package_view  = $this->common_model->get_order_products_packages($order_id);
                $query         = $this->db->query("SELECT package_id,package_name,model_number FROM order_products WHERE order_id='$order_id' group by package_id");
                foreach ($query->result_array() as $row) {

                    $package_id   = $row['package_id'];
                    $package_name = $row['package_name'];


                    $query_proed = $this->db->query("SELECT image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE order_id='$order_id' and package_id = '$package_id'");
                    foreach ($query_proed->result_array() as $row_proed) {
                        $image                 = $row_proed['image'];
                        $product_id            = $row_proed['product_id'];
                        $product_name          = $row_proed['product_name'];
                        $product_unit_price    = $row_proed['product_unit_price'];
                        $product_quantity      = $row_proed['product_quantity'];
                        $product_shipping_cost = $row_proed['product_shipping_cost'];
                        $model_number          = '-';

                        $product_name = str_replace(' ', '-', $product_name);
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_name = strtolower(str_replace('-', ' ', $product_name));
                        $product_name = ucfirst($product_name);

                        $total       = $product_unit_price * $product_quantity;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;
                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                    $package_aaray[] = array(
                        "package_id" => $package_id,
                        "package_name" => $package_name,
                        "product" => $product
                    );
                }
            }

            $product_total += intval($price_subtotal);
            $product_internet_charges += intval($internet_charges);
            $product_price_shipping += intval($price_shipping);

            $order_data[] = array(
                "slot_id" => $order_slot,
                "image" => $image,
                "order_type" => $order_type,
                "order_id" => $order_id,
                "product_id" => $product_id,
                "product_name" => $product_name,
                "product_unit_price" => $product_unit_price,
                "product_quantity" => $product_quantity,
                "product_shipping_cost" => $product_shipping_cost,
                "order_status" => $order_status,
                "total" => $total,
                "grand_total" => $grand_total,
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "created_at" => $created_at,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "order_number" => $order_number,
                "price_subtotal" => $price_subtotal,
                "price_shipping" => $price_shipping,
                "price_total" => $price_total,
                "internet_charges" => $internet_charges,
                "student_name" => $student_name,
                "school_name" => $school_name,
                "invoice_no" => $invoice_no,
                "model_number" => $model_number,
                "total_weight" => $total_weight,
                "package_aaray" => $package_aaray,
                "package_view" => '<p><b>' . $grade_name . '</b></p>' . $package_view
            );
            $i++;
        }



        $data[] = array(
            "slot_no" => $order_slot,
            "data" => $order_data,
            "vendor" => $vendor
        );


        $get_shipping      = $this->db->query("SELECT alternate_phone,flat_house_no,building_name,name,phone,email,location,address,state,city,pincode,landmark FROM `order_shipping` WHERE order_id='$order_id' limit 1")->row_array();
        $shipping_name     = $get_shipping['name'];
        $shipping_phone    = $get_shipping['phone'];
        $shipping_email    = $get_shipping['email'];
        $shipping_location = $get_shipping['location'];
        $shipping_address  = $get_shipping['address'];
        $shipping_state    = $get_shipping['state'];
        $shipping_city     = $get_shipping['city'];
        $shipping_pincode  = $get_shipping['pincode'];
        $shipping_landmark = $get_shipping['landmark'];
        $alternate_phone   = $get_shipping['alternate_phone'];
        $flat_house_no     = $get_shipping['flat_house_no'];
        $building_name     = $get_shipping['building_name'];
        $state_name        = get_state_name($shipping_state);
        $city_name         = get_city_name($shipping_city);

        $get_user   = $this->db->query("SELECT username,email,phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
        $username   = $get_user['username'];
        $user_email = $get_user['email'];
        $user_phone = $get_user['phone_number'];

        $get_vendor_billing = $this->db->query("SELECT pan,gst,address,pincode,state_id,city_id FROM vendor_billing_details where vendor_id='$vendor_id' limit 1")->row_array();
        $vendor_pan_no      = $get_vendor_billing['pan'];
        $vendor_gst_no      = $get_vendor_billing['gst'];

        //$get_vendor_shipping = $this->db->query("SELECT address,pincode,state_id,city_id FROM vendor_shipping_details where id='$warehouse_id'")->row_array();
        $vendor_address    = $get_vendor_billing['address'];
        $vendor_pincode    = $get_vendor_billing['pincode'];
        $vendor_city_name  = get_state_name($get_vendor_billing['state_id']);
        $vendor_state_name = get_city_name($get_vendor_billing['city_id']);


        $get_sch = $this->db->query("SELECT school_name,grade_name FROM orders WHERE order_slot='$order_slot' AND order_status != 'cancelled' AND order_type='bookset' limit 1");
        if ($get_sch->num_rows() > 0) {
            $sch            = $get_sch->row();
            $school_name_   = $sch->school_name;
            $grade_name_    = $sch->grade_name;
            $category_name_ = '';
        } else {
            $school_name_ = '';
            $grade_name_  = '';
        }
        $category_name_ = $this->get_order_category($order_slot);

        $alternate_phone = $get_shipping['alternate_phone'];
        $flat_house_no   = $get_shipping['flat_house_no'];
        $building_name   = $get_shipping['building_name'];

        $address[] = array(
            "shipping_name" => $shipping_name,
            "shipping_phone" => $shipping_phone,
            "shipping_email" => $shipping_email,
            "shipping_location" => $shipping_location,
            "shipping_address" => $shipping_address,
            "shipping_alternate_phone" => $alternate_phone,
            "shipping_flat_house_no" => $flat_house_no,
            "shipping_building_name" => $building_name,
            "shipping_state" => $state_name,
            "shipping_city" => $city_name,
            "shipping_pincode" => $shipping_pincode,
            "shipping_landmark" => $shipping_landmark,
            "vendor_name" => $vendor_name,
            "vendor_pan_no" => $vendor_pan_no,
            "vendor_gst_no" => $vendor_gst_no,
            "vendor_address" => $vendor_address,
            "vendor_pincode" => $vendor_pincode,
            "vendor_city_name" => $vendor_city_name,
            "vendor_state_name" => $vendor_state_name,
            "total_weight" => $final_total_weight,
            "total_weight_1" => gm_to_kg($final_total_weight),
            "school_name" => $school_name_,
            "grade_name" => $grade_name_,
            "category_name" => $category_name_,
            "slot_no" => $order_slot,
            "wow_pincode" => '',
            "order_type" => $order_type_,
            "created_at" => $created_at_
        );


        $resultdata = array(
            'status' => 200,
            'message' => 'Success',
            "address" => $address,
            "data" => $data
        );


        return $resultdata;
    }


    public function order_details_by_order_slot($order_slot)
    {
        $order_slot_ = $order_slot;
        $data        = array();
        $resultdata  = array();
        $product     = array();
        $order_type_ = $this->auth_model->get_shipping_label_order_type($order_slot);

        $query_prod               = $this->db->query("SELECT id,order_slot,order_type,order_number,school_name,grade_name,board_name,price_subtotal,price_shipping,price_total,internet_charges,order_status,warehouse_id,invoice_no,total_weight,s_name,f_name,m_name,buyer_id,payment_method,payment_id,created_at,firm_name,vendor_id,shipment_provider FROM orders WHERE order_slot='$order_slot' AND order_status != 'cancelled' AND (process_slot != '' or process_slot IS NOT NULL)");
        // echo $this->db->last_query();
        // $row_prod         = $query_prod->row_array();
        $order_data               = array();
        $vendor                   = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        $final_total_weight       = 0;
        $package_view             = '';
        foreach ($query_prod->result_array() as $row_prod) {
            $order_id         = $row_prod['id'];
            $order_slot       = $row_prod['order_slot'];
            $order_type       = $row_prod['order_type'];
            $order_number     = $row_prod['order_number'];
            $school_name      = $row_prod['school_name'];
            $grade_name       = $row_prod['grade_name'];
            $board_name       = $row_prod['board_name'];
            $price_subtotal   = $row_prod['price_subtotal'];
            $price_shipping   = $row_prod['price_shipping'];
            $price_total      = $row_prod['price_total'];
            $internet_charges = $row_prod['internet_charges'];
            $order_status     = $row_prod['order_status'];
            $warehouse_id     = $row_prod['warehouse_id'];
            $invoice_no       = $row_prod['invoice_no'];
            $total_weight     = $row_prod['total_weight'];
            $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];
            $buyer_id         = $row_prod['buyer_id'];
            $user_id          = $row_prod['buyer_id'];
            $vendor_id        = $row_prod['vendor_id'];
            $payment_method   = $row_prod['payment_method'];
            $payment_id       = $row_prod['payment_id'];
            $created_at       = date("d M Y h:i a", strtotime($row_prod['created_at']));
            $created_at_      = date("d M Y", strtotime($row_prod['created_at']));
            $vendor_name      = $row_prod['firm_name'];
            $shipment_provider= $row_prod['shipment_provider'];
            $total_amount     = 0;

            $total_amount  = 0;
            $package_aaray = array();

            $final_total_weight = $final_total_weight + $total_weight;

            if ($order_type == 'individual') {

                $query = $this->db->query("SELECT id,image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost,model_number FROM order_products WHERE order_id='$order_id'");
                $count = $query->num_rows();
                // $order_data = array();
                foreach ($query->result_array() as $row) {
                    $id                    = $row['id'];
                    $image                 = $row['image'];
                    $product_id            = $row['product_id'];
                    $product_name          = $row['product_name'];
                    $product_unit_price    = $row['product_unit_price'];
                    $product_quantity      = $row['product_quantity'];
                    $product_shipping_cost = $row['product_shipping_cost'];
                    $model_number          = $row['model_number'];

                    /* $product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/

                    $total       = $product_unit_price * $product_quantity;
                    $grand_total = $total + $product_shipping_cost;
                    $total_amount .= $grand_total;

                    $product[] = array(
                        "product_name" => $product_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }
            } else {
                $image         = '';
                $package_aaray = array();
                $package_view  = $this->common_model->get_order_products_packages($order_id);
                $query         = $this->db->query("SELECT package_id,package_name,model_number FROM order_products WHERE order_id='$order_id' group by package_id");
                foreach ($query->result_array() as $row) {

                    $package_id   = $row['package_id'];
                    $package_name = $row['package_name'];


                    $query_proed = $this->db->query("SELECT image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE order_id='$order_id' and package_id = '$package_id'");
                    foreach ($query_proed->result_array() as $row_proed) {
                        $image                 = $row_proed['image'];
                        $product_id            = $row_proed['product_id'];
                        $product_name          = $row_proed['product_name'];
                        $product_unit_price    = $row_proed['product_unit_price'];
                        $product_quantity      = $row_proed['product_quantity'];
                        $product_shipping_cost = $row_proed['product_shipping_cost'];
                        $model_number          = '-';

                        $product_name = str_replace(' ', '-', $product_name);
                        $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                        $product_name = strtolower(str_replace('-', ' ', $product_name));
                        $product_name = ucfirst($product_name);

                        $total       = $product_unit_price * $product_quantity;
                        $grand_total = $total + $product_shipping_cost;
                        $total_amount .= $grand_total;
                        $product[] = array(
                            "product_name" => $product_name,
                            "product_unit_price" => $product_unit_price,
                            "product_quantity" => $product_quantity,
                            "product_total" => $total,
                            "grand_total" => $grand_total
                        );
                    }
                    $package_aaray[] = array(
                        "package_id" => $package_id,
                        "package_name" => $package_name,
                        "product" => $product
                    );
                }
            }

            $product_total += intval($price_subtotal);
            $product_internet_charges += intval($internet_charges);
            $product_price_shipping += intval($price_shipping);

            $order_data[] = array(
                "slot_id" => $order_slot,
                "image" => $image,
                "order_type" => $order_type,
                "order_id" => $order_id,
                "product_id" => $product_id,
                "product_name" => $product_name,
                "product_unit_price" => $product_unit_price,
                "product_quantity" => $product_quantity,
                "product_shipping_cost" => $product_shipping_cost,
                "order_status" => $order_status,
                "total" => $total,
                "grand_total" => $grand_total,
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "created_at" => $created_at,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "order_number" => $order_number,
                "price_subtotal" => $price_subtotal,
                "price_shipping" => $price_shipping,
                "price_total" => $price_total,
                "internet_charges" => $internet_charges,
                "student_name" => $student_name,
                "school_name" => $school_name,
                "invoice_no" => $invoice_no,
                "model_number" => $model_number,
                "total_weight" => $total_weight,
                "shipment_provider" => $shipment_provider,
                "package_aaray" => $package_aaray,
                "package_view" => '<p><b>' . $grade_name . '</b></p>' . $package_view
            );
            $i++;
        }



        $data[] = array(
            "slot_no" => $order_slot,
            "data" => $order_data,
            "vendor" => $vendor
        );


        $get_shipping      = $this->db->query("SELECT alternate_phone,flat_house_no,building_name,name,phone,email,location,address,state,city,pincode,landmark FROM `order_shipping` WHERE order_id='$order_id'")->row_array();
        $shipping_name     = $get_shipping['name'];
        $shipping_phone    = $get_shipping['phone'];
        $shipping_email    = $get_shipping['email'];
        $shipping_location = $get_shipping['location'];
        $shipping_address  = $get_shipping['address'];
        $shipping_state    = $get_shipping['state'];
        $shipping_city     = $get_shipping['city'];
        $shipping_pincode  = $get_shipping['pincode'];
        $shipping_landmark = $get_shipping['landmark'];
        $alternate_phone   = $get_shipping['alternate_phone'];
        $flat_house_no     = $get_shipping['flat_house_no'];
        $building_name     = $get_shipping['building_name'];
        $state_name        = get_state_name($shipping_state);
        $city_name         = get_city_name($shipping_city);

        $get_user   = $this->db->query("SELECT username,email,phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
        $username   = $get_user['username'];
        $user_email = $get_user['email'];
        $user_phone = $get_user['phone_number'];

        $get_vendor_billing = $this->db->query("SELECT pan,gst,address,pincode,state_id,city_id FROM vendor_billing_details where vendor_id='$vendor_id' limit 1")->row_array();
        $vendor_pan_no      = $get_vendor_billing['pan'];
        $vendor_gst_no      = $get_vendor_billing['gst'];

        //$get_vendor_shipping = $this->db->query("SELECT address,pincode,state_id,city_id FROM vendor_shipping_details where id='$warehouse_id'")->row_array();
        $vendor_address    = $get_vendor_billing['address'];
        $vendor_pincode    = $get_vendor_billing['pincode'];
        $vendor_city_name  = get_state_name($get_vendor_billing['state_id']);
        $vendor_state_name = get_city_name($get_vendor_billing['city_id']);


        $get_sch = $this->db->query("SELECT school_name,grade_name FROM orders WHERE order_slot='$order_slot' AND order_status != 'cancelled' AND order_type='bookset'");
        if ($get_sch->num_rows() > 0) {
            $sch            = $get_sch->row();
            $school_name_   = $sch->school_name;
            $grade_name_    = $sch->grade_name;
            $category_name_ = '';
        } else {
            $school_name_ = '';
            $grade_name_  = '';
        }
        $category_name_ = $this->get_order_category($order_slot);

        $alternate_phone = $get_shipping['alternate_phone'];
        $flat_house_no   = $get_shipping['flat_house_no'];
        $building_name   = $get_shipping['building_name'];
 
		$ord=$this->common_model->getRowById('vendor_shipping_label','shipment_provider,awb_number,slot_no',array('slot_no'=>$order_slot));

		if($ord['shipment_provider']=="self"){				
			$barcode_no = $ord['slot_no'];
		}
		elseif($ord['shipment_provider']=="bigship"){			
			$barcode_no = $ord['awb_number'];
		}
		else{
			$barcode_no = '';
		}

        $address[] = array(
            "shipping_name" => $shipping_name,
            "shipping_phone" => $shipping_phone,
            "shipping_email" => $shipping_email,
            "shipping_location" => $shipping_location,
            "shipping_address" => $shipping_address,
            "shipping_alternate_phone" => $alternate_phone,
            "shipping_flat_house_no" => $flat_house_no,
            "shipping_building_name" => $building_name,
            "shipping_state" => $state_name,
            "shipping_city" => $city_name,
            "shipping_pincode" => $shipping_pincode,
            "shipping_landmark" => $shipping_landmark,
            "vendor_name" => $vendor_name,
            "vendor_pan_no" => $vendor_pan_no,
            "vendor_gst_no" => $vendor_gst_no,
            "vendor_address" => $vendor_address,
            "vendor_pincode" => $vendor_pincode,
            "vendor_city_name" => $vendor_city_name,
            "vendor_state_name" => $vendor_state_name,
            "total_weight" => $final_total_weight,
            "total_weight_1" => gm_to_kg($final_total_weight),
            "school_name" => $school_name_,
            "grade_name" => $grade_name_,
            "category_name" => $category_name_,
            "slot_no" => $order_slot,
            "wow_pincode" => '',
            "order_type" => $order_type_,
            "shipment_provider" => $shipment_provider,
            "barcode_no" => $barcode_no,
            "student_name" => $student_name,
            "created_at" => $created_at_
        );


        $resultdata = array(
            'status' => 200,
            'message' => 'Success',
            "address" => $address,
            "data" => $data
        );


        return $resultdata;
    }

    public function get_order_category($order_slot)
    {
        $arr     = array();
        $tags    = '';
        $get_sch = $this->db->query("SELECT product_id FROM orders WHERE order_type='individual'  AND order_slot='$order_slot' AND order_status != 'cancelled' GROUP BY product_id");
        if ($get_sch->num_rows() > 0) {
            foreach ($get_sch->result_array() as $row) {
                $product_id = $row['product_id'];
                $product    = $this->db->query("SELECT parent_cid FROM products WHERE id='$product_id'")->row();
                $arr[]      = $this->common_model->get_category_name($product->parent_cid);
            }
            $tags = implode(',', array_unique($arr));
        }

        return $tags;

    }


    public function get_orders_details_by_shupping_no($user_id, $order_slot)
    {

        $query           = $this->db->query("SELECT GROUP_CONCAT(complaint_status) as complaint_status,process_slot,order_type,id as order_id,order_number,invoice_no,payment_method,txn_id,order_status,slot_no, warehouse_id, address_id,price_total,created_at,firm_name,courier,processing_date,shipping_date,slot_date,dispatched_date,delivered_date FROM orders WHERE payment_status='payment_received' AND  (order_slot='$order_slot' OR order_number='$order_slot') AND vendor_id='$user_id' group by order_slot");
        // echo $this->db->last_query();
        $count           = $query->num_rows();
        $data            = array();
        $pickup          = array();
        $dropoff         = array();
        $package_details = array();
        $resultpost      = array();

        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $address   = $this->get_order_shipping_2($row['order_id']);
                $warehouse = $this->get_warehouse_details_by_id_2($row['warehouse_id']);
                $route     = $this->get_delivery_routes_by_order($row['order_id']);

                if ($row['complaint_status'] == NULL) {
                    $complaint_status = '';
                } else {
                    $complaint_status = $row['complaint_status'];
                }


                $pickup[] = array(
                    "warehouse_name" => $warehouse['name'],
                    "address" => $warehouse['address'],
                    "state" => $warehouse['state'],
                    "city" => $warehouse['city'],
                    "pincode" => $warehouse['pincode'],
                    "landmark" => $warehouse['landmark'],
                    "lattitude" => $warehouse['lattitude'],
                    "longitude" => $warehouse['longitude'],
                    "contact_number" => $warehouse['contact_number']
                );

                $dropoff[] = array(
                    "name" => $address['name'],
                    "phone" => $address['phone'],
                    "email" => $address['email'],
                    "location" => $address['location'],
                    "address" => $address['address'],
                    "state" => $address['state'],
                    "city" => $address['city'],
                    "pincode" => $address['pincode'],
                    "landmark" => $address['landmark'],
                    "type" => $address['type'],
                    "lattitude" => $address['lattitude'],
                    "longitude" => $address['longitude'],
                    "alternate_phone" => $address['alternate_phone'],
                    "flat_house_no" => $address['flat_house_no'],
                    "building_name" => $address['building_name']
                );


                $logs       = array();
                $query_logs = $this->db->query("SELECT id, order_slot, slot_no, vehicle_name, driver_name, order_status, remark, added_date FROM oc_delivery_order_status_logs WHERE order_slot='$order_slot' AND order_status!='out_for_delivery' ORDER BY id asc");
                if (!empty($query_logs)) {
                    foreach ($query_logs->result_array() as $item) {
                        $logs[] = array(
                            "id" => $item['id'],
                            "order_slot" => $item['order_slot'],
                            "slot_no" => $item['slot_no'],
                            "vehicle_name" => $item['vehicle_name'],
                            "driver_name" => $item['driver_name'],
                            "remark" => $item['remark'],
                            "order_status" => $item['order_status'],
                            "disp_order_status" => get_phrase($item['order_status']),
                            "added_date" => date("d M Y h:i a", strtotime($item['added_date']))
                        );
                    }
                }
                $data[] = array(
                    "order_id" => $row['order_id'],
                    "order_type" => $row['order_type'],
                    "order_number" => $row['order_number'],
                    "invoice_no" => $row['invoice_no'],
                    "payment_method" => $row['payment_method'],
                    "txn_id" => $row['txn_id'],
                    "price_total" => $row['price_total'],
                    "courier" => $row['courier'],
                    "slot_no" => ($row['slot_no'] != NULL ? $row['slot_no'] : '-'),
                    "driver_name" => ($route['driver_name'] != NULL ? $route['driver_name'] : '-'),
                    "vehicle_name" => ($route['vehicle_name'] != NULL ? $route['vehicle_name'] : '-'),
                    "process_slot" => ($row['process_slot'] != NULL ? $row['process_slot'] : '-'),
                    "vendor" => $row['firm_name'],
                    "order_status" => $row['order_status'],
                    "order_date" => date("d M Y | h:i A", strtotime($row['created_at'])),
                    "processing_date" => ($row['processing_date'] != NULL ? date("d M Y | h:i A", strtotime($row['processing_date'])) : '-'),
                    "shipping_date" => ($row['shipping_date'] != NULL ? date("d M Y | h:i A", strtotime($row['shipping_date'])) : '-'),
                    "slot_date" => ($row['slot_date'] != NULL ? date("d M Y | h:i A", strtotime($row['slot_date'])) : '-'),
                    "dispatched_date" => ($row['dispatched_date'] != NULL ? date("d M Y | h:i A", strtotime($row['dispatched_date'])) : '-'),
                    "delivered_date" => ($row['delivered_date'] != NULL ? date("d M Y | h:i A", strtotime($row['delivered_date'])) : '-'),

                    "pickup" => $pickup,
                    "dropoff" => $dropoff,
                    "complaint_status" => $complaint_status,
                    "status_logs" => $logs
                );


                $resultpost = array(
                    'status' => 200,
                    'message' => 'success',
                    'data' => $data
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Not Found'
            );
        }
        return $resultpost;
    }

    public function get_order_shipping_2($id)
    {
        $resultdata = array();
        $query      = $this->db->query("SELECT alternate_phone,flat_house_no,building_name,name,phone,email,location,address,state,city,pincode,landmark,lattitude,longitude,type FROM `order_shipping` WHERE order_id='$id'");
        if (!empty($query)) {
            $item       = $query->row_array();
            $resultdata = array(
                "name" => $item['name'],
                "phone" => $item['phone'],
                "email" => $item['email'],
                "location" => $item['location'],
                "address" => $item['address'],
                "state" => $this->auth_model->get_state_name($item['state']),
                "city" => $this->auth_model->get_city_name($item['city']),
                "pincode" => $item['pincode'],
                "landmark" => $item['landmark'],
                "type" => $item['type'],
                "lattitude" => $item['lattitude'],
                "longitude" => $item['longitude'],
                "alternate_phone" => $item['alternate_phone'],
                "flat_house_no" => $item['flat_house_no'],
                "building_name" => $item['building_name']
            );

        }
        return $resultdata;

    }

    public function get_warehouse_details_by_id_2($id)
    {
        $resultdata = array();
        $query      = $this->db->query("SELECT name,address,state_id,city_id,pincode,landmark,lattitude,longitude,contact_number FROM `vendor_shipping_details` WHERE id='$id' ORDER BY id desc");
        if (!empty($query)) {
            $item       = $query->row_array();
            $resultdata = array(
                "name" => $item['name'],
                "address" => $item['address'],
                "state" => $this->auth_model->get_state_name($item['state_id']),
                "city" => $this->auth_model->get_city_name($item['city_id']),
                "pincode" => $item['pincode'],
                "landmark" => $item['landmark'],
                "lattitude" => $item['lattitude'],
                "longitude" => $item['longitude'],
                "contact_number" => $item['contact_number']
            );

        }
        return $resultdata;

    }

    public function get_delivery_routes_by_order($order_id)
    {
        $query = $this->db->query("SELECT id, delivery_city, slot_no, driver_id,driver_name,vehicle_id,vehicle_name FROM oc_delivery_routes WHERE order_id='$order_id' ORDER BY id desc");
        return $query->row_array();
    }

    public function all_orders_by_school($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter         = '';
        $grade_filter         = "";
        $school_filter        = "";
        $date_filter          = "";
        $academic_year_filter = "";
        $order_status_filter  = "";

        if (!empty($filter['order_status']) && $filter['order_status'] != ""):
            $order_status        = implode(",", $filter['order_status']);
            $order_status_filter = " AND  FIND_IN_SET(order_status, '$order_status')";
        endif;

        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = $filter['school_id'];
            $school_filter = " AND school_id='$school_id'";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            //$academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        $school_id     = $filter['school_id'];

        $rows = $this->db->query("SELECT order_slot FROM orders WHERE (order_type ='bookset') AND (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot   ORDER BY id ASC");

        $query = $this->db->query("SELECT order_slot FROM orders WHERE (order_type ='bookset') AND (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id desc  LIMIT $offset,$per_page");

        $count        = $query->num_rows();
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {

            foreach ($query->result_array() as $row_1) {
                $order_slot = $row_1['order_slot'];

                $query_1      = $this->db->query("SELECT return_status,complaint_status,exchange_id,product_parent_cid,username,price_total,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') AND (order_status != 'applied_for_exchange')  $order_filter ORDER BY id desc");
                $daily_report = array();
                foreach ($query_1->result_array() as $row) {
                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }
                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }

                    $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
                    $pending_since = get_time_difference($date_);

                    $single_slot_no = $this->get_single_order_slot($order_id);
                    $slot_no        = $single_slot_no['order_slot'];

                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "order_status" => $row['order_status'],
                        "username" => $row['username'],
                        "price_total" => $row['price_total'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name
                    );
                }
                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );
            }
        }
        $total_data = $rows->num_rows();

        $school_name = $this->auth_model->get_school_name($school_id);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'school_name' => $school_name.' Orders',
            'data' => $report_data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function all_orders_by_individual($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter         = '';
        $grade_filter         = "";
        $school_filter        = "";
        $date_filter          = "";
        $academic_year_filter = "";
        $order_status_filter  = "";

        if (!empty($filter['order_status']) && $filter['order_status'] != ""):
            $order_status        = implode(",", $filter['order_status']);
            $order_status_filter = " AND  FIND_IN_SET(order_status, '$order_status')";
        endif;

        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = $filter['school_id'];
            $school_filter = " AND school_id='$school_id'";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        $school_id     = $filter['school_id'];

        $rows = $this->db->query("SELECT order_slot FROM orders WHERE (order_type ='individual') AND (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot   ORDER BY id ASC");

        $query = $this->db->query("SELECT order_slot FROM orders WHERE (order_type ='individual') AND (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id desc  LIMIT $offset,$per_page");

        $count        = $query->num_rows();
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {

            foreach ($query->result_array() as $row_1) {
                $order_slot = $row_1['order_slot'];

                $query_1      = $this->db->query("SELECT return_status,complaint_status,exchange_id,product_parent_cid,username,price_total,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') AND (order_status != 'applied_for_exchange')  $order_filter ORDER BY id desc");
                $daily_report = array();
                foreach ($query_1->result_array() as $row) {
                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }
                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }

                    $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
                    $pending_since = get_time_difference($date_);

                    $single_slot_no = $this->get_single_order_slot($order_id);
                    $slot_no        = $single_slot_no['order_slot'];

                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "order_status" => $row['order_status'],
                        "username" => $row['username'],
                        "price_total" => $row['price_total'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name
                    );
                }
                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );
            }
        }
        $total_data = $rows->num_rows();

        $school_name = $this->auth_model->get_school_name($school_id);

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'school_name' => $school_name.' Orders',
            'data' => $report_data,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function all_orders_mobile($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter         = '';
        $grade_filter         = "";
        $school_filter        = "";
        $date_filter          = "";
        $academic_year_filter = "";
        $order_status_filter  = "";

        if (!empty($filter['order_status']) && $filter['order_status'] != ""):
            $order_status        = implode(",", $filter['order_status']);
            $order_status_filter = " AND  FIND_IN_SET(order_status, '$order_status')";
        endif;

        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";

        }

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;


        $rows = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot   ORDER BY id ASC");

        $query = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id desc  LIMIT $offset,$per_page");
        // $query = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange') $order_filter $grade_filter $school_filter $date_filter group by order_slot  ORDER BY id desc LIMIT $offset,$per_page");


        $count        = $query->num_rows();
        /* echo $this->db->last_query();
        exit();*/
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {

            foreach ($query->result_array() as $row_1) {
                $order_slot = $row_1['order_slot'];

                $query_1      = $this->db->query("SELECT return_status,complaint_status,exchange_id,product_parent_cid,username,price_total,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') AND (order_status != 'applied_for_exchange')  $order_filter ORDER BY id desc");
                $daily_report = array();
                foreach ($query_1->result_array() as $row) {

                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }

                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }



                    $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
                    $pending_since = get_time_difference($date_);


                    $single_slot_no = $this->get_single_order_slot($order_id);
                    // echo $this->db->last_query();
                    $slot_no        = $single_slot_no['order_slot'];


                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "order_status" => $row['order_status'],
                        "username" => $row['username'],
                        "price_total" => $row['price_total'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name
                    );

                }

                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );

            }
        }


        $total_data = $rows->num_rows();



        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $daily_report,
            'total_data' => $total_data
        );
        return $resultpost;
    }

    public function all_orders($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter         = '';
        $grade_filter         = "";
        $school_filter        = "";
        $date_filter          = "";
        $academic_year_filter = "";
        $order_status_filter  = "";

        if (!empty($filter['order_status']) && $filter['order_status'] != ""):
            $order_status        = implode(",", $filter['order_status']);
            $order_status_filter = " AND  FIND_IN_SET(order_status, '$order_status')";
        endif;

        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or order_number like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or f_name like '%" . $keyword . "%'
              or m_name like '%" . $keyword . "%'
              or s_name like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";

        }

        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;


        $rows = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id ASC");

        $query = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'applied_for_exchange') $order_status_filter $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot ORDER BY id desc  LIMIT $offset,$per_page");



        $count        = $query->num_rows();
        /* echo $this->db->last_query();
        exit();*/
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {

            foreach ($query->result_array() as $row_1) {
                $order_slot = $row_1['order_slot'];

                $query_1      = $this->db->query("SELECT process_slot,return_status,complaint_status,exchange_id,product_parent_cid,username,price_total,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') AND (order_status != 'applied_for_exchange')  $order_filter ORDER BY id desc");
                $daily_report = array();
                foreach ($query_1->result_array() as $row) {

                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }

                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }



                    $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
                    $pending_since = get_time_difference($date_);


                    $single_slot_no = $this->get_single_order_slot($order_id);
                    // echo $this->db->last_query();
                    $slot_no        = $single_slot_no['order_slot'];


                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "process_slot" => $row['process_slot'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "order_status" => $row['order_status'],
                        "username" => $row['username'],
                        "price_total" => $row['price_total'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name
                    );

                }

                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );

            }
        }


        $total_data = $rows->num_rows();



        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $report_data,
            'total_data' => $total_data
        );
        return $resultpost;
    }





    public function all_proccess_order($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter = '';
        $warehouse_id = $filter['warehouse_id'];
        if ($filter['warehouse_id'] != '') {
            $warehouse_id = $filter['warehouse_id'];
            $order_filter .= "and warehouse_id = '$warehouse_id'";
        }
        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= "and courier_id = '$courier_id'";
        }

        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            $order_filter .= " and ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') ";
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or process_slot like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        $order_by = '';
        if ($filter['order_status'] == 'delivered') {
            $order_by = 'ORDER BY delivered_date DESC';
        } elseif ($filter['order_status'] == 'out_for_delivery') {
            $order_by = 'ORDER BY dispatched_date DESC';
        } else {
            $order_by = 'ORDER BY id desc';
        }



        $rows = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') AND (order_slot!='') AND (payment_status='payment_received') AND process_slot IS NOT NULL $order_filter  group by order_slot  $order_by");

        $query        = $this->db->query("SELECT return_status,complaint_id,complaint_date,complaint_status,exchange_id,product_parent_cid,process_slot,order_slot,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges,shipping_date, dispatched_date, delivered_date FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND process_slot IS NOT NULL AND (order_slot!='') $order_filter $order_by LIMIT $offset,$per_page");
        $count        = $query->num_rows();
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $daily_report = array();
                $shipping     = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);


                if ($row['order_type'] == 'individual') {
                    if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                        $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                    } else {
                        $product_name = $row['product_name'];
                    }

                } else {
                    $product_name = $row['school_name'];
                }

                if ($row['complaint_status'] != NULL) {
                    $product_name = $product_name . ' (Complaint)';
                }

                if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                    $product_name = $product_name . ' (Exchange)';
                }

                $complaint_id = $row['complaint_id'];
                if ($complaint_id != NULL) {
                    $ticket    = $this->db->query("SELECT id,ctype,cat_name,ticket_desc FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                    $ticket_no = '#' . $ticket['ctype'] . sprintf('%04d', $ticket['id']);
                } else {
                    $ticket_no    = '-';
                    $complaint_id = '';
                }



                /*$product_name = str_replace(' ', '-', $product_name);
                $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                $product_name = strtolower(str_replace('-', ' ', $product_name));
                $product_name = ucfirst($product_name);*/

                $date_         = date("Y-m-d H:i:s", strtotime($row['updated_at']));
                $pending_since = get_time_difference($date_);

                $dispatched_date = $row['dispatched_date'];
                if ($dispatched_date != NULL) {
                    $date_out_                = date("Y-m-d H:i:s", strtotime($row['dispatched_date']));
                    $pending_out_for_delivery = get_time_difference($date_out_);
                } else {
                    $pending_out_for_delivery = '';
                }

                $delivered_date = $row['delivered_date'];
                if ($delivered_date != NULL) {
                    $date_delivered_   = date("d M Y h:i a", strtotime($row['delivered_date']));
                    $pending_delivered = $date_delivered_;
                } else {
                    $pending_delivered = '';
                }


                $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                $daily_report[] = array(
                    "id" => $row['id'],
                    "process_slot" => $row['process_slot'],
                    "order_slot_no" => $row['order_slot'],
                    "address_id" => $row['address_id'],
                    "buyer_id" => $row['buyer_id'],
                    "order_type" => $row['order_type'],
                    "order_number" => $row['order_number'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['slot_no'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "city_name" => $shipping->city_name,
                    "pincode" => $shipping->pincode,
                    "order_status" => $row['order_status'],
                    "created_at" => $created_at,
                    "pending_since" => $pending_since,
                    "pending_out" => $pending_out_for_delivery,
                    "pending_delivered" => $pending_delivered,
                    "product_name" => $product_name,
                    "ticket_no" => $ticket_no,
                    "complaint_id" => $complaint_id
                );




                $report_data[] = array(
                    "process_slot" => $row['process_slot'],
                    "order_slot_no" => $row['order_slot'],
                    "list" => $daily_report
                );

            }
        }


        $order_status = $filter['order_status'];

        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset'  AND process_slot IS NOT NULL  ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' AND process_slot IS NOT NULL   ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '1' AND (order_slot!='') AND process_slot IS NOT NULL group by order_slot ORDER BY id  ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '2' AND (order_slot!='') AND process_slot IS NOT NULL group by order_slot ORDER BY id ASC")->num_rows();

        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $report_data,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'total_data' => $total_data
        );
        return $resultpost;
    }



    public function exchange_pending_slot_order($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";


        $warehouse_id = $filter['warehouse_id'];
        /*        if ($filter['warehouse_id'] != '') {
        $warehouse_id = $filter['warehouse_id'];
        $order_filter .= "and warehouse_id = '$warehouse_id'";
        }*/
        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= " and courier_id = '$courier_id'";
        }

        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            $order_filter .= " and (order_status = '$order_status')";
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }


        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
		
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;


        //$rows = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) $order_filter $grade_filter $school_filter $date_filter group by order_slot   ORDER BY id ASC");

        //$query        = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) $order_filter $grade_filter $school_filter $date_filter group by order_slot  ORDER BY id desc LIMIT $offset,$per_page");
        $query = $this->db->query("SELECT order_slot FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id desc");

        $count        = $query->num_rows();
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {

            foreach ($query->result_array() as $row_1) {

                $order_slot = $row_1['order_slot'];

                $query_1 = $this->db->query("SELECT return_status,complaint_status,exchange_id,product_parent_cid,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') $order_filter ORDER BY id desc");
                //$daily_report = array();
                foreach ($query_1->result_array() as $row) {

                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }

                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }



                    /*                    $product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/


                    $date_         = date("Y-m-d H:i:s", strtotime($row['created_at']));
                    $pending_since = get_time_difference($date_);



                    $single_slot_no = $this->get_single_order_slot($order_id);
                    // echo $this->db->last_query();
                    $slot_no        = $single_slot_no['order_slot'];



                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "warehouse_name" => $shipping->name,
                        "warehouse_id" => $shipping->id,
                        "order_status" => $row['order_status'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name
                    );

                }

                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );

            }
        }


        $order_status = $filter['order_status'];

        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset' $academic_year_filter    ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (order_status ='$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' $academic_year_filter    ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (order_status ='$order_status') and courier_id = '1' $academic_year_filter ORDER BY id ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (order_status ='$order_status') and courier_id = '2' $academic_year_filter ORDER BY id ASC")->num_rows();

        //$total_data = $rows->num_rows();

        $total_data = count($daily_report);


        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'data' => $daily_report,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count
        );
        return $resultpost;
    }



    public function get_exchange_product_details($order_id_revised)
    {
        $product         = array();
        $total           = 0;
        $subtotal        = 0;
        $delivery_chager = 0;

        $query_check = $this->db->query("SELECT order_id_revised FROM orders WHERE  id='$order_id_revised' LIMIT 1");
        if ($query_check->num_rows() > 0) {
            $grow              = $query_check->row_array();
            $order_id_revised2 = $grow['order_id_revised'];
        } else {
            $order_id_revised2 = 0;
        }


        if ($order_id_revised2 != '0') {
            $query_prod = $this->db->query("SELECT id,order_id_revised,exchange_status,size_id,order_type,product_quantity,order_number,product_name,school_name,grade_name,board_name,order_status,reason,not_delivered_date,order_status,price_total,price_subtotal,price_discount,price_shipping,shipping_date,dispatched_date,delivered_date,s_name,f_name,m_name,created_at,username,firm_name FROM orders WHERE  (id='$order_id_revised' OR id='$order_id_revised2') order by id desc");
        } else {
            $query_prod = $this->db->query("SELECT id,order_id_revised,exchange_status,size_id,order_type,product_quantity,order_number,product_name,school_name,grade_name,board_name,order_status,reason,not_delivered_date,order_status,price_total,price_subtotal,price_discount,price_shipping,shipping_date,dispatched_date,delivered_date,s_name,f_name,m_name,created_at,username,firm_name FROM orders WHERE  id='$order_id_revised' LIMIT 1");

        }
        if ($query_prod->num_rows() > 0) {
            foreach ($query_prod->result_array() as $row_prod) {
                $order_id             = $row_prod['id'];
                $order_type           = $row_prod['order_type'];
                $product_quantity     = $row_prod['product_quantity'];
                $order_number         = $row_prod['order_number'];
                $product_name         = $row_prod['product_name'];
                $school_name          = $row_prod['school_name'];
                $grade_name           = $row_prod['grade_name'];
                $board_name           = $row_prod['board_name'];
                $order_status         = $row_prod['order_status'];
                $not_delivered_reason = $row_prod['reason'];
                $not_delivered_date   = date("d M Y h:i a", strtotime($row_prod['not_delivered_date']));
                $order_status         = $row_prod['order_status'];
                $price_total          = $row_prod['price_total'];
                $price_subtotal       = $row_prod['price_subtotal'];
                $price_discount       = $row_prod['price_discount'];
                $price_shipping       = $row_prod['price_shipping'];
                $shipping_date        = date("d M Y h:i a", strtotime($row_prod['shipping_date']));
                $dispatched_date      = date("d M Y h:i a", strtotime($row_prod['dispatched_date']));
                $delivered_date       = date("d M Y h:i a", strtotime($row_prod['delivered_date']));
                $student_name         = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];


                $created_at    = date("d M Y h:i a", strtotime($row_prod['created_at']));
                $username      = $row_prod['username'];
                $firm_name     = $row_prod['firm_name'];
                $package_aaray = array();

                $query2 = $this->db->query("SELECT image from order_products WHERE order_id='$order_id' group by order_id");
                $row2   = $query2->row_array();
                $image  = $row2['image'];

                if ($order_type == 'bookset') {
                    if ($row2['image'] == '' || $row2['image'] == 'null') {
                        $image = vendor_url() . 'uploads/default-school.jpg';
                    } else {
                        $image = vendor_url() . $row2['image'];
                    }
                }
                if ($order_type == 'individual') {
                    if ($row2['image'] == '' || $row2['image'] == 'null') {
                        $image = vendor_url() . 'uploads/products/default-img.jpg';
                    } else {
                        $image = $row2['image'];
                    }
                }


                $size_id    = $row_prod['size_id'];
                $size_name  = '';
                $size_query = $this->db->query("SELECT name FROM size where id='$size_id' LIMIT 1");
                if ($size_query->num_rows() > 0) {
                    $get_size  = $size_query->row_array();
                    $size_name = $get_size['name'];
                }

                $order_status = 'Applied for exchange';
                $refund_text  = 'Applied for exchange';
                $refund_value = 'Applied for exchange';


                $product[] = array(
                    "id" => $order_id,
                    "image" => $image,
                    "order_type" => $order_type,
                    "order_id" => $order_id,
                    "product_name" => $product_name,
                    "product_quantity" => $product_quantity,
                    "order_status" => $order_status,
                    "not_delivered_reason" => $not_delivered_reason,
                    "not_delivered_date" => $not_delivered_date,
                    "created_at" => $created_at,
                    "shipping_date" => $shipping_date,
                    "dispatched_date" => $dispatched_date,
                    "delivered_date" => $delivered_date,
                    "firm_name" => $firm_name,
                    "school_name" => $school_name,
                    "grade_name" => $grade_name,
                    "board_name" => $board_name,
                    "order_number" => $order_number,
                    "price_total" => $price_total,
                    "price_subtotal" => $price_subtotal - $price_discount,
                    "student_name" => $student_name,
                    "size_id" => $size_id,
                    "size_name" => $size_name,
                    "total" => $price_total,
                    "refund_text" => $refund_text,
                    "refund_value" => $refund_value
                );

            }
        }
        return $product;

    }




    public function back_to_pending_order($user_id, $order_array, $order_status)
    {
        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND  ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        if ($check_ws->num_rows() == count($order_array)) {
            if (count($order_array) > 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    // $order_arr[]   = $order_list['order_id'];
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id,complaint_id  FROM orders  WHERE vendor_id='$user_id'  AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') AND order_slot = '$or_id'");
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = array(
                            "id" => $row['id'],
                            "complaint_id" => $row['complaint_id']
                        );
                    }

                }


                if ($order_status == 'pending') {
                    foreach ($order_arr as $item) {
                        if ($this->auth_model->check_order_complaints($item['id']) > 0) {
                            $data_order = array(
                                'complaint_status' => $order_status,
                                'process_slot' => NULL,
                                'updated_at' => $updated_date
                            );

                        } else {
                            $data_order = array(
                                'order_status' => $order_status,
                                'process_slot' => NULL,
                                'updated_at' => $updated_date
                            );
                        }
                        $this->db->where('id', $item['id']);
                        $update = $this->db->update('orders', $data_order);
                    }

                    $resultpost = array(
                        'status' => 200,
                        'message' => 'success'
                    );

                } else {
                    $resultpost = array(
                        'status' => 400,
                        'message' => 'Error! order must be in process status'
                    );
                }


            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'error'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Processing Status..'
            );
        }
        return $resultpost;
    }




    public function all_complaints_pending_order($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";


        $warehouse_id = $filter['warehouse_id'];
        /*        if ($filter['warehouse_id'] != '') {
        $warehouse_id = $filter['warehouse_id'];
        $order_filter .= "and warehouse_id = '$warehouse_id'";
        }*/
        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= "and courier_id = '$courier_id'";
        }

        /*        if ($filter['order_status'] != '') {
        $order_status = $filter['order_status'];
        $order_filter .= "and order_status = '$order_status'";
        }
        */
        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }


        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;

        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
		
		$academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;

        $rows  = $this->db->query("SELECT order_slot,complaint_id FROM orders WHERE (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND complaint_status='pending' $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot   ORDER BY id ASC");
        $query = $this->db->query("SELECT order_slot,complaint_id FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND complaint_status='pending' $order_filter $grade_filter $school_filter $date_filter $academic_year_filter group by order_slot  ORDER BY id desc");  

        /* echo $this->db->last_query();
        exit();*/
        $count        = $query->num_rows();
        $daily_report = array();
        $report_data  = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row_1) {

                $order_slot = $row_1['order_slot'];

                $query_1 = $this->db->query("SELECT return_status,complaint_id,complaint_status,complaint_date,product_parent_cid,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges FROM orders WHERE (vendor_id = '$vendor_id') AND (order_slot = '$order_slot') AND (payment_status='payment_received') AND complaint_status='pending'  $order_filter ORDER BY id desc");
                //$daily_report = array();

                foreach ($query_1->result_array() as $row) {

                    $complaint_id = $row['complaint_id'];
                    if ($complaint_id != NULL) {
                        $ticket    = $this->db->query("SELECT id,ctype,cat_name,ticket_desc FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                        $ticket_no = '#' . $ticket['ctype'] . sprintf('%04d', $ticket['id']);
                    } else {
                        $ticket_no    = '-';
                        $complaint_id = '';
                    }


                    $shipping   = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                    $order_type = $row['order_type'];
                    $address_id = $row['address_id'];
                    $order_id   = $row['id'];

                    if ($order_type == 'individual') {
                        if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                            $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                        } else {
                            $product_name = $row['product_name'];
                        }

                    } else {
                        $product_name = $row['school_name'];
                    }

                    if ($row['complaint_status'] != NULL) {
                        $product_name = $product_name . ' (Complaint)';
                    }

                    if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                        $product_name = $product_name . ' (Exchange)';
                    }



                    /*$product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/


                    $date_         = date("Y-m-d H:i:s", strtotime($row['complaint_date']));
                    $pending_since = get_time_difference($date_);



                    $single_slot_no = $this->get_single_order_slot($order_id);
                    // echo $this->db->last_query();
                    $slot_no        = $single_slot_no['order_slot'];



                    $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                    $daily_report[] = array(
                        "id" => $row['id'],
                        "address_id" => $address_id,
                        "order_slot_no" => $slot_no,
                        "buyer_id" => $row['buyer_id'],
                        "order_type" => ucfirst($row['order_type']),
                        "order_number" => $row['order_number'],
                        "invoice_no" => $row['invoice_no'],
                        "slot_no" => $row['slot_no'],
                        "courier" => $row['courier'],
                        "school_name" => $row['school_name'],
                        "grade_name" => $row['grade_name'],
                        "board_name" => $row['board_name'],
                        "city_name" => $shipping->city_name,
                        "pincode" => $shipping->pincode,
                        "warehouse_name" => $shipping->name,
                        "order_status" => $row['order_status'],
                        "created_at" => $created_at,
                        "pending_since" => $pending_since,
                        "product_name" => $product_name,
                        "complaint_remark" => $ticket['cat_name'] . '-' . $ticket['ticket_desc'],
                        "ticket_no" => $ticket_no,
                        "complaint_id" => $complaint_id
                    );

                }

                $report_data[] = array(
                    "order_slot_no" => $order_slot,
                    "list" => $daily_report
                );

            }
        }









        $order_status = $filter['order_status'];

        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (complaint_status='pending')  and courier_id = '$courier_id' and order_type = 'bookset' $academic_year_filter ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (complaint_status='pending')  and courier_id = '$courier_id' and order_type = 'individual' $academic_year_filter ORDER BY id ASC")->num_rows();

        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (complaint_status='pending') and courier_id = '1' AND (order_slot!='' or order_slot IS NOT NULL) $academic_year_filter  group by order_slot ORDER BY id ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND (complaint_status='pending')  and courier_id = '2' AND (order_slot!='' or order_slot IS NOT NULL) $academic_year_filter  group by order_slot ORDER BY id ASC")->num_rows();

        $total_data = $rows->num_rows();




        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $daily_report,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count,
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'total_data' => $total_data
        );
        return $resultpost;
    }


    public function complaints_pending_to_process_order($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        $order_slot   = '';

        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND complaint_status='pending' AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            $order_arr = array();
            foreach ($order_array as $order_list) {
                $or_id = $order_list;
                $query = $this->db->query("SELECT id,complaint_id FROM orders  WHERE order_slot = '$or_id' AND complaint_status='pending'");
                $i     = 0;
                foreach ($query->result_array() as $row) {
                    $order_arr[] = array(
                        "id" => $row['id'],
                        "complaint_id" => $row['complaint_id']
                    );

                    if ($i == 0) {
                        $order_slot = $row['id'] . '_' . token_8_digit();
                    }
                    $i++;
                }
            }

            foreach ($order_arr as $item) {
                $data_order = array(
                    'process_slot' => $order_slot,
                    'complaint_status' => 'processing',
                    'updated_at' => $updated_date
                );


                $this->db->where('id', $item['id']);
                $update = $this->db->update('orders', $data_order);


                $data_comp_order = array(
                    'processing_date' => $updated_date
                );
                $this->db->where('id', $item['complaint_id']);
                $this->db->where('order_id', $item['id']);
                $update = $this->db->update('oc_tickets', $data_comp_order);

            }

            //shipping label
            foreach ($order_array as $slot_no) {
                $check = $this->db->query("SELECT id,label_url FROM vendor_shipping_label  WHERE slot_no = '$slot_no' LIMIT 1");
                if ($check->num_rows() == 0) {
                    $sql       = $this->db->query("SELECT vendor_id FROM orders  WHERE order_slot = '$slot_no' LIMIT 1");
                    $item      = $sql->row_array();
                    $data_slot = array(
                        'vendor_id' => $item['vendor_id'],
                        'process_slot' => $order_slot,
                        'slot_no' => $slot_no,
                        'ctype' => 'process',
                        'created_at' => $updated_date
                    );
                    $insert    = $this->db->insert('vendor_shipping_label', $data_slot);
                } else {
                    $item      = $check->row_array();
                    $label_url = $item['label_url'];

                    $data_slot = array(
                        'process_slot' => $order_slot,
                        'label_url' => NULL,
                        'old_label_url' => $label_url
                    );
                    $this->db->where('slot_no', $slot_no);
                    $update = $this->db->update('vendor_shipping_label', $data_slot);
                }

                //start logs
                $order_status_log = array();
                $order_status_log = array(
                    'order_status' => 'complaint_processing',
                    'order_slot' => $slot_no,
                    'slot_no' => '',
                    'vehicle_name' => '',
                    'driver_name' => '',
                    'remark' => '',
                    'added_date' => date("Y-m-d H:i:s")
                );
                $this->db->insert('oc_delivery_order_status_logs', $order_status_log);
                //end logs

            }

            //shipping label





            $resultpost = array(
                'status' => 200,
                'message' => 'success'
            );

        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Complaint Orders must be in Pending Status'
            );
        }
        return $resultpost;
    }



    public function complaints_order_details_by_order_slot($order_slot)
    {
        $order_slot_ = $order_slot;
        $data        = array();
        $resultdata  = array();
        $product     = array();
        $order_type_ = $this->auth_model->get_shipping_label_order_type($order_slot);

        $query_prod               = $this->db->query("SELECT id,complaint_id,order_slot,order_type,order_number,school_name,grade_name,board_name,price_subtotal,price_shipping,price_total,internet_charges,order_status,warehouse_id,invoice_no,total_weight,s_name,f_name,m_name,buyer_id,payment_method,payment_id,created_at,firm_name,vendor_id,shipment_provider FROM orders WHERE order_slot='$order_slot' AND order_status != 'cancelled' AND (process_slot != '' or process_slot IS NOT NULL)  AND complaint_status IS NOT NULL");
        // echo $this->db->last_query();
        // $row_prod         = $query_prod->row_array();
        $order_data               = array();
        $vendor                   = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        $final_total_weight       = 0;
        $package_view             = '';
        foreach ($query_prod->result_array() as $row_prod) {
            $order_id         = $row_prod['id'];
            $order_slot       = $row_prod['order_slot'];
            $order_type       = $row_prod['order_type'];
            $order_number     = $row_prod['order_number'];
            $school_name      = $row_prod['school_name'];
            $grade_name       = $row_prod['grade_name'];
            $board_name       = $row_prod['board_name'];
            $price_subtotal   = $row_prod['price_subtotal'];
            $price_shipping   = $row_prod['price_shipping'];
            $price_total      = $row_prod['price_total'];
            $internet_charges = $row_prod['internet_charges'];
            $order_status     = $row_prod['order_status'];
            $warehouse_id     = $row_prod['warehouse_id'];
            $invoice_no       = $row_prod['invoice_no'];
            $total_weight     = $row_prod['total_weight'];
            $student_name     = $row_prod['s_name'] . ' ' . $row_prod['f_name'] . ' ' . $row_prod['m_name'];
            $buyer_id         = $row_prod['buyer_id'];
            $user_id          = $row_prod['buyer_id'];
            $vendor_id        = $row_prod['vendor_id'];
            $payment_method   = $row_prod['payment_method'];
            $payment_id       = $row_prod['payment_id'];
            $created_at       = date("d M Y h:i a", strtotime($row_prod['created_at']));
            $vendor_name      = $row_prod['firm_name'];
            $shipment_provider= $row_prod['shipment_provider'];
            $total_amount     = 0;

            $total_amount  = 0;
            $package_aaray = array();

            $final_total_weight = $final_total_weight + $total_weight;

            //complaints


            $complaint_id         = $row_prod['complaint_id'];
            $sqlz                 = $this->db->query("SELECT product_id FROM oc_tickets where id='$complaint_id' order by id desc LIMIT 1");
            $gcomp                = $sqlz->row_array();
            $complaint_product_id = $gcomp['product_id'];

            if ($order_type == 'individual') {

                $query = $this->db->query("SELECT id,image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost,model_number FROM order_products WHERE order_id='$order_id' AND product_id='$complaint_product_id'");
                $count = $query->num_rows();
                // $order_data = array();
                foreach ($query->result_array() as $row) {
                    $id                    = $row['id'];
                    $image                 = $row['image'];
                    $product_id            = $row['product_id'];
                    $product_name          = $row['product_name'];
                    $product_unit_price    = $row['product_unit_price'];
                    $product_quantity      = $row['product_quantity'];
                    $product_shipping_cost = $row['product_shipping_cost'];
                    $model_number          = $row['model_number'];

                    /* $product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);*/

                    $total        = $product_unit_price * $product_quantity;
                    $grand_total  = $total + $product_shipping_cost;
                    $total_amount = $total_amount + $grand_total;

                    $product[] = array(
                        "product_name" => $product_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }
            } else {
                $image         = '';
                $package_aaray = array();
                $package_view  = $this->common_model->get_complaints_order_products_packages($order_id, $complaint_product_id);

                $query_proed = $this->db->query("SELECT image,product_id,product_name,product_unit_price,product_quantity,product_shipping_cost FROM order_products WHERE order_id='$order_id' AND (FIND_IN_SET(id,'$complaint_product_id')) ");
                foreach ($query_proed->result_array() as $row_proed) {
                    $image                 = $row_proed['image'];
                    $product_id            = $row_proed['product_id'];
                    $product_name          = $row_proed['product_name'];
                    $product_unit_price    = $row_proed['product_unit_price'];
                    $product_quantity      = $row_proed['product_quantity'];
                    $product_shipping_cost = $row_proed['product_shipping_cost'];
                    $model_number          = '-';

                    $product_name = str_replace(' ', '-', $product_name);
                    $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                    $product_name = strtolower(str_replace('-', ' ', $product_name));
                    $product_name = ucfirst($product_name);

                    $total        = $product_unit_price * $product_quantity;
                    $grand_total  = $total + $product_shipping_cost;
                    $total_amount = $total_amount + $grand_total;
                    $product[]    = array(
                        "product_name" => $product_name,
                        "product_unit_price" => $product_unit_price,
                        "product_quantity" => $product_quantity,
                        "product_total" => $total,
                        "grand_total" => $grand_total
                    );
                }


            }

            $product_total += intval($price_subtotal);
            $product_internet_charges += intval($internet_charges);
            $product_price_shipping += intval($price_shipping);

            $order_data[] = array(
                "slot_id" => $order_slot,
                "image" => $image,
                "order_type" => $order_type,
                "order_id" => $order_id,
                "product_id" => $product_id,
                "product_name" => $product_name,
                "product_unit_price" => $product_unit_price,
                "product_quantity" => $product_quantity,
                "product_shipping_cost" => $product_shipping_cost,
                "order_status" => $order_status,
                "total" => $total,
                "grand_total" => $grand_total,
                "payment_id" => $payment_id,
                "payment_method" => $payment_method,
                "created_at" => $created_at,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "order_number" => $order_number,
                "price_subtotal" => $price_subtotal,
                "price_shipping" => $price_shipping,
                "price_total" => $total_amount,
                "internet_charges" => $internet_charges,
                "student_name" => $student_name,
                "school_name" => $school_name,
                "invoice_no" => $invoice_no,
                "model_number" => $model_number,
                "total_weight" => $total_weight,
                "shipment_provider" => $shipment_provider,
                "package_aaray" => $package_aaray,
                "package_view" => '<p><b>' . $grade_name . '</b></p>' . $package_view
            );
            $i++;
        }



        $data[] = array(
            "slot_no" => $order_slot,
            "data" => $order_data,
            "vendor" => $vendor
        );


        $get_shipping      = $this->db->query("SELECT alternate_phone,flat_house_no,building_name,name,phone,email,location,address,state,city,pincode,landmark FROM `order_shipping` WHERE order_id='$order_id'")->row_array();
        $shipping_name     = $get_shipping['name'];
        $shipping_phone    = $get_shipping['phone'];
        $shipping_email    = $get_shipping['email'];
        $shipping_location = $get_shipping['location'];
        $shipping_address  = $get_shipping['address'];
        $shipping_state    = $get_shipping['state'];
        $shipping_city     = $get_shipping['city'];
        $shipping_pincode  = $get_shipping['pincode'];
        $shipping_landmark = $get_shipping['landmark'];
        $alternate_phone   = $get_shipping['alternate_phone'];
        $flat_house_no     = $get_shipping['flat_house_no'];
        $building_name     = $get_shipping['building_name'];
        $state_name        = get_state_name($shipping_state);
        $city_name         = get_city_name($shipping_city);

        $get_user   = $this->db->query("SELECT username,email,phone_number FROM users where users.id='$buyer_id' limit 1")->row_array();
        $username   = $get_user['username'];
        $user_email = $get_user['email'];
        $user_phone = $get_user['phone_number'];

        $get_vendor_billing = $this->db->query("SELECT pan,gst,address,pincode,state_id,city_id FROM vendor_billing_details where vendor_id='$vendor_id' limit 1")->row_array();
        $vendor_pan_no      = $get_vendor_billing['pan'];
        $vendor_gst_no      = $get_vendor_billing['gst'];

        //$get_vendor_shipping = $this->db->query("SELECT address,pincode,state_id,city_id FROM vendor_shipping_details where id='$warehouse_id'")->row_array();
        $vendor_address    = $get_vendor_billing['address'];
        $vendor_pincode    = $get_vendor_billing['pincode'];
        $vendor_city_name  = get_state_name($get_vendor_billing['state_id']);
        $vendor_state_name = get_city_name($get_vendor_billing['city_id']);


        $get_sch = $this->db->query("SELECT school_name,grade_name FROM orders WHERE order_slot='$order_slot' AND order_status != 'cancelled' AND order_type='bookset'");
        if ($get_sch->num_rows() > 0) {
            $sch            = $get_sch->row();
            $school_name_   = $sch->school_name;
            $grade_name_    = $sch->grade_name;
            $category_name_ = '';
        } else {
            $school_name_ = '';
            $grade_name_  = '';
        }
        $category_name_ = $this->get_order_category($order_slot);

        $alternate_phone = $get_shipping['alternate_phone'];
        $flat_house_no   = $get_shipping['flat_house_no'];
        $building_name   = $get_shipping['building_name'];	

		$ord=$this->common_model->getRowById('vendor_shipping_label','shipment_provider,awb_number,slot_no',array('slot_no'=>$order_slot));

		if($ord['shipment_provider']=="self"){				
			$barcode_no = $ord['slot_no'];
		}
		elseif($ord['shipment_provider']=="bigship"){			
			$barcode_no = $ord['awb_number'];
		}
		else{
			$barcode_no = '';
		}

        $address[] = array(
            "shipping_name" => $shipping_name,
            "shipping_phone" => $shipping_phone,
            "shipping_email" => $shipping_email,
            "shipping_location" => $shipping_location,
            "shipping_address" => $shipping_address,
            "shipping_alternate_phone" => $alternate_phone,
            "shipping_flat_house_no" => $flat_house_no,
            "shipping_building_name" => $building_name,
            "shipping_state" => $state_name,
            "shipping_city" => $city_name,
            "shipping_pincode" => $shipping_pincode,
            "shipping_landmark" => $shipping_landmark,
            "vendor_name" => $vendor_name,
            "vendor_pan_no" => $vendor_pan_no,
            "vendor_gst_no" => $vendor_gst_no,
            "vendor_address" => $vendor_address,
            "vendor_pincode" => $vendor_pincode,
            "vendor_city_name" => $vendor_city_name,
            "vendor_state_name" => $vendor_state_name,
            "total_weight" => $final_total_weight,
            "total_weight_1" => gm_to_kg($final_total_weight),
            "school_name" => $school_name_,
            "grade_name" => $grade_name_,
            "category_name" => $category_name_,
            "slot_no" => $order_slot,
            "wow_pincode" => '',
            "order_type" => $order_type_,
            "shipment_provider" => $shipment_provider,
            "barcode_no" => $barcode_no,
            "student_name" => $student_name,
        );


        $resultdata = array(
            'status' => 200,
            'message' => 'Success',
            "address" => $address,
            "data" => $data
        );


        return $resultdata;
    }




    public function back_to_process_order($user_id, $order_array, $order_status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');


        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND  ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            if (count($order_array) > 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id FROM orders  WHERE vendor_id='$user_id' AND ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') AND order_slot = '$or_id'");
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = $row['id'];
                    }

                }


                if ($order_status == 'processing') {
                    if (!empty($order_arr)) {
                        foreach ($order_arr as $order_id) {
                            if ($this->auth_model->check_order_complaints($order_id) > 0) {
                                $data_order = array(
                                    'complaint_status' => $order_status,
                                    'updated_at' => $updated_date
                                );
                            } else {
                                $data_order = array(
                                    'order_status' => $order_status,
                                    'updated_at' => $updated_date
                                );
                            }
                            $this->db->where('id', $order_id);
                            $update = $this->db->update('orders', $data_order);
                        }

                        $resultpost = array(
                            'status' => 200,
                            'message' => 'success'
                        );
                    } else {
                        $resultpost = array(
                            'status' => 400,
                            'message' => 'Error! Order must be in shipment status..'
                        );
                    }

                } else {
                    $resultpost = array(
                        'status' => 400,
                        'message' => 'Error! Order must be in shipment status.'
                    );
                }


            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'error'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Ready For Shipment Status'
            );
        }
        return $resultpost;
    }




    public function all_shipping_bills_details($vendor_id, $id)
    {
        $order_slot_ = $order_slot;
        $data        = array();
        $resultdata  = array();
        $product     = array();

        $query_prod = $this->db->query("SELECT id,order_slot FROM orders WHERE  (vendor_id ='$vendor_id') AND (payment_status='payment_received') AND (process_slot='$id') AND (process_slot != '' or process_slot IS NOT NULL) AND ((order_status = 'processing' AND complaint_status IS NULL) OR complaint_status = 'processing') GROUP BY order_slot LIMIT 150");

        $order_data               = array();
        $vendor                   = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        $final_total_weight       = 0;
        $package_view             = '';
        foreach ($query_prod->result_array() as $row_prod) {
            $order_data = array();
            $address    = array();

            $order_type_ = $this->auth_model->get_shipping_label_order_type($row_prod['order_slot']);
            if ($order_type_ == 'Complaints') {
                $response = $this->order_model->complaints_order_details_by_order_slot($row_prod['order_slot']);
            } else {
                $response = $this->order_model->order_details_by_order_slot($row_prod['order_slot']);
            }


            $order_data = $response['data'][0]['data'];
            $address    = $response['address'];

            $data[] = array(
                "slot_no" => $row_prod['order_slot'],
                "data" => $order_data,
                "address" => $address
            );
        }

        $resultdata = $data;

        return $resultdata;
    }



    public function all_shipped_shipping_bills_details($vendor_id, $warehouse_id, $courier_id) {
        $order_slot_ = $order_slot;
        $data        = array();
        $resultdata  = array();
        $product     = array();

        $query_prod = $this->db->query("SELECT id,order_slot FROM orders WHERE  (vendor_id='$vendor_id' AND warehouse_id='$warehouse_id' AND courier_id='$courier_id') AND (payment_status='payment_received')  AND ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') AND (order_slot!='') GROUP BY order_slot LIMIT 150");

        $order_data               = array();
        $vendor                   = array();
        $i                        = 0;
        $product_total            = 0;
        $price_subtotal           = 0;
        $product_internet_charges = 0;
        $product_price_shipping   = 0;
        $final_amount             = 0;
        $final_total_weight       = 0;
        $package_view             = '';
        foreach ($query_prod->result_array() as $row_prod) {
            $order_data = array();
            $address    = array();

            $order_type_ = $this->auth_model->get_shipping_label_order_type($row_prod['order_slot']);
            if ($order_type_ == 'Complaints') {
                $response = $this->order_model->complaints_order_details_by_order_slot($row_prod['order_slot']);
            } else {
                $response = $this->order_model->order_details_by_order_slot($row_prod['order_slot']);
            }


            $order_data = $response['data'][0]['data'];
            $address    = $response['address'];

            $data[] = array(
                "slot_no" => $row_prod['order_slot'],
                "data" => $order_data,
                "address" => $address
            );
        }

        $resultdata = $data;

        return $resultdata;
    }


    public function return_order_list($vendor_id, $per_page, $offset, $filter)
    {
        $order_filter = '';
        $courier_id   = $filter['courier_id'];


        if ($courier_id == '1') {
            $order_filter .= "and status = 'returned'";
        } else {
            $order_filter .= "and status = 'pending'";
        }


        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_type like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or order_number like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or return_status like '%" . $keyword . "%'
              or driver_name like '%" . $keyword . "%'
              or vehicle_name like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or status like '%" . $keyword . "%')";
        }


        $rows = $this->db->query("SELECT id FROM oc_returned_orders WHERE (vendor_id ='$vendor_id') $order_filter   group by order_slot ");

        $query = $this->db->query("SELECT * FROM oc_returned_orders WHERE (vendor_id = '$vendor_id')  $order_filter ORDER BY id desc LIMIT $offset,$per_page");

        $count        = $query->num_rows();
        $daily_report = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {


                if ($row['order_type'] == 'individual') {
                    if ($row['school_name'] != '') {
                        $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                    } else {
                        $product_name = $row['product_name'];
                    }

                } else {
                    $product_name = $row['school_name'] . '/' . $row['product_name'];
                }



                $date_          = date("Y-m-d H:i:s", strtotime($row['added_date']));
                $approval_date_ = date("Y-m-d H:i:s", strtotime($row['approval_date']));
                $pending_since  = get_time_difference($date_);
                $approval_since = get_time_difference($approval_date_);

                if ($courier_id == 2) {
                    $created_at    = $date_;
                    $pending_since = $pending_since;
                } else {
                    $created_at    = $approval_date_;
                    $pending_since = $approval_since;
                }

                $daily_report[] = array(
                    "id" => $row['id'],
                    "process_slot" => $row['process_slot'],
                    "order_type" => $row['order_type'],
                    "order_slot" => $row['order_slot'],
                    "order_number" => $row['order_number'],
                    "product_name" => $product_name,
                    "return_status" => $row['return_status'],
                    "product_unit_price" => $row['product_unit_price'],
                    "product_quantity" => $row['product_quantity'],
                    "product_total_price" => $row['product_total_price'],
                    "size_name" => $row['size_name'],
                    "driver_name" => $row['driver_name'],
                    "vehicle_name" => $row['vehicle_name'],
                    "otp" => ($row['otp'] != NULL ? '| <b>OTP-</b>' . $row['otp'] : '-'),
                    "pending_since" => $pending_since,
                    "returned_since" => $returned_since,
                    "created_at" => $created_at
                );

            }
        }


        $grouped_array = $this->group_array($daily_report, "order_slot", true);
        $report_data   = array();
        foreach ($grouped_array as $key => $value) {
            $list = array();
            foreach ($value as $value2) {
                $list[] = array(
                    "id" => $value2['id'],
                    "process_slot" => $value2['process_slot'],
                    "order_type" => $value2['order_type'],
                    "order_slot" => $value2['order_slot'],
                    "order_number" => $value2['order_number'],
                    "product_name" => $value2['product_name'],
                    "return_status" => $value2['return_status'],
                    "product_unit_price" => $value2['product_unit_price'],
                    "product_quantity" => $value2['product_quantity'],
                    "product_total_price" => $value2['product_total_price'],
                    "size_name" => $value2['size_name'],
                    "driver_name" => $value2['driver_name'],
                    "vehicle_name" => $value2['vehicle_name'],
                    "otp" => $value2['otp'],
                    "pending_since" => $value2['pending_since'],
                    "returned_since" => $value2['returned_since'],
                    "created_at" => $value2['created_at']
                );
            }


            $report_data[] = array(
                "order_slot_no" => $key,
                "list" => $list
            );

        }

        $kirtibook_courir_count = $this->db->query("SELECT id FROM oc_returned_orders WHERE (vendor_id ='$vendor_id')   AND (status ='returned') GROUP BY order_slot ORDER BY id  ASC")->num_rows();
        $gati_courir_count      = $this->db->query("SELECT id FROM oc_returned_orders WHERE (vendor_id ='$vendor_id')   AND (status ='pending')  GROUP BY order_slot ORDER BY id ASC")->num_rows();

        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'data' => $report_data,
            'total_data' => $total_data
        );
        return $resultpost;
    }


    public function customer_invoice_order($vendor_id, $per_page, $offset, $filter){
        $order_filter         = '';
        $academic_year_filter = '';
        $warehouse_filter         = '';
        $warehouse_id         = $filter['warehouse_id'];
        if ($filter['warehouse_id'] != '') {
            $warehouse_id = $filter['warehouse_id'];
            $order_filter .= " and warehouse_id = '$warehouse_id'";
            $warehouse_filter = " and warehouse_id = '$warehouse_id'";
        }

        if ($filter['courier_id'] != '') {
            $courier_id = $filter['courier_id'];
            $order_filter .= " and courier_id = '$courier_id'";
        }

        $group_by_dtdc='';
        if ($filter['order_status'] != '') {
            $order_status = $filter['order_status'];
            if($order_status=='handed_dtdc'){
                $order_filter .= " AND is_picked_dtdc='1' and ((order_status = 'shipment' AND complaint_status IS NULL) OR complaint_status = 'shipment') ";
                $group_by_dtdc = ' GROUP BY slot_no';
            }
            else{
                $order_filter .= " AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') ";
                $group_by_dtdc='';
            }
        }
        else{
          $group_by_dtdc='';
        }

        if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter .= " AND (order_number like '%" . $keyword . "%'
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or process_slot like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
        }

        $order_by = '';
        if ($filter['order_status'] == 'delivered') {
            $order_by = 'ORDER BY delivered_date DESC';
        } elseif ($filter['order_status'] == 'out_for_delivery') {
            $order_by = 'ORDER BY dispatched_date DESC';
        } else {
            $order_by = 'ORDER BY id desc';
        }

        if ($filter['order_status'] == 'shipment') {
            $order_by = 'ORDER BY process_slot asc';
        }



        $academic_year_filter ='';
		if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year        = explode(" - ", $filter['academic_year']);
            $from                 = date('Y-m-d', strtotime($academic_year[0]));
            $to                   = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
		
		$group_by_dtdc='';

        $rows = $this->db->query("SELECT id FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='') $order_filter $academic_year_filter $group_by_dtdc ");

        $query        = $this->db->query("SELECT process_slot,awb_number,courier_name,return_status,complaint_id,complaint_status,exchange_id,product_parent_cid,order_slot,updated_at,buyer_id,address_id,id,order_type,order_number,slot_no,invoice_no,order_status,courier, school_id,warehouse_id as shipping_id, created_at, school_name, grade_name, board_name,  orderform_id,product_id,product_name,internet_charges,shipping_date, dispatched_date, delivered_date,txn_id,price_total,username,phone_number FROM orders WHERE (vendor_id = '$vendor_id') AND (payment_status='payment_received') AND (order_slot!='') $order_filter $academic_year_filter $order_by LIMIT $offset,$per_page");
		

        $count        = $rows->num_rows();
        $daily_report = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $shipping = $this->order_model->get_vendor_shipping_by_id($row['shipping_id']);
                $complaint_id = $row['complaint_id'];
                if ($complaint_id != NULL) {
                    $ticket    = $this->db->query("SELECT id,ctype,cat_name,ticket_desc FROM oc_tickets WHERE (id = '$complaint_id') LIMIT 1")->row_array();
                    $ticket_no = '#' . $ticket['ctype'] . sprintf('%04d', $ticket['id']);
                } else {
                    $ticket_no    = '-';
                    $complaint_id = '';
                }

                if ($row['order_type'] == 'individual') {
                    if ($row['product_parent_cid'] == '22' && $row['school_name'] != '') {
                        $product_name = $row['school_name'] . '-' . $row['board_name'] . '/' . $row['product_name'];
                    } else {
                        $product_name = $row['product_name'];
                    }
                } else {
                    $product_name = $row['school_name'];
                }

                if ($row['complaint_status'] != NULL) {
                    $product_name = $product_name . ' (Complaint)';
                }

                if ($row['return_status'] != NULL && $row['return_status'] == 'exchange_return') {
                    $product_name = $product_name . ' (Exchange)';
                }

                $date_         = date("Y-m-d H:i:s", strtotime($row['updated_at']));
                $pending_since = get_time_difference($date_);

                $dispatched_date = $row['dispatched_date'];
                if ($dispatched_date != NULL) {
                    $date_out_                = date("Y-m-d H:i:s", strtotime($row['dispatched_date']));
                    $pending_out_for_delivery = get_time_difference($date_out_);
                    $pending_since            = $pending_out_for_delivery;
                } else {
                    $pending_out_for_delivery = '';
                }

                $delivered_date = $row['delivered_date'];
                if ($delivered_date != NULL) {
                    $date_delivered_   = date("d M Y h:i a", strtotime($row['delivered_date']));
                    $pending_delivered = $date_delivered_;
                } else {
                    $pending_delivered = '';
                }

                $shipping_date = $row['shipping_date'];
                if ($shipping_date != NULL) {
                    $date_out_      = date("Y-m-d H:i:s", strtotime($row['shipping_date']));
                    $shipping_since = get_time_difference($date_out_);
                } else {
                    $shipping_since = '';
                }

                $created_at     = date("d M Y h:i a", strtotime($row['created_at']));
                $report_data[] = array(
                    "id" => $row['id'],
                    "process_slot" => $row['process_slot'],
                    "awb_number" => $row['awb_number'],
                    "courier_name" => $row['courier_name'],
                    "order_slot_no" => $row['order_slot'],
                    "address_id" => $row['address_id'],
                    "buyer_id" => $row['buyer_id'],
                    "order_type" => $row['order_type'],
                    "order_number" => $row['order_number'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['slot_no'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "city_name" => $shipping->city_name,
                    "pincode" => $shipping->pincode,
                    "order_status" => $row['order_status'],
                    "txn_id" => $row['txn_id'],
                    "amount" => $row['price_total']
					, "username" => $row['username'],
					"phone_number" => $row['phone_number'],
                    "created_at" => $created_at,
                    "pending_since" => $pending_since,
                    "shipping_since" => $shipping_since,
                    "pending_out" => $pending_out_for_delivery,
                    "pending_delivered" => $pending_delivered,
                    "product_name" => $product_name,
                    "ticket_no" => $ticket_no,
                    "complaint_id" => $complaint_id
                );
            }
        }


        //$grouped_array = $this->group_array($daily_report, "order_slot_no", true);
       // $report_data   = array();
   

        $order_status = $filter['order_status'];


        $bookset_count    = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'bookset' ORDER BY id ASC")->num_rows();
        $individual_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and warehouse_id = '$warehouse_id' and courier_id = '$courier_id' and order_type = 'individual' ORDER BY id ASC")->num_rows();


        $kirtibook_courir_count = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')  AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and courier_id = '1' AND (order_slot!='') $warehouse_filter $academic_year_filter ORDER BY id  ASC")->num_rows();

        $gati_courir_count      = $this->db->query("SELECT id FROM orders WHERE (vendor_id ='$vendor_id')    AND (payment_status='payment_received') AND ((order_status = '$order_status' AND complaint_status IS NULL) OR complaint_status = '$order_status') and courier_id = '2' AND (order_slot!='') $warehouse_filter $academic_year_filter ORDER BY id ASC")->num_rows();

        $total_data = $rows->num_rows();

        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'kirtibook_courir_count' => $kirtibook_courir_count,
            'gati_courir_count' => $gati_courir_count,
            'data' => $report_data,
            'bookset_count' => $bookset_count,
            'individual_count' => $individual_count,
            'total_data' => $total_data
        );
        return $resultpost;
    }



   
	
	public function pending_to_process_order_bigship($user_id, $order_array, $order_status){
        date_default_timezone_set('Asia/Kolkata');
        $updated_date = date('Y-m-d H:i:s');
        $order_slot   = '';

		$failed_orders = [];
        $order_slot_comma = implode(",", $order_array);
        $check_ws         = $this->db->query("SELECT id FROM orders WHERE vendor_id='$user_id' AND (order_status='pending' OR order_status='exchange_pending') AND FIND_IN_SET(order_slot, '$order_slot_comma') GROUP BY order_slot");

        if ($check_ws->num_rows() == count($order_array)) {
            if (count($order_array) > 0) {
                $order_arr = array();
                foreach ($order_array as $order_list) {
                    $or_id = $order_list;
                    $query = $this->db->query("SELECT id FROM orders WHERE order_slot = '$or_id'");
                    $i     = 0;
                    foreach ($query->result_array() as $row) {
                        $order_arr[] = $row['id'];
                        if ($i == 0) {
                            $order_slot = $row['id'] . '_' . token_8_digit();
                        }
                        $i++;
                    }
                }
  
              //shipping label
              foreach ($order_array as $slot_no) {
				$consignments = array();
				$check_slot_no = $this->db->query("SELECT order_type,invoice_no,id,total_weight,warehouse_id,product_name,order_number,price_total,buyer_id,created_at as user_invoice_date FROM orders WHERE order_slot = '$slot_no'");
				if ($check_slot_no->num_rows()>0) {

					$product_details = array();
					$declared_value=0;
					$total_weight=0;
					$total_weight_gm=0;
					foreach ($check_slot_no->result_array() as $slot_row) {
						$order_type = $slot_row['order_type'];
						if($order_type=='individual'){
							$product_name = $slot_row['product_name'];
							$order_number = $slot_row['order_number'];
							$price_total = (float) $slot_row['price_total'];
							$order_id = $slot_row['id'];
							$warehouse_id = $slot_row['warehouse_id'];
							$invoice_no = $slot_row['invoice_no'];
							$invoice_date = $slot_row['user_invoice_date'];
							$declared_value=(float)$declared_value+(float)$price_total;

							$total_weight_input = (float)$slot_row['total_weight'];
							if ($total_weight_input == 0) {
								$total_weight_input = 500;
							}
							$total_weight = (float)$total_weight + $total_weight_input;

							$hsn = $this->common_model->getNameByVar('order_products','hsn',array('order_id'=>$order_id));
					
							$product_details[] = array(	
								"product_category" => "Others",
								"product_sub_category" => "",
								"product_name" =>  $this->common_model->sanitize_allowed_chars($product_name),
								"product_quantity" => 1,
								"each_product_invoice_amount" => $price_total,
								"each_product_collectable_amount" => 0,
								"hsn" => $hsn
							);	
						}
						else{	
							$total_weight  = (float)$total_weight + (float)$slot_row['total_weight'];	
							$order_id 	   = $slot_row['id'];						
							$order_products= $this->common_model->getResultById('order_products','product_name,product_total_price as price_total,hsn',array('order_id'=>$order_id));
							$warehouse_id  = $slot_row['warehouse_id'];
							$invoice_no	   = $slot_row['invoice_no'];
							$invoice_date  = $slot_row['user_invoice_date'];
							$order_number  = $slot_row['order_number'];
								
							foreach($order_products as $oitem){
								$product_name = $oitem['product_name'];
								$hsn = $oitem['hsn'];
								$price_total    = (float) $oitem['price_total'];
								$declared_value = (float)$declared_value+(float)$price_total;

								$product_details[] = array(	
									"product_category" => "Others",
									"product_sub_category" => "",
									"product_name" =>  $this->common_model->sanitize_allowed_chars($product_name),
									"product_quantity" => 1,
									"each_product_invoice_amount" => $price_total,
									"each_product_collectable_amount" => 0,
									"hsn" => $hsn
								);	
							}								
						}	
					}
					  
					$add_query       = $this->db->query("SELECT name,phone,alternate_phone,flat_house_no,building_name,address,city_name,state_name,pincode,landmark FROM order_shipping WHERE order_id = '$order_id' LIMIT 1");
					$address      = $add_query->row_array();

					$name = $address['name'];
					$phone = $address['phone'];
					$alternate_phone = $address['alternate_phone'];
					$flat_house_no = $address['flat_house_no'];
					$building_name = $address['building_name'];
					$caddress = $address['address'];
					$city_name = $address['city_name'];
					$state_name = $address['state_name'];
					$pincode = $address['pincode'];
					$landmark = $address['landmark'];
					$address_line_1 = $flat_house_no.','.$building_name.','.$caddress;

					$ware_row       = $this->db->query("SELECT state_id,city_id,address,pincode,landmark,contact_number FROM vendor_shipping_details WHERE id = '$warehouse_id' LIMIT 1")->row_array();

					$ware_address = $ware_row['address'];
					$ware_pincode = $ware_row['pincode'];
					$ware_landmark = $ware_row['landmark'];
					$ware_phone = $ware_row['contact_number'];
					$state_id = $ware_row['state_id'];
					$city_id = $ware_row['city_id'];

					$state_row = $this->db->query("SELECT name FROM states WHERE id='$state_id' limit 1")->row_array();
					$ware_state_name = $state_row['name'];

					$city_row = $this->db->query("SELECT name FROM cities WHERE id='$city_id' limit 1")->row_array();
					$ware_city_name = $city_row['name'];

					$total_weight = $total_weight;

					if($total_weight==0){
						$total_weight=1;
						$total_weight = price_format_decimal($total_weight/1000);
					}
					else{
						$total_weight = price_format_decimal($total_weight/1000);
					}
						 
					$address_line_1 = $this->common_model->sanitizeAddress($address_line_1);
					$address_length = strlen($address_line_1);

					$address1 = $address2 = $address_landmark = '';

					if ($address_length < 10) {
						$address_line_1 = str_pad($address_line_1, 10, ' ');
					}

					if ($address_length > 50) {
						$chunkSize = 50;
						$address1 = substr($address_line_1, 0, $chunkSize);
						$remaining = substr($address_line_1, $chunkSize);

						$lastSpace = strrpos($address1, ' ');
						if ($lastSpace !== false) {
							$address1 = substr($address_line_1, 0, $lastSpace);
							$address2 = substr($address_line_1, $lastSpace + 1);
						} else {
							$address2 = $remaining;
						}

						if (strlen($address2) > 50) {
							$lastSpaceAddress2 = strrpos(substr($address2, 0, 50), ' ');
							if ($lastSpaceAddress2 !== false) {
								$address_landmark = substr($address2, $lastSpaceAddress2 + 1);
								$address2 = substr($address2, 0, $lastSpaceAddress2);
							} else {
								$address_landmark = substr($address2, 50);
								$address2 = substr($address2, 0, 50);
							}
						}

						if (strlen($address_landmark) > 50) {
							$address_landmark = substr($address_landmark, 0, 50);
						}
					} else {
						$address1 = $address_line_1;
						$address2 = '';
						$address_landmark = '';
					}

					
					//echo $name;			 
					$name_ = $this->common_model->sanitizeString($name); 
					$name_parts = explode(' ', trim($name_), 2);
	 
					$first_name = $name_parts[0] ?? '';
					if (strlen($first_name) < 3) {
						$first_name = str_pad($first_name, 3, '.'); 
					} elseif (strlen($first_name) > 25) {
						$first_name = substr($first_name, 0, 25); 
					}
	 
					$last_name = $name_parts[1] ?? '...'; 
					if (strlen($last_name) < 3) {
						$last_name = str_pad($last_name, 3, '.'); 
					} elseif (strlen($last_name) > 25) {
						$last_name = substr($last_name, 0, 25); 
					}
												
					$declared_value=price_format_decimal($declared_value);
			
					$box_details = array();
					$box_details[] = array(	
							"each_box_dead_weight" => $total_weight,
							"each_box_length" => 44,//17inch
							"each_box_width" => 31,//12inch
							"each_box_height" => 16,//6inch
							"each_box_invoice_amount" => $declared_value,
							"each_box_collectable_amount" => 0,
							"box_count" => 1,
							"product_details" => $product_details
					);

					
					$params = array();
					$params = array(
						"shipment_category" => "b2c",
						"warehouse_detail" => array(
							"pickup_location_id" => 141149,
							"return_location_id" => 141149
						),
						"consignee_detail" => array(
							"first_name" => $first_name,
							"last_name" => $last_name,
							"company_name" => "",
							"contact_number_primary" => $phone,
							"contact_number_secondary" => '',
							"email_id" => "",
							"consignee_address" => array(
								"address_line1" => $address1,
								"address_line2" => $address2,
								"address_landmark" => $address_landmark,
								"pincode" => $pincode
							)
						),
						"order_detail" => array(
							"invoice_date" =>  date("Y-m-d\TH:i:s", strtotime($invoice_date)),
							"invoice_id" => $slot_no,
							"payment_type" => "Prepaid",
							"shipment_invoice_amount" => $declared_value,
							"total_collectable_amount" => 0,
							"box_details" => $box_details,
							"ewaybill_number" => "",
							"document_detail" => array(
								"invoice_document_file" => "",
								"ewaybill_document_file" => ""
							)
						)
					);

				//echo json_encode($params);exit();

					$bigship=$this->create_bigship_order($params);
					$bigship_arr = json_decode($bigship);
					//echo json_encode($params);
					//echo json_encode($bigship_arr);exit();
					if($bigship_arr->responseCode==200 && $bigship_arr->success==true){		
						$system_parts = explode("system_order_id is ", $bigship_arr->data);
						$system_order_id = isset($system_parts[1]) ? trim($system_parts[1]) : null;					
						$data_reforder = array(
							'shipment_provider' => 'bigship',
							'system_order_id' => $system_order_id,
							'process_slot' => $order_slot,
							'order_status' => 'processing',
							'awb_number' 	=> NULL, 
							'courier_name' 	=> NULL,
							'processing_date' => $updated_date,
							'updated_at' => $updated_date
						);
						$this->db->where('order_slot', $slot_no);
						$update = $this->db->update('orders', $data_reforder);

						$check = $this->db->query("SELECT id FROM vendor_shipping_label  WHERE slot_no = '$slot_no' LIMIT 1")->num_rows();
						if ($check == 0) {
							$sql       = $this->db->query("SELECT vendor_id FROM orders  WHERE order_slot = '$slot_no' LIMIT 1");
							$item      = $sql->row_array();
							$data_slot = array(
								'shipment_provider' => 'bigship',
								'system_order_id' => $system_order_id,
								'vendor_id' => $item['vendor_id'],
								'process_slot' => $order_slot,
								'slot_no' => $slot_no,
								'ctype' => 'process',										
								'created_at' => $updated_date
							);
							$insert    = $this->db->insert('vendor_shipping_label', $data_slot);
						} else {
							$data_slot = array(
								'shipment_provider' => 'bigship',
								'system_order_id' => $system_order_id,
								'vendor_id' => $item['vendor_id'],
								'process_slot' => $order_slot,
								'awb_number' => NULL,
								'courier' => NULL,
							);
							$this->db->where('slot_no', $slot_no);
							$update = $this->db->update('vendor_shipping_label', $data_slot);
						}
					}
					else{
                     $failed_orders[] = $slot_no;              
					}	
					
				}
			}
			//shipping label


    			if (empty($failed_orders)) {
    				$resultpost = [
    					'status' => 200,
    					'message' => 'success'
    				];
    			} else {
    				$resultpost = [
    					'status' => 400, // Partial success
    					'message' => 'Some orders failed to process-'.implode(",",$failed_orders),
    					'res' => json_encode($bigship_arr),
    					'params' => json_encode($params),
    				];
    			}

            } else {
                $resultpost = array(
                    'status' => 400,
                    'message' => 'error'
                );
            }
        } else {
            $resultpost = array(
                'status' => 400,
                'message' => 'Error! All the Orders must be in Pending Status'
            );
        }

        return $resultpost;
    }

	public function create_bigship_order($consignments)    {
		$curl = curl_init();
		$token = $this->common_model->getNameByVar('ship_auth_token','token',array('id'=>1));
	
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bigship.in/api/order/add/single',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>json_encode($consignments),
		  CURLOPT_HTTPHEADER => array(
			'content-type: application/json',
            'Authorization: Bearer ' . trim($token)
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		return $response;
	}

}
