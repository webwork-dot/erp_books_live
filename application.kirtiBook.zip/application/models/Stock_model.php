<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock_model extends CI_Model
{
    public function get_warehouse_by_vendor($id)
    {
        return $this->db->get_where('vendor_shipping_details', array(
            'vendor_id' => $id
        ));
    }
    
    public function get_size_by_id($id)
    {
        return $this->db->get_where('size', array(
            'id' => $id
        ));
    }
    
    
    public function get_quantity_by_warehouse($warehouse_id,$product_id)
    {
        return $this->db->get_where('products_warehouse_qty', array(
            'product_id' => $product_id,
            'warehouse_id' => $warehouse_id,
        ));
    }
    
    public function stationery_stock_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        $warehouse_search='';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        }
        else {
            $product_search = '';
        }

        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        }
        
        $this->db->select('pwq.quantity,p.master_id,pwq.id as product_quantity_id,p.discount_price,p.id,pm.title,pm.isbn,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,pm.gst,p.status,p.is_sold,pm.stationery_id,pm.brand_id,pm.description');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('pm.parent_cid', $category);
        $product_search;
        $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
 
        
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "master_id" => $row['master_id'],
                "product_id" => $row['id'],
                "product_quantity_id" => $row['product_quantity_id'],
                "isbn" => $row['isbn'],
                "product_quantity" => $row['quantity'],
                "product_price" => $row['base_price'],
                "product_kirtibook_price" => $row['discount_price'],
                "product_name" => $row['title'],
                "status" => $row['status'],
                "warehouse_id" => $filter['warehouse_id'],
                "publisher" => $this->common_model->shorter($publisher,'11'),
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade
            );
        }
        $total_data = $this->stationery_stock_count($user_id, $category,$filter);
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'data' => $data
        );
        return $resultpost;
    }
    
    public function stationery_stock_count($user_id, $category,$filter)
    {
        $product_search = '';
        $warehouse_search='';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        }
        else {
            $product_search = '';
        }

        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        }
        
        $this->db->select('pwq.quantity,p.discount_price,p.id,pm.title,pm.isbn,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,pm.gst,p.status,p.is_sold,pm.stationery_id,pm.brand_id,pm.description');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('pm.parent_cid', $category);
        $product_search;
        $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
      
        return $query->num_rows();
    }
    
    public function product_stock_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        $warehouse_search='';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        }
        else {
            $product_search = '';
        }

        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        }
        
        $this->db->select('pm.id as master_id,pm.isbn,pwq.id as product_quantity_id,pwq.quantity,p.id,p.created_at,pm.title,p.gender,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,p.discount_price,pm.gst,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.id', 'desc'); 
        $query = $this->db->get('products as p');
        
        $data  = array();
        foreach ($query->result_array() as $row) {
            $get_publisher = $this->product_model->get_publisher_by_id($row['publisher_id']);
            if ($get_publisher->num_rows() > 0) {
                $publisher_data = $get_publisher->row();
                $publisher      = $publisher_data->name;
            } else {
                $publisher = '-';
            }
            
            $get_subject = $this->product_model->get_subject_by_id($row['subject_id']);
            if ($get_subject->num_rows() > 0) {
                $subject_data = $get_subject->row();
                $subject      = $subject_data->name;
            } else {
                $subject = '-';
            }
            
            $get_grade = $this->product_model->get_grades_by_id($row['grade_id']);
            if ($get_grade->num_rows() > 0) {
                $grade_data = $get_grade->row();
                $grade      = $grade_data->name;
            } else {
                $grade = '-';
            }
            
            $get_board = $this->product_model->get_board_by_id($row['board_id']);
            if ($get_board->num_rows() > 0) {
                $board_data = $get_board->row();
                $board      = $board_data->name;
            } else {
                $board = '-';
            }
            
            $data[] = array(
                "master_id" => $row['master_id'],
                "product_id" => $row['id'],
                "product_quantity_id" => $row['product_quantity_id'],
                "isbn" => $row['isbn'],
                "product_quantity" => $row['quantity'],
                "product_price" => $row['base_price'],
                "product_kirtibook_price" => $row['discount_price'],
                "product_name" => $row['title'],
                "status" => $row['status'],
                "warehouse_id" => $filter['warehouse_id'],
                "publisher" => $this->common_model->shorter($publisher,'11'),
                "board" => $board,
                "subject" => $subject,
                "grade" => $grade
            );
        }
        $total_data = $this->product_stock_count($user_id, $category,$filter);
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'total_data' => $total_data,
            'data' => $data
        );
        return $resultpost;
    }
    
    public function product_stock_count($user_id, $category,$filter)
    {
        $product_search = '';
        $warehouse_search='';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('pm.title', $filter['keyword']);
        }
        else {
            $product_search = '';
        }

        if ($filter['warehouse_id'] != '') {
            $warehouse_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        }
        
        $this->db->select('pwq.quantity,p.id,pm.title,p.gender,p.model_number,pm.publisher_id,pm.subject_id,pm.grade_id,pm.board_id,p.base_price,p.discount_price,pm.gst,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $warehouse_search;
        $this->db->group_by('p.id');
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        return $query->num_rows();
    }
    
    public function uniform_stock_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        
        $this->db->select('vsd.address,vsd.id as warehouse_id,s.name as size_name,pwq.id as product_quantity_id,pwq.size_id,pwq.quantity,pwq.price,pwq.kirtibook_price,vsd.address,p.id,p.user_id,p.title,p.status,p.is_sold');
        // $this->db->join('products_category', 'p.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=p.uniform_cat');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        
        // $this->db->group_by('vsd.id');
        $query = $this->db->get('products as p');
        // echo $this->db->last_query();
        // exit();
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            $get_size = $this->get_size_by_id($row['size_id'])->row();
            $size_name      = $get_size->name;
            
            $data[] = array(
                        "warehouse_name" => $row['address'],
                        "product_quantity_id" => $row['product_quantity_id'],
                        "product_size_id" => $row['size_id'],
                        "size_name" => $row['size_name'],
                        "product_quantity" => $row['quantity'],
                        "product_price" => $row['price'],
                        "product_kirtibook_price" => $row['kirtibook_price'],
                        "product_name" => $row['title'],
                        "status" => $row['status'],
                        "warehouse_id" => $row['warehouse_id'],
                );
            
        }
        
        $total_data = $this->uniform_stock_count($user_id,$category,$filter);
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function uniform_stock_count($user_id, $category,$filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        } 
         if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        $this->db->select('vsd.address,s.name as size_name,pwq.id as product_quantity_id,pwq.size_id,pwq.quantity,pwq.price,pwq.kirtibook_price,vsd.address,p.id,p.user_id,p.title,p.status,p.is_sold');
        $this->db->join('categories', 'categories.id=p.uniform_cat');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        $query = $this->db->get('products as p');
        
        return $query->num_rows();
    }
    
    public function update_product_status($user_id,$master_id,$status)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date("Y-m-d H:m:s");
        if($status==true){
            $status=1;
        }else{
            $status=0;
        }
        $pdata = array(
            'status' => $status
        );
        $this->db->where('master_id', $master_id);
        $this->db->update('products', $pdata);
        
        $this->db->where('id', $master_id);
        $this->db->update('product_master', $pdata);

        if($status==1){
            $msg = 'Success !! Status Is Active';
        }else{
            $msg = 'Success !! Status Is In-Active';
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }
    
    public function update_product_stock($user_id,$product_id,$master_id,$id,$quantity,$discount_price,$base_price)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date("Y-m-d H:m:s");
        $msg = '';
        
        $pdata = array(
            'base_price' => $base_price,
            'discount_price' => $discount_price
        );
        $this->db->where('id', $product_id);
        $this->db->update('products', $pdata);
           
        $data = array(
            'quantity' => $quantity,
            'last_modified' => $date
        );
        $this->db->where('id', $id);
        if($this->db->update('products_warehouse_qty', $data)){
            $msg = 'Success !! Stock Updated';
        }else{
            $msg = 'Error !! Stock Not Updated';
        }
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'msg' => $msg
        );
        return $resultpost;
    }
    
    public function shoes_stock_list($user_id, $category, $per_page, $offset, $filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('vsd.address,vsd.id as warehouse_id,s.name as size_name,s.indian as size_indian,s.usa as size_usa,s.uk as size_uk,pwq.id as product_quantity_id,pwq.size_id,pwq.quantity,pwq.price,pwq.kirtibook_price,vsd.address,p.id,p.user_id,pm.title,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $this->db->limit($per_page, $offset);
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        
        // $this->db->group_by('vsd.id');
        $query = $this->db->get('products as p');
        // echo $this->db->last_query();
        // exit();
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            
            $get_size = $this->get_size_by_id($row['size_id'])->row();
            $size_name      = $get_size->name;
            
            $data[] = array(
                        "warehouse_name" => $row['address'],
                        "product_quantity_id" => $row['product_quantity_id'],
                        "product_size_id" => $row['size_id'],
                        "size_name" => 'Indian:'.$row['size_indian'].', USA:'.$row['size_usa'].', UK:'.$row['size_uk'],
                        "product_quantity" => $row['quantity'],
                        "product_price" => $row['price'],
                        "product_kirtibook_price" => $row['kirtibook_price'],
                        "product_name" => $row['title'],
                        "status" => $row['status'],
                        "warehouse_id" => $row['warehouse_id'],
                );
            
        }
        
        $total_data = $this->shoes_stock_list_count($user_id, $category,$filter);
        
        $resultpost = array(
            'status' => 200,
            'message' => 'success',
            'data' => $data,
            'total_data' => $total_data
        );
        return $resultpost;
    }
    
    public function shoes_stock_list_count($user_id, $category,$filter)
    {
        $product_search = '';
        if ($filter['keyword'] != '') {
            $product_search = $this->db->like('p.title', $filter['keyword']);
        }
        
        if ($filter['warehouse_id'] != '') {
            $product_search = $this->db->where('vsd.id', $filter['warehouse_id']);
        } 
        
        
        $this->db->select('vsd.address,vsd.id as warehouse_id,s.name as size_name,s.indian as size_indian,s.usa as size_usa,s.uk as size_uk,pwq.id as product_quantity_id,pwq.size_id,pwq.quantity,pwq.price,pwq.kirtibook_price,vsd.address,p.id,p.user_id,pm.title,p.status,p.is_sold');
        $this->db->join('product_master as pm', 'p.master_id=pm.id');
        $this->db->join('products_category', 'pm.id=products_category.product_id');
        $this->db->join('categories', 'categories.id=products_category.category_id');
        $this->db->join('vendor_shipping_details as vsd', 'p.user_id=vsd.vendor_id','left');
        $this->db->join('products_warehouse_qty as pwq', 'p.id=pwq.product_id and vsd.id=pwq.warehouse_id');
        $this->db->join('size as s', 'pwq.size_id=s.id');
        $this->db->where('p.visibility', 1);
        $this->db->where('p.is_deleted', 0);
        $this->db->where('p.user_id', $user_id);
        $this->db->where('categories.parent_id', $category);
        $product_search;
        $this->db->order_by('vsd.id', 'vsd'); 
        $this->db->order_by('pwq.id', 'desc');
        
        // $this->db->group_by('vsd.id');
        $query = $this->db->get('products as p');
        // echo $this->db->last_query();
        // exit();
        $count = $query->num_rows();
        
        return $count;
    }
    
    
    
}