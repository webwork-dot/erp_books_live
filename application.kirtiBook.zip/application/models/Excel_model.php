<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Excel_model extends CI_Model {
  
    public function consolidated_report_list($user_id,$process_slot){
		$resultpost = array();
        $query  = $this->db->query("SELECT id,id as order_id,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name,  product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE (payment_status='payment_received') AND (order_status='processing')  AND (process_slot='$process_slot') AND vendor_id = '$user_id' LIMIT 2000");        		
        if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {		
		  $data_slot = array();	
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone,amount, added_date FROM consolidated_reports WHERE order_id='$order_id'");  
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$amount = $item['amount']; 
			$added_date = $item['added_date']; 		
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$invoice_no  	= $row['invoice_no'];
			$order_number   = $row['order_number']; 
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			
			$product_id   = $row['product_id'];
			$school_id    = $row['school_id'];				
			$category_id  = $row['product_parent_cid'];
			$size_id      = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name    = $this->common_model->get_size_name_by_id($size_id);
			$color_name   = $this->common_model->get_color_name_by_product($product_id);			
			$school_city  = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
             $details='';
			
            $package_details=array();		
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
		   
		   $query_amount = $this->db->query("SELECT price_total FROM orders WHERE id='$order_id'");
            $amount_ = $query_amount->row_array();
            $amount =  $amount_['price_total'];
	   
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "amount" => $amount,
                "added_date" => $added_date,
            ); 
           $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		  	
		  
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "amount" => $amount,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
            );
		 }
		}
	  return $resultpost;
  	}	
  	
  	
  	
  	
  	

public function get_gst_report($start_end_date,$vendor_id){ 
    $resultpost = array();
    $date_filter="";
   

       
    if($start_end_date!=""):
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(created_at) BETWEEN '$from' AND '$to')";
    endif;
	    
	$orders = $this->db->query("SELECT id, order_id, vendor_id, school_id, customer, invoice_no, created_at, order_number, invoice_amt, gst_0_excl, gst_0_amt, gst_5_excl, gst_5_amt, gst_12_excl, gst_12_amt, gst_18_excl, gst_18_amt, gst_28_excl, gst_28_amt, added_date FROM oc_gst_report WHERE  (vendor_id = '$vendor_id') $date_filter  GROUP BY order_id ORDER BY id asc");
    
		$orders_count = $orders->num_rows();
		if($orders_count >0){
		foreach ($orders->result() as $order) {
						
		$resultpost[]     = array(
            "id" => $order->id,
            "customer" => $order->customer,
            "invoice_no" => $order->invoice_no,
            "created_at" => $order->created_at,
            "order_number" => $order->order_number,
            "invoice_amt" => $order->invoice_amt,
            "gst_0_excl" => price_format_decimal($order->gst_0_excl),
            "gst_0_amt" => price_format_decimal($order->gst_0_amt),
            "gst_5_excl" => price_format_decimal($order->gst_5_excl),
            "gst_5_amt" => price_format_decimal($order->gst_5_amt),
            "gst_12_excl" => price_format_decimal($order->gst_12_excl),
            "gst_12_amt" => price_format_decimal($order->gst_12_amt),
            "gst_18_excl" => price_format_decimal($order->gst_18_excl),
            "gst_18_amt" => price_format_decimal($order->gst_18_amt),
            "gst_28_excl" => price_format_decimal($order->gst_28_excl),
            "gst_28_amt" => price_format_decimal($order->gst_28_amt),
          );
		
		 }
		}
		else{
		   $resultpost = array();
		}
		return $resultpost;
		
	}
  	
  	
   public function consolidated_report_by_status($warehouse_id,$courier_id,$user_id,$order_status,$filter){
		$resultpost = array();
		
		$order_filter = '';
    	$grade_filter="";
        $school_filter="";
        $date_filter="";  
        
        $order_ids    = implode(",", $filter['order_array']);
        $order_filter = " AND  FIND_IN_SET(order_slot, '$order_ids')";
      
   
		
/*	    if ($filter['keyword'] != '') {
            $keyword = $filter['keyword'];
            $order_filter= "and (order_slot='$keyword') ";
        } 
		
       	if(!empty($filter['grade_id']) && $filter['grade_id']!="") :
    	  $grade_id=implode(",",$filter['grade_id']);
          $grade_filter =" AND  FIND_IN_SET(grade_id, '$grade_id')"; 
        endif;	
         
        if(!empty($filter['school_id']) && $filter['school_id']!="") :
    	  $school_id=implode(",",$filter['school_id']);
          $school_filter =" AND  FIND_IN_SET(school_id, '$school_id')"; 
        endif; 
         
       	if(!empty($filter['start_end_date']) && $filter['start_end_date']!="") :
           $start_end_date=$filter['start_end_date'];
           $from =  date('Y-m-d',strtotime($start_end_date[0])); 
           $to =  date('Y-m-d',strtotime($start_end_date[1])); 
           $date_filter=" AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif; 
        */
		
        $query  = $this->db->query("SELECT id,id as order_id,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name, product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE  (payment_status='payment_received') AND (order_status='$order_status')  AND (vendor_id='$user_id') AND  courier_id = '$courier_id' AND (order_slot!='' or order_slot IS NOT NULL)  $order_filter $grade_filter $school_filter $date_filter LIMIT 2000");        		
      
        /*     echo $this->db->last_query();
      exit(); */
        if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {	
		  $data_slot = array();		
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone, added_date FROM consolidated_reports WHERE order_id='$order_id'");  
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$added_date = $item['added_date']; 		
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$order_number   = $row['order_number']; 
			$invoice_no  	= $row['invoice_no'];
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			$details  = '';
			
			$product_id     = $row['product_id'];				
			$school_id      = $row['school_id'];				
			$category_id    = $row['product_parent_cid'];
			$size_id        = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name      = $this->common_model->get_size_name_by_id($size_id);
			$color_name     = $this->common_model->get_color_name_by_product($product_id);			
			$school_city    = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $details='';			
				  
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
            
		
           $package_details=array();			
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
	   
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
            ); 
           $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		  	
		  
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
            );
		 }
		}
	  return $resultpost;
  	}	
  	
  	
  	
  
 public function consolidated_report_by_vendor_list($user_id){
		$resultpost = array();
        $query  = $this->db->query("SELECT id,id as order_id,tcs_gst,tcs,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name,  product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE (payment_status='payment_received') AND  vendor_id = '$user_id' LIMIT 4000");        		
        if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {	 
		  $data_slot = array();	
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone, added_date FROM consolidated_reports WHERE order_id='$order_id'");  
        
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$added_date = $item['added_date']; 		
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$invoice_no  	= $row['invoice_no'];
			$order_number   = $row['order_number']; 
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			
			$product_id   = $row['product_id'];
			$school_id    = $row['school_id'];				
			$category_id  = $row['product_parent_cid'];
			$size_id      = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name    = $this->common_model->get_size_name_by_id($size_id);
			$color_name   = $this->common_model->get_color_name_by_product($product_id);			
			$school_city  = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
             $details='';
			
            $package_details=array();		
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
	       
	     
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
            ); 
           $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		  	
		  
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
                "tcs_gst" => $row['tcs_gst'],
                "tcs" => $row['tcs'],
            );
		 }
		}
	  return $resultpost;
  	}	
  	
  	
    public function export_complaint_list($user_id="",$filter)   {
       $resultpost = array();
        
      $school_filter="";
	  $category_filter="";
	  $keyword_filter="";
	  $ticket_status_filter="";
	  
	  
    if(!empty($filter['school']) && $filter['school']!="") :
    	  $school_id=implode(",",$filter['school']);
          $school_filter =" AND  FIND_IN_SET(o.school_id, '$school_id')"; 
    endif; 
	
	if(!empty($filter['complaint_category']) && $filter['complaint_category']!="") :
    	  $complaint_category=implode(",",$filter['complaint_category']);
          $category_filter =" AND  FIND_IN_SET(t.cat_id, '$complaint_category')"; 
    endif; 
		
		
    if(isset($filter['keyword']) && $filter['keyword']!="") :
      $keyword=trim($filter['keyword']);
      $keyword_filter =" AND (t.id like '%".$keyword."%'  
      or t.username like '%".$keyword."%'  
      or t.email like '%".$keyword."%'
      or o.order_number like '%".$keyword."%'
      or t.phone_number like '%".$keyword."%'
      or t.cat_name like '%".$keyword."%'
      or t.subcat_name like '%".$keyword."%'
      or t.source like '%".$keyword."%'
      or t.dept_name like '%".$keyword."%')"; 
    endif;     
	
    if(isset($filter['ticket_status']) && !empty($filter['ticket_status']) &&  $filter['ticket_status']!="") :
      $ticket_status=$filter['ticket_status'];  
      $ticket_status_filter = " AND (t.ticket_status='$ticket_status')";
     endif;	


    
        $catrgory = "1,2,3,4";

       $query = $this->db->query("SELECT t.id,t.product_id,t.ticket_status,t.order_type,t.user_id,t.username,t.phone_number,t.order_id,t.cat_name,t.ticket_desc,t.added_date,o.order_number,o.product_name,o.school_name,o.grade_name,o.order_slot FROM oc_tickets as t LEFT JOIN orders as o ON t.order_id=o.id WHERE t.cat_id IN ($catrgory) and t.order_id!='' and t.vendor_id='$user_id' $school_filter $category_filter  $keyword_filter   $ticket_status_filter order by t.id desc  LIMIT 2000");  
        
        
       
        $count = $query->num_rows();
        $data  = array();
        foreach ($query->result_array() as $row) {
            $id   = $row['id'];
            $product_id = $row['product_id'];
            $ticket_status = $row['ticket_status'];
            
            if($ticket_status==1){
             $ticket_status = 'New';
            } 
            
            if($ticket_status==2){
             $ticket_status = 'Open';
            } 
            
            if($ticket_status==3){
             $ticket_status = 'Closed';
            }
            
            $order_type = $row['order_type'];
            $user_id = $row['user_id'];
            $username = $row['username'];
            $phone_number = $row['phone_number'];
            $order_id = $row['order_id'];
            $cat_name = $row['cat_name'];
            $ticket_desc = $row['ticket_desc'];
            $added_date = $row['added_date'];
            $order_slot = $row['order_slot'];
            $grade_name = $row['grade_name'];
            
          
            $date = date("Y-m-d H:i:s", strtotime($row['added_date']));
            
            if ($order_type == 'individual') {
               $product_name = $row['product_name'];
            } else {
              $product_name = $row['school_name'];
            }   
            
            
              $order_shipp = $this->db->query("SELECT location,flat_house_no,building_name,address,type,state_name,city_name,pincode,landmark FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $location = $shipp_data['location'];
            $address = $shipp_data['type'].'-'.$shipp_data['flat_house_no'].','.$shipp_data['building_name'].''.$shipp_data['address'];
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            
            $state = $shipp_data['state_name'];
            $city = $shipp_data['city_name'];      
            
            
            
            $resultpost[] = array(
                "id" => $id,
                "ticket_code" => sprintf('%04d',$id),
                "product_id" => $product_id,
                "ticket_status" => $ticket_status,
                "order_type" => ucfirst($order_type),
                "user_id" => $user_id,
                "username" => $username,
                "order_id" => $order_id,
                "order_number" => ($row['order_number']!=''? $row['order_number']:'-'),
                "product_name" => ($product_name!=''? $product_name:'-'),
                "cat_name" => $cat_name,
                "ticket_desc" => $ticket_desc,
                "shpping_no" => $order_slot,
                "added_date" => date("d M Y h:i a", strtotime($added_date)), 
                "location" => $location,
                "address" => $address,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "phone_number" => $phone_number,
                "grade_name" => $grade_name,
            );
        }
 
        return $resultpost;
    }
    
    
    public function download_customer_report($user_id,$filter){
		$resultpost = array();
        $query  = $this->db->query("SELECT id,username,email,phone_number,created_at FROM users WHERE role='member' order by id desc");  
        if ($query->num_rows() > 0) {		
		    foreach ($query->result_array() as $row) {
        		$id = $item['id'];
    			$username = $row['username'];               
    			$email = $row['email'];
    			$phone_number = $row['phone_number'];
    			$created_at = $row['created_at'];
    			
    			$resultpost[] = array(
    				"id" => $id,
    				"username" => $username,
                    "email" => $email,
                    "phone_number" => $phone_number,
                    "created_at" => date("d M Y h:i a", strtotime($created_at))
                );
		    }
		}
	    return $resultpost;
  	}
  	
  	public function consolidated_report_by_school_orders($user_id,$filter){
		$resultpost = array();  
		$order_filter = '';
    	$grade_filter="";
        $school_filter="";
        $date_filter="";
	
        $order_ids    = implode(",", $filter['order_array']);
        $order_filter = " AND  FIND_IN_SET(order_number, '$order_ids')";
      
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";
        $academic_year_filter   = "";
        
        
        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'  
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
            
        }
        
        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;
        
        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = $filter['school_id'];
            $school_filter = " AND school_id='$school_id'";
        endif;
        
        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
                
        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
        
        $query  = $this->db->query("SELECT id,id as order_id,price_total,price_shipping,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name, product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE (order_type='bookset') AND (vendor_id ='$user_id')  AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange')  $order_filter $grade_filter $school_filter $date_filter $academic_year_filter order by id desc LIMIT 2000");        		
/*     echo $this->db->last_query();
      exit(); */
      if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {		
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone, added_date FROM consolidated_reports WHERE order_id='$order_id' limit 1");  
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$added_date = $item['added_date']; 		
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$order_number   = $row['order_number']; 
			$invoice_no  	= $row['invoice_no'];
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			$details  = '';
			
			$product_id     = $row['product_id'];				
			$school_id      = $row['school_id'];				
			$category_id    = $row['product_parent_cid'];
			$size_id        = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name      = $this->common_model->get_size_name_by_id($size_id);
			$color_name     = $this->common_model->get_color_name_by_product($product_id);			
			$school_city    = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $details='';			
				  
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
            
		
           $package_details=array();			
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
	   
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
            ); 
           $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		  	
		  
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
                "price_total" => price_format_decimal($row['price_total']-$row['price_shipping']),
            );
		 }
		}
	  return $resultpost;
  	}
  	
  	public function consolidated_report_by_individual_orders($user_id,$filter){
		$resultpost = array();  
		$order_filter = '';
    	$grade_filter="";
        $school_filter="";
        $date_filter="";
	
        $order_ids    = implode(",", $filter['order_array']);
        $order_filter = " AND  FIND_IN_SET(order_number, '$order_ids')";
      
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";
        $academic_year_filter   = "";
        
        
        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'  
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
            
        }

        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
                
        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
        
        $query  = $this->db->query("SELECT id,id as order_id,price_total,price_shipping,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name, product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE (order_type='individual') AND (vendor_id ='$user_id')  AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange')  $order_filter $grade_filter $school_filter $date_filter $academic_year_filter order by id desc LIMIT 2000");        		

      if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {		
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone, added_date FROM consolidated_reports WHERE order_id='$order_id' limit 1");  
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$added_date = $item['added_date']; 		
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$order_number   = $row['order_number']; 
			$invoice_no  	= $row['invoice_no'];
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			$details  = '';
			
			$product_id     = $row['product_id'];				
			$school_id      = $row['school_id'];				
			$category_id    = $row['product_parent_cid'];
			$size_id        = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name      = $this->common_model->get_size_name_by_id($size_id);
			$color_name     = $this->common_model->get_color_name_by_product($product_id);			
			$school_city    = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $details='';			
				  
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
            
		
           $package_details=array();			
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
	   
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
            ); 
           $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		  	
		  
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
                "price_total" => price_format_decimal($row['price_total']-$row['price_shipping']),
            );
		 }
		}
	  return $resultpost;
  	}
  	
  	public function consolidated_report_by_students_orders($user_id,$filter){
		$resultpost = array();  
		$order_filter = '';
    	$grade_filter="";
        $school_filter="";
        $date_filter="";
	
        $order_ids    = implode(",", $filter['order_array']);
        $order_filter = " AND  FIND_IN_SET(order_number, '$order_ids')";
      
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";
        $academic_year_filter   = "";
        
        
        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'  
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
            
        }
        
        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;
        
        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;
        
        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
                
        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
        
        $query  = $this->db->query("SELECT id,school_name,grade_name,board_name,f_name,m_name,s_name,dob,phone_number FROM orders WHERE (vendor_id ='$user_id') AND order_type='bookset' and payment_status='payment_received' AND order_status != 'cancelled' $order_filter $grade_filter $school_filter $date_filter $academic_year_filter order by id desc LIMIT 2000");        		
        if ($query->num_rows() > 0) {		
		    foreach ($query->result_array() as $row) {
		        $order_id  		= $row['order_id'];
	  	        $sql  = $this->db->query("SELECT id,order_id,school_name,grade_name,board_name,f_name,m_name,s_name,dob,phone_number FROM consolidated_student_reports WHERE order_id='$order_id'");  
		        if ($sql->num_rows() > 0) {		
    			    $item=$sql->row_array();			
        			$order_id = $item['order_id'];
        			$school_name = $item['school_name'];               
        			$grade_name = $item['grade_name'];
        			$board_name = $item['board_name'];
        			$f_name = $item['f_name']; 
        			$m_name = $item['m_name'];
        			$s_name = $item['s_name'];
        			$dob = $item['dob'];
        			$phone_number = $item['phone_number']; 	
		        }
		        else{		 
        			$order_id  		= $row['id'];
        			$school_name = $row['school_name'];               
        			$grade_name = $row['grade_name'];
        			$board_name = $row['board_name'];
        			$f_name = $row['f_name']; 
        			$m_name = $row['m_name'];
        			$s_name = $row['s_name'];
        			$dob = $row['dob'];
        			$phone_number = $row['phone_number']; 	
        			
                    $data_slot = array(
                        "order_id" => $order_id,
        				"school_name" => $school_name,
                        "grade_name" => $grade_name,
                        "board_name" => $board_name,
                        "f_name" => $f_name,
                        "m_name" => $m_name,
                        "s_name" => $s_name,
                        "dob" => $dob,
                        "phone_number" => $phone_number,
                    ); 
                    $insert = $this->db->insert('consolidated_student_reports', $data_slot);  		  
		        }
		        $name=$f_name;
                if($m_name!=''){
                    $name.=' '.$m_name;
                }
                $name.=' '.$s_name;
		        
    		    $resultpost[] = array(
    				"order_id" => $order_id,
    				"school_name" => $school_name,
                    "grade_name" => $grade_name,
                    "board_name" => $board_name,
                    "name" => $name,
                    "dob" => $dob,
                    "phone_number" => $phone_number
                );
		    }
		}
	    return $resultpost;
  	}
    
    
    public function consolidated_report_by_all_orders($user_id,$filter){
		$resultpost = array();  
		$order_filter = '';
    	$grade_filter="";
        $school_filter="";
        $date_filter="";
	
        $order_ids    = implode(",", $filter['order_array']);
        $order_filter = " AND  FIND_IN_SET(order_number, '$order_ids')";
      
        $order_filter  = '';
        $grade_filter  = "";
        $school_filter = "";
        $date_filter   = "";
        $academic_year_filter   = "";
        
        
        if ($filter['keyword'] != '') {
            $keyword      = trim($filter['keyword']);
            $order_filter = " AND (order_number like '%" . $keyword . "%'  
              or firm_name like '%" . $keyword . "%'
              or order_slot like '%" . $keyword . "%'
              or invoice_no like '%" . $keyword . "%'
              or txn_id like '%" . $keyword . "%'
              or payment_id like '%" . $keyword . "%'
              or order_type like '%" . $keyword . "%'
              or username like '%" . $keyword . "%'
              or phone_number like '%" . $keyword . "%'
              or email like '%" . $keyword . "%'
              or product_name like '%" . $keyword . "%'
              or school_name like '%" . $keyword . "%'
              or grade_name like '%" . $keyword . "%'
              or board_name like '%" . $keyword . "%'
              or order_status like '%" . $keyword . "%')";
            
        }
        
        if (!empty($filter['grade_id']) && $filter['grade_id'] != ""):
            $grade_id     = implode(",", $filter['grade_id']);
            $grade_filter = " AND  FIND_IN_SET(grade_id, '$grade_id')";
        endif;
        
        if (!empty($filter['school_id']) && $filter['school_id'] != ""):
            $school_id     = implode(",", $filter['school_id']);
            $school_filter = " AND  FIND_IN_SET(school_id, '$school_id')";
        endif;
        
        if (!empty($filter['start_end_date']) && $filter['start_end_date'] != ""):
            $start_end_date = $filter['start_end_date'];
            $from           = date('Y-m-d', strtotime($start_end_date[0]));
            $to             = date('Y-m-d', strtotime($start_end_date[1]));
            $date_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
                
        if (!empty($filter['academic_year']) && $filter['academic_year'] != ""):
            $academic_year = explode(" - ",$filter['academic_year']);
            $from           = date('Y-m-d', strtotime($academic_year[0]));
            $to             = date('Y-m-d', strtotime($academic_year[1]));
            $academic_year_filter    = " AND (DATE(created_at) BETWEEN '$from' AND '$to')";
        endif;
        
        $query  = $this->db->query("SELECT f_name,m_name,s_name,id,id as order_id,price_total,price_shipping,order_type,total_weight, vendor_id,order_slot,invoice_no,created_at,order_number,school_id, board, grade_id, school_name, grade_name, board_name, product_id, product_name, product_quantity, product_parent_cid, size_id,username,phone_number,warehouse_id FROM orders WHERE  (vendor_id ='$user_id')  AND (payment_status='payment_received') AND (order_slot!='' or order_slot IS NOT NULL) AND (order_status != 'cancelled') AND (order_status != 'applied_for_exchange')  $order_filter $grade_filter $school_filter $date_filter $academic_year_filter order by id desc LIMIT 2000");        		
    /*     echo $this->db->last_query();
      exit(); */
      if ($query->num_rows() > 0) {		
		 foreach ($query->result_array() as $row) {		
		  $order_id  		= $row['order_id'];
	  	  $sql  = $this->db->query("SELECT id,student_name, order_id, order_type, vendor_id, order_slot, order_number, invoice_no, created_at, school_name, grade_name, board_name, school_city, product_name, category_name, size_name, color_name, details,warehouse, flat_house_no, building_name, address, location, state, city, pincode, landmark,alternate_phone, added_date FROM consolidated_reports WHERE order_id='$order_id'");  
		  if ($sql->num_rows() > 0) {		
			$item=$sql->row_array();			
			$order_id = $item['order_id'];
			$order_type = $item['order_type'];               
			$vendor_id = $item['vendor_id'];
			$order_slot = $item['order_slot'];
			$order_number = $item['order_number']; 
			$invoice_no = $item['invoice_no'];
			$created_at = $item['created_at'];
			$school_name = $item['school_name'];
			$grade_name = $item['grade_name']; 
			$board_name = $item['board_name']; 			
			$school_city = $item['school_city']; 
			$product_name = $item['product_name']; 
			$category_name = $item['category_name']; 
			$size_name = $item['size_name']; 
			$color_name = $item['color_name']; 
			$details = $item['details']; 
			$warehouse = $item['warehouse']; 
			$flat_house_no = $item['flat_house_no']; 
			$building_name = $item['building_name']; 
			$address = $item['address']; 
			$location = $item['location']; 
			$state = $item['state']; 
			$city = $item['city']; 
			$pincode = $item['pincode']; 
			$landmark = $item['landmark']; 
			$alternate_phone = $item['alternate_phone']; 
			$added_date = $item['added_date']; 	
			$student_name = $item['student_name']; 	
		  }
		  else{		 
			$order_id  		= $row['order_id'];
			$order_type  	= $row['order_type'];
			$vendor_id  	= $row['vendor_id'];
			$order_slot  	= $row['order_slot'];
			$order_number   = $row['order_number']; 
			$invoice_no  	= $row['invoice_no'];
			$created_at  	= $row['created_at'];	
			$school_name    = $row['school_name'];
			$grade_name 	= $row['grade_name'];
			$board_name  	= $row['board_name'];
			//$school_city  	= '';
			$product_name  	= $row['product_name'];		
			//$category_name  = '';
			//$size_name  = '';
			//$color_name  = '';
			$details  = '';
			
			$student_name   = $row['s_name'] . ' ' . $row['f_name'] . ' ' . $row['m_name'];
				
			$product_id     = $row['product_id'];				
			$school_id      = $row['school_id'];				
			$category_id    = $row['product_parent_cid'];
			$size_id        = $row['size_id'];
			$category_name  = $this->common_model->get_category_name($category_id);
			$size_name      = $this->common_model->get_size_name_by_id($size_id);
			$color_name     = $this->common_model->get_color_name_by_product($product_id);			
			$school_city    = $this->common_model->get_school_city($school_id);			
  	   
  	        date_default_timezone_set('Asia/Kolkata');
            $added_date = date('Y-m-d H:i');
		    $details='';			
				  
		    $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
            
            $flat_house_no = $shipp_data['flat_house_no'];
            $building_name = $shipp_data['building_name'];
            $address = $shipp_data['address'];
            $location = $shipp_data['location'];
            $state=get_state_name($shipp_data['state']);
            $city=get_city_name($shipp_data['city']); 
            $pincode = $shipp_data['pincode'];
            $landmark = $shipp_data['landmark'];
            $alternate_phone = $shipp_data['alternate_phone'];
         
         
            $order_shipp = $this->db->query("SELECT flat_house_no,building_name,location,address,state,city,pincode,landmark,alternate_phone FROM `order_shipping` WHERE order_id = '$order_id' limit 1");
            $shipp_data = $order_shipp->row_array();
           
			$warehouse_id  	= $row['warehouse_id'];	 
            
            $query_ware = $this->db->query("SELECT address FROM vendor_shipping_details WHERE id='$warehouse_id'");
            $ware = $query_ware->row_array();
            $warehouse =  $ware['address'];
            
            
		
           $package_details=array();			
		   if($order_type=='bookset'){
		      $packages  = $this->common_model->get_consolidated_order_packages($order_id);	
			   foreach($packages as $package): 
				 $package_details[] = $package->package_name.' ('.$package->total_products.')'; 
			   endforeach;
			  $details=implode(", ", $package_details);					   
		   }		   
		   else{		   
			   if($category_id=='22'){
				//Uniform: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
			   }		   
			   elseif($category_id=='38'){
				//Shoes: Product Name, Size and Color
				$details .='Product Name-'.$product_name;
				$details .=', Size-'.$size_name;
				$details .=', Color-'.$color_name;
			   }	   
			   else{
				$details .='Product Name-'.$product_name;
			   } 
		   }
	   
           $data_slot = array(
                "order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "student_name" => $student_name,
            ); 
            $insert = $this->db->insert('consolidated_reports', $data_slot);  		  
		  }		  	
		  
		    $resultpost[] = array(
				"order_id" => $order_id,
				"order_type" => $order_type,
                "vendor_id" => $vendor_id,
                "order_slot" => $order_slot,
                "order_number" => $order_number,
                "invoice_no" => $invoice_no,
                "created_at" => $created_at,
                "school_name" => $school_name,
                "grade_name" => $grade_name,
                "board_name" => $board_name,
                "school_city" => $school_city,
                "product_name" => $product_name,
                "category_name" => $category_name,
                "size_name" => $size_name,
                "color_name" => $color_name,
                "details" => $details,
                "warehouse" => $warehouse,
                "flat_house_no" => $flat_house_no,
                "building_name" => $building_name,
                "address" => $address,
                "location" => $location,
                "state" => $state,
                "city" => $city,
                "pincode" => $pincode,
                "landmark" => $landmark,
                "alternate_phone" => $alternate_phone,
                "added_date" => $added_date,
                "username" => $row['username'],
                "phone_number" => $row['phone_number'],
                "total_weight" => $row['total_weight'],
                "student_name" => $student_name,
                "price_total" => price_format_decimal($row['price_total']-$row['price_shipping']),
            );
		 }
		}
	  return $resultpost;
  	}
    
    
   
	
public function get_export_order_vendor_customer_cn($user_id,$filter_data){        
    $resultdata = array();
    $keyword_filter="";

    if(isset($filter_data['keywords']) && $filter_data['keywords']!="") :
      $keyword=trim($filter_data['keywords']);
      $keyword_filter =" AND (username like '%".$keyword."%'  
      or phone_number like '%".$keyword."%'
      or email like '%".$keyword."%'
      or order_slot like '%".$keyword."%'
      or txn_id like '%".$keyword."%'
      or order_number like '%".$keyword."%'
      or invoice_no like '%".$keyword."%'
      or invoice_cn like '%".$keyword."%'
      or phone_number like '%".$keyword."%')"; 
    endif;	

  
      
	  $query = $this->db->query("SELECT id,order_number,txn_id,username,phone_number,email,order_status,product_id,school_name,slot_no,product_name,order_type,price_shipping,price_subtotal,price_shipping,internet_charges,courier,price_discount,price_total,created_at,username,phone_number,firm_name,board_name,grade_name,warehouse_id,delivered_date,cancelled_date,cancel_type,cancel_amt,cancel_per,cancel_staff_id,refunded_id,refunded_date,invoice_no,invoice_cn,invoice_cn_url FROM orders WHERE vendor_id='$user_id' AND (payment_status = 'payment_received') AND (order_status='cancelled') AND (invoice_cn IS NOT NULL) $keyword_filter ORDER BY id desc LIMIT 2000");
	    if(!empty($query)){   
            foreach ($query->result_array() as $row) {
                $order_type = $row['order_type'];
                $address_id = $row['address_id'];
                $order_id = $row['id'];
                
                if ($order_type == 'individual') {
                    $product_name = $row['product_name'];
                } else {
                    $product_name = $row['school_name'];
                }                
                
                $product_name = str_replace(' ', '-', $product_name);
                $product_name = preg_replace('/[^A-Za-z0-9\-]/', ' ', $product_name);
                $product_name = strtolower(str_replace('-', ' ', $product_name));
                $product_name = ucfirst($product_name);
                      
                $slot_no = $row['order_slot'];                 
                         
                if($row['cancelled_date']!=NULL){
                    $cancelled_date = date("d M Y h:i a", strtotime($row['cancelled_date']));
                }
                else{
                   $cancelled_date='-';
                } 	                
           
               $created_at = date("d M Y h:i a", strtotime($row['created_at']));           
					                
                $resultdata[]     = array(
                    "id" => $row['id'],
                    "address_id" => $address_id,
                    "order_slot_no" => $slot_no,
                    "buyer_id" => $row['buyer_id'],
                    "order_type" => ucfirst($row['order_type']),
                    "order_number" => $row['order_number'],
                    "username" => $row['username'],
                    "invoice_no" => $row['invoice_no'],
                    "slot_no" => $row['order_slot'],
                    "courier" => $row['courier'],
                    "school_name" => $row['school_name'],
                    "grade_name" => $row['grade_name'],
                    "board_name" => $row['board_name'],
                    "price_total" => $row['price_total'],
                    "order_status" => $row['order_status'],
                    "payment_id" => $row['txn_id'],
                    "txn_id" => $row['txn_id'],
                    "firm_name" => $row['firm_name'],
                    "username" => $row['username'],
                    "phone_number" => $row['phone_number'],
                    "email" => $row['email'], 
                    "created_at" => $created_at,
                    "product_name" => $product_name,
                    "cancelled_date"  => $cancelled_date,
                    "invoice_cn" => ($row['invoice_cn']!=NULL?$row['invoice_cn']:'Not Generated'),
                    "invoice_url" => $row['invoice_cn_url'],
                    "price_shipping" => $row['price_shipping'],
                );
            }
        }
        
	  return  $resultdata;
    }	
      

  public function get_received_payments_report($start_end_date,$vendor_id){ 
    $resultpost = array();
    $date_filter="";
       
    if($start_end_date!=""):
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(vp.payment_date) BETWEEN '$from' AND '$to')";
    endif; 
    
    $orders = $this->db->query("SELECT vp.`payment_date`,vp.`utr_no`,SUM(vp.paid_amount) as payment_made FROM `vendor_payments` as vp INNER JOIN orders on vp.order_id=orders.id WHERE (vp.vendor_id= '$vendor_id') AND orders.payment_status = 'payment_received' AND vp.utr_no IS NOT NULL $date_filter GROUP BY vp.utr_no ORDER BY vp.id desc");

    
		$orders_count = $orders->num_rows();
		if($orders_count >0){
		foreach ($orders->result_array() as $order) {
    	$payment_date=date('d-m-Y', strtotime($order['payment_date']));
		$resultpost[]=array(
            'payment_date'  =>  $order['payment_date'],
            'utr_no' 		=>  $order['utr_no'],
            'payment_made'  =>  $order['payment_made']    
          );
		 }
		}
		else{
		   $resultpost = array();
		}
		return $resultpost;
	}
  	   
    public function get_pending_payments_report($start_end_date,$vendor_id){ 
    $this->load->model('account_model');    
    $resultpost = array();
    $date_filter="";
       
    if($start_end_date!=""):
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(orders.created_at) BETWEEN '$from' AND '$to')";
    endif; 
 
    $orders = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id WHERE (orders.vendor_id= '$vendor_id') AND orders.payment_status = 'payment_received' AND orders.is_settled=0 $date_filter GROUP BY orders.id ORDER BY orders.id desc");
    
		$orders_count = $orders->num_rows();
		if($orders_count >0){
		foreach ($orders->result_array() as $order) {
    		$total_price_excl = 0;
			$price_total_wsh = 0;
		    $net_amount = 0;
		 	$order_id    = $order['id'];
		    $total_price_excl = $order['total_price_excl'];	
		    

			$order_vpay = $this->db->query("SELECT GROUP_CONCAT(paid_amount ORDER BY id ASC) as payment_made,GROUP_CONCAT(payment_date ORDER BY id ASC) as payment_date,GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per,GROUP_CONCAT(utr_no ORDER BY id ASC) as utr_no, GROUP_CONCAT(advise_no ORDER BY id ASC) as advise_no, GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per FROM `vendor_payments` WHERE `order_id`='$order_id' GROUP BY order_id order by id asc");
			$vpay=$order_vpay->row_array();			
				$vendor          = $order['company_name'];
				$order_number    = $order['order_number'];
				$invoice_no    	 = $order['invoice_no'];
				$price_subtotal  = $order['price_subtotal'];
				$price_shipping  = $order['price_shipping'];
				$price_discount  = $order['price_discount'];
				$price_total     = $order['price_total']-$price_shipping;
				$created_at    	 = $order['created_at'];
				$processing_date = $order['processing_date'];
				$shipping_date   = $order['shipping_date'];
				$delivered_date  = $order['delivered_date'];			
				$dispatched_date  = $order['dispatched_date'];
				$price_total_wsh=$price_total;					
				$tds = $order['tds'];
				$tcs = $order['tcs'];				
				$commision_amount_final=$order['commision_amt'];				
				$net_amount=$order['net_payable'];				
				$order_date= date('d-m-Y H:i', strtotime($created_at));
				$order_date_ago=days_left($order_date);
				
				if($dispatched_date!='' || $dispatched_date != null){
				$dispatched_date= date('d-m-Y H:i', strtotime($dispatched_date));
				$dispatched_date_ago=days_left($dispatched_date);
				}
				else{
				   $dispatched_date=$dispatched_date_ago='-';
				}
				
				
				if($delivered_date!='' || $delivered_date != null){
				$delivered_date= date('d-m-Y H:i', strtotime($delivered_date));
				$delivered_date_ago=days_left($delivered_date);
				}
				else{
				   $delivered_date=$delivered_date_ago='-';
				}
				
			$paid_amount=0;
			
			$pamount_query=$this->account_model->get_paid_amount_by_order($order_id);	
			if($pamount_query->num_rows()>0):
			$gpaid=$pamount_query->row();
			$paid_amount=$gpaid->paid_amount;
			endif;					
			
			if($vpay['utr_no'] !='' || $vpay['utr_no'] != null)
			{ 
			    $utr_no = $vpay['utr_no']; 
			}else{
			    $utr_no = '-';
			}
			if($vpay['payment_made'] !='' || $vpay['payment_made'] != null)
			{ 
			    $payment_made = $vpay['payment_made']; 
			}else{
			    $payment_made = '-';
			}
			if($vpay['payment_date'] !='' || $vpay['payment_date'] != null)
			{ 
			    $payment_date = $vpay['payment_date']; 
			}else{
			    $payment_date = '-';
			}
			if($vpay['payment_per'] !='' || $vpay['payment_per'] != null)
			{ 
			    $payment_per = $vpay['payment_per']; 
			}else{
			    $payment_per = '-';
			}
			if($vpay['advise_no'] !='' || $vpay['advise_no'] != null)
			{ 
			    $advise_no = $vpay['advise_no']; 
			}else{
			    $advise_no = '-';
			}
			
			
	     	$final_net_amt = price_format_decimal($net_amount - $paid_amount);
			$balance_amt=($final_net_amt<0 ? '0.00':$final_net_amt);
				
			$resultpost[]= array(
                'order_id' => $order_id,
                'vendor' => $vendor,
                'order_number' => $order_number,
                'invoice_no' => $invoice_no,
                'invoice_amt' => price_format_decimal($price_total),
                'tds' => price_format_decimal($tds),
                'tcs' => price_format_decimal($tcs),
                'commision_amount' => price_format_decimal($commision_amount_final),
                'price_shipping' => price_format_decimal($price_shipping),
                'net_amount' => price_format_decimal($net_amount),
                'order_date' => $order_date,
                'order_date_ago' => $order_date_ago,
                'dispatched_date' => $dispatched_date,
                'dispatched_date_ago' => $dispatched_date_ago,
                'delivered_date' => $delivered_date,
                'delivered_date_ago' => $delivered_date_ago,
                'utr_no' =>  $utr_no,
                'payment_made' =>  $payment_made,
                'payment_date' =>  $payment_date,
                'payment_per' =>  $payment_per,
                'paid_amount' => $paid_amount,
                'net_amount_final' =>  $order['net_amount'],
                'advise_no' =>  $advise_no,
                'vendor_id' =>  $order['vendor_id'],
                'balance_amt' => $balance_amt,
            );
          
          
		 }
		}
		else{
		   $resultpost = array();
		}
		return $resultpost;
	}  
	
	
 public function get_completed_payments_report($start_end_date,$vendor_id){    $this->load->model('account_model');    
    $resultpost = array();
    $date_filter="";
       
    if($start_end_date!=""):
       $from =  date('Y-m-d',strtotime($start_end_date['0'])); 
       $to =  date('Y-m-d',strtotime($start_end_date['1'])); 
       $date_filter=" AND (DATE(orders.created_at) BETWEEN '$from' AND '$to')";
    endif; 
 
	$orders = $this->db->query("SELECT GROUP_CONCAT(DISTINCT vendor_payments.advise_no) as advise_no, SUM(DISTINCT vendor_payments.payment_per) as payment_per,orders.id,  orders.vendor_id,orders.paid_amount,orders.net_amount, orders.firm_name as company_name,orders.order_number,orders.invoice_no,orders.price_subtotal,orders.price_shipping,orders.price_discount,orders.price_total,orders.created_at,orders.processing_date,orders.shipping_date,orders.delivered_date,orders.dispatched_date,orders.total_price_excl, orders.tds_gst, orders.tds, orders.tcs_gst, orders.tcs, orders.tax_gst, orders.commision_amt, orders.net_payable FROM orders LEFT JOIN vendor_payments ON orders.id=vendor_payments.order_id WHERE (orders.vendor_id= '$vendor_id') and orders.payment_status = 'payment_received' AND orders.is_settled=1 $date_filter GROUP BY orders.id ORDER BY orders.id desc");
    
		$orders_count = $orders->num_rows();
		if($orders_count >0){
		foreach ($orders->result_array() as $order) {
    		$total_price_excl = 0;
			$price_total_wsh = 0;
		    $net_amount = 0;
		 	$order_id    = $order['id'];
		    $total_price_excl = $order['total_price_excl'];	
		
			$order_vpay = $this->db->query("SELECT GROUP_CONCAT(paid_amount ORDER BY id ASC) as payment_made,GROUP_CONCAT(payment_date ORDER BY id ASC) as payment_date,GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per,GROUP_CONCAT(utr_no ORDER BY id ASC) as utr_no, GROUP_CONCAT(advise_no ORDER BY id ASC) as advise_no, GROUP_CONCAT(payment_per ORDER BY id ASC) as payment_per FROM `vendor_payments` WHERE `order_id`='$order_id' GROUP BY order_id order by id asc");
			$vpay=$order_vpay->row_array();			
				$vendor          = $order['company_name'];
				$order_number    = $order['order_number'];
				$invoice_no    	 = $order['invoice_no'];
				$price_subtotal  = $order['price_subtotal'];
				$price_shipping  = $order['price_shipping'];
				$price_discount  = $order['price_discount'];
				$price_total     = $order['price_total']-$price_shipping;
				$created_at    	 = $order['created_at'];
				$processing_date = $order['processing_date'];
				$shipping_date   = $order['shipping_date'];
				$delivered_date  = $order['delivered_date'];			
				$dispatched_date  = $order['dispatched_date'];
				$price_total_wsh=$price_total;					
				$tds = $order['tds'];
				$tcs = $order['tcs'];				
				$commision_amount_final=$order['commision_amt'];				
				$net_amount=$order['net_payable'];				
				$order_date= date('d-m-Y H:i', strtotime($created_at));
				$order_date_ago=days_left($order_date);
				
				if($dispatched_date!=''){
				$dispatched_date= date('d-m-Y H:i', strtotime($dispatched_date));
				$dispatched_date_ago=days_left($dispatched_date);
				}
				else{
				   $dispatched_date=$dispatched_date_ago='-';
				}
				
				
				if($delivered_date!=''){
				$delivered_date= date('d-m-Y H:i', strtotime($delivered_date));
				$delivered_date_ago=days_left($delivered_date);
				}
				else{
				   $delivered_date=$delivered_date_ago='-';
				}
				
			$paid_amount=0;
			
			$pamount_query=$this->account_model->get_paid_amount_by_order($order_id);	
			if($pamount_query->num_rows()>0):
			$gpaid=$pamount_query->row();
			$paid_amount=$gpaid->paid_amount;
			endif;						
			
			if($vpay['utr_no'] !='' || $vpay['utr_no'] != null)
			{ 
			    $utr_no = $vpay['utr_no']; 
			}else{
			    $utr_no = '-';
			}
			if($vpay['payment_made'] !='' || $vpay['payment_made'] != null)
			{ 
			    $payment_made = $vpay['payment_made']; 
			}else{
			    $payment_made = '-';
			}
			if($vpay['payment_date'] !='' || $vpay['payment_date'] != null)
			{ 
			    $payment_date = $vpay['payment_date']; 
			}else{
			    $payment_date = '-';
			}
			if($vpay['payment_per'] !='' || $vpay['payment_per'] != null)
			{ 
			    $payment_per = $vpay['payment_per']; 
			}else{
			    $payment_per = '-';
			}
			if($vpay['advise_no'] !='' || $vpay['advise_no'] != null)
			{ 
			    $advise_no = $vpay['advise_no']; 
			}else{
			    $advise_no = '-';
			}
			
			
	     	$final_net_amt = price_format_decimal($net_amount - $paid_amount);
			$balance_amt=($final_net_amt<0 ? '0.00':$final_net_amt);
				
			$resultpost[]= array(
                'order_id' => $order_id,
                'vendor' => $vendor,
                'order_number' => $order_number,
                'invoice_no' => $invoice_no,
                'invoice_amt' => price_format_decimal($price_total),
                'tds' => price_format_decimal($tds),
                'tcs' => price_format_decimal($tcs),
                'commision_amount' => price_format_decimal($commision_amount_final),
                'price_shipping' => price_format_decimal($price_shipping),
                'net_amount' => price_format_decimal($net_amount),
                'order_date' => $order_date,
                'order_date_ago' => $order_date_ago,
                'dispatched_date' => $dispatched_date,
                'dispatched_date_ago' => $dispatched_date_ago,
                'delivered_date' => $delivered_date,
                'delivered_date_ago' => $delivered_date_ago,
                'utr_no' =>  $vpay['utr_no'],
                'payment_made' =>  $vpay['payment_made'],
                'payment_date' =>  $vpay['payment_date'],
                'payment_per' =>  $vpay['payment_per'],
                'paid_amount' => $paid_amount,
                'net_amount_final' =>  $order['net_amount'],
                'advise_no' =>  $vpay['advise_no'],
                'vendor_id' =>  $order['vendor_id'],
                'balance_amt' =>  $balance_amt,
            );
          
		 }
		}
		else{
		   $resultpost = array();
		}
		return $resultpost;
	} 
    
}