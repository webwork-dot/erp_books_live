<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['es_server'] = 'https://search-mw-domain01-sr5e5n4szx6xtfbqbujw7engbe.us-east-1.es.amazonaws.com';
$config['index'] = '';