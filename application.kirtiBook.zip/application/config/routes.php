<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
  | -------------------------------------------------------------------------
  | URI ROUTING
  | -------------------------------------------------------------------------
  | This file lets you re-map URI requests to specific controller functions.
  |
  | Typically there is a one-to-one relationship between a URL string
  | and its corresponding controller class/method. The segments in a
  | URL normally follow this pattern:
  |
  |	example.com/class/method/id/
  |
  | In some instances, however, you may want to remap this relationship
  | so that a different class/function is called than the one
  | corresponding to the URL.
  |
  | Please see the user guide for complete details:
  |
  |	http://codeigniter.com/user_guide/general/routing.html
  |
  | -------------------------------------------------------------------------
  | RESERVED ROUTES
  | -------------------------------------------------------------------------
  |
  | There are three reserved routes:
  |
  |	$route['default_controller'] = 'welcome';
  |
  | This route indicates which controller class should be loaded if the
  | URI contains no data. In the above example, the "welcome" class
  | would be loaded.
  |
  |	$route['404_override'] = 'errors/page_missing';
  |
  | This route will tell the Router which controller/method to use if those
  | provided in the URL cannot be matched to a valid route.
  |
  |	$route['translate_uri_dashes'] = FALSE;
  |
  | This is not exactly a route, but allows you to automatically route
  | controller and method names that contain dashes. '-' isn't a valid
  | class or method name character, so it requires translation.
  | When you set this option to TRUE, it will replace ALL dashes in the
  | controller and method URI segments.
  |
  | Examples:	my-controller/index	-> my_controller/index
  |		my-controller/my-method	-> my_controller/my_method
 */ 
$route['default_controller'] = 'main';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['Pdf_controller/generate_shipping_label2'] = 'pdf_controller/generate_shipping_label2';

$route['excel/generate_consolidate_report_by_slot'] = 'excel_controller/generate_consolidate_report_by_slot';
$route['excel/download_consolidate_report'] = 'excel_controller/export_consolidate_report_by_slot';
$route['excel/test_export_consolidate_report_by_slot'] = 'excel_controller/test_export_consolidate_report_by_slot';

$route['excel/check_gst_report'] = 'excel_controller/check_gst_report';
$route['excel/export_gst_report'] = 'excel_controller/export_gst_report';

$route['excel/generate_consolidate_report_by_status'] = 'excel_controller/generate_consolidate_by_status';
$route['excel/download_consolidate_report_status'] = 'excel_controller/export_consolidate_report_by_status';


$route['excel/export_consolidate_report_by_vendor'] = 'excel_controller/export_consolidate_report_by_vendor';



$route['excel/generate_complaints_reports'] = 'excel_controller/generate_complaints_reports';
$route['excel/export_complaints_reports'] = 'excel_controller/export_complaints_reports';
$route['excel/generate_consolidate_report_by_all_orders'] = 'excel_controller/generate_consolidate_report_by_all_orders';
$route['excel/generate_consolidate_report_by_students_orders'] = 'excel_controller/generate_consolidate_report_by_students_orders';
$route['excel/generate_consolidate_report_by_school_orders'] = 'excel_controller/generate_consolidate_report_by_school_orders';
$route['excel/generate_consolidate_report_by_individual_orders'] = 'excel_controller/generate_consolidate_report_by_individual_orders';
$route['excel/download_consolidate_report_all_orders'] = 'excel_controller/download_consolidate_report_all_orders';
$route['excel/download_consolidate_report_students_orders'] = 'excel_controller/download_consolidate_report_students_orders';
$route['excel/download_consolidate_report_by_school_orders'] = 'excel_controller/download_consolidate_report_by_school_orders';
$route['excel/download_consolidate_report_by_individual_orders'] = 'excel_controller/download_consolidate_report_by_individual_orders';
$route['excel/download_customer_report'] = 'excel_controller/download_customer_report';

$route['excel/generate_credit_note_reports'] = 'excel_controller/generate_credit_note_reports';
$route['excel/download_credit_note_reports'] = 'excel_controller/download_credit_note_reports';


$route['excel/check_received_payments_report'] = 'excel_controller/check_received_payments_report';
$route['excel/export_received_payments_report'] = 'excel_controller/export_received_payments_report';

$route['excel/check_pending_payments_report'] = 'excel_controller/check_pending_payments_report';
$route['excel/export_pending_payments_report'] = 'excel_controller/export_pending_payments_report';

$route['excel/check_completed_payments_report'] = 'excel_controller/check_completed_payments_report';
$route['excel/export_completed_payments_report'] = 'excel_controller/export_completed_payments_report';


